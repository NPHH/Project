const express = require('express');
const client = require('prom-client');
const app = express();
const port = 8081;

// Enable default metrics collection
const collectDefaultMetrics = client.collectDefaultMetrics;
collectDefaultMetrics({ prefix: 'node_app_' });

// Custom metric for simulated errors
const errorCounter = new client.Counter({
  name: 'node_app_simulated_errors_total',
  help: 'Total number of simulated errors'
});

// Custom metric for response time
const httpRequestDurationSeconds = new client.Histogram({
  name: 'node_app_http_request_duration_seconds',
  help: 'Duration of HTTP requests in seconds',
  labelNames: ['method', 'route', 'status_code'],
  buckets: [0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10]
});

// Middleware to track response time
app.use((req, res, next) => {
  if (req.path === '/metrics') {
    return next();
  }
  const end = httpRequestDurationSeconds.startTimer();
  res.on('finish', () => {
    end({ route: req.path, status_code: res.statusCode, method: req.method });
  });
  next();
});

app.get('/', (req, res) => {
  res.send('<h1>Simulated App for Monitoring</h1><p>Visit <a href="/metrics">/metrics</a> to see Prometheus metrics.</p><p>Visit <a href="/simulate-error">/simulate-error</a> to increment the error counter.</p><p>Visit <a href="/slow">/slow</a> to test response time latency.</p>');
});

app.get('/slow', async (req, res) => {
  const delay = Math.floor(Math.random() * 2000) + 1000; // 1s to 3s delay
  await new Promise(resolve => setTimeout(resolve, delay));
  res.send(`Slow response simulated! Took ${delay}ms`);
});

app.get('/simulate-error', (req, res) => {
  errorCounter.inc();
  console.log('Simulated an error! Counter incremented.');
  res.status(500).send('Simulated Error Occurred! This will trigger the Grafana alert if configured.');
});

// Metrics endpoint for Prometheus
app.get('/metrics', async (req, res) => {
  res.set('Content-Type', client.register.contentType);
  res.end(await client.register.metrics());
});

app.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});
