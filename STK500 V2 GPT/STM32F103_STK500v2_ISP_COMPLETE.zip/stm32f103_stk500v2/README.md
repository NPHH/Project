# STM32F103C8 STK500v2 ISP – completed revision

Bản này hoàn thiện firmware STK500v2 ISP qua USB CDC cho STM32F103C8.

## Đã bổ sung

- SPI phần cứng cho SCK từ khoảng 250 kHz trở lên.
- Bit-bang SCK tự động cho 125 kHz xuống khoảng 2 kHz, dùng DWT cycle counter.
- Polling Ready/Busy bằng opcode `F0 00 00 00`.
- Value polling cho Flash và EEPROM theo mode/opcode/poll value AVR Studio gửi.
- Hàng đợi USB TX 8 frame, không chặn trong bộ xử lý giao thức.
- Phát hiện tràn RX ring buffer và tự đồng bộ lại parser.
- Payload tăng lên 550 byte, đủ page 256/512 byte cùng header.
- Extended address cho AVR Flash lớn.

## CubeMX

- STM32F103C8Tx, SYSCLK 72 MHz, USB 48 MHz.
- USB Device FS / CDC.
- SPI1 Master full duplex, CPOL Low, CPHA 1 Edge, software NSS.
- PA5 SCK, PA6 MISO, PA7 MOSI; PB0 RESET active-low.
- Gọi `STK500V2_Init()` sau khi SPI và USB được init.
- Gọi `STK500V2_Task()` liên tục trong `while(1)`.
- Trong `CDC_Receive_FS()`, gọi `STK500V2_RxBytes(Buf,*Len)` rồi arm lại OUT endpoint.

## Lưu ý điện áp

STM32F103 chạy 3.3 V. Khi target AVR chạy 5 V, dùng buffer/chuyển mức phù hợp, đặc biệt đường MISO đi vào STM32. Nối chung GND và không cấp hai nguồn ngược nhau.

## Phạm vi

Tương thích giao thức STK500v2 cho AVR ISP/SPI. Không hỗ trợ HVPP, HVSP, TPI, PDI hoặc UPDI vì các giao diện đó cần phần cứng/giao thức khác.

## Kiểm thử đề nghị

- ATmega8/16/32
- ATmega48/88/168/328P
- ATmega128/2560 để kiểm tra extended address
- ATtiny25/45/85 khi SPIEN và RESET fuse còn hợp lệ

Kiểm tra lần lượt: Sign On, Read Signature, Erase, Write/Verify Flash, EEPROM, Fuse read và Lock read.
