# STM32F103C8 STK500v2 ISP – completed revision

Bản này hoàn thiện firmware STK500v2 ISP qua USB CDC cho STM32F103C8.

## Đã bổ sung

- SPI phần cứng cho SCK từ khoảng 250 kHz trở lên.
- Bit-bang SCK tự động cho 125 kHz xuống khoảng 2 kHz, dùng DWT cycle counter.
- Polling Ready/Busy bằng opcode `F0 00 00 00`.
- Value polling cho Flash và EEPROM theo mode/opcode/poll value AVR Studio gửi.
- Hàng đợi USB TX 8 frame, không chặn trong bộ xử lý giao thức.
- Phát hiện tràn RX ring buffer và tự đồng bộ lại parser.
- Payload tăng lên 550 byte, đủ page 256/512 byte cùng header.
- Extended address cho AVR Flash lớn.

## CubeMX

- STM32F103C8Tx, SYSCLK 72 MHz, USB 48 MHz.
- USB Device FS / CDC.
- SPI1 Master full duplex, CPOL Low, CPHA 1 Edge, software NSS.
- PA5 SCK, PA6 MISO, PA7 MOSI; PB0 RESET active-low.
- Gọi `STK500V2_Init()` sau khi SPI và USB được init.
- Gọi `STK500V2_Task()` liên tục trong `while(1)`.
- Trong `CDC_Receive_FS()`, gọi `STK500V2_RxBytes(Buf,*Len)` rồi arm lại OUT endpoint.

## Lưu ý điện áp

STM32F103 chạy 3.3 V. Khi target AVR chạy 5 V, dùng buffer/chuyển mức phù hợp, đặc biệt đường MISO đi vào STM32. Nối chung GND và không cấp hai nguồn ngược nhau.

## Phạm vi

Tương thích giao thức STK500v2 cho AVR ISP/SPI. Không hỗ trợ HVPP, HVSP, TPI, PDI hoặc UPDI vì các giao diện đó cần phần cứng/giao thức khác.

## Kiểm thử đề nghị

- ATmega8/16/32
- ATmega48/88/168/328P
- ATmega128/2560 để kiểm tra extended address
- ATtiny25/45/85 khi SPIEN và RESET fuse còn hợp lệ

Kiểm tra lần lượt: Sign On, Read Signature, Erase, Write/Verify Flash, EEPROM, Fuse read và Lock read.

# Bổ sung High-Voltage Parallel Programming (HVPP)

Firmware đã thêm nhóm lệnh STK500v2 `CMD_*_PP` từ `0x20` đến `0x2D`: control stack, enter/leave PP, erase, Flash, EEPROM, fuse, lock, signature và OSCCAL.

## Đầu nối HVPP logic của STM32F103C8

| STM32 | Tín hiệu HVPP |
|---|---|
| PB8..PB15 | DATA0..DATA7 |
| PC0 | XA0 |
| PC1 | XA1 |
| PC2 | BS1 |
| PC3 | BS2 |
| PC4 | PAGEL |
| PC5 | XTAL1 |
| PB3 | /WR |
| PB4 | /OE |
| PB5 | RDY/BSY |
| PB6 | VTARGET_EN |
| PB7 | VPP12_EN |

PB3/PB4 là chân JTAG, firmware gọi `HAL_AFIO_REMAP_SWJ_NOJTAG()` để giữ SWD nhưng tắt JTAG.

## Phần cứng bắt buộc

- `VPP12_EN` chỉ điều khiển MOSFET/transistor hoặc high-side switch để đưa 11.5–12.5 V vào RESET của AVR. Không nối 12 V trực tiếp vào STM32.
- `VTARGET_EN` điều khiển nguồn 5 V cho target; cần tắt/bật được theo trình tự HVPP.
- DATA0..7 phải đi qua buffer hai chiều 3.3/5 V có chân OE, ví dụ ghép transceiver phù hợp. Không dùng mạch chia áp thụ động cho bus hai chiều.
- Các đường điều khiển 5 V nên qua buffer 3.3→5 V. RDY/BSY về STM32 cần giới hạn mức phù hợp.
- Mỗi họ AVR cần adapter socket ánh xạ chân vật lý của chip sang các tín hiệu logic HVPP trên bảng này. Firmware không thể tự thay đổi dây nối vật lý.

## CubeMX GPIO

- PB8..PB15: Output push-pull ban đầu, firmware đổi Input khi đọc.
- PC0..PC5, PB3, PB4, PB6, PB7: Output push-pull.
- PB5: Input không pull hoặc pull phù hợp với buffer.
- Tất cả output khởi động mức an toàn: `VPP12_EN=0`, `VTARGET_EN=0`, `/WR=1`, `/OE=1`, các tín hiệu còn lại bằng 0.

## Giới hạn quan trọng

`CMD_SET_CONTROL_STACK` được lưu và dùng như cờ khởi tạo, nhưng firmware dùng đầu nối HVPP logic cố định thay vì giải mã ma trận socket nội bộ của STK500 thật. Vì vậy AVR Studio có thể gửi thuật toán PP theo từng chip, còn việc tương thích pinout được giải quyết bằng adapter socket ngoài.

Bản này triển khai thuật toán HVPP cổ điển của megaAVR có bus DATA[7:0], XA0/XA1, BS1/BS2, PAGEL, XTAL1, /WR, /OE và RDY/BSY. Chip ít chân sử dụng HVSP, chip AVR mới dùng UPDI/PDI/TPI không thuộc phần HVPP này.


# HVSP cho ATtiny cổ điển

Firmware bổ sung nhóm lệnh STK500v2 `0x30..0x3C` cho High-Voltage Serial Programming.
Đối tượng chính: ATtiny13A và ATtiny25/45/85, cùng các classic tinyAVR có thuật toán HVSP tương thích.

## Chân HVSP mặc định

| STM32F103C8 | HVSP target |
|---|---|
| PA0 | SDI |
| PA1 | SII |
| PA2 | SDO |
| PA3 | SCI |
| PA4 | điều khiển nguồn target 5 V |
| PA8 | điều khiển switch RESET 12 V |
| GND | GND |

ATtiny25/45/85 DIP-8: PB0=SDI, PB1=SII, PB2=SDO, PB3=SCI, PB5=RESET/VPP.
Phải dùng level shifter 3.3/5 V và switch 12 V ngoài. Không nối 12 V vào STM32.

## Hỗ trợ

- Enter/leave HVSP
- Chip erase
- Read/write Flash
- Read/write EEPROM
- Read/write low/high/extended fuse
- Read/write lock bits
- Read signature và OSCCAL
- Poll SDO ready/busy

## Giới hạn

- Đây là HVSP cho classic tinyAVR. ATtiny 0/1/2-series như ATtiny402/814 dùng UPDI, không dùng HVSP.
- Một số ATtiny có biến thể instruction/address khác; cần đối chiếu datasheet và thử thực tế trước khi dùng trong sản xuất.
- EEPROM page mode không có trên một số ATtiny trong HVSP; firmware tự dùng byte mode khi AVR Studio yêu cầu.
