#include "avr_hvsp.h"
#include "main.h"

#define HVSP_OK             0x00u
#define HVSP_RDY_BSY_TOUT   0x81u

/*
 * Logical HVSP connector (classic tinyAVR, e.g. ATtiny13A/25/45/85):
 *   PA0 -> SDI   (target PB0)
 *   PA1 -> SII   (target PB1)
 *   PA2 <- SDO   (target PB2)
 *   PA3 -> SCI   (target PB3)
 *   PA4 -> VTARGET_EN external 5-V switch
 *   PA8 -> VPP12_EN external 11.5..12.5-V RESET switch
 *
 * Use proper 3.3/5-V level translators. PA8 only controls the external
 * high-voltage switch; never connect 12 V to the STM32.
 */
#define SDI_PORT GPIOA
#define SDI_PIN  GPIO_PIN_0
#define SII_PORT GPIOA
#define SII_PIN  GPIO_PIN_1
#define SDO_PORT GPIOA
#define SDO_PIN  GPIO_PIN_2
#define SCI_PORT GPIOA
#define SCI_PIN  GPIO_PIN_3
#define VTG_PORT GPIOA
#define VTG_PIN  GPIO_PIN_4
#define VPP_PORT GPIOA
#define VPP_PIN  GPIO_PIN_8

static uint8_t in_progmode;

static void delay_us(uint32_t us)
{
    if ((DWT->CTRL & DWT_CTRL_CYCCNTENA_Msk) == 0u) {
        CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
        DWT->CYCCNT = 0u;
        DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
    }
    const uint32_t cycles = (SystemCoreClock / 1000000u) * us;
    const uint32_t start = DWT->CYCCNT;
    while ((DWT->CYCCNT - start) < cycles) {}
}

static void pin(GPIO_TypeDef *port, uint16_t pin_no, uint8_t high)
{
    HAL_GPIO_WritePin(port, pin_no, high ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

static uint8_t sdo(void)
{
    return HAL_GPIO_ReadPin(SDO_PORT, SDO_PIN) == GPIO_PIN_SET ? 1u : 0u;
}

static void pulse_sci(void)
{
    /* Datasheet minimum high/low is 125 ns; 1 us gives generous margin. */
    pin(SCI_PORT, SCI_PIN, 1u); delay_us(1u);
    pin(SCI_PORT, SCI_PIN, 0u); delay_us(1u);
}

/* Shift one HVSP 11-bit data/instruction frame, MSB first. */
static uint8_t transfer(uint8_t data, uint8_t instruction)
{
    uint8_t result = 0u;
    pin(SCI_PORT, SCI_PIN, 0u);
    pin(SDI_PORT, SDI_PIN, 0u);
    pin(SII_PORT, SII_PIN, 0u);
    pulse_sci(); /* start bit */

    for (uint8_t mask = 0x80u; mask != 0u; mask >>= 1) {
        pin(SDI_PORT, SDI_PIN, (data & mask) != 0u);
        pin(SII_PORT, SII_PIN, (instruction & mask) != 0u);
        pin(SCI_PORT, SCI_PIN, 1u);
        delay_us(1u);
        result <<= 1;
        if (sdo()) result |= 1u;
        pin(SCI_PORT, SCI_PIN, 0u);
        delay_us(1u);
    }

    pin(SDI_PORT, SDI_PIN, 0u);
    pin(SII_PORT, SII_PIN, 0u);
    pulse_sci(); /* trailing bit 1 */
    pulse_sci(); /* trailing bit 2 */
    return result;
}

static uint8_t wait_ready(uint8_t timeout_ms)
{
    if (timeout_ms == 0u) return HVSP_OK;
    const uint32_t start = HAL_GetTick();
    do {
        if (sdo()) return HVSP_OK;
    } while ((HAL_GetTick() - start) <= timeout_ms);
    return HVSP_RDY_BSY_TOUT;
}

static void load_command(uint8_t command) { (void)transfer(command, 0x4Cu); }
static void load_addr_low(uint8_t value)  { (void)transfer(value, 0x0Cu); }
static void load_addr_high(uint8_t value) { (void)transfer(value, 0x1Cu); }
static void load_data_low(uint8_t value)  { (void)transfer(value, 0x2Cu); }
static void load_data_high(uint8_t value) { (void)transfer(value, 0x3Cu); }

void AVRHvsp_Init(void)
{
    in_progmode = 0u;
    pin(SDI_PORT, SDI_PIN, 0u);
    pin(SII_PORT, SII_PIN, 0u);
    pin(SCI_PORT, SCI_PIN, 0u);
    pin(VPP_PORT, VPP_PIN, 0u);
    pin(VTG_PORT, VTG_PIN, 0u);
}

bool AVRHvsp_Enter(uint8_t stab_delay_ms, uint8_t cmdexe_delay_ms,
                   uint8_t synch_cycles, uint8_t latch_cycles,
                   uint8_t toggle_vtg, uint8_t poweroff_delay_ms,
                   uint8_t reset_delay_ms, uint8_t reset_delay_10us)
{
    pin(VPP_PORT, VPP_PIN, 0u);
    pin(VTG_PORT, VTG_PIN, 0u);
    pin(SDI_PORT, SDI_PIN, 0u);
    pin(SII_PORT, SII_PIN, 0u);
    pin(SCI_PORT, SCI_PIN, 0u);
    HAL_Delay(stab_delay_ms);

    if (toggle_vtg) HAL_Delay(poweroff_delay_ms);
    pin(VTG_PORT, VTG_PIN, 1u);
    if (reset_delay_ms) HAL_Delay(reset_delay_ms);
    if (reset_delay_10us) delay_us((uint32_t)reset_delay_10us * 10u);
    else delay_us(30u);

    pin(VPP_PORT, VPP_PIN, 1u);
    delay_us(12u); /* hold Prog_enable=000 while RESET high voltage latches */

    /* SDO was held low as Prog_enable[2]; release is physical through the
       unidirectional target-to-programmer level shifter. */
    while (latch_cycles--) pulse_sci();
    while (synch_cycles--) pulse_sci();
    if (cmdexe_delay_ms) HAL_Delay(cmdexe_delay_ms); else delay_us(300u);
    in_progmode = 1u;
    return true;
}

void AVRHvsp_Leave(uint8_t stab_delay_ms, uint8_t reset_delay_ms)
{
    pin(VPP_PORT, VPP_PIN, 0u);
    HAL_Delay(reset_delay_ms);
    pin(VTG_PORT, VTG_PIN, 0u);
    HAL_Delay(stab_delay_ms);
    pin(SDI_PORT, SDI_PIN, 0u);
    pin(SII_PORT, SII_PIN, 0u);
    pin(SCI_PORT, SCI_PIN, 0u);
    in_progmode = 0u;
}

uint8_t AVRHvsp_ChipErase(uint8_t poll_timeout_ms, uint8_t erase_time_ms)
{
    load_command(0x80u);
    (void)transfer(0x00u, 0x64u);
    (void)transfer(0x00u, 0x6Cu);
    if (erase_time_ms) { HAL_Delay(erase_time_ms); return HVSP_OK; }
    return wait_ready(poll_timeout_ms ? poll_timeout_ms : 20u);
}

uint8_t AVRHvsp_ProgramFlash(uint32_t word_address, const uint8_t *data,
                            uint16_t count, uint8_t mode,
                            uint8_t poll_timeout_ms, uint32_t *next_word_address)
{
    uint32_t a = word_address;
    uint16_t i = 0u;
    load_command(0x10u);
    while (i < count) {
        load_addr_low((uint8_t)a);
        load_addr_high((uint8_t)(a >> 8));
        load_data_low(data[i++]);
        (void)transfer(0x00u, 0x7Du); /* latch low byte */
        if (i < count) load_data_high(data[i++]); else load_data_high(0xFFu);
        (void)transfer(0x00u, 0x7Cu); /* latch high byte */
        ++a;
    }
    if ((mode & 0x80u) != 0u || (mode & 0x01u) == 0u) {
        (void)transfer(0x00u, 0x64u);
        (void)transfer(0x00u, 0x6Cu);
        uint8_t st = wait_ready(poll_timeout_ms ? poll_timeout_ms : 20u);
        if (next_word_address) *next_word_address = a;
        return st;
    }
    if (next_word_address) *next_word_address = a;
    return HVSP_OK;
}

uint8_t AVRHvsp_ReadFlash(uint32_t word_address, uint8_t *data,
                         uint16_t count, uint32_t *next_word_address)
{
    uint32_t a = word_address;
    uint16_t i = 0u;
    load_command(0x02u);
    while (i < count) {
        load_addr_low((uint8_t)a);
        load_addr_high((uint8_t)(a >> 8));
        (void)transfer(0x00u, 0x68u);
        data[i++] = transfer(0x00u, 0x6Cu);
        if (i < count) {
            (void)transfer(0x00u, 0x7Au);
            data[i++] = transfer(0x00u, 0x7Eu);
        }
        ++a;
    }
    if (next_word_address) *next_word_address = a;
    return HVSP_OK;
}

uint8_t AVRHvsp_ProgramEeprom(uint32_t byte_address, const uint8_t *data,
                             uint16_t count, uint8_t mode,
                             uint8_t poll_timeout_ms, uint32_t *next_byte_address)
{
    uint32_t a = byte_address;
    load_command(0x11u);
    for (uint16_t i = 0u; i < count; ++i, ++a) {
        load_addr_low((uint8_t)a);
        load_addr_high((uint8_t)(a >> 8));
        load_data_low(data[i]);
        (void)transfer(0x00u, 0x6Du); /* latch EEPROM byte */
        if ((mode & 0x01u) == 0u) {
            (void)transfer(0x00u, 0x64u);
            (void)transfer(0x00u, 0x6Cu);
            uint8_t st = wait_ready(poll_timeout_ms ? poll_timeout_ms : 20u);
            if (st != HVSP_OK) return st;
        }
    }
    if ((mode & 0x01u) != 0u && (mode & 0x80u) != 0u) {
        (void)transfer(0x00u, 0x64u);
        (void)transfer(0x00u, 0x6Cu);
        uint8_t st = wait_ready(poll_timeout_ms ? poll_timeout_ms : 20u);
        if (st != HVSP_OK) return st;
    }
    if (next_byte_address) *next_byte_address = a;
    return HVSP_OK;
}

uint8_t AVRHvsp_ReadEeprom(uint32_t byte_address, uint8_t *data,
                          uint16_t count, uint32_t *next_byte_address)
{
    uint32_t a = byte_address;
    load_command(0x03u);
    for (uint16_t i = 0u; i < count; ++i, ++a) {
        load_addr_low((uint8_t)a);
        load_addr_high((uint8_t)(a >> 8));
        (void)transfer(0x00u, 0x68u);
        data[i] = transfer(0x00u, 0x6Cu);
    }
    if (next_byte_address) *next_byte_address = a;
    return HVSP_OK;
}

uint8_t AVRHvsp_ProgramFuse(uint8_t address, uint8_t value, uint8_t poll_timeout_ms)
{
    load_command(0x40u);
    load_data_low(value);
    if (address == 0u) {
        (void)transfer(0x00u, 0x64u); (void)transfer(0x00u, 0x6Cu);
    } else if (address == 1u) {
        (void)transfer(0x00u, 0x74u); (void)transfer(0x00u, 0x7Cu);
    } else {
        (void)transfer(0x00u, 0x66u); (void)transfer(0x00u, 0x6Eu);
    }
    return wait_ready(poll_timeout_ms ? poll_timeout_ms : 10u);
}

uint8_t AVRHvsp_ReadFuse(uint8_t address)
{
    load_command(0x04u);
    if (address == 0u) { (void)transfer(0x00u,0x68u); return transfer(0x00u,0x6Cu); }
    if (address == 1u) { (void)transfer(0x00u,0x7Au); return transfer(0x00u,0x7Eu); }
    (void)transfer(0x00u,0x6Au); return transfer(0x00u,0x6Eu);
}

uint8_t AVRHvsp_ProgramLock(uint8_t value, uint8_t poll_timeout_ms)
{
    load_command(0x20u);
    load_data_low(value);
    (void)transfer(0x00u,0x64u); (void)transfer(0x00u,0x6Cu);
    return wait_ready(poll_timeout_ms ? poll_timeout_ms : 10u);
}

uint8_t AVRHvsp_ReadLock(void)
{
    load_command(0x04u);
    (void)transfer(0x00u,0x78u);
    return transfer(0x00u,0x7Cu);
}

uint8_t AVRHvsp_ReadSignature(uint8_t address)
{
    load_command(0x08u);
    load_addr_low(address);
    load_addr_high(0u);
    (void)transfer(0x00u,0x68u);
    return transfer(0x00u,0x6Cu);
}

uint8_t AVRHvsp_ReadOscCal(uint8_t address)
{
    load_command(0x08u);
    load_addr_low(address);
    load_addr_high(0u);
    (void)transfer(0x00u,0x78u);
    return transfer(0x00u,0x7Cu);
}
