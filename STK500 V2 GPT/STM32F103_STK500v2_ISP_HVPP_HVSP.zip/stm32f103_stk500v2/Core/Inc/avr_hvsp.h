#ifndef AVR_HVSP_H
#define AVR_HVSP_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

void AVRHvsp_Init(void);
bool AVRHvsp_Enter(uint8_t stab_delay_ms,
                   uint8_t cmdexe_delay_ms,
                   uint8_t synch_cycles,
                   uint8_t latch_cycles,
                   uint8_t toggle_vtg,
                   uint8_t poweroff_delay_ms,
                   uint8_t reset_delay_ms,
                   uint8_t reset_delay_10us);
void AVRHvsp_Leave(uint8_t stab_delay_ms, uint8_t reset_delay_ms);
uint8_t AVRHvsp_ChipErase(uint8_t poll_timeout_ms, uint8_t erase_time_ms);
uint8_t AVRHvsp_ProgramFlash(uint32_t word_address, const uint8_t *data,
                            uint16_t count, uint8_t mode,
                            uint8_t poll_timeout_ms, uint32_t *next_word_address);
uint8_t AVRHvsp_ReadFlash(uint32_t word_address, uint8_t *data,
                         uint16_t count, uint32_t *next_word_address);
uint8_t AVRHvsp_ProgramEeprom(uint32_t byte_address, const uint8_t *data,
                             uint16_t count, uint8_t mode,
                             uint8_t poll_timeout_ms, uint32_t *next_byte_address);
uint8_t AVRHvsp_ReadEeprom(uint32_t byte_address, uint8_t *data,
                          uint16_t count, uint32_t *next_byte_address);
uint8_t AVRHvsp_ProgramFuse(uint8_t address, uint8_t value, uint8_t poll_timeout_ms);
uint8_t AVRHvsp_ReadFuse(uint8_t address);
uint8_t AVRHvsp_ProgramLock(uint8_t value, uint8_t poll_timeout_ms);
uint8_t AVRHvsp_ReadLock(void);
uint8_t AVRHvsp_ReadSignature(uint8_t address);
uint8_t AVRHvsp_ReadOscCal(uint8_t address);

#ifdef __cplusplus
}
#endif
#endif
