# STM32F103C8 STK500v2 ISP Programmer

Firmware lớp ứng dụng cho mạch nạp AVR dùng STM32F103C8, giao tiếp máy tính bằng USB CDC (COM ảo) và giao tiếp target AVR bằng ISP/SPI.

## Phạm vi

Hỗ trợ các lệnh STK500v2 ISP chính:

- Sign-on, get/set parameter, load address
- Enter/leave programming mode
- Chip erase
- Read/write Flash
- Read/write EEPROM
- Read/write fuse và lock bits
- Read signature, calibration byte
- SPI multi

Không hỗ trợ:

- High-voltage parallel programming (HVPP)
- High-voltage serial programming (HVSP)
- JTAG, PDI, TPI hoặc UPDI
- Điều chỉnh nguồn VTarget thật bằng DAC

Vì vậy đây là programmer **STK500v2 ISP**, không phải bản sao toàn bộ phần cứng STK500.

## Phần cứng mặc định

| STM32F103 | AVR ISP |
|---|---|
| PA5 | SCK |
| PA6 | MISO |
| PA7 | MOSI |
| PB0 | RESET, active-low |
| GND | GND |

Nguồn target nên cấp riêng đúng điện áp của AVR. Nếu target chạy 5 V, cần bảo đảm chân MISO vào STM32 chịu được mức điện áp phù hợp; nên dùng mạch chuyển mức logic hai chiều hoặc buffer 3.3/5 V đúng chuẩn.

USB:

- PA11 = USB D-
- PA12 = USB D+
- Blue Pill thường cần điện trở kéo lên D+ 1.5 kΩ đúng giá trị.

## Tạo project CubeMX

1. MCU: STM32F103C8Tx.
2. Clock: HSE 8 MHz, SYSCLK 72 MHz, USB clock 48 MHz.
3. USB Device FS: Device Only.
4. Middleware USB_DEVICE: Communication Device Class (CDC).
5. SPI1:
   - Master
   - Full Duplex
   - 8-bit
   - CPOL Low
   - CPHA 1 Edge
   - NSS Software
   - MSB first
   - Prescaler 256 lúc khởi động
6. PB0: GPIO Output, initial level High.
7. Generate code cho STM32CubeIDE.

Sau đó chép các file trong `Core/Inc` và `Core/Src` vào project, rồi áp dụng hai file patch mẫu.

## Thiết lập AVR Studio / Microchip Studio

- Chọn tool STK500.
- Chọn đúng COM của USB CDC.
- Baud rate logic là 115200, mặc dù USB CDC không phụ thuộc tốc độ UART vật lý.
- Chọn interface ISP.
- Giảm ISP clock nếu AVR target đang chạy clock thấp.

## Kiểm tra cơ bản

1. Kết nối USB, Windows xuất hiện một COM port.
2. Mở terminal 115200 và gửi frame SIGN_ON:
   `1B 00 00 01 0E 01 15`
3. Phản hồi phải chứa chuỗi `STK500_2`.
4. Sau đó thử Read Signature trong AVR Studio.
5. Nếu không vào programming mode:
   - kiểm tra RESET active-low;
   - kiểm tra MOSI/MISO không đấu ngược;
   - giảm SCK;
   - kiểm tra target có nguồn và chung GND;
   - kiểm tra fuse đã tắt SPIEN hay RESET chưa.

## Lưu ý quan trọng

Giao thức STK500v2 cho phép AVR Studio truyền timing và opcode theo từng AVR. Tuy nhiên khả năng tương thích thực tế vẫn cần thử trên từng nhóm chip, đặc biệt chip Flash lớn hơn 128 KiB, EEPROM kiểu đặc biệt, hoặc chip chỉ hỗ trợ TPI/UPDI.

Mã này không tự động cấp 5 V cho target và không có bảo vệ chập mạch. Nên thêm buffer logic, điện trở nối tiếp 47–100 Ω cho SCK/MOSI/RESET và bảo vệ nguồn.
