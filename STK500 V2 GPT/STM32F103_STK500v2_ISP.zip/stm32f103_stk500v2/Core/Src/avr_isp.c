#include "avr_isp.h"
#include "main.h"

/*
 * Mặc định STM32F103C8:
 *   SPI1_SCK  = PA5
 *   SPI1_MISO = PA6
 *   SPI1_MOSI = PA7
 *   AVR_RESET = PB0, active-low
 *
 * CubeMX:
 *   SPI1: Master, Full Duplex, 8 bit, CPOL Low, CPHA 1 Edge, MSB first,
 *         NSS software, initial prescaler 256.
 *   PB0: GPIO Output, default HIGH.
 */
extern SPI_HandleTypeDef hspi1;

#ifndef AVR_RESET_GPIO_Port
#define AVR_RESET_GPIO_Port GPIOB
#endif
#ifndef AVR_RESET_Pin
#define AVR_RESET_Pin GPIO_PIN_0
#endif

static uint8_t g_sck_duration = 32u;

void AVRISP_DelayMs(uint32_t ms)
{
    HAL_Delay(ms);
}

void AVRISP_SetReset(bool asserted)
{
    HAL_GPIO_WritePin(AVR_RESET_GPIO_Port, AVR_RESET_Pin,
                      asserted ? GPIO_PIN_RESET : GPIO_PIN_SET);
}

static uint32_t duration_to_prescaler(uint8_t d)
{
    /*
     * STK500 parameter is based on old STK500 timing, but exact clock matching
     * is not required. Select the fastest SPI clock not exceeding a safe
     * approximation. STM32F103 SPI1 clock is normally PCLK2 = 72 MHz.
     *
     * d=0 -> about 1.8 MHz requested -> use /64 = 1.125 MHz
     * larger d -> progressively slower.
     */
    if (d <= 1u)   return SPI_BAUDRATEPRESCALER_64;
    if (d <= 3u)   return SPI_BAUDRATEPRESCALER_128;
    return SPI_BAUDRATEPRESCALER_256;
}

void AVRISP_SetSckDuration(uint8_t duration)
{
    g_sck_duration = duration;

    while (HAL_SPI_GetState(&hspi1) != HAL_SPI_STATE_READY) {}
    __HAL_SPI_DISABLE(&hspi1);
    MODIFY_REG(hspi1.Instance->CR1, SPI_CR1_BR, duration_to_prescaler(duration));
    __HAL_SPI_ENABLE(&hspi1);
}

uint8_t AVRISP_GetSckDuration(void)
{
    return g_sck_duration;
}

void AVRISP_Init(void)
{
    AVRISP_SetReset(false);
    AVRISP_SetSckDuration(g_sck_duration);
}

uint8_t AVRISP_TransferByte(uint8_t value)
{
    uint8_t rx = 0xFFu;
    (void)HAL_SPI_TransmitReceive(&hspi1, &value, &rx, 1u, 100u);
    return rx;
}

uint8_t AVRISP_Transfer4(const uint8_t tx[4], uint8_t rx[4])
{
    if (HAL_SPI_TransmitReceive(&hspi1, (uint8_t *)tx, rx, 4u, 200u) != HAL_OK)
        return 0u;
    return 1u;
}

bool AVRISP_EnterProgramming(uint8_t timeout,
                            uint8_t stab_delay,
                            uint8_t cmdexe_delay,
                            uint8_t synch_loops,
                            uint8_t byte_delay,
                            uint8_t poll_value,
                            uint8_t poll_index,
                            const uint8_t command[4])
{
    (void)timeout;

    AVRISP_SetReset(false);
    AVRISP_DelayMs(stab_delay);
    AVRISP_SetReset(true);
    AVRISP_DelayMs(cmdexe_delay);

    if (synch_loops == 0u)
        synch_loops = 1u;

    for (uint8_t attempt = 0; attempt < synch_loops; ++attempt)
    {
        uint8_t rx[4] = {0};
        for (uint8_t i = 0; i < 4u; ++i)
        {
            rx[i] = AVRISP_TransferByte(command[i]);
            if (byte_delay)
                AVRISP_DelayMs(byte_delay);
        }

        if ((poll_index < 4u && rx[poll_index] == poll_value) ||
            (rx[2] == 0x53u))
            return true;

        AVRISP_SetReset(false);
        AVRISP_DelayMs(2u);
        AVRISP_SetReset(true);
        AVRISP_DelayMs(20u);
    }

    return false;
}

void AVRISP_LeaveProgramming(uint8_t pre_delay, uint8_t post_delay)
{
    AVRISP_DelayMs(pre_delay);
    AVRISP_SetReset(false);
    AVRISP_DelayMs(post_delay);
}
