#include "stk500v2.h"
#include "avr_isp.h"
#include "usb_cdc_bridge.h"
#include <string.h>

/* Transport */
#define MESSAGE_START               0x1Bu
#define TOKEN                       0x0Eu

/* Status */
#define STATUS_CMD_OK               0x00u
#define STATUS_CMD_TOUT             0x80u
#define STATUS_RDY_BSY_TOUT         0x81u
#define STATUS_SET_PARAM_MISSING    0x82u
#define STATUS_CMD_FAILED           0xC0u
#define STATUS_CKSUM_ERROR          0xC1u
#define STATUS_CMD_UNKNOWN          0xC9u

/* General commands */
#define CMD_SIGN_ON                 0x01u
#define CMD_SET_PARAMETER           0x02u
#define CMD_GET_PARAMETER           0x03u
#define CMD_SET_DEVICE_PARAMETERS   0x04u
#define CMD_OSCCAL                  0x05u
#define CMD_LOAD_ADDRESS            0x06u
#define CMD_FIRMWARE_UPGRADE        0x07u

/* ISP commands */
#define CMD_ENTER_PROGMODE_ISP      0x10u
#define CMD_LEAVE_PROGMODE_ISP      0x11u
#define CMD_CHIP_ERASE_ISP          0x12u
#define CMD_PROGRAM_FLASH_ISP       0x13u
#define CMD_READ_FLASH_ISP          0x14u
#define CMD_PROGRAM_EEPROM_ISP      0x15u
#define CMD_READ_EEPROM_ISP         0x16u
#define CMD_PROGRAM_FUSE_ISP        0x17u
#define CMD_READ_FUSE_ISP           0x18u
#define CMD_PROGRAM_LOCK_ISP        0x19u
#define CMD_READ_LOCK_ISP           0x1Au
#define CMD_READ_SIGNATURE_ISP      0x1Bu
#define CMD_READ_OSCCAL_ISP         0x1Cu
#define CMD_SPI_MULTI               0x1Du

/* Parameters */
#define PARAM_BUILD_NUMBER_LOW      0x80u
#define PARAM_BUILD_NUMBER_HIGH     0x81u
#define PARAM_HW_VER                0x90u
#define PARAM_SW_MAJOR              0x91u
#define PARAM_SW_MINOR              0x92u
#define PARAM_VTARGET               0x94u
#define PARAM_VADJUST               0x95u
#define PARAM_OSC_PSCALE            0x96u
#define PARAM_OSC_CMATCH            0x97u
#define PARAM_SCK_DURATION          0x98u
#define PARAM_TOPCARD_DETECT        0x9Au
#define PARAM_STATUS                0x9Cu
#define PARAM_DATA                  0x9Du
#define PARAM_RESET_POLARITY        0x9Eu
#define PARAM_CONTROLLER_INIT       0x9Fu

#define RX_RING_SIZE 1024u
#define TX_FRAME_MAX (STK500V2_MAX_BODY + 6u)

typedef enum {
    RX_WAIT_START = 0,
    RX_SEQUENCE,
    RX_SIZE_H,
    RX_SIZE_L,
    RX_TOKEN,
    RX_BODY,
    RX_CHECKSUM
} rx_state_t;

static volatile uint8_t rx_ring[RX_RING_SIZE];
static volatile uint16_t rx_head;
static volatile uint16_t rx_tail;

static rx_state_t pstate;
static uint8_t sequence_number;
static uint16_t message_size;
static uint16_t body_index;
static uint8_t checksum;
static uint8_t body[STK500V2_MAX_BODY];

static uint32_t current_address; /* AVR byte address for EEPROM, word base for flash handling */
static uint8_t parameters[256];
static uint8_t target_in_progmode;

static uint8_t response[STK500V2_MAX_BODY];

static uint8_t ring_pop(uint8_t *out)
{
    if (rx_head == rx_tail)
        return 0u;
    *out = rx_ring[rx_tail];
    rx_tail = (uint16_t)((rx_tail + 1u) % RX_RING_SIZE);
    return 1u;
}

void STK500V2_RxBytes(const uint8_t *data, uint32_t length)
{
    for (uint32_t i = 0; i < length; ++i)
    {
        uint16_t next = (uint16_t)((rx_head + 1u) % RX_RING_SIZE);
        if (next == rx_tail)
            break;
        rx_ring[rx_head] = data[i];
        rx_head = next;
    }
}

static void send_frame(const uint8_t *payload, uint16_t length)
{
    static uint8_t frame[TX_FRAME_MAX];
    if (length > STK500V2_MAX_BODY)
        return;

    frame[0] = MESSAGE_START;
    frame[1] = sequence_number;
    frame[2] = (uint8_t)(length >> 8);
    frame[3] = (uint8_t)(length);
    frame[4] = TOKEN;
    memcpy(&frame[5], payload, length);

    uint8_t c = 0u;
    for (uint16_t i = 0; i < (uint16_t)(5u + length); ++i)
        c ^= frame[i];
    frame[5u + length] = c;

    for (uint16_t retry = 0; retry < 1000u; ++retry)
    {
        if (USB_CDC_Send(frame, (uint16_t)(length + 6u)))
            return;
        AVRISP_DelayMs(1u);
    }
}

static void simple_status(uint8_t cmd, uint8_t status)
{
    response[0] = cmd;
    response[1] = status;
    send_frame(response, 2u);
}

static uint8_t get_parameter(uint8_t id)
{
    switch (id)
    {
        case PARAM_BUILD_NUMBER_LOW:  return 0u;
        case PARAM_BUILD_NUMBER_HIGH: return 0u;
        case PARAM_HW_VER:            return 2u;
        case PARAM_SW_MAJOR:          return 2u;
        case PARAM_SW_MINOR:          return 10u;
        case PARAM_VTARGET:           return 50u; /* 5.0 V, informational only */
        case PARAM_VADJUST:           return 50u;
        case PARAM_SCK_DURATION:      return AVRISP_GetSckDuration();
        case PARAM_TOPCARD_DETECT:    return 0u;
        default:                      return parameters[id];
    }
}

static void set_parameter(uint8_t id, uint8_t value)
{
    parameters[id] = value;
    if (id == PARAM_SCK_DURATION)
        AVRISP_SetSckDuration(value);
}

static uint8_t poll_ready(uint8_t poll_method,
                          uint8_t poll_value,
                          uint32_t timeout_ms,
                          const uint8_t read_cmd[4],
                          uint8_t read_index)
{
    if (poll_method == 0u)
    {
        AVRISP_DelayMs(timeout_ms);
        return STATUS_CMD_OK;
    }

    uint32_t start = HAL_GetTick();
    while ((HAL_GetTick() - start) <= timeout_ms)
    {
        uint8_t rx[4] = {0};
        AVRISP_Transfer4(read_cmd, rx);
        if (read_index < 4u && rx[read_index] != poll_value)
            return STATUS_CMD_OK;
    }
    return STATUS_RDY_BSY_TOUT;
}

static void handle_sign_on(void)
{
    static const uint8_t sign[] = {'S','T','K','5','0','0','_','2'};
    response[0] = CMD_SIGN_ON;
    response[1] = STATUS_CMD_OK;
    response[2] = sizeof(sign);
    memcpy(&response[3], sign, sizeof(sign));
    send_frame(response, (uint16_t)(3u + sizeof(sign)));
}

static void handle_enter_progmode(void)
{
    if (message_size < 12u) {
        simple_status(CMD_ENTER_PROGMODE_ISP, STATUS_CMD_FAILED);
        return;
    }

    target_in_progmode = AVRISP_EnterProgramming(
        body[1], body[2], body[3], body[4],
        body[5], body[6], body[7], &body[8]) ? 1u : 0u;

    simple_status(CMD_ENTER_PROGMODE_ISP,
                  target_in_progmode ? STATUS_CMD_OK : STATUS_CMD_FAILED);
}

static void handle_chip_erase(void)
{
    if (message_size < 7u) {
        simple_status(CMD_CHIP_ERASE_ISP, STATUS_CMD_FAILED);
        return;
    }

    const uint8_t erase_delay = body[1];
    const uint8_t poll_method = body[2];
    uint8_t rx[4] = {0};
    AVRISP_Transfer4(&body[3], rx);

    uint8_t st = STATUS_CMD_OK;
    if (poll_method == 0u)
        AVRISP_DelayMs(erase_delay);
    else
    {
        uint8_t pollcmd[4] = {0xF0u, 0x00u, 0x00u, 0x00u};
        st = poll_ready(1u, 0u, erase_delay ? erase_delay : 50u, pollcmd, 3u);
    }
    simple_status(CMD_CHIP_ERASE_ISP, st);
}

static void flash_set_ext_addr(uint32_t word_address)
{
    static uint8_t last_ext = 0xFFu;
    uint8_t ext = (uint8_t)(word_address >> 16);
    if (ext != last_ext)
    {
        uint8_t cmd[4] = {0x4Du, 0x00u, ext, 0x00u};
        uint8_t rx[4];
        AVRISP_Transfer4(cmd, rx);
        last_ext = ext;
    }
}

static void handle_program_flash(void)
{
    if (message_size < 10u) {
        simple_status(CMD_PROGRAM_FLASH_ISP, STATUS_CMD_FAILED);
        return;
    }

    uint16_t count = ((uint16_t)body[1] << 8) | body[2];
    uint8_t mode = body[3];
    uint8_t delay = body[4];
    uint8_t cmd_load = body[5];
    uint8_t cmd_write = body[6];
    uint8_t cmd_read = body[7];
    uint8_t poll1 = body[8];
    uint8_t poll2 = body[9];

    if ((uint32_t)count + 10u > message_size) {
        simple_status(CMD_PROGRAM_FLASH_ISP, STATUS_CMD_FAILED);
        return;
    }

    uint32_t word_addr = current_address;
    uint8_t status = STATUS_CMD_OK;

    for (uint16_t i = 0; i < count; ++i)
    {
        flash_set_ext_addr(word_addr);
        uint8_t high = (uint8_t)(i & 1u);
        uint8_t cmd[4] = {
            (uint8_t)(cmd_load | (high ? 0x08u : 0x00u)),
            (uint8_t)(word_addr >> 8),
            (uint8_t)word_addr,
            body[10u + i]
        };
        uint8_t rx[4];
        AVRISP_Transfer4(cmd, rx);
        if (high)
            ++word_addr;
    }

    /* bit 7: write page */
    if (mode & 0x80u)
    {
        uint32_t page_addr = current_address;
        flash_set_ext_addr(page_addr);
        uint8_t cmd[4] = {
            cmd_write,
            (uint8_t)(page_addr >> 8),
            (uint8_t)page_addr,
            0x00u
        };
        uint8_t rx[4];
        AVRISP_Transfer4(cmd, rx);

        if (mode & 0x20u) /* timed delay */
            AVRISP_DelayMs(delay);
        else if (mode & 0x40u) /* value polling */
        {
            uint8_t read4[4] = {
                cmd_read,
                (uint8_t)(page_addr >> 8),
                (uint8_t)page_addr,
                0x00u
            };
            status = poll_ready(1u, poll1 ? poll1 : poll2,
                                delay ? delay : 50u, read4, 3u);
        }
    }

    current_address = word_addr;
    response[0] = CMD_PROGRAM_FLASH_ISP;
    response[1] = status;
    send_frame(response, 2u);
}

static void handle_read_flash(void)
{
    if (message_size < 4u) {
        simple_status(CMD_READ_FLASH_ISP, STATUS_CMD_FAILED);
        return;
    }

    uint16_t count = ((uint16_t)body[1] << 8) | body[2];
    uint8_t read_cmd = body[3];

    if ((uint32_t)count + 3u > STK500V2_MAX_BODY) {
        simple_status(CMD_READ_FLASH_ISP, STATUS_CMD_FAILED);
        return;
    }

    response[0] = CMD_READ_FLASH_ISP;
    response[1] = STATUS_CMD_OK;

    uint32_t word_addr = current_address;
    for (uint16_t i = 0; i < count; ++i)
    {
        flash_set_ext_addr(word_addr);
        uint8_t high = (uint8_t)(i & 1u);
        uint8_t cmd[4] = {
            (uint8_t)(read_cmd | (high ? 0x08u : 0x00u)),
            (uint8_t)(word_addr >> 8),
            (uint8_t)word_addr,
            0x00u
        };
        uint8_t rx[4];
        AVRISP_Transfer4(cmd, rx);
        response[2u + i] = rx[3];
        if (high)
            ++word_addr;
    }
    current_address = word_addr;
    response[2u + count] = STATUS_CMD_OK;
    send_frame(response, (uint16_t)(count + 3u));
}

static void handle_program_eeprom(void)
{
    if (message_size < 10u) {
        simple_status(CMD_PROGRAM_EEPROM_ISP, STATUS_CMD_FAILED);
        return;
    }

    uint16_t count = ((uint16_t)body[1] << 8) | body[2];
    uint8_t mode = body[3];
    uint8_t delay = body[4];
    uint8_t cmd_write = body[5];

    if ((uint32_t)count + 10u > message_size) {
        simple_status(CMD_PROGRAM_EEPROM_ISP, STATUS_CMD_FAILED);
        return;
    }

    uint32_t addr = current_address;
    for (uint16_t i = 0; i < count; ++i, ++addr)
    {
        uint8_t cmd[4] = {
            cmd_write,
            (uint8_t)(addr >> 8),
            (uint8_t)addr,
            body[10u + i]
        };
        uint8_t rx[4];
        AVRISP_Transfer4(cmd, rx);
        AVRISP_DelayMs(delay ? delay : 5u);
    }
    current_address = addr;
    (void)mode;
    simple_status(CMD_PROGRAM_EEPROM_ISP, STATUS_CMD_OK);
}

static void handle_read_eeprom(void)
{
    if (message_size < 4u) {
        simple_status(CMD_READ_EEPROM_ISP, STATUS_CMD_FAILED);
        return;
    }

    uint16_t count = ((uint16_t)body[1] << 8) | body[2];
    uint8_t read_cmd = body[3];

    if ((uint32_t)count + 3u > STK500V2_MAX_BODY) {
        simple_status(CMD_READ_EEPROM_ISP, STATUS_CMD_FAILED);
        return;
    }

    response[0] = CMD_READ_EEPROM_ISP;
    response[1] = STATUS_CMD_OK;
    for (uint16_t i = 0; i < count; ++i, ++current_address)
    {
        uint8_t cmd[4] = {
            read_cmd,
            (uint8_t)(current_address >> 8),
            (uint8_t)current_address,
            0x00u
        };
        uint8_t rx[4];
        AVRISP_Transfer4(cmd, rx);
        response[2u + i] = rx[3];
    }
    response[2u + count] = STATUS_CMD_OK;
    send_frame(response, (uint16_t)(count + 3u));
}

static void handle_program_misc(uint8_t cmd_id)
{
    if (message_size < 5u) {
        simple_status(cmd_id, STATUS_CMD_FAILED);
        return;
    }
    uint8_t rx[4];
    AVRISP_Transfer4(&body[1], rx);
    simple_status(cmd_id, STATUS_CMD_OK);
}

static void handle_read_misc(uint8_t cmd_id)
{
    if (message_size < 6u) {
        simple_status(cmd_id, STATUS_CMD_FAILED);
        return;
    }
    uint8_t ret_index = body[1];
    uint8_t rx[4] = {0};
    AVRISP_Transfer4(&body[2], rx);

    response[0] = cmd_id;
    response[1] = STATUS_CMD_OK;
    response[2] = (ret_index < 4u) ? rx[ret_index] : 0u;
    response[3] = STATUS_CMD_OK;
    send_frame(response, 4u);
}

static void handle_spi_multi(void)
{
    if (message_size < 4u) {
        simple_status(CMD_SPI_MULTI, STATUS_CMD_FAILED);
        return;
    }

    uint8_t num_tx = body[1];
    uint8_t num_rx = body[2];
    uint8_t rx_start = body[3];

    if ((uint16_t)num_tx + 4u > message_size ||
        (uint16_t)num_rx + 3u > STK500V2_MAX_BODY) {
        simple_status(CMD_SPI_MULTI, STATUS_CMD_FAILED);
        return;
    }

    uint8_t rxbuf[255];
    for (uint16_t i = 0; i < num_tx; ++i)
        rxbuf[i] = AVRISP_TransferByte(body[4u + i]);

    response[0] = CMD_SPI_MULTI;
    response[1] = STATUS_CMD_OK;
    for (uint16_t i = 0; i < num_rx; ++i)
    {
        uint16_t idx = (uint16_t)rx_start + i;
        response[2u + i] = (idx < num_tx) ? rxbuf[idx] : 0u;
    }
    response[2u + num_rx] = STATUS_CMD_OK;
    send_frame(response, (uint16_t)(num_rx + 3u));
}

static void dispatch_packet(void)
{
    if (message_size == 0u)
        return;

    uint8_t cmd = body[0];
    switch (cmd)
    {
        case CMD_SIGN_ON:
            handle_sign_on();
            break;

        case CMD_SET_PARAMETER:
            if (message_size >= 3u) {
                set_parameter(body[1], body[2]);
                simple_status(cmd, STATUS_CMD_OK);
            } else simple_status(cmd, STATUS_CMD_FAILED);
            break;

        case CMD_GET_PARAMETER:
            if (message_size >= 2u) {
                response[0] = cmd;
                response[1] = STATUS_CMD_OK;
                response[2] = get_parameter(body[1]);
                send_frame(response, 3u);
            } else simple_status(cmd, STATUS_CMD_FAILED);
            break;

        case CMD_SET_DEVICE_PARAMETERS:
            /* AVR Studio supplies algorithm data in later commands; accept it. */
            simple_status(cmd, STATUS_CMD_OK);
            break;

        case CMD_LOAD_ADDRESS:
            if (message_size >= 5u) {
                current_address = ((uint32_t)body[1] << 24) |
                                  ((uint32_t)body[2] << 16) |
                                  ((uint32_t)body[3] << 8) |
                                  body[4];
                simple_status(cmd, STATUS_CMD_OK);
            } else simple_status(cmd, STATUS_CMD_FAILED);
            break;

        case CMD_ENTER_PROGMODE_ISP:
            handle_enter_progmode();
            break;

        case CMD_LEAVE_PROGMODE_ISP:
            if (message_size >= 3u) {
                AVRISP_LeaveProgramming(body[1], body[2]);
                target_in_progmode = 0u;
                simple_status(cmd, STATUS_CMD_OK);
            } else simple_status(cmd, STATUS_CMD_FAILED);
            break;

        case CMD_CHIP_ERASE_ISP:
            handle_chip_erase();
            break;

        case CMD_PROGRAM_FLASH_ISP:
            handle_program_flash();
            break;

        case CMD_READ_FLASH_ISP:
            handle_read_flash();
            break;

        case CMD_PROGRAM_EEPROM_ISP:
            handle_program_eeprom();
            break;

        case CMD_READ_EEPROM_ISP:
            handle_read_eeprom();
            break;

        case CMD_PROGRAM_FUSE_ISP:
        case CMD_PROGRAM_LOCK_ISP:
            handle_program_misc(cmd);
            break;

        case CMD_READ_FUSE_ISP:
        case CMD_READ_LOCK_ISP:
        case CMD_READ_SIGNATURE_ISP:
        case CMD_READ_OSCCAL_ISP:
            handle_read_misc(cmd);
            break;

        case CMD_SPI_MULTI:
            handle_spi_multi();
            break;

        case CMD_OSCCAL:
        case CMD_FIRMWARE_UPGRADE:
            simple_status(cmd, STATUS_CMD_FAILED);
            break;

        default:
            simple_status(cmd, STATUS_CMD_UNKNOWN);
            break;
    }
}

void STK500V2_Init(void)
{
    rx_head = rx_tail = 0u;
    pstate = RX_WAIT_START;
    sequence_number = 0u;
    message_size = 0u;
    body_index = 0u;
    checksum = 0u;
    current_address = 0u;
    target_in_progmode = 0u;
    memset(parameters, 0, sizeof(parameters));
    parameters[PARAM_RESET_POLARITY] = 1u;
    AVRISP_Init();
}

void STK500V2_Task(void)
{
    uint8_t b;
    while (ring_pop(&b))
    {
        switch (pstate)
        {
            case RX_WAIT_START:
                if (b == MESSAGE_START) {
                    checksum = b;
                    pstate = RX_SEQUENCE;
                }
                break;

            case RX_SEQUENCE:
                sequence_number = b;
                checksum ^= b;
                pstate = RX_SIZE_H;
                break;

            case RX_SIZE_H:
                message_size = (uint16_t)b << 8;
                checksum ^= b;
                pstate = RX_SIZE_L;
                break;

            case RX_SIZE_L:
                message_size |= b;
                checksum ^= b;
                if (message_size > STK500V2_MAX_BODY)
                    pstate = RX_WAIT_START;
                else
                    pstate = RX_TOKEN;
                break;

            case RX_TOKEN:
                checksum ^= b;
                if (b != TOKEN)
                    pstate = RX_WAIT_START;
                else {
                    body_index = 0u;
                    pstate = message_size ? RX_BODY : RX_CHECKSUM;
                }
                break;

            case RX_BODY:
                body[body_index++] = b;
                checksum ^= b;
                if (body_index >= message_size)
                    pstate = RX_CHECKSUM;
                break;

            case RX_CHECKSUM:
                checksum ^= b;
                if (checksum == 0u)
                    dispatch_packet();
                else {
                    response[0] = (message_size ? body[0] : 0u);
                    response[1] = STATUS_CKSUM_ERROR;
                    send_frame(response, 2u);
                }
                pstate = RX_WAIT_START;
                break;

            default:
                pstate = RX_WAIT_START;
                break;
        }
    }
}
