#include "usb_cdc_bridge.h"
#include "usbd_cdc_if.h"
#include "usbd_def.h"

bool USB_CDC_Send(const uint8_t *data, uint16_t length)
{
    return CDC_Transmit_FS((uint8_t *)data, length) == USBD_OK;
}
