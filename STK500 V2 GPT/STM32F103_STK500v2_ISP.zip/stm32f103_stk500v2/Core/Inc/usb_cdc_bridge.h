#ifndef USB_CDC_BRIDGE_H
#define USB_CDC_BRIDGE_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Không chặn vô hạn. Hàm trả false nếu USB đang BUSY. */
bool USB_CDC_Send(const uint8_t *data, uint16_t length);

#ifdef __cplusplus
}
#endif
#endif
