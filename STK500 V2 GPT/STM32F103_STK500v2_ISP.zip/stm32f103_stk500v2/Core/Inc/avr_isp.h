#ifndef AVR_ISP_H
#define AVR_ISP_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

void AVRISP_Init(void);
void AVRISP_SetSckDuration(uint8_t duration);
uint8_t AVRISP_GetSckDuration(void);

bool AVRISP_EnterProgramming(uint8_t timeout,
                            uint8_t stab_delay,
                            uint8_t cmdexe_delay,
                            uint8_t synch_loops,
                            uint8_t byte_delay,
                            uint8_t poll_value,
                            uint8_t poll_index,
                            const uint8_t command[4]);

void AVRISP_LeaveProgramming(uint8_t pre_delay, uint8_t post_delay);
uint8_t AVRISP_Transfer4(const uint8_t tx[4], uint8_t rx[4]);
uint8_t AVRISP_TransferByte(uint8_t value);
void AVRISP_SetReset(bool asserted);
void AVRISP_DelayMs(uint32_t ms);

#ifdef __cplusplus
}
#endif
#endif
