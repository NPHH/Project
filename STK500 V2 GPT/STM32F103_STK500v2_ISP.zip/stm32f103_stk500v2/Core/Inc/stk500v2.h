#ifndef STK500V2_H
#define STK500V2_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

#define STK500V2_MAX_BODY  285u

void STK500V2_Init(void);
void STK500V2_Task(void);

/* Gọi hàm này từ CDC_Receive_FS() với toàn bộ dữ liệu USB nhận được. */
void STK500V2_RxBytes(const uint8_t *data, uint32_t length);

#ifdef __cplusplus
}
#endif
#endif
