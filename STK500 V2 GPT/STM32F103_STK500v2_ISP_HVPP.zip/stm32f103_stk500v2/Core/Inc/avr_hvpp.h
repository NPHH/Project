#ifndef AVR_HVPP_H
#define AVR_HVPP_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

void AVRHvpp_Init(void);
void AVRHvpp_SetControlStack(const uint8_t stack[32]);
bool AVRHvpp_ControlStackValid(void);

bool AVRHvpp_Enter(uint8_t stab_delay_ms,
                   uint8_t progmode_delay_ms,
                   uint8_t latch_cycles,
                   uint8_t toggle_vtg,
                   uint8_t poweroff_delay_ms,
                   uint8_t reset_delay_ms,
                   uint8_t reset_delay_10us);
void AVRHvpp_Leave(uint8_t stab_delay_ms, uint8_t reset_delay_ms);

uint8_t AVRHvpp_ChipErase(uint8_t pulse_width_ms, uint8_t poll_timeout_ms);
uint8_t AVRHvpp_ProgramFlash(uint32_t word_address, const uint8_t *data,
                            uint16_t count, uint8_t mode, uint8_t poll_timeout_ms,
                            uint32_t *next_word_address);
uint8_t AVRHvpp_ReadFlash(uint32_t word_address, uint8_t *data,
                          uint16_t count, uint32_t *next_word_address);
uint8_t AVRHvpp_ProgramEeprom(uint32_t byte_address, const uint8_t *data,
                             uint16_t count, uint8_t mode, uint8_t poll_timeout_ms,
                             uint32_t *next_byte_address);
uint8_t AVRHvpp_ReadEeprom(uint32_t byte_address, uint8_t *data,
                           uint16_t count, uint32_t *next_byte_address);
uint8_t AVRHvpp_ProgramFuse(uint8_t address, uint8_t value,
                            uint8_t pulse_width_ms, uint8_t poll_timeout_ms);
uint8_t AVRHvpp_ReadFuse(uint8_t address);
uint8_t AVRHvpp_ProgramLock(uint8_t value, uint8_t pulse_width_ms,
                            uint8_t poll_timeout_ms);
uint8_t AVRHvpp_ReadLock(void);
uint8_t AVRHvpp_ReadSignature(uint8_t address);
uint8_t AVRHvpp_ReadOscCal(uint8_t address);
uint8_t AVRHvpp_ReadDataBus(void);

#ifdef __cplusplus
}
#endif
#endif
