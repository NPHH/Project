#ifndef USB_CDC_BRIDGE_H
#define USB_CDC_BRIDGE_H
#include <stdint.h>
#include <stdbool.h>
#ifdef __cplusplus
extern "C" {
#endif
#define USB_TX_QUEUE_DEPTH 8u
#define USB_TX_PACKET_MAX  600u
void USB_CDC_BridgeInit(void);
bool USB_CDC_Queue(const uint8_t *data, uint16_t length);
void USB_CDC_TxTask(void);
uint16_t USB_CDC_TxFree(void);
uint32_t USB_CDC_TxDropped(void);
#ifdef __cplusplus
}
#endif
#endif
