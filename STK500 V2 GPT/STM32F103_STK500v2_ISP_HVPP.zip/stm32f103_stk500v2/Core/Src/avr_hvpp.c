#include "avr_hvpp.h"
#include "main.h"
#include <string.h>

/* Return values match STK500v2 status values. */
#define HVPP_OK             0x00u
#define HVPP_RDY_BSY_TOUT   0x81u

/*
 * Fixed logical HVPP connector for STM32F103C8 LQFP48:
 *   PB8..PB15 : DATA0..DATA7 (through a 5-V tolerant bidirectional buffer)
 *   PC0 XA0, PC1 XA1, PC2 BS1, PC3 BS2, PC4 PAGEL, PC5 XTAL1
 *   PB3 /WR, PB4 /OE, PB5 RDY/BSY input
 *   PB6 VTARGET_EN, PB7 VPP12_EN
 *
 * PB3/PB4 are JTAG pins. Disable JTAG but retain SWD in CubeMX:
 * HAL_AFIO_REMAP_SWJ_NOJTAG().
 * VPP12_EN and VTARGET_EN drive external switches; never connect 12 V directly
 * to an STM32 pin. DATA and control pins require 3.3/5-V level translation.
 */
#define HV_DATA_PORT GPIOB
#define HV_DATA_MASK (GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14|GPIO_PIN_15)
#define XA0_PORT GPIOC
#define XA0_PIN GPIO_PIN_0
#define XA1_PORT GPIOC
#define XA1_PIN GPIO_PIN_1
#define BS1_PORT GPIOC
#define BS1_PIN GPIO_PIN_2
#define BS2_PORT GPIOC
#define BS2_PIN GPIO_PIN_3
#define PAGEL_PORT GPIOC
#define PAGEL_PIN GPIO_PIN_4
#define XTAL1_PORT GPIOC
#define XTAL1_PIN GPIO_PIN_5
#define WR_PORT GPIOB
#define WR_PIN GPIO_PIN_3
#define OE_PORT GPIOB
#define OE_PIN GPIO_PIN_4
#define RDY_PORT GPIOB
#define RDY_PIN GPIO_PIN_5
#define VTG_PORT GPIOB
#define VTG_PIN GPIO_PIN_6
#define VPP_PORT GPIOB
#define VPP_PIN GPIO_PIN_7

static uint8_t control_stack[32];
static uint8_t stack_valid;
static uint8_t in_progmode;

static void delay_us(uint32_t us)
{
    uint32_t cycles = (SystemCoreClock / 1000000u) * us;
    if ((DWT->CTRL & DWT_CTRL_CYCCNTENA_Msk) == 0u) {
        CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
        DWT->CYCCNT = 0u;
        DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
    }
    uint32_t start = DWT->CYCCNT;
    while ((DWT->CYCCNT - start) < cycles) {}
}

static void pin(GPIO_TypeDef *port, uint16_t p, uint8_t high)
{
    HAL_GPIO_WritePin(port, p, high ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

static void data_output(void)
{
    GPIO_InitTypeDef g = {0};
    g.Pin = HV_DATA_MASK;
    g.Mode = GPIO_MODE_OUTPUT_PP;
    g.Pull = GPIO_NOPULL;
    g.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(HV_DATA_PORT, &g);
}

static void data_input(void)
{
    GPIO_InitTypeDef g = {0};
    g.Pin = HV_DATA_MASK;
    g.Mode = GPIO_MODE_INPUT;
    g.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(HV_DATA_PORT, &g);
}

static void data_write(uint8_t v)
{
    uint32_t odr = HV_DATA_PORT->ODR;
    odr &= ~(uint32_t)HV_DATA_MASK;
    odr |= ((uint32_t)v << 8);
    HV_DATA_PORT->ODR = odr;
}

uint8_t AVRHvpp_ReadDataBus(void)
{
    return (uint8_t)((HV_DATA_PORT->IDR >> 8) & 0xFFu);
}

static void pulse_xtal1(void)
{
    pin(XTAL1_PORT, XTAL1_PIN, 1u); delay_us(1u);
    pin(XTAL1_PORT, XTAL1_PIN, 0u); delay_us(1u);
}

static void pulse_pagel(void)
{
    pin(PAGEL_PORT, PAGEL_PIN, 1u); delay_us(1u);
    pin(PAGEL_PORT, PAGEL_PIN, 0u); delay_us(1u);
}

static void pulse_wr(uint8_t width_ms)
{
    pin(WR_PORT, WR_PIN, 0u);
    if (width_ms) HAL_Delay(width_ms); else delay_us(2u);
    pin(WR_PORT, WR_PIN, 1u);
}

static uint8_t wait_ready(uint8_t timeout_ms)
{
    if (timeout_ms == 0u) return HVPP_OK;
    uint32_t start = HAL_GetTick();
    /* RDY/BSY is high when ready. Allow a short interval for it to go low. */
    delay_us(2u);
    while ((HAL_GetTick() - start) <= timeout_ms) {
        if (HAL_GPIO_ReadPin(RDY_PORT, RDY_PIN) == GPIO_PIN_SET)
            return HVPP_OK;
    }
    return HVPP_RDY_BSY_TOUT;
}

static void load_cycle(uint8_t xa1, uint8_t xa0, uint8_t bs1, uint8_t value)
{
    data_output();
    pin(XA1_PORT, XA1_PIN, xa1);
    pin(XA0_PORT, XA0_PIN, xa0);
    pin(BS1_PORT, BS1_PIN, bs1);
    data_write(value);
    delay_us(1u);
    pulse_xtal1();
}

static void load_command(uint8_t command) { load_cycle(1u, 0u, 0u, command); }
static void load_addr_low(uint8_t address) { load_cycle(0u, 0u, 0u, address); }
static void load_addr_high(uint8_t address){ load_cycle(0u, 0u, 1u, address); }
static void load_data_low(uint8_t value)   { load_cycle(0u, 1u, 0u, value); }
static void load_data_high(uint8_t value)  { load_cycle(0u, 1u, 1u, value); }

static uint8_t read_selected(uint8_t bs1, uint8_t bs2)
{
    data_input();
    pin(BS1_PORT, BS1_PIN, bs1);
    pin(BS2_PORT, BS2_PIN, bs2);
    pin(OE_PORT, OE_PIN, 0u);
    delay_us(2u);
    uint8_t v = AVRHvpp_ReadDataBus();
    pin(OE_PORT, OE_PIN, 1u);
    data_output();
    return v;
}

void AVRHvpp_Init(void)
{
    HAL_AFIO_REMAP_SWJ_NOJTAG();
    stack_valid = 0u;
    in_progmode = 0u;
    memset(control_stack, 0, sizeof(control_stack));
    data_output();
    data_write(0u);
    pin(XA0_PORT, XA0_PIN, 0u); pin(XA1_PORT, XA1_PIN, 0u);
    pin(BS1_PORT, BS1_PIN, 0u); pin(BS2_PORT, BS2_PIN, 0u);
    pin(PAGEL_PORT, PAGEL_PIN, 0u); pin(XTAL1_PORT, XTAL1_PIN, 0u);
    pin(WR_PORT, WR_PIN, 1u); pin(OE_PORT, OE_PIN, 1u);
    pin(VPP_PORT, VPP_PIN, 0u); pin(VTG_PORT, VTG_PIN, 0u);
}

void AVRHvpp_SetControlStack(const uint8_t stack[32])
{
    memcpy(control_stack, stack, 32u);
    stack_valid = 1u;
}

bool AVRHvpp_ControlStackValid(void) { return stack_valid != 0u; }

bool AVRHvpp_Enter(uint8_t stab_delay_ms, uint8_t progmode_delay_ms,
                   uint8_t latch_cycles, uint8_t toggle_vtg,
                   uint8_t poweroff_delay_ms, uint8_t reset_delay_ms,
                   uint8_t reset_delay_10us)
{
    if (!stack_valid) return false;
    pin(VPP_PORT, VPP_PIN, 0u);
    pin(VTG_PORT, VTG_PIN, 0u);
    data_output(); data_write(0u);
    pin(PAGEL_PORT, PAGEL_PIN, 0u); pin(XA1_PORT, XA1_PIN, 0u);
    pin(XA0_PORT, XA0_PIN, 0u); pin(BS1_PORT, BS1_PIN, 0u);
    pin(BS2_PORT, BS2_PIN, 0u); pin(WR_PORT, WR_PIN, 1u); pin(OE_PORT, OE_PIN, 1u);
    HAL_Delay(stab_delay_ms);

    if (toggle_vtg) {
        HAL_Delay(poweroff_delay_ms);
        pin(VTG_PORT, VTG_PIN, 1u);
    } else {
        pin(VTG_PORT, VTG_PIN, 1u);
    }
    HAL_Delay(reset_delay_ms);
    if (reset_delay_10us) delay_us((uint32_t)reset_delay_10us * 10u);
    else delay_us(30u);
    pin(VPP_PORT, VPP_PIN, 1u); /* external switch applies 11.5..12.5 V */
    delay_us(12u);
    while (latch_cycles--) pulse_xtal1();
    if (progmode_delay_ms) HAL_Delay(progmode_delay_ms); else delay_us(300u);
    in_progmode = 1u;
    return true;
}

void AVRHvpp_Leave(uint8_t stab_delay_ms, uint8_t reset_delay_ms)
{
    pin(VPP_PORT, VPP_PIN, 0u);
    HAL_Delay(reset_delay_ms);
    pin(VTG_PORT, VTG_PIN, 0u);
    HAL_Delay(stab_delay_ms);
    data_input();
    in_progmode = 0u;
}

uint8_t AVRHvpp_ChipErase(uint8_t pulse_width_ms, uint8_t poll_timeout_ms)
{
    load_command(0x80u);
    pin(BS1_PORT, BS1_PIN, 0u); pin(BS2_PORT, BS2_PIN, 0u);
    pulse_wr(pulse_width_ms);
    if (poll_timeout_ms) return wait_ready(poll_timeout_ms);
    HAL_Delay(10u);
    return HVPP_OK;
}

uint8_t AVRHvpp_ProgramFlash(uint32_t word_address, const uint8_t *data,
                            uint16_t count, uint8_t mode, uint8_t poll_timeout_ms,
                            uint32_t *next_word_address)
{
    load_command(0x10u);
    load_addr_high((uint8_t)(word_address >> 8));
    uint32_t a = word_address;
    uint16_t i = 0u;
    while (i < count) {
        load_addr_low((uint8_t)a);
        load_data_low(data[i++]);
        if (i < count) load_data_high(data[i++]); else load_data_high(0xFFu);
        pulse_pagel();
        ++a;
        if ((a & 0xFFu) == 0u && i < count) load_addr_high((uint8_t)(a >> 8));
    }
    if (mode & 0x80u) {
        pin(BS1_PORT, BS1_PIN, 0u); pin(BS2_PORT, BS2_PIN, 0u);
        pulse_wr(0u);
        uint8_t st = poll_timeout_ms ? wait_ready(poll_timeout_ms) : (HAL_Delay(5u), HVPP_OK);
        if (next_word_address) *next_word_address = a;
        return st;
    }
    if (next_word_address) *next_word_address = a;
    return HVPP_OK;
}

uint8_t AVRHvpp_ReadFlash(uint32_t word_address, uint8_t *data,
                          uint16_t count, uint32_t *next_word_address)
{
    load_command(0x02u);
    uint32_t a = word_address;
    uint16_t i = 0u;
    while (i < count) {
        load_addr_high((uint8_t)(a >> 8));
        load_addr_low((uint8_t)a);
        data[i++] = read_selected(0u, 0u);
        if (i < count) data[i++] = read_selected(1u, 0u);
        ++a;
    }
    if (next_word_address) *next_word_address = a;
    return HVPP_OK;
}

uint8_t AVRHvpp_ProgramEeprom(uint32_t byte_address, const uint8_t *data,
                             uint16_t count, uint8_t mode, uint8_t poll_timeout_ms,
                             uint32_t *next_byte_address)
{
    (void)mode;
    load_command(0x11u);
    uint32_t a = byte_address;
    for (uint16_t i = 0u; i < count; ++i, ++a) {
        load_addr_high((uint8_t)(a >> 8));
        load_addr_low((uint8_t)a);
        load_data_low(data[i]);
        pulse_pagel();
    }
    pin(BS1_PORT, BS1_PIN, 0u); pin(BS2_PORT, BS2_PIN, 0u);
    pulse_wr(0u);
    uint8_t st = poll_timeout_ms ? wait_ready(poll_timeout_ms) : (HAL_Delay(5u), HVPP_OK);
    if (next_byte_address) *next_byte_address = a;
    return st;
}

uint8_t AVRHvpp_ReadEeprom(uint32_t byte_address, uint8_t *data,
                           uint16_t count, uint32_t *next_byte_address)
{
    load_command(0x03u);
    uint32_t a = byte_address;
    for (uint16_t i = 0u; i < count; ++i, ++a) {
        load_addr_high((uint8_t)(a >> 8));
        load_addr_low((uint8_t)a);
        data[i] = read_selected(0u, 0u);
    }
    if (next_byte_address) *next_byte_address = a;
    return HVPP_OK;
}

uint8_t AVRHvpp_ProgramFuse(uint8_t address, uint8_t value,
                            uint8_t pulse_width_ms, uint8_t poll_timeout_ms)
{
    load_command(0x40u); load_data_low(value);
    if (address == 1u) { pin(BS1_PORT, BS1_PIN, 1u); pin(BS2_PORT, BS2_PIN, 0u); }
    else if (address >= 2u) { pin(BS1_PORT, BS1_PIN, 0u); pin(BS2_PORT, BS2_PIN, 1u); }
    else { pin(BS1_PORT, BS1_PIN, 0u); pin(BS2_PORT, BS2_PIN, 0u); }
    pulse_wr(pulse_width_ms);
    uint8_t st = poll_timeout_ms ? wait_ready(poll_timeout_ms) : (HAL_Delay(5u), HVPP_OK);
    pin(BS1_PORT, BS1_PIN, 0u); pin(BS2_PORT, BS2_PIN, 0u);
    return st;
}

uint8_t AVRHvpp_ReadFuse(uint8_t address)
{
    load_command(0x04u);
    if (address == 1u) return read_selected(1u, 1u);
    if (address >= 2u) return read_selected(0u, 1u);
    return read_selected(0u, 0u);
}

uint8_t AVRHvpp_ProgramLock(uint8_t value, uint8_t pulse_width_ms,
                            uint8_t poll_timeout_ms)
{
    load_command(0x20u); load_data_low(value);
    pin(BS1_PORT, BS1_PIN, 0u); pin(BS2_PORT, BS2_PIN, 0u);
    pulse_wr(pulse_width_ms);
    return poll_timeout_ms ? wait_ready(poll_timeout_ms) : (HAL_Delay(5u), HVPP_OK);
}

uint8_t AVRHvpp_ReadLock(void)
{
    load_command(0x04u);
    return read_selected(1u, 0u);
}

uint8_t AVRHvpp_ReadSignature(uint8_t address)
{
    load_command(0x08u); load_addr_low(address);
    return read_selected(0u, 0u);
}

uint8_t AVRHvpp_ReadOscCal(uint8_t address)
{
    load_command(0x08u); load_addr_low(address);
    return read_selected(1u, 0u);
}
