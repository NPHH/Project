#include "stk500v2.h"
#include "avr_isp.h"
#include "avr_hvpp.h"
#include "usb_cdc_bridge.h"
#include <string.h>

/* Transport */
#define MESSAGE_START               0x1Bu
#define TOKEN                       0x0Eu

/* Status */
#define STATUS_CMD_OK               0x00u
#define STATUS_CMD_TOUT             0x80u
#define STATUS_RDY_BSY_TOUT         0x81u
#define STATUS_SET_PARAM_MISSING    0x82u
#define STATUS_CMD_FAILED           0xC0u
#define STATUS_CKSUM_ERROR          0xC1u
#define STATUS_CMD_UNKNOWN          0xC9u

/* General commands */
#define CMD_SIGN_ON                 0x01u
#define CMD_SET_PARAMETER           0x02u
#define CMD_GET_PARAMETER           0x03u
#define CMD_SET_DEVICE_PARAMETERS   0x04u
#define CMD_OSCCAL                  0x05u
#define CMD_LOAD_ADDRESS            0x06u
#define CMD_FIRMWARE_UPGRADE        0x07u

/* ISP commands */
#define CMD_ENTER_PROGMODE_ISP      0x10u
#define CMD_LEAVE_PROGMODE_ISP      0x11u
#define CMD_CHIP_ERASE_ISP          0x12u
#define CMD_PROGRAM_FLASH_ISP       0x13u
#define CMD_READ_FLASH_ISP          0x14u
#define CMD_PROGRAM_EEPROM_ISP      0x15u
#define CMD_READ_EEPROM_ISP         0x16u
#define CMD_PROGRAM_FUSE_ISP        0x17u
#define CMD_READ_FUSE_ISP           0x18u
#define CMD_PROGRAM_LOCK_ISP        0x19u
#define CMD_READ_LOCK_ISP           0x1Au
#define CMD_READ_SIGNATURE_ISP      0x1Bu
#define CMD_READ_OSCCAL_ISP         0x1Cu
#define CMD_SPI_MULTI               0x1Du

/* High-voltage parallel programming commands */
#define CMD_ENTER_PROGMODE_PP       0x20u
#define CMD_LEAVE_PROGMODE_PP       0x21u
#define CMD_CHIP_ERASE_PP           0x22u
#define CMD_PROGRAM_FLASH_PP        0x23u
#define CMD_READ_FLASH_PP           0x24u
#define CMD_PROGRAM_EEPROM_PP       0x25u
#define CMD_READ_EEPROM_PP          0x26u
#define CMD_PROGRAM_FUSE_PP         0x27u
#define CMD_READ_FUSE_PP            0x28u
#define CMD_PROGRAM_LOCK_PP         0x29u
#define CMD_READ_LOCK_PP            0x2Au
#define CMD_READ_SIGNATURE_PP       0x2Bu
#define CMD_READ_OSCCAL_PP          0x2Cu
#define CMD_SET_CONTROL_STACK       0x2Du

/* Parameters */
#define PARAM_BUILD_NUMBER_LOW      0x80u
#define PARAM_BUILD_NUMBER_HIGH     0x81u
#define PARAM_HW_VER                0x90u
#define PARAM_SW_MAJOR              0x91u
#define PARAM_SW_MINOR              0x92u
#define PARAM_VTARGET               0x94u
#define PARAM_VADJUST               0x95u
#define PARAM_OSC_PSCALE            0x96u
#define PARAM_OSC_CMATCH            0x97u
#define PARAM_SCK_DURATION          0x98u
#define PARAM_TOPCARD_DETECT        0x9Au
#define PARAM_STATUS                0x9Cu
#define PARAM_DATA                  0x9Du
#define PARAM_RESET_POLARITY        0x9Eu
#define PARAM_CONTROLLER_INIT       0x9Fu

#define RX_RING_SIZE 1024u
#define TX_FRAME_MAX (STK500V2_MAX_BODY + 6u)

typedef enum {
    RX_WAIT_START = 0,
    RX_SEQUENCE,
    RX_SIZE_H,
    RX_SIZE_L,
    RX_TOKEN,
    RX_BODY,
    RX_CHECKSUM
} rx_state_t;

static volatile uint8_t rx_ring[RX_RING_SIZE];
static volatile uint16_t rx_head;
static volatile uint16_t rx_tail;

static rx_state_t pstate;
static uint8_t sequence_number;
static uint16_t message_size;
static uint16_t body_index;
static uint8_t checksum;
static uint8_t body[STK500V2_MAX_BODY];

static uint32_t current_address; /* AVR byte address for EEPROM, word base for flash handling */
static uint8_t parameters[256];
static uint8_t target_in_progmode;

static uint8_t response[STK500V2_MAX_BODY];
static uint8_t parser_overflow;

static uint8_t ring_pop(uint8_t *out)
{
    if (rx_head == rx_tail)
        return 0u;
    *out = rx_ring[rx_tail];
    rx_tail = (uint16_t)((rx_tail + 1u) % RX_RING_SIZE);
    return 1u;
}

void STK500V2_RxBytes(const uint8_t *data, uint32_t length)
{
    for (uint32_t i = 0; i < length; ++i)
    {
        uint16_t next = (uint16_t)((rx_head + 1u) % RX_RING_SIZE);
        if (next == rx_tail) { parser_overflow = 1u; break; }
        rx_ring[rx_head] = data[i];
        rx_head = next;
    }
}

static void send_frame(const uint8_t *payload, uint16_t length)
{
    static uint8_t frame[TX_FRAME_MAX];
    if (length > STK500V2_MAX_BODY)
        return;

    frame[0] = MESSAGE_START;
    frame[1] = sequence_number;
    frame[2] = (uint8_t)(length >> 8);
    frame[3] = (uint8_t)(length);
    frame[4] = TOKEN;
    memcpy(&frame[5], payload, length);

    uint8_t c = 0u;
    for (uint16_t i = 0; i < (uint16_t)(5u + length); ++i)
        c ^= frame[i];
    frame[5u + length] = c;

    (void)USB_CDC_Queue(frame, (uint16_t)(length + 6u));
}

static void simple_status(uint8_t cmd, uint8_t status)
{
    response[0] = cmd;
    response[1] = status;
    send_frame(response, 2u);
}

static uint8_t get_parameter(uint8_t id)
{
    switch (id)
    {
        case PARAM_BUILD_NUMBER_LOW:  return 0u;
        case PARAM_BUILD_NUMBER_HIGH: return 0u;
        case PARAM_HW_VER:            return 2u;
        case PARAM_SW_MAJOR:          return 2u;
        case PARAM_SW_MINOR:          return 10u;
        case PARAM_VTARGET:           return 50u; /* 5.0 V, informational only */
        case PARAM_VADJUST:           return 50u;
        case PARAM_SCK_DURATION:      return AVRISP_GetSckDuration();
        case PARAM_TOPCARD_DETECT:    return 0u;
        case PARAM_DATA:              return AVRHvpp_ReadDataBus();
        case PARAM_CONTROLLER_INIT:   return AVRHvpp_ControlStackValid() ? 1u : parameters[id];
        default:                      return parameters[id];
    }
}

static void set_parameter(uint8_t id, uint8_t value)
{
    parameters[id] = value;
    if (id == PARAM_SCK_DURATION)
        AVRISP_SetSckDuration(value);
}

static uint8_t poll_value_ready(uint8_t poll_value, uint32_t timeout_ms,
                                const uint8_t read_cmd[4], uint8_t read_index)
{
    const uint32_t start = AVRISP_Millis();
    do {
        uint8_t rx[4] = {0};
        AVRISP_Transfer4(read_cmd, rx);
        if (read_index < 4u && rx[read_index] != poll_value)
            return STATUS_CMD_OK;
    } while ((AVRISP_Millis() - start) <= timeout_ms);
    return STATUS_RDY_BSY_TOUT;
}

static uint8_t poll_rdy_bsy(uint32_t timeout_ms)
{
    const uint32_t start = AVRISP_Millis();
    const uint8_t cmd[4] = {0xF0u, 0x00u, 0x00u, 0x00u};
    do {
        uint8_t rx[4] = {0};
        AVRISP_Transfer4(cmd, rx);
        if ((rx[3] & 0x01u) == 0u) return STATUS_CMD_OK;
    } while ((AVRISP_Millis() - start) <= timeout_ms);
    return STATUS_RDY_BSY_TOUT;
}

static void handle_sign_on(void)
{
    static const uint8_t sign[] = {'S','T','K','5','0','0','_','2'};
    response[0] = CMD_SIGN_ON;
    response[1] = STATUS_CMD_OK;
    response[2] = sizeof(sign);
    memcpy(&response[3], sign, sizeof(sign));
    send_frame(response, (uint16_t)(3u + sizeof(sign)));
}

static void handle_enter_progmode(void)
{
    if (message_size < 12u) {
        simple_status(CMD_ENTER_PROGMODE_ISP, STATUS_CMD_FAILED);
        return;
    }

    target_in_progmode = AVRISP_EnterProgramming(
        body[1], body[2], body[3], body[4],
        body[5], body[6], body[7], &body[8]) ? 1u : 0u;

    simple_status(CMD_ENTER_PROGMODE_ISP,
                  target_in_progmode ? STATUS_CMD_OK : STATUS_CMD_FAILED);
}

static void handle_chip_erase(void)
{
    if (message_size < 7u) {
        simple_status(CMD_CHIP_ERASE_ISP, STATUS_CMD_FAILED);
        return;
    }

    const uint8_t erase_delay = body[1];
    const uint8_t poll_method = body[2];
    uint8_t rx[4] = {0};
    AVRISP_Transfer4(&body[3], rx);

    uint8_t st = STATUS_CMD_OK;
    if (poll_method == 0u)
        AVRISP_DelayMs(erase_delay);
    else
    {
        uint8_t pollcmd[4] = {0xF0u, 0x00u, 0x00u, 0x00u};
        st = poll_rdy_bsy(erase_delay ? erase_delay : 50u);
    }
    simple_status(CMD_CHIP_ERASE_ISP, st);
}

static void flash_set_ext_addr(uint32_t word_address)
{
    static uint8_t last_ext = 0xFFu;
    uint8_t ext = (uint8_t)(word_address >> 16);
    if (ext != last_ext)
    {
        uint8_t cmd[4] = {0x4Du, 0x00u, ext, 0x00u};
        uint8_t rx[4];
        AVRISP_Transfer4(cmd, rx);
        last_ext = ext;
    }
}

static void handle_program_flash(void)
{
    if (message_size < 10u) {
        simple_status(CMD_PROGRAM_FLASH_ISP, STATUS_CMD_FAILED);
        return;
    }

    uint16_t count = ((uint16_t)body[1] << 8) | body[2];
    uint8_t mode = body[3];
    uint8_t delay = body[4];
    uint8_t cmd_load = body[5];
    uint8_t cmd_write = body[6];
    uint8_t cmd_read = body[7];
    uint8_t poll1 = body[8];
    uint8_t poll2 = body[9];

    if ((uint32_t)count + 10u > message_size) {
        simple_status(CMD_PROGRAM_FLASH_ISP, STATUS_CMD_FAILED);
        return;
    }

    uint32_t word_addr = current_address;
    uint8_t status = STATUS_CMD_OK;

    for (uint16_t i = 0; i < count; ++i)
    {
        flash_set_ext_addr(word_addr);
        uint8_t high = (uint8_t)(i & 1u);
        uint8_t cmd[4] = {
            (uint8_t)(cmd_load | (high ? 0x08u : 0x00u)),
            (uint8_t)(word_addr >> 8),
            (uint8_t)word_addr,
            body[10u + i]
        };
        uint8_t rx[4];
        AVRISP_Transfer4(cmd, rx);
        if (high)
            ++word_addr;
    }

    /* bit 7: write page */
    if (mode & 0x80u)
    {
        uint32_t page_addr = current_address;
        flash_set_ext_addr(page_addr);
        uint8_t cmd[4] = {
            cmd_write,
            (uint8_t)(page_addr >> 8),
            (uint8_t)page_addr,
            0x00u
        };
        uint8_t rx[4];
        AVRISP_Transfer4(cmd, rx);

        if (mode & 0x20u) /* timed delay */
            AVRISP_DelayMs(delay);
        else if (mode & 0x40u) /* value polling */
        {
            uint8_t read4[4] = {
                cmd_read,
                (uint8_t)(page_addr >> 8),
                (uint8_t)page_addr,
                0x00u
            };
            status = poll_value_ready(poll1 ? poll1 : poll2,
                                      delay ? delay : 50u, read4, 3u);
        }
    }

    current_address = word_addr;
    response[0] = CMD_PROGRAM_FLASH_ISP;
    response[1] = status;
    send_frame(response, 2u);
}

static void handle_read_flash(void)
{
    if (message_size < 4u) {
        simple_status(CMD_READ_FLASH_ISP, STATUS_CMD_FAILED);
        return;
    }

    uint16_t count = ((uint16_t)body[1] << 8) | body[2];
    uint8_t read_cmd = body[3];

    if ((uint32_t)count + 3u > STK500V2_MAX_BODY) {
        simple_status(CMD_READ_FLASH_ISP, STATUS_CMD_FAILED);
        return;
    }

    response[0] = CMD_READ_FLASH_ISP;
    response[1] = STATUS_CMD_OK;

    uint32_t word_addr = current_address;
    for (uint16_t i = 0; i < count; ++i)
    {
        flash_set_ext_addr(word_addr);
        uint8_t high = (uint8_t)(i & 1u);
        uint8_t cmd[4] = {
            (uint8_t)(read_cmd | (high ? 0x08u : 0x00u)),
            (uint8_t)(word_addr >> 8),
            (uint8_t)word_addr,
            0x00u
        };
        uint8_t rx[4];
        AVRISP_Transfer4(cmd, rx);
        response[2u + i] = rx[3];
        if (high)
            ++word_addr;
    }
    current_address = word_addr;
    response[2u + count] = STATUS_CMD_OK;
    send_frame(response, (uint16_t)(count + 3u));
}

static void handle_program_eeprom(void)
{
    if (message_size < 10u) {
        simple_status(CMD_PROGRAM_EEPROM_ISP, STATUS_CMD_FAILED);
        return;
    }

    uint16_t count = ((uint16_t)body[1] << 8) | body[2];
    uint8_t mode = body[3];
    uint8_t delay = body[4];
    uint8_t cmd_write = body[5];

    if ((uint32_t)count + 10u > message_size) {
        simple_status(CMD_PROGRAM_EEPROM_ISP, STATUS_CMD_FAILED);
        return;
    }

    uint32_t addr = current_address;
    for (uint16_t i = 0; i < count; ++i, ++addr)
    {
        uint8_t cmd[4] = {
            cmd_write,
            (uint8_t)(addr >> 8),
            (uint8_t)addr,
            body[10u + i]
        };
        uint8_t rx[4];
        AVRISP_Transfer4(cmd, rx);
        /* In byte-write mode each command starts a write cycle. In page mode
           the target accepts the byte stream and is polled after the page. */
        if ((mode & 0x80u) == 0u) {
            if (mode & 0x20u) AVRISP_DelayMs(delay ? delay : 5u);
            else if ((mode & 0x40u) == 0u) {
                uint8_t st = poll_rdy_bsy(delay ? delay : 20u);
                if (st != STATUS_CMD_OK) {
                    current_address = addr + 1u;
                    simple_status(CMD_PROGRAM_EEPROM_ISP, st);
                    return;
                }
            }
        }
    }
    current_address = addr;
    uint8_t status = STATUS_CMD_OK;
    /* mode bit 5: timed delay; bit 6: value polling; bit 7: page mode. */
    if ((mode & 0x80u) && (mode & 0x20u)) {
        AVRISP_DelayMs(delay ? delay : 5u);
    } else if ((mode & 0x40u) && count) {
        uint32_t last = current_address - 1u;
        uint8_t read4[4] = { body[6], (uint8_t)(last >> 8), (uint8_t)last, 0u };
        status = poll_value_ready(body[8] ? body[8] : body[9],
                                  delay ? delay : 20u, read4, 3u);
    } else if (mode & 0x80u) {
        status = poll_rdy_bsy(delay ? delay : 20u);
    }
    simple_status(CMD_PROGRAM_EEPROM_ISP, status);
}

static void handle_read_eeprom(void)
{
    if (message_size < 4u) {
        simple_status(CMD_READ_EEPROM_ISP, STATUS_CMD_FAILED);
        return;
    }

    uint16_t count = ((uint16_t)body[1] << 8) | body[2];
    uint8_t read_cmd = body[3];

    if ((uint32_t)count + 3u > STK500V2_MAX_BODY) {
        simple_status(CMD_READ_EEPROM_ISP, STATUS_CMD_FAILED);
        return;
    }

    response[0] = CMD_READ_EEPROM_ISP;
    response[1] = STATUS_CMD_OK;
    for (uint16_t i = 0; i < count; ++i, ++current_address)
    {
        uint8_t cmd[4] = {
            read_cmd,
            (uint8_t)(current_address >> 8),
            (uint8_t)current_address,
            0x00u
        };
        uint8_t rx[4];
        AVRISP_Transfer4(cmd, rx);
        response[2u + i] = rx[3];
    }
    response[2u + count] = STATUS_CMD_OK;
    send_frame(response, (uint16_t)(count + 3u));
}

static void handle_program_misc(uint8_t cmd_id)
{
    if (message_size < 5u) {
        simple_status(cmd_id, STATUS_CMD_FAILED);
        return;
    }
    uint8_t rx[4];
    AVRISP_Transfer4(&body[1], rx);
    simple_status(cmd_id, STATUS_CMD_OK);
}

static void handle_read_misc(uint8_t cmd_id)
{
    if (message_size < 6u) {
        simple_status(cmd_id, STATUS_CMD_FAILED);
        return;
    }
    uint8_t ret_index = body[1];
    uint8_t rx[4] = {0};
    AVRISP_Transfer4(&body[2], rx);

    response[0] = cmd_id;
    response[1] = STATUS_CMD_OK;
    response[2] = (ret_index < 4u) ? rx[ret_index] : 0u;
    response[3] = STATUS_CMD_OK;
    send_frame(response, 4u);
}

static void handle_spi_multi(void)
{
    if (message_size < 4u) {
        simple_status(CMD_SPI_MULTI, STATUS_CMD_FAILED);
        return;
    }

    uint8_t num_tx = body[1];
    uint8_t num_rx = body[2];
    uint8_t rx_start = body[3];

    if ((uint16_t)num_tx + 4u > message_size ||
        (uint16_t)num_rx + 3u > STK500V2_MAX_BODY) {
        simple_status(CMD_SPI_MULTI, STATUS_CMD_FAILED);
        return;
    }

    uint8_t rxbuf[255];
    for (uint16_t i = 0; i < num_tx; ++i)
        rxbuf[i] = AVRISP_TransferByte(body[4u + i]);

    response[0] = CMD_SPI_MULTI;
    response[1] = STATUS_CMD_OK;
    for (uint16_t i = 0; i < num_rx; ++i)
    {
        uint16_t idx = (uint16_t)rx_start + i;
        response[2u + i] = (idx < num_tx) ? rxbuf[idx] : 0u;
    }
    response[2u + num_rx] = STATUS_CMD_OK;
    send_frame(response, (uint16_t)(num_rx + 3u));
}


static void handle_set_control_stack(void)
{
    if (message_size != 33u) { simple_status(CMD_SET_CONTROL_STACK, STATUS_CMD_FAILED); return; }
    AVRHvpp_SetControlStack(&body[1]);
    parameters[PARAM_CONTROLLER_INIT] = 1u;
    simple_status(CMD_SET_CONTROL_STACK, STATUS_CMD_OK);
}

static void handle_enter_pp(void)
{
    if (message_size < 8u) { simple_status(CMD_ENTER_PROGMODE_PP, STATUS_CMD_FAILED); return; }
    bool ok = AVRHvpp_Enter(body[1], body[2], body[3], body[4], body[5], body[6], body[7]);
    target_in_progmode = ok ? 2u : 0u;
    simple_status(CMD_ENTER_PROGMODE_PP, ok ? STATUS_CMD_OK : STATUS_CMD_FAILED);
}

static void handle_program_memory_pp(uint8_t cmd, uint8_t eeprom)
{
    if (message_size < 5u) { simple_status(cmd, STATUS_CMD_FAILED); return; }
    uint16_t n = ((uint16_t)body[1] << 8) | body[2];
    if ((uint32_t)n + 5u > message_size) { simple_status(cmd, STATUS_CMD_FAILED); return; }
    uint32_t next = current_address;
    uint8_t st = eeprom ? AVRHvpp_ProgramEeprom(current_address, &body[5], n, body[3], body[4], &next)
                        : AVRHvpp_ProgramFlash(current_address, &body[5], n, body[3], body[4], &next);
    current_address = next;
    simple_status(cmd, st);
}

static void handle_read_memory_pp(uint8_t cmd, uint8_t eeprom)
{
    if (message_size < 3u) { simple_status(cmd, STATUS_CMD_FAILED); return; }
    uint16_t n = ((uint16_t)body[1] << 8) | body[2];
    if ((uint32_t)n + 3u > STK500V2_MAX_BODY) { simple_status(cmd, STATUS_CMD_FAILED); return; }
    uint32_t next = current_address;
    response[0] = cmd; response[1] = STATUS_CMD_OK;
    uint8_t st = eeprom ? AVRHvpp_ReadEeprom(current_address, &response[2], n, &next)
                        : AVRHvpp_ReadFlash(current_address, &response[2], n, &next);
    current_address = next;
    if (st != STATUS_CMD_OK) { simple_status(cmd, st); return; }
    response[2u+n] = STATUS_CMD_OK;
    send_frame(response, (uint16_t)(n+3u));
}

static void handle_program_fuse_pp(uint8_t cmd, uint8_t lock)
{
    if (message_size < 5u) { simple_status(cmd, STATUS_CMD_FAILED); return; }
    uint8_t st = lock ? AVRHvpp_ProgramLock(body[2], body[3], body[4])
                      : AVRHvpp_ProgramFuse(body[1], body[2], body[3], body[4]);
    simple_status(cmd, st);
}

static void handle_read_byte_pp(uint8_t cmd)
{
    if (message_size < 2u) { simple_status(cmd, STATUS_CMD_FAILED); return; }
    uint8_t v = 0u;
    if (cmd == CMD_READ_FUSE_PP) v = AVRHvpp_ReadFuse(body[1]);
    else if (cmd == CMD_READ_LOCK_PP) v = AVRHvpp_ReadLock();
    else if (cmd == CMD_READ_SIGNATURE_PP) v = AVRHvpp_ReadSignature(body[1]);
    else v = AVRHvpp_ReadOscCal(body[1]);
    response[0]=cmd; response[1]=STATUS_CMD_OK; response[2]=v;
    send_frame(response, 3u);
}

static void dispatch_packet(void)
{
    if (message_size == 0u)
        return;

    uint8_t cmd = body[0];
    switch (cmd)
    {
        case CMD_SIGN_ON:
            handle_sign_on();
            break;

        case CMD_SET_PARAMETER:
            if (message_size >= 3u) {
                set_parameter(body[1], body[2]);
                simple_status(cmd, STATUS_CMD_OK);
            } else simple_status(cmd, STATUS_CMD_FAILED);
            break;

        case CMD_GET_PARAMETER:
            if (message_size >= 2u) {
                response[0] = cmd;
                response[1] = STATUS_CMD_OK;
                response[2] = get_parameter(body[1]);
                send_frame(response, 3u);
            } else simple_status(cmd, STATUS_CMD_FAILED);
            break;

        case CMD_SET_DEVICE_PARAMETERS:
            /* AVR Studio supplies algorithm data in later commands; accept it. */
            simple_status(cmd, STATUS_CMD_OK);
            break;

        case CMD_LOAD_ADDRESS:
            if (message_size >= 5u) {
                current_address = ((uint32_t)body[1] << 24) |
                                  ((uint32_t)body[2] << 16) |
                                  ((uint32_t)body[3] << 8) |
                                  body[4];
                simple_status(cmd, STATUS_CMD_OK);
            } else simple_status(cmd, STATUS_CMD_FAILED);
            break;

        case CMD_ENTER_PROGMODE_ISP:
            handle_enter_progmode();
            break;

        case CMD_LEAVE_PROGMODE_ISP:
            if (message_size >= 3u) {
                AVRISP_LeaveProgramming(body[1], body[2]);
                target_in_progmode = 0u;
                simple_status(cmd, STATUS_CMD_OK);
            } else simple_status(cmd, STATUS_CMD_FAILED);
            break;

        case CMD_CHIP_ERASE_ISP:
            handle_chip_erase();
            break;

        case CMD_PROGRAM_FLASH_ISP:
            handle_program_flash();
            break;

        case CMD_READ_FLASH_ISP:
            handle_read_flash();
            break;

        case CMD_PROGRAM_EEPROM_ISP:
            handle_program_eeprom();
            break;

        case CMD_READ_EEPROM_ISP:
            handle_read_eeprom();
            break;

        case CMD_PROGRAM_FUSE_ISP:
        case CMD_PROGRAM_LOCK_ISP:
            handle_program_misc(cmd);
            break;

        case CMD_READ_FUSE_ISP:
        case CMD_READ_LOCK_ISP:
        case CMD_READ_SIGNATURE_ISP:
        case CMD_READ_OSCCAL_ISP:
            handle_read_misc(cmd);
            break;

        case CMD_SPI_MULTI:
            handle_spi_multi();
            break;

        case CMD_SET_CONTROL_STACK:
            handle_set_control_stack();
            break;
        case CMD_ENTER_PROGMODE_PP:
            handle_enter_pp();
            break;
        case CMD_LEAVE_PROGMODE_PP:
            if (message_size >= 3u) { AVRHvpp_Leave(body[1], body[2]); target_in_progmode=0u; simple_status(cmd, STATUS_CMD_OK); }
            else simple_status(cmd, STATUS_CMD_FAILED);
            break;
        case CMD_CHIP_ERASE_PP:
            if (message_size >= 3u) simple_status(cmd, AVRHvpp_ChipErase(body[1], body[2]));
            else simple_status(cmd, STATUS_CMD_FAILED);
            break;
        case CMD_PROGRAM_FLASH_PP:  handle_program_memory_pp(cmd, 0u); break;
        case CMD_READ_FLASH_PP:     handle_read_memory_pp(cmd, 0u); break;
        case CMD_PROGRAM_EEPROM_PP: handle_program_memory_pp(cmd, 1u); break;
        case CMD_READ_EEPROM_PP:    handle_read_memory_pp(cmd, 1u); break;
        case CMD_PROGRAM_FUSE_PP:   handle_program_fuse_pp(cmd, 0u); break;
        case CMD_PROGRAM_LOCK_PP:   handle_program_fuse_pp(cmd, 1u); break;
        case CMD_READ_FUSE_PP:
        case CMD_READ_LOCK_PP:
        case CMD_READ_SIGNATURE_PP:
        case CMD_READ_OSCCAL_PP:
            handle_read_byte_pp(cmd);
            break;

        case CMD_OSCCAL:
        case CMD_FIRMWARE_UPGRADE:
            simple_status(cmd, STATUS_CMD_FAILED);
            break;

        default:
            simple_status(cmd, STATUS_CMD_UNKNOWN);
            break;
    }
}

void STK500V2_Init(void)
{
    rx_head = rx_tail = 0u;
    pstate = RX_WAIT_START;
    sequence_number = 0u;
    message_size = 0u;
    body_index = 0u;
    checksum = 0u;
    current_address = 0u;
    target_in_progmode = 0u;
    parser_overflow = 0u;
    USB_CDC_BridgeInit();
    memset(parameters, 0, sizeof(parameters));
    parameters[PARAM_RESET_POLARITY] = 1u;
    AVRISP_Init();
    AVRHvpp_Init();
}

void STK500V2_Task(void)
{
    USB_CDC_TxTask();
    if (parser_overflow) {
        rx_tail = rx_head; pstate = RX_WAIT_START; parser_overflow = 0u;
    }
    uint8_t b;
    while (ring_pop(&b))
    {
        switch (pstate)
        {
            case RX_WAIT_START:
                if (b == MESSAGE_START) {
                    checksum = b;
                    pstate = RX_SEQUENCE;
                }
                break;

            case RX_SEQUENCE:
                sequence_number = b;
                checksum ^= b;
                pstate = RX_SIZE_H;
                break;

            case RX_SIZE_H:
                message_size = (uint16_t)b << 8;
                checksum ^= b;
                pstate = RX_SIZE_L;
                break;

            case RX_SIZE_L:
                message_size |= b;
                checksum ^= b;
                if (message_size > STK500V2_MAX_BODY)
                    pstate = RX_WAIT_START;
                else
                    pstate = RX_TOKEN;
                break;

            case RX_TOKEN:
                checksum ^= b;
                if (b != TOKEN)
                    pstate = RX_WAIT_START;
                else {
                    body_index = 0u;
                    pstate = message_size ? RX_BODY : RX_CHECKSUM;
                }
                break;

            case RX_BODY:
                body[body_index++] = b;
                checksum ^= b;
                if (body_index >= message_size)
                    pstate = RX_CHECKSUM;
                break;

            case RX_CHECKSUM:
                checksum ^= b;
                if (checksum == 0u)
                    dispatch_packet();
                else {
                    response[0] = (message_size ? body[0] : 0u);
                    response[1] = STATUS_CKSUM_ERROR;
                    send_frame(response, 2u);
                }
                pstate = RX_WAIT_START;
                break;

            default:
                pstate = RX_WAIT_START;
                break;
        }
    }
}
