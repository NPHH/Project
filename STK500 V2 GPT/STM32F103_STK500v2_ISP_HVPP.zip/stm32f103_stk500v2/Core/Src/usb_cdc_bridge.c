#include "usb_cdc_bridge.h"
#include "usbd_cdc_if.h"
#include "usbd_def.h"
#include <string.h>

typedef struct { uint16_t len; uint8_t data[USB_TX_PACKET_MAX]; } tx_item_t;
static tx_item_t q[USB_TX_QUEUE_DEPTH];
static volatile uint8_t head, tail, count;
static volatile uint32_t dropped;

void USB_CDC_BridgeInit(void) { head = tail = count = 0u; dropped = 0u; }
uint16_t USB_CDC_TxFree(void) { return (uint16_t)(USB_TX_QUEUE_DEPTH - count); }
uint32_t USB_CDC_TxDropped(void) { return dropped; }

bool USB_CDC_Queue(const uint8_t *data, uint16_t length)
{
    if (!data || length == 0u || length > USB_TX_PACKET_MAX) return false;
    if (count >= USB_TX_QUEUE_DEPTH) { dropped++; return false; }
    uint8_t slot = head;
    memcpy(q[slot].data, data, length);
    q[slot].len = length;
    head = (uint8_t)((head + 1u) % USB_TX_QUEUE_DEPTH);
    count++;
    return true;
}

void USB_CDC_TxTask(void)
{
    if (count == 0u) return;
    tx_item_t *it = &q[tail];
    if (CDC_Transmit_FS(it->data, it->len) == USBD_OK) {
        tail = (uint8_t)((tail + 1u) % USB_TX_QUEUE_DEPTH);
        count--;
    }
}
