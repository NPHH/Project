#include "avr_isp.h"
#include "main.h"

extern SPI_HandleTypeDef hspi1;

#ifndef AVR_RESET_GPIO_Port
#define AVR_RESET_GPIO_Port GPIOB
#endif
#ifndef AVR_RESET_Pin
#define AVR_RESET_Pin GPIO_PIN_0
#endif
#ifndef AVR_SCK_GPIO_Port
#define AVR_SCK_GPIO_Port GPIOA
#endif
#ifndef AVR_SCK_Pin
#define AVR_SCK_Pin GPIO_PIN_5
#endif
#ifndef AVR_MISO_GPIO_Port
#define AVR_MISO_GPIO_Port GPIOA
#endif
#ifndef AVR_MISO_Pin
#define AVR_MISO_Pin GPIO_PIN_6
#endif
#ifndef AVR_MOSI_GPIO_Port
#define AVR_MOSI_GPIO_Port GPIOA
#endif
#ifndef AVR_MOSI_Pin
#define AVR_MOSI_Pin GPIO_PIN_7
#endif

static uint8_t g_duration = 32u;
static uint32_t g_sck_hz = 125000u;
static avrisp_clock_mode_t g_mode = AVRISP_CLOCK_BITBANG;
static uint32_t g_half_period_us = 4u;

void AVRISP_DelayMs(uint32_t ms) { HAL_Delay(ms); }
uint32_t AVRISP_Millis(void) { return HAL_GetTick(); }

static void delay_us(uint32_t us)
{
    /* DWT gives stable sub-millisecond delay on Cortex-M3. */
    if ((DWT->CTRL & DWT_CTRL_CYCCNTENA_Msk) == 0u) {
        CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
        DWT->CYCCNT = 0u;
        DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
    }
    const uint32_t cycles = (SystemCoreClock / 1000000u) * us;
    const uint32_t start = DWT->CYCCNT;
    while ((uint32_t)(DWT->CYCCNT - start) < cycles) { }
}

static void gpio_spi_mode(void)
{
    GPIO_InitTypeDef io = {0};
    __HAL_RCC_GPIOA_CLK_ENABLE();
    io.Pin = AVR_SCK_Pin | AVR_MOSI_Pin;
    io.Mode = GPIO_MODE_OUTPUT_PP;
    io.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(AVR_SCK_GPIO_Port, &io);
    io.Pin = AVR_MISO_Pin;
    io.Mode = GPIO_MODE_INPUT;
    io.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(AVR_MISO_GPIO_Port, &io);
    HAL_GPIO_WritePin(AVR_SCK_GPIO_Port, AVR_SCK_Pin, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(AVR_MOSI_GPIO_Port, AVR_MOSI_Pin, GPIO_PIN_RESET);
}

static void af_spi_mode(void)
{
    GPIO_InitTypeDef io = {0};
    io.Pin = AVR_SCK_Pin | AVR_MOSI_Pin;
    io.Mode = GPIO_MODE_AF_PP;
    io.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(AVR_SCK_GPIO_Port, &io);
    io.Pin = AVR_MISO_Pin;
    io.Mode = GPIO_MODE_INPUT;
    io.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(AVR_MISO_GPIO_Port, &io);
}

static uint32_t duration_to_hz(uint8_t d)
{
    /* AVR068: SCK duration grows with the parameter. This table intentionally
       selects conservative frequencies and covers targets down to 32 kHz. */
    if (d == 0u) return 1000000u;
    if (d <= 1u) return 500000u;
    if (d <= 2u) return 250000u;
    if (d <= 4u) return 125000u;
    if (d <= 8u) return 62500u;
    if (d <= 16u) return 31250u;
    if (d <= 32u) return 15625u;
    if (d <= 64u) return 7812u;
    if (d <= 128u) return 3906u;
    return 1953u;
}

static uint32_t hw_prescaler_for(uint32_t hz)
{
    uint32_t pclk = HAL_RCC_GetPCLK2Freq();
    if ((pclk / 2u) <= hz) return SPI_BAUDRATEPRESCALER_2;
    if ((pclk / 4u) <= hz) return SPI_BAUDRATEPRESCALER_4;
    if ((pclk / 8u) <= hz) return SPI_BAUDRATEPRESCALER_8;
    if ((pclk / 16u) <= hz) return SPI_BAUDRATEPRESCALER_16;
    if ((pclk / 32u) <= hz) return SPI_BAUDRATEPRESCALER_32;
    if ((pclk / 64u) <= hz) return SPI_BAUDRATEPRESCALER_64;
    if ((pclk / 128u) <= hz) return SPI_BAUDRATEPRESCALER_128;
    return SPI_BAUDRATEPRESCALER_256;
}

void AVRISP_SetSckDuration(uint8_t duration)
{
    g_duration = duration;
    g_sck_hz = duration_to_hz(duration);
    if (g_sck_hz >= 300000u) {
        g_mode = AVRISP_CLOCK_HARDWARE;
        af_spi_mode();
        while (HAL_SPI_GetState(&hspi1) != HAL_SPI_STATE_READY) { }
        __HAL_SPI_DISABLE(&hspi1);
        MODIFY_REG(hspi1.Instance->CR1, SPI_CR1_BR, hw_prescaler_for(g_sck_hz));
        __HAL_SPI_ENABLE(&hspi1);
    } else {
        g_mode = AVRISP_CLOCK_BITBANG;
        __HAL_SPI_DISABLE(&hspi1);
        gpio_spi_mode();
        g_half_period_us = (500000u + g_sck_hz - 1u) / g_sck_hz;
        if (g_half_period_us == 0u) g_half_period_us = 1u;
    }
}

uint8_t AVRISP_GetSckDuration(void) { return g_duration; }
uint32_t AVRISP_GetSckHz(void) { return g_sck_hz; }
avrisp_clock_mode_t AVRISP_GetClockMode(void) { return g_mode; }

void AVRISP_SetReset(bool asserted)
{
    HAL_GPIO_WritePin(AVR_RESET_GPIO_Port, AVR_RESET_Pin,
                      asserted ? GPIO_PIN_RESET : GPIO_PIN_SET);
}

void AVRISP_Init(void)
{
    AVRISP_SetReset(false);
    AVRISP_SetSckDuration(g_duration);
}

static uint8_t bitbang_transfer(uint8_t tx)
{
    uint8_t rx = 0u;
    for (uint8_t mask = 0x80u; mask != 0u; mask >>= 1) {
        HAL_GPIO_WritePin(AVR_MOSI_GPIO_Port, AVR_MOSI_Pin,
                          (tx & mask) ? GPIO_PIN_SET : GPIO_PIN_RESET);
        delay_us(g_half_period_us);
        HAL_GPIO_WritePin(AVR_SCK_GPIO_Port, AVR_SCK_Pin, GPIO_PIN_SET);
        rx <<= 1;
        if (HAL_GPIO_ReadPin(AVR_MISO_GPIO_Port, AVR_MISO_Pin) == GPIO_PIN_SET)
            rx |= 1u;
        delay_us(g_half_period_us);
        HAL_GPIO_WritePin(AVR_SCK_GPIO_Port, AVR_SCK_Pin, GPIO_PIN_RESET);
    }
    return rx;
}

uint8_t AVRISP_TransferByte(uint8_t value)
{
    if (g_mode == AVRISP_CLOCK_BITBANG)
        return bitbang_transfer(value);
    uint8_t rx = 0xFFu;
    if (HAL_SPI_TransmitReceive(&hspi1, &value, &rx, 1u, 100u) != HAL_OK)
        return 0xFFu;
    return rx;
}

uint8_t AVRISP_Transfer4(const uint8_t tx[4], uint8_t rx[4])
{
    for (uint8_t i = 0; i < 4u; ++i)
        rx[i] = AVRISP_TransferByte(tx[i]);
    return 1u;
}

bool AVRISP_EnterProgramming(uint8_t timeout_ms, uint8_t stab_delay_ms,
                            uint8_t cmdexe_delay_ms, uint8_t synch_loops,
                            uint8_t byte_delay_ms, uint8_t poll_value,
                            uint8_t poll_index, const uint8_t command[4])
{
    const uint32_t start = AVRISP_Millis();
    if (synch_loops == 0u) synch_loops = 1u;
    AVRISP_SetReset(false);
    AVRISP_DelayMs(stab_delay_ms);

    for (uint8_t attempt = 0u; attempt < synch_loops; ++attempt) {
        AVRISP_SetReset(true);
        AVRISP_DelayMs(cmdexe_delay_ms);
        uint8_t rx[4] = {0};
        for (uint8_t i = 0; i < 4u; ++i) {
            rx[i] = AVRISP_TransferByte(command[i]);
            if (byte_delay_ms) AVRISP_DelayMs(byte_delay_ms);
        }
        if ((poll_index < 4u && rx[poll_index] == poll_value) || rx[2] == 0x53u)
            return true;
        AVRISP_SetReset(false);
        AVRISP_DelayMs(2u);
        if (timeout_ms && (AVRISP_Millis() - start >= timeout_ms)) break;
    }
    return false;
}

void AVRISP_LeaveProgramming(uint8_t pre_delay_ms, uint8_t post_delay_ms)
{
    AVRISP_DelayMs(pre_delay_ms);
    AVRISP_SetReset(false);
    AVRISP_DelayMs(post_delay_ms);
}
