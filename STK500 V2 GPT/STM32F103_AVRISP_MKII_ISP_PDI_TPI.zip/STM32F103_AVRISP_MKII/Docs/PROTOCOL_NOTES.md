# AVR069 implementation notes

## USB

- Device class vendor-specific.
- Endpoint 1 IN bulk, endpoint 2 OUT bulk.
- Commands do not have STK500 serial framing.
- Every command receives exactly one answer.
- Short packet indicates end of command/answer.

## Address

`CMD_LOAD_ADDRESS` uses four bytes MSB first.

- Flash address is a word address.
- EEPROM address is a byte address.
- Bit 31 indicates memory larger than 64 KiB and requests Load Extended Address.

## Status

- `0x00` success
- `0x80` command timeout
- `0x81` ready/busy timeout
- `0xC0` command failed
- `0xC9` unknown command

## Official descriptor identity

- VID `0x03EB`
- PID `0x2104`
- Product string `AVRISP mkII`
