# PDI/TPI additions

USB commands use the AVRISP mkII XPROG wrapper:

- CMD_XPROG = 0x50
- CMD_XPROG_SETMODE = 0x51
- mode 0=PDI, 1=TPI
- subcommands 1 enter, 2 leave, 3 erase, 4 write, 5 read, 6 CRC, 7 set parameter

The implementation contains real physical framing (start, 8 LSB-first data bits, even parity, stop bits), PDI NVM key activation, TPI NVM key activation, raw block access, erase/write polling and USB integration.

Important: NVM controller command values and memory maps vary between device families. Verify the selected XMEGA/tinyAVR datasheet before fuse/lock writes. CRC is returned as illegal/not implemented in this revision.
