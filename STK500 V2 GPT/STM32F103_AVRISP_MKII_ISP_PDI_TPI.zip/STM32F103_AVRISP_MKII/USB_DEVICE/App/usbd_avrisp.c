#include "usbd_avrisp.h"
#include "avrisp_mkii.h"
#include "usbd_ctlreq.h"
#include <string.h>

typedef struct {
    uint8_t rx_buf[AVRISP_FS_MAX_PACKET_SIZE];
    uint8_t *tx_buf;
    uint16_t tx_len;
} USBD_AVRISP_HandleTypeDef;

static uint8_t USBD_AVRISP_Init(USBD_HandleTypeDef *pdev, uint8_t cfgidx);
static uint8_t USBD_AVRISP_DeInit(USBD_HandleTypeDef *pdev, uint8_t cfgidx);
static uint8_t USBD_AVRISP_Setup(USBD_HandleTypeDef *pdev,
                                USBD_SetupReqTypedef *req);
static uint8_t *USBD_AVRISP_GetFSCfgDesc(uint16_t *length);
static uint8_t *USBD_AVRISP_GetDeviceQualifierDescriptor(uint16_t *length);
static uint8_t USBD_AVRISP_DataIn(USBD_HandleTypeDef *pdev, uint8_t epnum);
static uint8_t USBD_AVRISP_DataOut(USBD_HandleTypeDef *pdev, uint8_t epnum);

USBD_ClassTypeDef USBD_AVRISP = {
    USBD_AVRISP_Init,
    USBD_AVRISP_DeInit,
    USBD_AVRISP_Setup,
    NULL,
    NULL,
    USBD_AVRISP_DataIn,
    USBD_AVRISP_DataOut,
    NULL,
    NULL,
    NULL,
    USBD_AVRISP_GetFSCfgDesc,
    USBD_AVRISP_GetFSCfgDesc,
    USBD_AVRISP_GetFSCfgDesc,
    USBD_AVRISP_GetDeviceQualifierDescriptor
};

__ALIGN_BEGIN static uint8_t USBD_AVRISP_CfgFSDesc[USB_AVRISP_CONFIG_DESC_SIZ]
__ALIGN_END = {
    /* Configuration */
    0x09, USB_DESC_TYPE_CONFIGURATION,
    USB_AVRISP_CONFIG_DESC_SIZ, 0x00,
    0x01, 0x01, 0x00,
    0x80, 0x32,

    /* Interface: vendor-specific */
    0x09, USB_DESC_TYPE_INTERFACE,
    0x00, 0x00, 0x02,
    0xFF, 0x00, 0x00, 0x00,

    /* Bulk IN endpoint 0x81 */
    0x07, USB_DESC_TYPE_ENDPOINT,
    AVRISP_IN_EP, 0x02,
    LOBYTE(AVRISP_FS_MAX_PACKET_SIZE),
    HIBYTE(AVRISP_FS_MAX_PACKET_SIZE),
    0x0A,

    /* Bulk OUT endpoint 0x02 */
    0x07, USB_DESC_TYPE_ENDPOINT,
    AVRISP_OUT_EP, 0x02,
    LOBYTE(AVRISP_FS_MAX_PACKET_SIZE),
    HIBYTE(AVRISP_FS_MAX_PACKET_SIZE),
    0x0A
};

__ALIGN_BEGIN static uint8_t USBD_AVRISP_DeviceQualifierDesc[10] __ALIGN_END = {
    0x0A, USB_DESC_TYPE_DEVICE_QUALIFIER,
    0x00,0x02, 0x00,0x00,0x00, 0x40, 0x01,0x00
};

static uint8_t USBD_AVRISP_Init(USBD_HandleTypeDef *pdev, uint8_t cfgidx)
{
    (void)cfgidx;
    USBD_LL_OpenEP(pdev, AVRISP_IN_EP, USBD_EP_TYPE_BULK,
                   AVRISP_FS_MAX_PACKET_SIZE);
    USBD_LL_OpenEP(pdev, AVRISP_OUT_EP, USBD_EP_TYPE_BULK,
                   AVRISP_FS_MAX_PACKET_SIZE);

    pdev->pClassData = USBD_malloc(sizeof(USBD_AVRISP_HandleTypeDef));
    if (!pdev->pClassData) return USBD_FAIL;
    memset(pdev->pClassData, 0, sizeof(USBD_AVRISP_HandleTypeDef));

    USBD_AVRISP_HandleTypeDef *h = pdev->pClassData;
    USBD_LL_PrepareReceive(pdev, AVRISP_OUT_EP, h->rx_buf,
                           AVRISP_FS_MAX_PACKET_SIZE);
    return USBD_OK;
}

static uint8_t USBD_AVRISP_DeInit(USBD_HandleTypeDef *pdev, uint8_t cfgidx)
{
    (void)cfgidx;
    USBD_LL_CloseEP(pdev, AVRISP_IN_EP);
    USBD_LL_CloseEP(pdev, AVRISP_OUT_EP);
    if (pdev->pClassData) {
        USBD_free(pdev->pClassData);
        pdev->pClassData = NULL;
    }
    return USBD_OK;
}

static uint8_t USBD_AVRISP_Setup(USBD_HandleTypeDef *pdev,
                                USBD_SetupReqTypedef *req)
{
    switch (req->bmRequest & USB_REQ_TYPE_MASK) {
        case USB_REQ_TYPE_STANDARD:
            if (req->bRequest == USB_REQ_GET_STATUS) {
                uint16_t status = 0;
                USBD_CtlSendData(pdev, (uint8_t*)&status, 2);
                return USBD_OK;
            }
            break;
        default:
            break;
    }
    USBD_CtlError(pdev, req);
    return USBD_FAIL;
}

static uint8_t USBD_AVRISP_DataOut(USBD_HandleTypeDef *pdev, uint8_t epnum)
{
    if (epnum == (AVRISP_OUT_EP & 0x7Fu)) {
        USBD_AVRISP_HandleTypeDef *h = pdev->pClassData;
        uint16_t len = (uint16_t)USBD_LL_GetRxDataSize(pdev, epnum);
        AVRISP_MKII_USB_RxPacket(h->rx_buf, len,
                                len < AVRISP_FS_MAX_PACKET_SIZE);
        USBD_LL_PrepareReceive(pdev, AVRISP_OUT_EP, h->rx_buf,
                               AVRISP_FS_MAX_PACKET_SIZE);
    }
    return USBD_OK;
}

static uint8_t USBD_AVRISP_DataIn(USBD_HandleTypeDef *pdev, uint8_t epnum)
{
    if (epnum == (AVRISP_IN_EP & 0x7Fu))
        AVRISP_MKII_USB_TxComplete();
    return USBD_OK;
}

uint8_t USBD_AVRISP_TransmitPacket(USBD_HandleTypeDef *pdev,
                                   uint8_t *buffer,
                                   uint16_t length)
{
    if (!pdev || pdev->dev_state != USBD_STATE_CONFIGURED)
        return USBD_FAIL;
    if (pdev->ep_in[AVRISP_IN_EP & 0x7Fu].is_used == 0u)
        return USBD_FAIL;

    USBD_AVRISP_HandleTypeDef *h = pdev->pClassData;
    if (!h) return USBD_FAIL;

    h->tx_buf = buffer;
    h->tx_len = length;
    return USBD_LL_Transmit(pdev, AVRISP_IN_EP, buffer, length);
}

static uint8_t *USBD_AVRISP_GetFSCfgDesc(uint16_t *length)
{
    *length = sizeof(USBD_AVRISP_CfgFSDesc);
    return USBD_AVRISP_CfgFSDesc;
}

static uint8_t *USBD_AVRISP_GetDeviceQualifierDescriptor(uint16_t *length)
{
    *length = sizeof(USBD_AVRISP_DeviceQualifierDesc);
    return USBD_AVRISP_DeviceQualifierDesc;
}
