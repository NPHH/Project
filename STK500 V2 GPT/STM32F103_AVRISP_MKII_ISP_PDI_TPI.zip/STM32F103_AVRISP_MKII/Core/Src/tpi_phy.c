#include "tpi_phy.h"
#include "main.h"

/* Default pins: PB12=TPICLK, PB13=TPIDATA, PB14=TPI_RESET_12V_EN. */
#ifndef TPI_CLK_GPIO_Port
#define TPI_CLK_GPIO_Port GPIOB
#define TPI_CLK_Pin GPIO_PIN_12
#define TPI_DATA_GPIO_Port GPIOB
#define TPI_DATA_Pin GPIO_PIN_13
#define TPI_VPP_GPIO_Port GPIOB
#define TPI_VPP_Pin GPIO_PIN_14
#endif
#define TPI_SLD      0x20u
#define TPI_SLD_PI   0x24u
#define TPI_SST      0x60u
#define TPI_SST_PI   0x64u
#define TPI_SIN(a)   (uint8_t)(0x10u|((a)&0x0Fu))
#define TPI_SOUT(a)  (uint8_t)(0x90u|((a)&0x0Fu))
#define TPI_SLDCS(a) (uint8_t)(0x80u|((a)&0x0Fu))
#define TPI_SSTCS(a) (uint8_t)(0xC0u|((a)&0x0Fu))
#define TPI_SKEY     0xE0u
#define TPI_TPIPCR   0x02u
#define TPI_TPIIR    0x0Fu
#define TPI_NVMEN_KEY 0x1289AB45CDD888FFULL
static uint32_t half_us=2u;static uint8_t nvmcmd_addr=0x33u,nvmcsr_addr=0x32u;
static void out(void){GPIO_InitTypeDef g={0};g.Pin=TPI_DATA_Pin;g.Mode=GPIO_MODE_OUTPUT_OD;g.Speed=GPIO_SPEED_FREQ_HIGH;HAL_GPIO_Init(TPI_DATA_GPIO_Port,&g);}
static void in(void){GPIO_InitTypeDef g={0};g.Pin=TPI_DATA_Pin;g.Mode=GPIO_MODE_INPUT;g.Pull=GPIO_PULLUP;HAL_GPIO_Init(TPI_DATA_GPIO_Port,&g);}
static void dly(void){extern void AVRISP_PHY_DelayUs(uint32_t);AVRISP_PHY_DelayUs(half_us);}static void clk(int v){HAL_GPIO_WritePin(TPI_CLK_GPIO_Port,TPI_CLK_Pin,v?GPIO_PIN_SET:GPIO_PIN_RESET);}static void dat(int v){HAL_GPIO_WritePin(TPI_DATA_GPIO_Port,TPI_DATA_Pin,v?GPIO_PIN_SET:GPIO_PIN_RESET);}static uint8_t parity(uint8_t v){v^=v>>4;v^=v>>2;v^=v>>1;return v&1u;}
void TPI_SetClock(uint32_t hz){if(hz<1000)hz=1000;if(hz>500000)hz=500000;half_us=(500000u+hz-1u)/hz;if(!half_us)half_us=1;}
void TPI_SetNvmRegisters(uint8_t c,uint8_t s){nvmcmd_addr=c;nvmcsr_addr=s;}
void TPI_Init(void){GPIO_InitTypeDef g={0};g.Pin=TPI_CLK_Pin|TPI_VPP_Pin;g.Mode=GPIO_MODE_OUTPUT_PP;g.Speed=GPIO_SPEED_FREQ_HIGH;HAL_GPIO_Init(GPIOB,&g);HAL_GPIO_WritePin(TPI_VPP_GPIO_Port,TPI_VPP_Pin,GPIO_PIN_RESET);in();clk(0);TPI_SetClock(250000);}
tpi_result_t TPI_Send(uint8_t v){out();dat(0);dly();clk(1);dly();clk(0);for(unsigned i=0;i<8;i++){dat((v>>i)&1);dly();clk(1);dly();clk(0);}dat(parity(v));dly();clk(1);dly();clk(0);dat(1);for(unsigned i=0;i<2;i++){dly();clk(1);dly();clk(0);}in();return TPI_OK;}
tpi_result_t TPI_Recv(uint8_t *v,uint32_t to){in();while(HAL_GPIO_ReadPin(TPI_DATA_GPIO_Port,TPI_DATA_Pin)){if(!to--)return TPI_TIMEOUT;extern void AVRISP_PHY_DelayUs(uint32_t);AVRISP_PHY_DelayUs(1);}uint8_t x=0;for(unsigned i=0;i<8;i++){dly();clk(1);if(HAL_GPIO_ReadPin(TPI_DATA_GPIO_Port,TPI_DATA_Pin))x|=1u<<i;dly();clk(0);}dly();clk(1);uint8_t p=HAL_GPIO_ReadPin(TPI_DATA_GPIO_Port,TPI_DATA_Pin)?1:0;dly();clk(0);for(unsigned i=0;i<2;i++){dly();clk(1);dly();clk(0);}if(p!=parity(x))return TPI_PARITY;*v=x;return TPI_OK;}
tpi_result_t TPI_Break(void){out();dat(0);for(unsigned i=0;i<24;i++){dly();clk(1);dly();clk(0);}dat(1);in();return TPI_OK;}
static tpi_result_t set_ptr(uint32_t a){for(unsigned i=0;i<4;i++){if(TPI_Send(TPI_SSTCS(0)))return TPI_IO;if(TPI_Send((uint8_t)(a>>(8*i))))return TPI_IO;}return TPI_OK;}
static tpi_result_t io_write(uint8_t a,uint8_t v){if(TPI_Send(TPI_SOUT(a)))return TPI_IO;return TPI_Send(v);}
static tpi_result_t io_read(uint8_t a,uint8_t *v){if(TPI_Send(TPI_SIN(a)))return TPI_IO;return TPI_Recv(v,5000);}
static tpi_result_t wait_nvm(void){for(unsigned i=0;i<30000;i++){uint8_t s;if(io_read(nvmcsr_addr,&s))return TPI_IO;if(!(s&0x80u))return TPI_OK;}return TPI_TIMEOUT;}
tpi_result_t TPI_Enter(void){/* Hardware must generate 12 V on RESET only after target VCC is stable. */HAL_GPIO_WritePin(TPI_VPP_GPIO_Port,TPI_VPP_Pin,GPIO_PIN_SET);extern void AVRISP_PHY_DelayUs(uint32_t);AVRISP_PHY_DelayUs(400);TPI_Break();TPI_Send(TPI_SKEY);uint64_t k=TPI_NVMEN_KEY;for(unsigned i=0;i<8;i++){TPI_Send((uint8_t)k);k>>=8;}for(unsigned i=0;i<1000;i++){uint8_t s=0;if(!io_read(nvmcsr_addr,&s)&&!(s&0x80u))return TPI_OK;}return TPI_TIMEOUT;}
void TPI_Leave(void){HAL_GPIO_WritePin(TPI_VPP_GPIO_Port,TPI_VPP_Pin,GPIO_PIN_RESET);in();clk(0);}
tpi_result_t TPI_ReadBlock(uint32_t a,uint8_t *d,uint16_t n){if(set_ptr(a))return TPI_IO;for(uint16_t i=0;i<n;i++){if(TPI_Send(TPI_SLD_PI))return TPI_IO;if(TPI_Recv(&d[i],5000))return TPI_IO;}return TPI_OK;}
tpi_result_t TPI_WriteBlock(uint8_t mt,uint32_t a,const uint8_t *d,uint16_t n){uint8_t cmd=(mt==1u)?0x1Du:0x1Du;if(io_write(nvmcmd_addr,cmd))return TPI_IO;if(set_ptr(a))return TPI_IO;for(uint16_t i=0;i<n;i++){if(TPI_Send(TPI_SST_PI)||TPI_Send(d[i]))return TPI_IO;if(wait_nvm())return TPI_TIMEOUT;}return TPI_OK;}
tpi_result_t TPI_Erase(uint8_t mode,uint32_t a){(void)a;uint8_t cmd=(mode==1u)?0x10u:(mode==2u?0x14u:0x1Bu);if(io_write(nvmcmd_addr,cmd))return TPI_IO;if(TPI_Send(TPI_SST)||TPI_Send(0xFFu))return TPI_IO;return wait_nvm();}
