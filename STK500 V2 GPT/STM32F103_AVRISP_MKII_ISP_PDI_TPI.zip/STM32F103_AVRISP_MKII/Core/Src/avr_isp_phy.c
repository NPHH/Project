#include "avr_isp_phy.h"
#include "main.h"

/*
 * STM32F103C8 mặc định:
 * PA5 = SCK, PA6 = MISO, PA7 = MOSI (SPI1)
 * PB0 = RESET_OUT, qua transistor/open-drain phù hợp
 * PA0 = ADC VTARGET (bộ chia áp)
 *
 * SCK nhanh: SPI1 hardware.
 * SCK chậm: bit-bang để đạt gần dải AVRISP mkII 51 Hz..8 MHz.
 */
extern SPI_HandleTypeDef hspi1;
extern ADC_HandleTypeDef hadc1;

#ifndef AVR_RESET_GPIO_Port
#define AVR_RESET_GPIO_Port GPIOB
#endif
#ifndef AVR_RESET_Pin
#define AVR_RESET_Pin GPIO_PIN_0
#endif

#ifndef AVR_SCK_GPIO_Port
#define AVR_SCK_GPIO_Port GPIOA
#endif
#ifndef AVR_SCK_Pin
#define AVR_SCK_Pin GPIO_PIN_5
#endif
#ifndef AVR_MISO_GPIO_Port
#define AVR_MISO_GPIO_Port GPIOA
#endif
#ifndef AVR_MISO_Pin
#define AVR_MISO_Pin GPIO_PIN_6
#endif
#ifndef AVR_MOSI_GPIO_Port
#define AVR_MOSI_GPIO_Port GPIOA
#endif
#ifndef AVR_MOSI_Pin
#define AVR_MOSI_Pin GPIO_PIN_7
#endif

#define STATUS_ISP_READY             0x00u
#define STATUS_CONN_FAIL_MOSI        0x01u
#define STATUS_CONN_FAIL_RST         0x02u
#define STATUS_CONN_FAIL_SCK         0x04u
#define STATUS_TGT_NOT_DETECTED      0x10u
#define STATUS_TGT_REVERSE_INSERTED  0x20u

static uint8_t g_reset_active_low = 1u;
static uint8_t g_sck_duration = 6u;
static uint32_t g_sck_hz = 125000u;
static uint8_t g_use_bitbang = 0u;
static uint32_t g_half_period_us = 4u;
static uint8_t g_protection_latched = 0u;

/* AVR069 table 6.3, index is PARAM_SCK_DURATION. */
static const uint32_t sck_table[] = {
    8000000,4000000,2000000,1000000,500000,250000,125000,
    96386,89888,84211,79208,74767,70797,67227,64000,
    61069,58395,55945,51613,49690,47905,46243,43244,
    41885,39409,38278,36200,34335,32654,31129,29740,
    28470,27304,25724,24768,23461,22285,21221,20254,
    19379,18580,17544,16913,16314,15747,15211,14706,
    14230,13780,13355,12953,12573,12214,11874,11552,
    11247,10958,10683,10423,10176,9942,9720,9509,
    9309,9119,8938,8766,8602,8446,8297,8155,
    8020,7891,7767,7649,7536,7428,7324,7225,
    7130,7039,6952,6868,6787,6709,6635,6563,
    6494,6427,6363,6301,6241,6184,6128,6075,
    6023,5973,5925,5878,5833,5789,5747,5706,
    5667,5628,5591,5555,5520,5486,5453,5421,
    5390,5360,5331,5302,5275,5248,5222,5196,
    5172,5148,5124,5101,5079,5057,5036,5015,
    4995,4975,4956,4937,4919,4901,4883,4866,
    4849,4833,4817,4801,4785,4770,4755,4741,
    4726,4712,4699,4685,4672,4659,4646,4634,
    4621,4609,4597,4586,4574,4563,4552,4541,
    4530,4519,4509,4499,4488,4478,4468,4459,
    4449,4439,4430,4421,4412,4403,4394,4385,
    4377,4368,4360,4352,4344,4336,4328,4320,
    4312,4305,4297,4290,4282,4275,4268,4261,
    4254,4247,4240,4233,4227,4220,4213,4207,
    4200,4194,4188,4182,4176,4170,4164,4158,
    4152,4146,4141,4135,4129,4124,4118,4113,
    4108,4102,4097,4092,4087,4082,4077,4072,
    4067,4062,4057,4053,4048,4043,4039,4034,
    4030,4025,4021,4016,4012,4008,4004,4000,
    2000,1000,500,250,125,100,50
};

static void gpio_spi_mode(void)
{
    GPIO_InitTypeDef gi = {0};

    HAL_SPI_DeInit(&hspi1);

    gi.Pin = AVR_SCK_Pin | AVR_MOSI_Pin;
    gi.Mode = GPIO_MODE_OUTPUT_PP;
    gi.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &gi);

    gi.Pin = AVR_MISO_Pin;
    gi.Mode = GPIO_MODE_INPUT;
    gi.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &gi);

    HAL_GPIO_WritePin(AVR_SCK_GPIO_Port, AVR_SCK_Pin, GPIO_PIN_RESET);
}

static void hardware_spi_mode(uint32_t requested_hz)
{
    uint32_t pclk = HAL_RCC_GetPCLK2Freq();
    uint32_t divs[8] = {2,4,8,16,32,64,128,256};
    uint32_t brs[8] = {
        SPI_BAUDRATEPRESCALER_2, SPI_BAUDRATEPRESCALER_4,
        SPI_BAUDRATEPRESCALER_8, SPI_BAUDRATEPRESCALER_16,
        SPI_BAUDRATEPRESCALER_32, SPI_BAUDRATEPRESCALER_64,
        SPI_BAUDRATEPRESCALER_128, SPI_BAUDRATEPRESCALER_256
    };
    uint32_t selected = SPI_BAUDRATEPRESCALER_256;

    for (unsigned i = 0; i < 8; ++i) {
        if ((pclk / divs[i]) <= requested_hz) {
            selected = brs[i];
            break;
        }
    }

    hspi1.Init.Mode = SPI_MODE_MASTER;
    hspi1.Init.Direction = SPI_DIRECTION_2LINES;
    hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
    hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
    hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
    hspi1.Init.NSS = SPI_NSS_SOFT;
    hspi1.Init.BaudRatePrescaler = selected;
    hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
    hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
    hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
    hspi1.Init.CRCPolynomial = 7;
    (void)HAL_SPI_Init(&hspi1);
}

void AVRISP_PHY_DelayUs(uint32_t us)
{
    uint32_t cycles = (SystemCoreClock / 1000000u) * us;
    if ((DWT->CTRL & DWT_CTRL_CYCCNTENA_Msk) == 0u) {
        CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
        DWT->CYCCNT = 0u;
        DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
    }
    uint32_t start = DWT->CYCCNT;
    while ((uint32_t)(DWT->CYCCNT - start) < cycles) {}
}

void AVRISP_PHY_DelayMs(uint32_t ms) { HAL_Delay(ms); }

void AVRISP_PHY_SetResetPolarity(uint8_t avr_active_low)
{
    g_reset_active_low = avr_active_low ? 1u : 0u;
}

void AVRISP_PHY_SetReset(bool asserted)
{
    GPIO_PinState state;
    if (g_reset_active_low)
        state = asserted ? GPIO_PIN_RESET : GPIO_PIN_SET;
    else
        state = asserted ? GPIO_PIN_SET : GPIO_PIN_RESET;
    HAL_GPIO_WritePin(AVR_RESET_GPIO_Port, AVR_RESET_Pin, state);
}

void AVRISP_PHY_SetSckDuration(uint8_t duration)
{
    g_sck_duration = duration;
    uint32_t n = sizeof(sck_table) / sizeof(sck_table[0]);
    uint32_t idx = duration;
    if (idx >= n) idx = n - 1u;
    g_sck_hz = sck_table[idx];

    /*
     * SPI1 /256 tại 72 MHz = 281.25 kHz.
     * Dùng hardware khi yêu cầu >= 281 kHz, bit-bang khi thấp hơn.
     */
    if (g_sck_hz >= (HAL_RCC_GetPCLK2Freq() / 256u)) {
        g_use_bitbang = 0u;
        hardware_spi_mode(g_sck_hz);
    } else {
        g_use_bitbang = 1u;
        g_half_period_us = (500000u + g_sck_hz - 1u) / g_sck_hz;
        if (g_half_period_us == 0u) g_half_period_us = 1u;
        gpio_spi_mode();
    }
}

uint8_t AVRISP_PHY_GetSckDuration(void) { return g_sck_duration; }
uint32_t AVRISP_PHY_GetSckHz(void) { return g_sck_hz; }

static uint8_t bitbang_transfer(uint8_t value)
{
    uint8_t rx = 0u;
    for (int bit = 7; bit >= 0; --bit) {
        HAL_GPIO_WritePin(AVR_MOSI_GPIO_Port, AVR_MOSI_Pin,
                          (value & (1u << bit)) ? GPIO_PIN_SET : GPIO_PIN_RESET);
        AVRISP_PHY_DelayUs(g_half_period_us);
        HAL_GPIO_WritePin(AVR_SCK_GPIO_Port, AVR_SCK_Pin, GPIO_PIN_SET);
        rx <<= 1;
        if (HAL_GPIO_ReadPin(AVR_MISO_GPIO_Port, AVR_MISO_Pin) == GPIO_PIN_SET)
            rx |= 1u;
        AVRISP_PHY_DelayUs(g_half_period_us);
        HAL_GPIO_WritePin(AVR_SCK_GPIO_Port, AVR_SCK_Pin, GPIO_PIN_RESET);
    }
    return rx;
}

uint8_t AVRISP_PHY_Transfer(uint8_t value)
{
    if (g_use_bitbang)
        return bitbang_transfer(value);

    uint8_t rx = 0xFFu;
    if (HAL_SPI_TransmitReceive(&hspi1, &value, &rx, 1u, 100u) != HAL_OK)
        return 0xFFu;
    return rx;
}

bool AVRISP_PHY_Transfer4(const uint8_t tx[4], uint8_t rx[4])
{
    for (unsigned i = 0; i < 4; ++i)
        rx[i] = AVRISP_PHY_Transfer(tx[i]);
    return true;
}

uint16_t AVRISP_PHY_ReadTargetMillivolts(void)
{
    /*
     * CubeMX ADC PA0. Bộ chia mặc định 47k/47k:
     * VTARGET = ADC * 3300 / 4095 * 2.
     * Hiệu chỉnh hệ số theo mạch thực tế.
     */
    if (HAL_ADC_Start(&hadc1) != HAL_OK)
        return 0u;
    if (HAL_ADC_PollForConversion(&hadc1, 10u) != HAL_OK)
        return 0u;
    uint32_t raw = HAL_ADC_GetValue(&hadc1);
    (void)HAL_ADC_Stop(&hadc1);
    return (uint16_t)((raw * 6600u + 2047u) / 4095u);
}

uint8_t AVRISP_PHY_GetConnectionStatus(void)
{
    uint16_t mv = AVRISP_PHY_ReadTargetMillivolts();
    if (mv < 1600u)
        return STATUS_TGT_NOT_DETECTED;
    if (g_protection_latched)
        return STATUS_CONN_FAIL_RST;
    return STATUS_ISP_READY;
}

void AVRISP_PHY_ResetProtection(void)
{
    g_protection_latched = 0u;
}

void AVRISP_PHY_Init(void)
{
    AVRISP_PHY_SetResetPolarity(1u);
    AVRISP_PHY_SetReset(false);
    AVRISP_PHY_SetSckDuration(g_sck_duration);
}

void AVRISP_PHY_Task(void) {}
