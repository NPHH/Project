#include "pdi_phy.h"
#include "main.h"

/* Default pins: PB10=PDI_CLK, PB11=PDI_DATA. DATA is half-duplex. */
#ifndef PDI_CLK_GPIO_Port
#define PDI_CLK_GPIO_Port GPIOB
#define PDI_CLK_Pin GPIO_PIN_10
#endif
#ifndef PDI_DATA_GPIO_Port
#define PDI_DATA_GPIO_Port GPIOB
#define PDI_DATA_Pin GPIO_PIN_11
#endif

#define PDI_LDS(a,d)   (uint8_t)(0x00u|(((a)-1u)<<2)|((d)-1u))
#define PDI_LD(m,d)    (uint8_t)(0x20u|((m)<<2)|((d)-1u))
#define PDI_STS(a,d)   (uint8_t)(0x40u|(((a)-1u)<<2)|((d)-1u))
#define PDI_ST(m,d)    (uint8_t)(0x60u|((m)<<2)|((d)-1u))
#define PDI_LDCS(r)    (uint8_t)(0x80u|((r)&0x0Fu))
#define PDI_REPEAT(d)  (uint8_t)(0xA0u|((d)-1u))
#define PDI_STCS(r)    (uint8_t)(0xC0u|((r)&0x0Fu))
#define PDI_KEY        0xE0u
#define PDI_PTR_DIRECT 0u
#define PDI_PTR_PI     1u
#define PDI_CS_STATUS  0u
#define PDI_CS_RESET   1u
#define PDI_CS_CTRL    2u
#define PDI_STATUS_NVMEN 0x02u

#define XMEGA_NVM_BASE       0x010001C0u
#define XMEGA_NVM_CMD        (XMEGA_NVM_BASE + 0x0Au)
#define XMEGA_NVM_STATUS     (XMEGA_NVM_BASE + 0x0Fu)
#define XMEGA_NVM_CHIP_ERASE 0x40u

static uint32_t half_us=1u;
static const uint8_t nvm_key[8]={0xFF,0x88,0xD8,0xCD,0x45,0xAB,0x89,0x12};

static void data_output(void){GPIO_InitTypeDef g={0};g.Pin=PDI_DATA_Pin;g.Mode=GPIO_MODE_OUTPUT_OD;g.Speed=GPIO_SPEED_FREQ_HIGH;HAL_GPIO_Init(PDI_DATA_GPIO_Port,&g);}
static void data_input(void){GPIO_InitTypeDef g={0};g.Pin=PDI_DATA_Pin;g.Mode=GPIO_MODE_INPUT;g.Pull=GPIO_PULLUP;HAL_GPIO_Init(PDI_DATA_GPIO_Port,&g);}
static void delay_half(void){extern void AVRISP_PHY_DelayUs(uint32_t);AVRISP_PHY_DelayUs(half_us);}
static void clk(int v){HAL_GPIO_WritePin(PDI_CLK_GPIO_Port,PDI_CLK_Pin,v?GPIO_PIN_SET:GPIO_PIN_RESET);}
static void dat(int v){HAL_GPIO_WritePin(PDI_DATA_GPIO_Port,PDI_DATA_Pin,v?GPIO_PIN_SET:GPIO_PIN_RESET);}

void PDI_SetClock(uint32_t hz){if(hz<10000u)hz=10000u;if(hz>1000000u)hz=1000000u;half_us=(500000u+hz-1u)/hz;if(!half_us)half_us=1u;}
void PDI_Init(void){GPIO_InitTypeDef g={0};g.Pin=PDI_CLK_Pin;g.Mode=GPIO_MODE_OUTPUT_PP;g.Speed=GPIO_SPEED_FREQ_HIGH;HAL_GPIO_Init(PDI_CLK_GPIO_Port,&g);data_input();clk(0);PDI_SetClock(500000u);}
static uint8_t parity8(uint8_t v){v^=v>>4;v^=v>>2;v^=v>>1;return v&1u;}

pdi_result_t PDI_Send(uint8_t value){data_output();dat(0);delay_half();clk(1);delay_half();clk(0);for(unsigned i=0;i<8;i++){dat((value>>i)&1u);delay_half();clk(1);delay_half();clk(0);}dat(parity8(value));delay_half();clk(1);delay_half();clk(0);dat(1);for(unsigned s=0;s<2;s++){delay_half();clk(1);delay_half();clk(0);}data_input();return PDI_OK;}
pdi_result_t PDI_Recv(uint8_t *value,uint32_t timeout_us){data_input();while(HAL_GPIO_ReadPin(PDI_DATA_GPIO_Port,PDI_DATA_Pin)==GPIO_PIN_SET){if(!timeout_us--)return PDI_TIMEOUT;extern void AVRISP_PHY_DelayUs(uint32_t);AVRISP_PHY_DelayUs(1);}uint8_t v=0;for(unsigned i=0;i<8;i++){delay_half();clk(1);if(HAL_GPIO_ReadPin(PDI_DATA_GPIO_Port,PDI_DATA_Pin))v|=(1u<<i);delay_half();clk(0);}delay_half();clk(1);uint8_t p=HAL_GPIO_ReadPin(PDI_DATA_GPIO_Port,PDI_DATA_Pin)?1u:0u;delay_half();clk(0);for(unsigned s=0;s<2;s++){delay_half();clk(1);delay_half();clk(0);}if(p!=parity8(v))return PDI_PARITY;*value=v;return PDI_OK;}
pdi_result_t PDI_Break(void){data_output();dat(0);for(unsigned i=0;i<24;i++){delay_half();clk(1);delay_half();clk(0);}dat(1);data_input();return PDI_OK;}
static pdi_result_t send32(uint32_t v){for(unsigned i=0;i<4;i++){pdi_result_t r=PDI_Send((uint8_t)v);if(r)return r;v>>=8;}return PDI_OK;}
static pdi_result_t sts8(uint32_t a,uint8_t v){pdi_result_t r=PDI_Send(PDI_STS(4,1));if(r)return r;if((r=send32(a)))return r;return PDI_Send(v);}
static pdi_result_t lds8(uint32_t a,uint8_t *v){pdi_result_t r=PDI_Send(PDI_LDS(4,1));if(r)return r;if((r=send32(a)))return r;return PDI_Recv(v,5000);}
static pdi_result_t wait_nvm(void){for(unsigned i=0;i<20000;i++){uint8_t s=0;pdi_result_t r=lds8(XMEGA_NVM_STATUS,&s);if(r)return r;if(!(s&0x80u))return PDI_OK;}return PDI_TIMEOUT;}

pdi_result_t PDI_Enter(void){PDI_Break();PDI_Send(PDI_KEY);for(unsigned i=0;i<8;i++)if(PDI_Send(nvm_key[i]))return PDI_IO;for(unsigned i=0;i<1000;i++){uint8_t s=0;PDI_Send(PDI_LDCS(PDI_CS_STATUS));if(PDI_Recv(&s,5000))continue;if(s&PDI_STATUS_NVMEN)return PDI_OK;}return PDI_TIMEOUT;}
void PDI_Leave(void){PDI_Send(PDI_STCS(PDI_CS_RESET));PDI_Send(0x00u);data_input();clk(0);}
pdi_result_t PDI_ReadBlock(uint32_t address,uint8_t *data,uint16_t length){for(uint16_t i=0;i<length;i++){pdi_result_t r=lds8(address+i,&data[i]);if(r)return r;}return PDI_OK;}
pdi_result_t PDI_WriteBlock(uint32_t address,const uint8_t *data,uint16_t length){/* Raw data-space writes; XPROG host selects NVM mapped address/commands. */for(uint16_t i=0;i<length;i++){pdi_result_t r=sts8(address+i,data[i]);if(r)return r;}return wait_nvm();}
pdi_result_t PDI_ChipErase(void){pdi_result_t r=sts8(XMEGA_NVM_CMD,XMEGA_NVM_CHIP_ERASE);if(r)return r;PDI_Send(PDI_ST(PDI_PTR_DIRECT,1));PDI_Send(0x00u);return wait_nvm();}
pdi_result_t PDI_Erase(uint8_t mode,uint32_t address){if(mode==1u)return PDI_ChipErase();(void)address;return PDI_IO;}
