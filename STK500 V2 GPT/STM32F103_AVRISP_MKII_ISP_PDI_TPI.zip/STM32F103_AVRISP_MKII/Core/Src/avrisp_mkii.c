#include "avrisp_mkii.h"
#include "avr_isp_phy.h"
#include "usbd_avrisp.h"
#include "xprog.h"
#include "usb_device.h"
#include <string.h>

/* AVR069 command IDs */
#define CMD_SIGN_ON                 0x01u
#define CMD_SET_PARAMETER           0x02u
#define CMD_GET_PARAMETER           0x03u
#define CMD_OSCCAL                  0x05u
#define CMD_LOAD_ADDRESS            0x06u
#define CMD_FIRMWARE_UPGRADE        0x07u
#define CMD_RESET_PROTECTION        0x0Au

#define CMD_ENTER_PROGMODE_ISP      0x10u
#define CMD_LEAVE_PROGMODE_ISP      0x11u
#define CMD_CHIP_ERASE_ISP          0x12u
#define CMD_PROGRAM_FLASH_ISP       0x13u
#define CMD_READ_FLASH_ISP          0x14u
#define CMD_PROGRAM_EEPROM_ISP      0x15u
#define CMD_READ_EEPROM_ISP         0x16u
#define CMD_PROGRAM_FUSE_ISP        0x17u
#define CMD_READ_FUSE_ISP           0x18u
#define CMD_PROGRAM_LOCK_ISP        0x19u
#define CMD_READ_LOCK_ISP           0x1Au
#define CMD_READ_SIGNATURE_ISP      0x1Bu
#define CMD_READ_OSCCAL_ISP         0x1Cu
#define CMD_SPI_MULTI               0x1Du

#define STATUS_CMD_OK               0x00u
#define STATUS_CMD_TOUT             0x80u
#define STATUS_RDY_BSY_TOUT         0x81u
#define STATUS_SET_PARAM_MISSING    0x82u
#define STATUS_CMD_FAILED           0xC0u
#define STATUS_CMD_UNKNOWN          0xC9u

#define PARAM_BUILD_NUMBER_LOW      0x80u
#define PARAM_BUILD_NUMBER_HIGH     0x81u
#define PARAM_HW_VER                0x90u
#define PARAM_SW_MAJOR              0x91u
#define PARAM_SW_MINOR              0x92u
#define PARAM_VTARGET               0x94u
#define PARAM_SCK_DURATION          0x98u
#define PARAM_RESET_POLARITY        0x9Eu
#define PARAM_STATUS_TGT_CONN       0xA1u
#define PARAM_DISCHARGEDELAY        0xA4u

extern USBD_HandleTypeDef hUsbDeviceFS;

typedef struct {
    uint8_t data[AVRISP_USB_MESSAGE_MAX];
    uint16_t len;
} usb_message_t;

#define RX_QUEUE_DEPTH 3u
#define TX_QUEUE_DEPTH 3u

static usb_message_t rxq[RX_QUEUE_DEPTH];
static volatile uint8_t rx_r, rx_w, rx_count;
static usb_message_t txq[TX_QUEUE_DEPTH];
static volatile uint8_t tx_r, tx_w, tx_count;
static volatile uint8_t tx_busy;

static uint8_t assembling[AVRISP_USB_MESSAGE_MAX];
static uint16_t assembling_len;
static uint8_t rx_overflow;

static uint32_t current_address;
static uint8_t address_is_extended;
static uint8_t parameters[256];
static uint8_t in_progmode;
static uint8_t last_ext_addr = 0xFFu;

static uint8_t response[AVRISP_USB_MESSAGE_MAX];

static uint16_t be16(const uint8_t *p)
{
    return ((uint16_t)p[0] << 8) | p[1];
}

static void tx_enqueue(const uint8_t *data, uint16_t len)
{
    if (len > AVRISP_USB_MESSAGE_MAX || tx_count >= TX_QUEUE_DEPTH)
        return;

    memcpy(txq[tx_w].data, data, len);
    txq[tx_w].len = len;
    tx_w = (uint8_t)((tx_w + 1u) % TX_QUEUE_DEPTH);
    __disable_irq();
    ++tx_count;
    __enable_irq();
}

static void tx_task(void)
{
    if (tx_busy || tx_count == 0u)
        return;

    tx_busy = 1u;
    if (USBD_AVRISP_TransmitPacket(&hUsbDeviceFS,
                                   txq[tx_r].data,
                                   txq[tx_r].len) != USBD_OK) {
        tx_busy = 0u;
    }
}

void AVRISP_MKII_USB_TxComplete(void)
{
    if (tx_count) {
        tx_r = (uint8_t)((tx_r + 1u) % TX_QUEUE_DEPTH);
        --tx_count;
    }
    tx_busy = 0u;
}

void AVRISP_MKII_USB_RxPacket(const uint8_t *data,
                              uint16_t length,
                              bool short_packet)
{
    if ((uint32_t)assembling_len + length > AVRISP_USB_MESSAGE_MAX) {
        rx_overflow = 1u;
    } else if (!rx_overflow && length) {
        memcpy(&assembling[assembling_len], data, length);
        assembling_len += length;
    }

    if (short_packet) {
        if (!rx_overflow && assembling_len && rx_count < RX_QUEUE_DEPTH) {
            memcpy(rxq[rx_w].data, assembling, assembling_len);
            rxq[rx_w].len = assembling_len;
            rx_w = (uint8_t)((rx_w + 1u) % RX_QUEUE_DEPTH);
            ++rx_count;
        }
        assembling_len = 0u;
        rx_overflow = 0u;
    }
}

static void reply2(uint8_t cmd, uint8_t status)
{
    response[0] = cmd;
    response[1] = status;
    tx_enqueue(response, 2u);
}

static uint8_t get_parameter(uint8_t id, uint8_t *ok)
{
    *ok = 1u;
    switch (id) {
        case PARAM_BUILD_NUMBER_LOW:  return 0x34u;
        case PARAM_BUILD_NUMBER_HIGH: return 0x12u;
        case PARAM_HW_VER:            return 1u;
        case PARAM_SW_MAJOR:          return 1u;
        case PARAM_SW_MINOR:          return 18u;
        case PARAM_VTARGET:
            return (uint8_t)((AVRISP_PHY_ReadTargetMillivolts() + 50u) / 100u);
        case PARAM_SCK_DURATION:      return AVRISP_PHY_GetSckDuration();
        case PARAM_RESET_POLARITY:    return parameters[id];
        case PARAM_STATUS_TGT_CONN:   return AVRISP_PHY_GetConnectionStatus();
        case PARAM_DISCHARGEDELAY:    return parameters[id];
        default:
            *ok = 0u;
            return 0u;
    }
}

static uint8_t set_parameter(uint8_t id, uint8_t value)
{
    switch (id) {
        case PARAM_SCK_DURATION:
            parameters[id] = value;
            AVRISP_PHY_SetSckDuration(value);
            return STATUS_CMD_OK;

        case PARAM_RESET_POLARITY:
            parameters[id] = value;
            AVRISP_PHY_SetResetPolarity(value);
            return STATUS_CMD_OK;

        case PARAM_DISCHARGEDELAY:
            parameters[id] = value;
            return STATUS_CMD_OK;

        default:
            return STATUS_CMD_FAILED;
    }
}

static void set_extended_address(uint32_t word_addr)
{
    if (!address_is_extended)
        return;
    uint8_t ext = (uint8_t)(word_addr >> 16);
    if (ext != last_ext_addr) {
        uint8_t tx[4] = {0x4Du, 0x00u, ext, 0x00u};
        uint8_t rx[4];
        AVRISP_PHY_Transfer4(tx, rx);
        last_ext_addr = ext;
    }
}

static uint8_t wait_ready_busy(uint16_t timeout_ms)
{
    uint32_t start = HAL_GetTick();
    do {
        uint8_t tx[4] = {0xF0u,0,0,0};
        uint8_t rx[4];
        AVRISP_PHY_Transfer4(tx, rx);
        if ((rx[3] & 0x01u) == 0u)
            return STATUS_CMD_OK;
    } while ((HAL_GetTick() - start) < timeout_ms);
    return STATUS_RDY_BSY_TOUT;
}

static uint8_t poll_memory_value(uint8_t read_opcode,
                                 uint32_t address,
                                 uint8_t high_byte,
                                 uint8_t expected,
                                 uint16_t timeout_ms)
{
    uint32_t start = HAL_GetTick();
    do {
        uint8_t tx[4] = {
            (uint8_t)(read_opcode | (high_byte ? 0x08u : 0u)),
            (uint8_t)(address >> 8),
            (uint8_t)address,
            0u
        };
        uint8_t rx[4];
        AVRISP_PHY_Transfer4(tx, rx);
        if (rx[3] == expected)
            return STATUS_CMD_OK;
    } while ((HAL_GetTick() - start) < timeout_ms);
    return STATUS_CMD_TOUT;
}

static void cmd_sign_on(void)
{
    static const uint8_t sig[] = "AVRISP_MK2";
    response[0] = CMD_SIGN_ON;
    response[1] = STATUS_CMD_OK;
    response[2] = 10u;
    memcpy(&response[3], sig, 10u);
    tx_enqueue(response, 13u);
}

static void cmd_enter(const uint8_t *p, uint16_t n)
{
    if (n < 12u) { reply2(CMD_ENTER_PROGMODE_ISP, STATUS_CMD_FAILED); return; }

    uint8_t timeout = p[1], stab = p[2], cmdexe = p[3];
    uint8_t loops = p[4], byte_delay = p[5];
    uint8_t poll_value = p[6], poll_index = p[7];

    if (AVRISP_PHY_GetConnectionStatus() != 0u) {
        reply2(CMD_ENTER_PROGMODE_ISP, STATUS_CMD_FAILED);
        return;
    }

    AVRISP_PHY_SetReset(false);
    AVRISP_PHY_DelayMs(stab);
    AVRISP_PHY_SetReset(true);
    AVRISP_PHY_DelayMs(cmdexe);
    if (!loops) loops = 1u;

    uint32_t started = HAL_GetTick();
    uint8_t ok = 0u;
    for (uint8_t attempt = 0; attempt < loops; ++attempt) {
        uint8_t rx[4];
        for (uint8_t i = 0; i < 4u; ++i) {
            rx[i] = AVRISP_PHY_Transfer(p[8u+i]);
            if (byte_delay) AVRISP_PHY_DelayMs(byte_delay);
        }

        /* AVR069 pollIndex is one-based; 0 means no polling. */
        if (poll_index == 0u ||
            (poll_index <= 4u && rx[poll_index-1u] == poll_value)) {
            ok = 1u;
            break;
        }

        AVRISP_PHY_SetReset(false);
        AVRISP_PHY_DelayMs(2u);
        AVRISP_PHY_SetReset(true);
        AVRISP_PHY_DelayMs(20u);

        if ((HAL_GetTick() - started) >= timeout)
            break;
    }

    in_progmode = ok;
    reply2(CMD_ENTER_PROGMODE_ISP,
           ok ? STATUS_CMD_OK : STATUS_CMD_FAILED);
}

static void cmd_leave(const uint8_t *p, uint16_t n)
{
    if (n < 3u) { reply2(CMD_LEAVE_PROGMODE_ISP, STATUS_CMD_FAILED); return; }
    AVRISP_PHY_DelayMs(p[1]);
    AVRISP_PHY_SetReset(false);
    AVRISP_PHY_DelayMs(p[2]);
    in_progmode = 0u;
    last_ext_addr = 0xFFu;
    reply2(CMD_LEAVE_PROGMODE_ISP, STATUS_CMD_OK);
}

static void cmd_chip_erase(const uint8_t *p, uint16_t n)
{
    if (n < 7u || !in_progmode) {
        reply2(CMD_CHIP_ERASE_ISP, STATUS_CMD_FAILED); return;
    }
    uint8_t erase_delay = p[1];
    uint8_t poll_method = p[2];
    uint8_t rx[4];
    AVRISP_PHY_Transfer4(&p[3], rx);

    uint8_t st;
    if (poll_method == 0u) {
        AVRISP_PHY_DelayMs(erase_delay);
        st = STATUS_CMD_OK;
    } else {
        st = wait_ready_busy(erase_delay ? erase_delay : 100u);
    }
    reply2(CMD_CHIP_ERASE_ISP, st);
}

static void cmd_program_flash(const uint8_t *p, uint16_t n)
{
    if (n < 10u || !in_progmode) {
        reply2(CMD_PROGRAM_FLASH_ISP, STATUS_CMD_FAILED); return;
    }

    uint16_t count = be16(&p[1]);
    if ((uint32_t)count + 10u > n) {
        reply2(CMD_PROGRAM_FLASH_ISP, STATUS_CMD_FAILED); return;
    }

    uint8_t mode = p[3];
    uint8_t delay = p[4];
    uint8_t cmd_load = p[5];
    uint8_t cmd_write = p[6];
    uint8_t cmd_read = p[7];
    uint8_t poll1 = p[8];
    uint8_t poll2 = p[9];
    (void)poll2;

    uint32_t start_word = current_address & 0x7FFFFFFFu;
    uint32_t word = start_word;

    for (uint16_t i = 0; i < count; ++i) {
        uint8_t hi = (uint8_t)(i & 1u);
        set_extended_address(word);
        uint8_t tx[4] = {
            (uint8_t)(cmd_load | (hi ? 0x08u : 0u)),
            (uint8_t)(word >> 8),
            (uint8_t)word,
            p[10u+i]
        };
        uint8_t rx[4];
        AVRISP_PHY_Transfer4(tx, rx);
        if (hi) ++word;
    }

    uint8_t st = STATUS_CMD_OK;
    if (mode & 0x80u) {
        set_extended_address(start_word);
        uint8_t tx[4] = {
            cmd_write,
            (uint8_t)(start_word >> 8),
            (uint8_t)start_word,
            0
        };
        uint8_t rx[4];
        AVRISP_PHY_Transfer4(tx, rx);

        if (mode & 0x20u) {
            AVRISP_PHY_DelayMs(delay);
        } else if (mode & 0x40u) {
            /* Value polling on first byte of page. */
            st = poll_memory_value(cmd_read, start_word, 0u, poll1,
                                   delay ? delay : 100u);
        } else {
            st = wait_ready_busy(delay ? delay : 100u);
        }
    }

    current_address = (current_address & 0x80000000u) | word;
    reply2(CMD_PROGRAM_FLASH_ISP, st);
}

static void cmd_read_flash(const uint8_t *p, uint16_t n)
{
    if (n < 4u || !in_progmode) {
        reply2(CMD_READ_FLASH_ISP, STATUS_CMD_FAILED); return;
    }
    uint16_t count = be16(&p[1]);
    if ((uint32_t)count + 3u > AVRISP_USB_MESSAGE_MAX) {
        reply2(CMD_READ_FLASH_ISP, STATUS_CMD_FAILED); return;
    }

    uint8_t read_opcode = p[3];
    uint32_t word = current_address & 0x7FFFFFFFu;
    response[0] = CMD_READ_FLASH_ISP;
    response[1] = STATUS_CMD_OK;

    for (uint16_t i = 0; i < count; ++i) {
        uint8_t hi = (uint8_t)(i & 1u);
        set_extended_address(word);
        uint8_t tx[4] = {
            (uint8_t)(read_opcode | (hi ? 0x08u : 0u)),
            (uint8_t)(word >> 8),
            (uint8_t)word,
            0
        };
        uint8_t rx[4];
        AVRISP_PHY_Transfer4(tx, rx);
        response[2u+i] = rx[3];
        if (hi) ++word;
    }
    response[2u+count] = STATUS_CMD_OK;
    current_address = (current_address & 0x80000000u) | word;
    tx_enqueue(response, count + 3u);
}

static void cmd_program_eeprom(const uint8_t *p, uint16_t n)
{
    if (n < 10u || !in_progmode) {
        reply2(CMD_PROGRAM_EEPROM_ISP, STATUS_CMD_FAILED); return;
    }
    uint16_t count = be16(&p[1]);
    if ((uint32_t)count + 10u > n) {
        reply2(CMD_PROGRAM_EEPROM_ISP, STATUS_CMD_FAILED); return;
    }

    uint8_t mode = p[3], delay = p[4], write_op = p[5], read_op = p[7];
    uint8_t poll1 = p[8], poll2 = p[9];
    uint32_t addr = current_address & 0x7FFFFFFFu;
    uint8_t st = STATUS_CMD_OK;

    for (uint16_t i = 0; i < count; ++i, ++addr) {
        uint8_t tx[4] = {
            write_op, (uint8_t)(addr >> 8), (uint8_t)addr, p[10u+i]
        };
        uint8_t rx[4];
        AVRISP_PHY_Transfer4(tx, rx);

        if (mode & 0x20u) {
            AVRISP_PHY_DelayMs(delay);
        } else if (mode & 0x40u) {
            uint8_t expected = (p[10u+i] == poll1) ? poll2 : poll1;
            st = poll_memory_value(read_op, addr, 0u, expected,
                                   delay ? delay : 50u);
        } else {
            st = wait_ready_busy(delay ? delay : 50u);
        }
        if (st != STATUS_CMD_OK) break;
    }

    current_address = (current_address & 0x80000000u) | addr;
    reply2(CMD_PROGRAM_EEPROM_ISP, st);
}

static void cmd_read_eeprom(const uint8_t *p, uint16_t n)
{
    if (n < 4u || !in_progmode) {
        reply2(CMD_READ_EEPROM_ISP, STATUS_CMD_FAILED); return;
    }
    uint16_t count = be16(&p[1]);
    if ((uint32_t)count + 3u > AVRISP_USB_MESSAGE_MAX) {
        reply2(CMD_READ_EEPROM_ISP, STATUS_CMD_FAILED); return;
    }

    uint8_t read_op = p[3];
    uint32_t addr = current_address & 0x7FFFFFFFu;
    response[0] = CMD_READ_EEPROM_ISP;
    response[1] = STATUS_CMD_OK;

    for (uint16_t i = 0; i < count; ++i, ++addr) {
        uint8_t tx[4] = {
            read_op, (uint8_t)(addr >> 8), (uint8_t)addr, 0
        };
        uint8_t rx[4];
        AVRISP_PHY_Transfer4(tx, rx);
        response[2u+i] = rx[3];
    }
    response[2u+count] = STATUS_CMD_OK;
    current_address = (current_address & 0x80000000u) | addr;
    tx_enqueue(response, count + 3u);
}

static void cmd_program_misc(uint8_t cmd, const uint8_t *p, uint16_t n)
{
    if (n < 5u || !in_progmode) {
        reply2(cmd, STATUS_CMD_FAILED); return;
    }
    uint8_t rx[4];
    AVRISP_PHY_Transfer4(&p[1], rx);
    reply2(cmd, STATUS_CMD_OK);
}

static void cmd_read_misc(uint8_t cmd, const uint8_t *p, uint16_t n)
{
    if (n < 6u || !in_progmode) {
        reply2(cmd, STATUS_CMD_FAILED); return;
    }
    uint8_t ret_index = p[1];
    uint8_t rx[4];
    AVRISP_PHY_Transfer4(&p[2], rx);
    response[0] = cmd;
    response[1] = STATUS_CMD_OK;
    response[2] = ret_index < 4u ? rx[ret_index] : 0u;
    response[3] = STATUS_CMD_OK;
    tx_enqueue(response, 4u);
}

static void cmd_spi_multi(const uint8_t *p, uint16_t n)
{
    if (n < 4u || !in_progmode) {
        reply2(CMD_SPI_MULTI, STATUS_CMD_FAILED); return;
    }
    uint8_t tx_count_bytes = p[1];
    uint8_t rx_count_bytes = p[2];
    uint8_t rx_start = p[3];
    if ((uint16_t)tx_count_bytes + 4u > n ||
        (uint16_t)rx_count_bytes + 3u > AVRISP_USB_MESSAGE_MAX) {
        reply2(CMD_SPI_MULTI, STATUS_CMD_FAILED); return;
    }

    uint8_t bus_rx[255];
    uint16_t total = tx_count_bytes;
    if ((uint16_t)rx_start + rx_count_bytes > total)
        total = (uint16_t)rx_start + rx_count_bytes;

    for (uint16_t i = 0; i < total; ++i) {
        uint8_t out = i < tx_count_bytes ? p[4u+i] : 0u;
        bus_rx[i] = AVRISP_PHY_Transfer(out);
    }

    response[0] = CMD_SPI_MULTI;
    response[1] = STATUS_CMD_OK;
    for (uint16_t i = 0; i < rx_count_bytes; ++i)
        response[2u+i] = bus_rx[(uint16_t)rx_start+i];
    response[2u+rx_count_bytes] = STATUS_CMD_OK;
    tx_enqueue(response, rx_count_bytes + 3u);
}

static void dispatch(const uint8_t *p, uint16_t n)
{
    if (!n) return;

    { uint16_t xrlen=0; if (XPROG_Handle(p,n,response,&xrlen)) { tx_enqueue(response,xrlen); return; } }

    switch (p[0]) {
        case CMD_SIGN_ON:
            cmd_sign_on();
            break;

        case CMD_SET_PARAMETER:
            if (n >= 3u) reply2(p[0], set_parameter(p[1],p[2]));
            else reply2(p[0], STATUS_CMD_FAILED);
            break;

        case CMD_GET_PARAMETER:
            if (n >= 2u) {
                uint8_t ok;
                uint8_t value = get_parameter(p[1], &ok);
                if (ok) {
                    response[0]=p[0]; response[1]=STATUS_CMD_OK; response[2]=value;
                    tx_enqueue(response,3u);
                } else reply2(p[0], STATUS_CMD_FAILED);
            } else reply2(p[0], STATUS_CMD_FAILED);
            break;

        case CMD_LOAD_ADDRESS:
            if (n >= 5u) {
                current_address = ((uint32_t)p[1]<<24) |
                                  ((uint32_t)p[2]<<16) |
                                  ((uint32_t)p[3]<<8) | p[4];
                address_is_extended = (current_address & 0x80000000u) ? 1u : 0u;
                reply2(p[0], STATUS_CMD_OK);
            } else reply2(p[0], STATUS_CMD_FAILED);
            break;

        case CMD_RESET_PROTECTION:
            AVRISP_PHY_ResetProtection();
            reply2(p[0], STATUS_CMD_OK);
            break;

        case CMD_FIRMWARE_UPGRADE:
        case CMD_OSCCAL:
            reply2(p[0], STATUS_CMD_FAILED);
            break;

        case CMD_ENTER_PROGMODE_ISP: cmd_enter(p,n); break;
        case CMD_LEAVE_PROGMODE_ISP: cmd_leave(p,n); break;
        case CMD_CHIP_ERASE_ISP: cmd_chip_erase(p,n); break;
        case CMD_PROGRAM_FLASH_ISP: cmd_program_flash(p,n); break;
        case CMD_READ_FLASH_ISP: cmd_read_flash(p,n); break;
        case CMD_PROGRAM_EEPROM_ISP: cmd_program_eeprom(p,n); break;
        case CMD_READ_EEPROM_ISP: cmd_read_eeprom(p,n); break;

        case CMD_PROGRAM_FUSE_ISP:
        case CMD_PROGRAM_LOCK_ISP:
            cmd_program_misc(p[0],p,n);
            break;

        case CMD_READ_FUSE_ISP:
        case CMD_READ_LOCK_ISP:
        case CMD_READ_SIGNATURE_ISP:
        case CMD_READ_OSCCAL_ISP:
            cmd_read_misc(p[0],p,n);
            break;

        case CMD_SPI_MULTI:
            cmd_spi_multi(p,n);
            break;

        default:
            reply2(p[0], STATUS_CMD_UNKNOWN);
            break;
    }
}

void AVRISP_MKII_Init(void)
{
    memset(parameters,0,sizeof(parameters));
    parameters[PARAM_RESET_POLARITY] = 1u;
    parameters[PARAM_SCK_DURATION] = 6u;
    rx_r=rx_w=rx_count=0u;
    tx_r=tx_w=tx_count=tx_busy=0u;
    assembling_len=0u;
    current_address=0u;
    address_is_extended=0u;
    in_progmode=0u;
    AVRISP_PHY_Init();
    XPROG_Init();
}

void AVRISP_MKII_Task(void)
{
    AVRISP_PHY_Task();
    XPROG_Task();

    if (rx_count) {
        usb_message_t msg;
        __disable_irq();
        memcpy(&msg, &rxq[rx_r], sizeof(msg));
        rx_r = (uint8_t)((rx_r + 1u) % RX_QUEUE_DEPTH);
        --rx_count;
        __enable_irq();
        dispatch(msg.data, msg.len);
    }
    tx_task();
}
