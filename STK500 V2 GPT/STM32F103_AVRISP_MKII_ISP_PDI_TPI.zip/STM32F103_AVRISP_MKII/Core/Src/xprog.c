#include "xprog.h"
#include "pdi_phy.h"
#include "tpi_phy.h"
#include <string.h>
#define X_ENTER 0x01u
#define X_LEAVE 0x02u
#define X_ERASE 0x03u
#define X_WRITE 0x04u
#define X_READ  0x05u
#define X_CRC   0x06u
#define X_SETP  0x07u
#define XR_OK 0u
#define XR_FAILED 1u
#define XR_COLLISION 2u
#define XR_TIMEOUT 3u
#define XR_ILLEGAL 4u
#define XP_NVMCMD 0x03u
#define XP_NVMCSR 0x04u
static uint8_t mode=XPROG_MODE_PDI;static uint8_t nvmcmd=0x33,nvmcsr=0x32;
static uint16_t be16(const uint8_t*p){return ((uint16_t)p[0]<<8)|p[1];}static uint32_t be32(const uint8_t*p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static uint8_t mapr(int r){if(r==0)return XR_OK;if(r==1)return XR_TIMEOUT;if(r==2)return XR_COLLISION;return XR_FAILED;}
void XPROG_Init(void){PDI_Init();TPI_Init();}void XPROG_Task(void){}
bool XPROG_Handle(const uint8_t*q,uint16_t n,uint8_t*r,uint16_t*rn){if(!n)return false;if(q[0]==CMD_XPROG_SETMODE){if(n<2||q[1]>1){r[0]=q[0];r[1]=XR_ILLEGAL;}else{mode=q[1];r[0]=q[0];r[1]=XR_OK;}*rn=2;return true;}if(q[0]!=CMD_XPROG)return false;if(n<2){r[0]=q[0];r[1]=0;r[2]=XR_FAILED;*rn=3;return true;}uint8_t sub=q[1];r[0]=CMD_XPROG;r[1]=sub;r[2]=XR_FAILED;*rn=3;switch(sub){case X_ENTER:r[2]=mapr(mode==XPROG_MODE_PDI?PDI_Enter():TPI_Enter());break;case X_LEAVE:if(mode==XPROG_MODE_PDI)PDI_Leave();else TPI_Leave();r[2]=XR_OK;break;case X_SETP:if(n<4){r[2]=XR_ILLEGAL;break;}if(q[2]==XP_NVMCMD)nvmcmd=q[3];else if(q[2]==XP_NVMCSR)nvmcsr=q[3];else{r[2]=XR_ILLEGAL;break;}TPI_SetNvmRegisters(nvmcmd,nvmcsr);r[2]=XR_OK;break;case X_ERASE:if(n<7){r[2]=XR_ILLEGAL;break;}r[2]=mapr(mode==XPROG_MODE_PDI?PDI_Erase(q[2],be32(&q[3])):TPI_Erase(q[2],be32(&q[3])));break;case X_WRITE:{if(n<10){r[2]=XR_ILLEGAL;break;}uint8_t mt=q[2];uint32_t a=be32(&q[4]);uint16_t l=be16(&q[8]);if((uint32_t)10+l>n){r[2]=XR_ILLEGAL;break;}r[2]=mapr(mode==XPROG_MODE_PDI?PDI_WriteBlock(a,&q[10],l):TPI_WriteBlock(mt,a,&q[10],l));break;}case X_READ:{if(n<8){r[2]=XR_ILLEGAL;break;}uint32_t a=be32(&q[2]);uint16_t l=be16(&q[6]);if(l>512){r[2]=XR_ILLEGAL;break;}int z=mode==XPROG_MODE_PDI?PDI_ReadBlock(a,&r[3],l):TPI_ReadBlock(a,&r[3],l);r[2]=mapr(z);*rn=(uint16_t)(3+(r[2]==XR_OK?l:0));break;}case X_CRC:r[2]=XR_ILLEGAL;break;default:r[2]=XR_ILLEGAL;break;}return true;}
