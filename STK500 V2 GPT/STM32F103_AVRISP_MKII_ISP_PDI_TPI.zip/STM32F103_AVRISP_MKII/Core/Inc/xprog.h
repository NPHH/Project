#ifndef XPROG_H
#define XPROG_H
#include <stdint.h>
#include <stdbool.h>

#define CMD_XPROG          0x50u
#define CMD_XPROG_SETMODE  0x51u
#define XPROG_MODE_PDI     0x00u
#define XPROG_MODE_TPI     0x01u

void XPROG_Init(void);
void XPROG_Task(void);
bool XPROG_Handle(const uint8_t *request, uint16_t length,
                  uint8_t *response, uint16_t *response_length);
#endif
