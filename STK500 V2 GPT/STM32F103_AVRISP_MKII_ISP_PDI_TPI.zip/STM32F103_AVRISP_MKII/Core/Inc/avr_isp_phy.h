#ifndef AVR_ISP_PHY_H
#define AVR_ISP_PHY_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    AVRISP_PHY_OK = 0,
    AVRISP_PHY_TIMEOUT,
    AVRISP_PHY_CLOCK_ERROR,
    AVRISP_PHY_IO_ERROR
} avrisp_phy_result_t;

void AVRISP_PHY_Init(void);
void AVRISP_PHY_Task(void);

void AVRISP_PHY_SetResetPolarity(uint8_t avr_active_low);
void AVRISP_PHY_SetReset(bool asserted);
void AVRISP_PHY_SetSckDuration(uint8_t duration);
uint8_t AVRISP_PHY_GetSckDuration(void);
uint32_t AVRISP_PHY_GetSckHz(void);

uint8_t AVRISP_PHY_Transfer(uint8_t value);
bool AVRISP_PHY_Transfer4(const uint8_t tx[4], uint8_t rx[4]);

void AVRISP_PHY_DelayUs(uint32_t us);
void AVRISP_PHY_DelayMs(uint32_t ms);

uint16_t AVRISP_PHY_ReadTargetMillivolts(void);
uint8_t AVRISP_PHY_GetConnectionStatus(void);
void AVRISP_PHY_ResetProtection(void);

#ifdef __cplusplus
}
#endif
#endif
