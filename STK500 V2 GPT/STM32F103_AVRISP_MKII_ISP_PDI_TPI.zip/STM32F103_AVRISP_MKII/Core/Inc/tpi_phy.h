#ifndef TPI_PHY_H
#define TPI_PHY_H
#include <stdint.h>
#include <stdbool.h>

typedef enum { TPI_OK=0, TPI_TIMEOUT, TPI_PARITY, TPI_COLLISION, TPI_IO } tpi_result_t;
void TPI_Init(void);
void TPI_SetClock(uint32_t hz);
void TPI_SetNvmRegisters(uint8_t nvmcmd_addr, uint8_t nvmcsr_addr);
tpi_result_t TPI_Enter(void);
void TPI_Leave(void);
tpi_result_t TPI_Send(uint8_t value);
tpi_result_t TPI_Recv(uint8_t *value, uint32_t timeout_us);
tpi_result_t TPI_Break(void);
tpi_result_t TPI_ReadBlock(uint32_t address, uint8_t *data, uint16_t length);
tpi_result_t TPI_WriteBlock(uint8_t memory_type, uint32_t address,
                            const uint8_t *data, uint16_t length);
tpi_result_t TPI_Erase(uint8_t mode, uint32_t address);
#endif
