#ifndef AVRISP_MKII_H
#define AVRISP_MKII_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define AVRISP_USB_MESSAGE_MAX  600u

void AVRISP_MKII_Init(void);
void AVRISP_MKII_Task(void);

/*
 * USB Bulk OUT callback:
 * - Gọi cho từng packet OUT nhận được.
 * - short_packet = true nếu packet nhỏ hơn 64 byte hoặc là ZLP.
 */
void AVRISP_MKII_USB_RxPacket(const uint8_t *data,
                              uint16_t length,
                              bool short_packet);

/* USB Bulk IN complete callback. */
void AVRISP_MKII_USB_TxComplete(void);

#ifdef __cplusplus
}
#endif
#endif
