#ifndef __USBD_AVRISP_H
#define __USBD_AVRISP_H

#ifdef __cplusplus
extern "C" {
#endif

#include "usbd_ioreq.h"

#define AVRISP_IN_EP                 0x81U
#define AVRISP_OUT_EP                0x02U
#define AVRISP_FS_MAX_PACKET_SIZE    64U

#define USB_AVRISP_CONFIG_DESC_SIZ   32U

extern USBD_ClassTypeDef USBD_AVRISP;

uint8_t USBD_AVRISP_TransmitPacket(USBD_HandleTypeDef *pdev,
                                   uint8_t *buffer,
                                   uint16_t length);

#ifdef __cplusplus
}
#endif
#endif
