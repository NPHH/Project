#ifndef PDI_PHY_H
#define PDI_PHY_H
#include <stdint.h>
#include <stdbool.h>

typedef enum { PDI_OK=0, PDI_TIMEOUT, PDI_PARITY, PDI_COLLISION, PDI_IO } pdi_result_t;
void PDI_Init(void);
void PDI_SetClock(uint32_t hz);
pdi_result_t PDI_Enter(void);
void PDI_Leave(void);
pdi_result_t PDI_Send(uint8_t value);
pdi_result_t PDI_Recv(uint8_t *value, uint32_t timeout_us);
pdi_result_t PDI_Break(void);
pdi_result_t PDI_ReadBlock(uint32_t address, uint8_t *data, uint16_t length);
pdi_result_t PDI_WriteBlock(uint32_t address, const uint8_t *data, uint16_t length);
pdi_result_t PDI_ChipErase(void);
pdi_result_t PDI_Erase(uint8_t mode, uint32_t address);
#endif
