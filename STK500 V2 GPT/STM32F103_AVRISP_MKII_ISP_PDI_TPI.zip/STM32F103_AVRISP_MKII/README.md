# STM32F103 AVRISP mkII ISP clone

Đây là firmware AVRISP mkII **ISP/SPI** cho STM32F103C8T6, giao tiếp trực tiếp
với AVR Studio/Atmel Studio bằng USB vendor-specific Bulk, theo AVR069.

## Khác với firmware STK500v2 trước

AVRISP mkII không dùng CDC/COM và không có frame:

```
1B sequence length 0E payload checksum
```

Thay vào đó:

- USB class: Vendor Specific `0xFF`
- Bulk IN: `0x81`
- Bulk OUT: `0x02`
- Packet size: 64 byte
- Một command/response có thể gồm nhiều packet.
- Short packet hoặc ZLP kết thúc một message.
- Byte đầu message là command ID.

## Phạm vi hiện tại

Đã có:

- AVRISP mkII USB descriptors và Bulk class
- `CMD_SIGN_ON` trả `AVRISP_MK2`
- Parameter version, target voltage, SCK, reset polarity, target status
- ISP Enter/Leave programming
- Chip erase
- Flash read/write và extended addressing
- EEPROM read/write
- Fuse/lock/signature/OSCCAL
- SPI_MULTI
- Hardware SPI và slow bit-bang SCK
- USB RX/TX queues không chặn

Đã bổ sung thử nghiệm:

- XPROG/PDI cho XMEGA qua `CMD_XPROG`
- XPROG/TPI cho ATtiny4/5/9/10/20/40 và họ TPI tương thích

Chưa hoàn tất tuyệt đối:

- CRC XPROG
- mọi biến thể NVM command của từng XMEGA/tinyAVR
- Firmware upgrade bootloader tương thích Atmel
- Mạch phát hiện ngược đầu cáp và short-circuit giống AVRISP mkII thật
- Kiểm thử thực tế trên mọi AVR

Do đó đây là **AVRISP mkII ISP clone**, chưa phải bản sao đầy đủ mọi giao diện
của sản phẩm chính hãng.

## CubeMX

MCU: STM32F103C8Tx

Clock:

- HSE 8 MHz
- SYSCLK 72 MHz
- USB 48 MHz

Bật:

- USB Device FS, Device Only
- SPI1 master full duplex:
  - PA5 SCK
  - PA6 MISO
  - PA7 MOSI
  - Mode 0
- PB0 GPIO Output cho RESET
- ADC1 IN0 PA0 đo VTarget

Không chọn USB CDC middleware. Tạo USB Device rồi thay class bằng
`USBD_AVRISP` theo file patch.

## ISP connector

| ISP pin | Tín hiệu | STM32 |
|---|---|---|
| 1 | MISO | PA6 qua buffer |
| 2 | VTARGET sense | PA0 qua chia áp |
| 3 | SCK | PA5 qua level shifter |
| 4 | MOSI | PA7 qua level shifter |
| 5 | RESET | PB0 qua open-drain |
| 6 | GND | GND |

AVRISP mkII thật không cấp nguồn target. VTarget chỉ được đo để chọn mức logic
và báo trạng thái. Target phải có nguồn riêng.

## Level shifting

Để hỗ trợ 1.8–5.5 V như thiết bị thật, cần transceiver theo VTarget, ví dụ:

- SN74LVC2T45 / SN74AXC4T245 cho SCK/MOSI/RESET
- buffer chiều ngược cho MISO
- RESET open-drain có điện trở kéo lên VTarget

Không nối trực tiếp target 5 V vào chân STM32 không chịu 5 V.

## Driver Windows

AVR Studio cũ thường dùng Jungo. Atmel Studio 7 có thể dùng driver Microchip/
Jungo tùy phiên bản. VID/PID chính thức trong AVR069 là `03EB:2104`.

Việc dùng VID của hãng khác trong sản phẩm thương mại cần xem xét quyền sử dụng
USB VID. Firmware để các giá trị trong descriptor patch nhằm thử nghiệm tương
thích trong phòng lab.

## Thử nghiệm

1. Cấp nguồn riêng cho target.
2. Đo VTarget trên ADC.
3. Cắm USB programmer.
4. Kiểm tra Windows nhận `AVRISP mkII`.
5. Trong Atmel Studio chọn Tool → AVRISP mkII.
6. Đặt ISP clock chậm, ví dụ 125 kHz.
7. Read Device Signature.
8. Read Flash.
9. Program và Verify một firmware nhỏ.
10. Cuối cùng mới thử fuse.

## Điểm cần rà khi chạy thật

- Nếu Atmel Studio không thấy thiết bị: driver/VID/PID/descriptors.
- Nếu thấy nhưng không trả lời: kiểm tra short-packet/ZLP ở Bulk OUT.
- Nếu đọc signature `FFFFFF`: MISO hở, target chưa nguồn hoặc chưa vào ISP.
- Nếu `000000`: chân bị kéo thấp hoặc reset/sck sai.
- Nếu chip clock thấp: giảm ISP clock.


## Chân PDI/TPI mặc định

PDI: PB10=PDI_CLK, PB11=PDI_DATA. PDI_DATA là half-duplex open-drain; nên ghép TX/RX qua điện trở 220 ohm hoặc transceiver phù hợp VTarget.

TPI: PB12=TPICLK, PB13=TPIDATA, PB14=VPP12_EN. PB14 chỉ điều khiển công tắc 12 V; không nối trực tiếp RESET target. TPI programming của các chip tương ứng yêu cầu target 5 V và 12 V trên RESET.

## Cấu hình CubeMX bổ sung

PB10/PB12 output, PB11/PB13 được firmware đổi input/open-drain runtime, PB14 output default LOW.
