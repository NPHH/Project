感谢 千年板蓝根(github: lihaoyun6) 提供的字体文件以及相关素材！！！
Thanks for the font files and related materials provided by 千年板蓝根 (GitHub: lihaoyun6)!!!