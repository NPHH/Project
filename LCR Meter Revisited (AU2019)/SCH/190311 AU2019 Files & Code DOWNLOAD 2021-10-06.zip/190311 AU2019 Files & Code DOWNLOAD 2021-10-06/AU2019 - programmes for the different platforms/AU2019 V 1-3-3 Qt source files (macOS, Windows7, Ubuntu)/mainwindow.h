#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QSettings>
#include <QCloseEvent>
#include <QDebug>
#include <QInputDialog>
#include <QMessageBox>
#include <QStatusBar>
#include <QAction>
#include <QMenu>
#include <QMenuBar>
#include <QWidget>
#include <QIntValidator>
#include <QThread>
#include <QtMath>
#include <QProgressDialog>
#include <QFileDialog>
#include <QTimer>
//#include <string.h>

#define AU2019_VERSION      "1.3.3" //  "1.3.3"     Increase size of some DockWidget

                                    //  "1.3.2"     display Ranges

                                    //  "1.3.1"     always display Z, PHI and Q parameters

                                    //  "1.3.0"     synchro with firmware Version 2.0.0 (Qlimit & Average)

                                    //  "1.2.2"     Improved "RUN" and "HALT" command

                                    //  "1.2.1"     Inversion of Short and Open Trim menus

                                    //  "1.2.0"     Possibility to have lines of comment (lines starting with "//") in the text file used for Languages.
                                    //              Such lines are skipped.


//#define BOOTLOADER

#define SEND_LANGUAGE_TEXTES

//#define OK_LANGUAGE         // use language defined by the 'Locale' and *.qrm files

// -------------------------------------------------------------------------------
// *** WARNING don't modify these #define values, there are commands send to the hardware
// -------------------------------------------------------------------------------
#define	RUN					"RUN\n"         // -> start measurement
#define	HALT				"HALT\n"        // -> stop measurement
#define MODE_D              "MODE_D\n"      // change the display mode: SERIES or PARALLEL or AUTO
#define F_VERS              "F_VERS\n"      // ask for Firmware Version
#define R_HOLD              "R_HOLD\n"      // change Range Hold
#define TRIM_SHORT          "TRIMS\n"       // -> Trim command (short pressed)
#define TRIM_LONG           "TRIML\n"       // -> Trim command (long pressed)
#define KEY_5               "K5\n"          // OK command
#define KEY_4               "K4\n"          // EXIT command
#define MOVE_UP             "MOVUP\n"       // move up command
#define MOVE_DOWN           "MOVDW\n"       // move down command
#define SORT                "SORT\n"        // Sort command
#define START               "START\n"       // START command
#define	FIRMW_UPDATE		"FWUPDA\n"		// Firmware Update requested
#define AVG_SLOW            "AVGS\n"        // Change AVERAGE to SLOW
#define AVG_FAST            "AVGF\n"        // Change AVERAGE to FAST

#define message_READY_RECEIVE_TXT   "RDY_TXT "
#define STR_TEXT_ARRAY              "W "                // string to update at TEXT_ARRAY_ADD
#define STR_CONFIG_ARRAY            "X "                // string to update at CONFIG_ARRAY_ADD
#define STR_MENU_ARRAY              "Y "                // string to update at MENU_ARRAY_ADD
#define STR_LANG_ARRAY              "Z "                // string to update at LANG_ARRAY_ADD
#define NB_LANG                     "NB_LANG "          // number of languages in memory
#define END_TEXTS                   "E_TXT "            // string to send at the end of file

#define	TEXTS_UPDATE                "TXTUPDA\n"         // Texts Update requested
#define TEXTARRAY                   "TEXT_ARRAY\n"      // string identifier for TEXT_ARRAY
#define CONFIGARRAY                 "CONFIG_ARRAY\n"    // string identifier for CONFIG_ARRAY
#define MENUARRAY                   "MENU_ARRAY\n"      // string identifier for MENU_ARRAY
#define LANGARRAY                   "LANG_ARRAY\n"      // string identifier for LANG_ARRAY


// message send to the Bootloader
#define	UPDATE				"UPD\n"		// update firmware
#define	UPDATE2				"UPD2\n"		// erase bank2 & update firmware

// menu configurations
#define	SINUS_GEN_OFS		"SIN_OFS\n" 	// set sinus generator offset
//#define	SET_DDS_VREF        1           // -> only value send to hardware
#define	CMRR_INPUT_AMP		"CMRR\n"        // set CMRR of input AOP
#define	G3_CALIBRATION		"G3_CAL\n"		// set PGA2: gain 3 calibration
#define	G10_CALIBRATION		"G10_CAL\n" 	// set PGA2: gain 10 calibration.
#define	CALIB_RANGE1		"CAL_R1\n"      // set Range 1 calibration.
#define	CALIB_RANGE2		"CAL_R2\n"      // set Range 2 calibration.
#define	CALIB_RANGE3		"CAL_R3\n"      // set Range 3 calibration.
#define	CALIB_RANGE4		"CAL_R4\n"      // set Range 4 calibration.
#define	TRIM_OPEN_ALL		"TRIM_O\n"		// set trim-open calibration (all freq)
#define	TRIM_SHORT_ALL		"TRIM_S\n"		// set trim-short calibration (all freq)

// commands with added parameter(s)
#define AC_LEVEL            "AC_LEVEL "     // change AC level
#define DC_BIAS             "DC_BIAS "      // change DC bias
#define NEW_FREQ            "USER_F "       // change Frequency
#define NEW_QLIMIT          "Q_LIMIT "      // send Q limit for secondary display
#define NEW_SORT_PARAM      "SORT_P "       // send series for sorting
#define NEW_DDSVREF         "DDSV "         // New DDS Vref
#define BAUD2               "BAUDS 2\n"      // set UART1 115200 bauderate (after reset of the hardware)
#define BAUD1               "BAUDS 1\n"      // set UART1 9600 bauderate (after reset of the hardware)

// --------------------------------------------------------------------------------
// *** WARNING *** don't modify these strings, there are receveid from the hardware
// --------------------------------------------------------------------------------
#define  message_SP_MODE 	                "SP_MODE "
#define  message_PRIMARY                    "PRIMAR "
#define  message_SECONDARY 	                "SECOND "
#define  message_Z 	                        "Z "
#define  message_Q 	                        "QQ "
#define  message_D 	                        "DD "
#define  message_PHI                        "PHI "
#define  message_VX                         "Vx "
#define  message_IX                         "Ix "
#define  message_FREQ                       "FREQ "
#define  message_DC                         "DC "
#define  message_AC                         "AC "
#define  message_R_HOLD                     "R-Hold "
#define  message_NO_DISPLAY_SECONDARY       "NDIS_S "
#define  message_CIRCUIT                    "CIR "
#define  message_MEASURE                    "MEAS "

#define  message_STATUS                     "I_STATUS "
#define  message_FIRMVERSION                "FVER "
#define  message_BOOTVERSION                "BVER "
#define  message_LANGVERSION                "LVERS "
#define  message_TEXT                       "J "
//#define  message_MESSAGE                    "MSG "
//#define  message_ERF                        "ERF "
#define  message_ERPS                       "ERPS "
#define  message_SAVED_PARAMETERS           "PAR "
#define  message_INDEX                      "IND "
#define  message_END                        "END "
#define  message_MAX                        "MAX "
#define  message_MIN                        "MIN "

#define message_GO_APP                      "GO_APP "
#define message_SYNCHRO                     "NEED_S "
#define message_UPDATE_READY                "UD_RDY "
#define message_MEMORY_FAIL                 "M_FAIL "
#define message_NEED_UPDATE                 "ND_UPD "
#define message_READY_RECEIVE               "RDY_RCV "
#define message_ERROR_TXT                   "ERR_TXT "
#define message_AVGS                        "AVG_S "
#define message_AVGF                        "AVG_F "
#define message_AVGF                        "AVG_F "
#define message_RUI                         "RUI "

#define message_UART                        "MUART "

#define max_Q                               "50000"


#define  SERIES					1
#define  PARALLEL               2
#define  PLAIN					3

#define  NO_KIND				0
#define  R_KIND					1
#define  L_KIND					2
#define  C_KIND					3

#define  MOVE_MARK_DOWN         20
#define  MOVE_MARK_UP           21

#define FREQ_MEM_SIZE           54    // will be synchronized with the value 'FREQ_MEM_SIZE' in the firmware


namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;

    QSerialPort *port;
    QStatusBar *barreEtat;
    QSettings *settings;
    QAction *aboutAction;
    QAction *aboutQtAction;
    QAction *exitAction;
    QAction *setPortNameAction;
    QAction *closeThePortAction;
    QAction *FirmwareUpdateAction;
    QAction *TextsUpdateAction;
    QAction *openQLimitWidgetAction;
    QAction *openSeriesWidgetAction;
    QAction *SortAction;
    QAction *SinGenOffset;
    QAction *DDS_VRef;
    QAction *CMRR;
    QAction *PGA2_Gain3;
    QAction *PGA2_Gain10;
    QAction *Calib_R1;
    QAction *Calib_R2;
    QAction *Calib_R3;
    QAction *Calib_R4;
    QAction *OpenTRIM_AllFreq;
    QAction *ShortTRIM_AllFreq;

    QValidator *FreqValidator;
    QValidator *mVDCValidator;
    QValidator *mADCValidator;
    QValidator *DDSValidator;
    QProgressDialog *progressDialog;

    QMenu *portMenu;
    QMenu *settingsMenu;
    QMenu *reglagesMenu;
    QMenu *trierMenu;
    QMenu *helpMenu;

    void closeEvent(QCloseEvent *event);
    void setDelay(unsigned int);
    void createActions(void);
    void createMenus(void);
    void ReadRequest(void);
    void RemplaceKey(void);
    void Display_Symboles(void);
    void ClearDataInWindow(void);
    void ShowDataInWindow(void);
    void SetPGA2_GX(int);
    void testPhase(void);
    void showProgressDialog(void);
    void showOKExitDialog(void);
    void SetCalibAllRanges(int);
    bool GetFileNameHex(void);
    void SendFichierHex(void);
    bool GetTextsFileName(void);
    void SendFichierTexts(void);

    QString inputQString;
    QString stringValue;
    QString portDeviceName;
    QString nomFichierHex;

    QString nomFichierTexts;
    int NbLANG;
    int LongLigneLANG;
    int NbLigneCONFIG;
    int LongLigneCONFIG;
    int NbLigneTEXT;
    int LongLigneTEXT;
    int NbLigneMENU;
    int LongLigneMENU;

    QString chaineSort;
    QString firmwareVersion;
    QString bootloaderVersion;
    QString Q_Limit = "1000";
    QString Series = "E24 -> 5%";
    QString DDSVRef = "1200";
    QByteArray theFreqText;

    // these QStringList should be synchronized with the allowed values in the Firmware code
    // --> there are zero based index like C++ arrays
    QStringList QlimitList =
    {
        "100",          // 0
        "200",          // 1
        "500",          // 2
        "1000",         // 3
        "2000",         // 4
        "5000",         // 5
        max_Q           // 6
    };

    char lastQIndex = 6;    // **** WARNING: must equal to index of max_Q in the list


    QStringList SeriesList =
    {
        "E6  -> 20%",   // 0
        "E12 -> 10%",   // 1
        "E24 -> 5%",    // 2
        "E48 -> 2%",    // 3
        "E96 -> 1%"     // 4
    };


    bool initMessageReceived = false;
    bool onMeasurement;
    bool messageReceived;
    bool onEditFrequency = false;
    bool inRun;
    bool onEditDC = false;
    bool onEditDSSVRef = false;
    bool onAdjustPhiPGA2 = false;
    bool onFrequenciesSettings = false;
    bool onQLimitChoise = false;
    bool onSeriesChoise = false;
    bool onValueChoise = false;
    bool onSorting = false;
    bool EraseBank2 = false;
    bool onFirmwareUpdate = false;
    bool forcedUpdateByUser = false;
    bool firstTimeFreqReceived = true;
    bool longPressed = false;
    bool AVG_slow = true;
    bool onTextsUpdate = false;
    bool measurementState;
    bool displayRange = false;
    char choice;
    char savedChoice = -1;
    char inputString[127];
    char FirmwareUpdateState = 0;

    int circuitKind;
    int primaryKind;
    int secondaryKind;
    int SP_mode;
    int AutoModel;
    int ACLevel = 1;
    int SeriesIndex = 3;    // E24
    int PGA2_inTest;
    int progressIndex;
    int QlimitIndex = 2;

    long UARTBaudrate;

    float ValueForSort;
    float MaxValueForSort;
    float MinValueForSort;

private slots:
    void aboutAct(void);
    void aboutQtAct(void);
    void GetPortName(void);
    void OpenSerialPort(void);
    void setFirmwareUpdate(void);
    void setTextsUpdate(void);
    void RunStopMeasure(void);
    void CloseApplication(void);
    void slotRead(void);
    void setMode(void);
    void setAVG(void);
    void setFreq(void);
    void getFreq(void);
    void setRHold(void);
    void setACLevel(void);
    void setDCBias(void);
    void getDCBias(void);
    void setTrimLongPressed(void);
    void setTrimPressed(void);
    void setTrimReleased(void);
    void openQLimitWidget(void);
    void openSeriesWidget(void);
    void SetQLimitOrSeries(void);
    void SetSinGenOff(void);
    void SetDDS_VRef(void);
    void getDDSVRef(void);
    void SetCMRR(void);
    void setCMRRFrequency(bool);
    void closeCMRRWidget(void);
    void SetPGA2_G3(void);
    void SetPGA2_G10(void);
    void Send_OK(void);
    void Send_Exit(void);
    void SetCalib_Range1(void);
    void SetCalib_Range2(void);
    void SetCalib_Range3(void);
    void SetCalib_Range4(void);
    void OpenTrimAllFreq(void);
    void ShortTrimAllFreq(void);
    void SendMenuUp(void);
    void SendMenuDown(void);
    void Display_the_Ranges(void);
    void Sort(void);
    void QuitSort(void);

};

#endif // MAINWINDOW_H
