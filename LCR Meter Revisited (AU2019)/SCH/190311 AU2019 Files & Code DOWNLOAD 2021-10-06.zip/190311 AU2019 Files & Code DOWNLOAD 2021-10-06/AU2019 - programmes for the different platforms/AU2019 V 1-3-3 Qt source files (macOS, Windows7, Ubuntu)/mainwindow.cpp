#include "mainwindow.h"
#include "ui_mainwindow.h"


//-----------------------------------------------------------------------------
// MainWindow Constructor
//-----------------------------------------------------------------------------
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    settings = new QSettings( QSettings::IniFormat, QSettings::UserScope, "FRAUBRJ", "AU2019 " + QString( AU2019_VERSION ) );
    ui->setupUi(this);

    if (settings->contains("myWidget/geometry"))
    {
        restoreGeometry(settings->value("myWidget/geometry").toByteArray());
        restoreState(settings->value("myWidget/windowState").toByteArray());
    }
    else
        MainWindow::adjustSize ();   // Adjusts the size of the widget to fit its contents.

    QString message = tr ("   LCR Meter AU2019  version ");
    message.append(AU2019_VERSION);
    setWindowTitle(message);

    ui->QLimitSeriesDockWidget->hide();
    ui->CMRRDockWidget->hide();
    ui->DDS_VRefDockWidget->hide();
    ui->PhaseG2dockWidget->hide();
    ui->UPpushButton->hide();
    ui->DownpushButton->hide();
    ui->OKpushButton->hide();
    ui->EXITpushButton->hide();
    ui->SortDockWidget->hide();

    createActions();
    createMenus();

    port = new QSerialPort(this);
    portDeviceName = "";

    if (settings->contains("port_name"))
    {
        portDeviceName = settings->value("port_name").toString( );
        port->setPortName(portDeviceName);
    }
    else
       GetPortName();

    connect(ui->openPort, &QPushButton::clicked, this, &MainWindow::OpenSerialPort);
    connect(port, &QSerialPort::readyRead, this, &MainWindow::slotRead, Qt::DirectConnection);
    connect(ui->runButton, &QPushButton::released, this, &MainWindow::RunStopMeasure, Qt::DirectConnection);
    connect(ui->ModeButton, &QPushButton::clicked,this, &MainWindow::setMode);
    connect(ui->AVGButton, &QPushButton::clicked,this, &MainWindow::setAVG);
    connect(ui->setFreqButton, &QPushButton::clicked, this, &MainWindow::setFreq);
    connect(ui->FreqLineEdit, &QLineEdit::returnPressed, this, &MainWindow::getFreq, Qt::DirectConnection);
    connect(ui->RholdButton,&QPushButton::clicked, this, &MainWindow::setRHold, Qt::DirectConnection);
    connect(ui->ACButton, &QPushButton::clicked, this, &MainWindow::setACLevel, Qt::DirectConnection);
    connect(ui->DCButton, &QPushButton::clicked, this, &MainWindow::setDCBias, Qt::DirectConnection);
    connect(ui->DCLineEdit, &QLineEdit::returnPressed, this, &MainWindow::getDCBias, Qt::DirectConnection);
    connect(ui->TrimButton,&QPushButton::pressed, this, &MainWindow::setTrimPressed, Qt::DirectConnection);
    connect(ui->TrimButton,&QPushButton::released, this, &MainWindow::setTrimReleased, Qt::DirectConnection);
    connect(ui->QLimitSeriesOKpushButton, &QPushButton::clicked, this, &MainWindow::SetQLimitOrSeries);
    connect(ui->radioButton1MHz, SIGNAL(toggled(bool)),this, SLOT(setCMRRFrequency(bool)));
    connect(ui->radioButton10kHz, SIGNAL(toggled(bool)),this, SLOT(setCMRRFrequency(bool)));
    connect(ui->CMRROkpushButton, &QPushButton::clicked, this, &MainWindow::closeCMRRWidget);
    connect(ui->PG2OKpushButton, &QPushButton::clicked, this, &MainWindow::Send_OK);
    connect(ui->PG2ExitPushButton, &QPushButton::clicked, this, &MainWindow::Send_Exit);
    connect(ui->OKpushButton, &QPushButton::clicked, this, &MainWindow::Send_OK);
    connect(ui->EXITpushButton, &QPushButton::clicked, this, &MainWindow::Send_Exit);
    connect(ui->UPpushButton, &QPushButton::clicked, this, &MainWindow::SendMenuUp);
    connect(ui->DownpushButton, &QPushButton::clicked, this, &MainWindow::SendMenuDown);
    connect(ui->DDS_VRefLineEdit, &QLineEdit::returnPressed, this, &MainWindow::getDDSVRef, Qt::DirectConnection);
    connect(ui->SortingEXITpushButton, &QPushButton::clicked, this, &MainWindow::QuitSort);
    //connect(ui->RcheckBox,SIGNAL(stateChanged(int)), this, SLOT(Display_the_Ranges(int)));
    connect(ui->RcheckBox, &QCheckBox::clicked, this, &MainWindow::Display_the_Ranges);

    // Tooltips.
    ui->Frequency->setToolTip(tr("Measurement frequency"));
    ui->primaryValue->setToolTip(tr("Dominant parameter value"));
    ui->secondaryValue->setToolTip(tr("Secondary parameter value"));
    ui->RH_OnOffLabel->setToolTip(tr("R-Range Hold state"));
    ui->Impedance->setToolTip(tr("Impedance"));
    ui->Quality->setToolTip(tr("Quality or Dissipation factor"));
    ui->Phase->setToolTip(tr("Phase angle"));
    ui->Vx->setToolTip(tr("DUT voltage"));
    ui->Ix->setToolTip(tr("DUT current"));
    ui->DC->setToolTip(tr("DUT DC bias"));
    ui->AC->setToolTip(tr("Generator AC level"));
    ui->DCButton->setToolTip(tr("Change DC bias"));
    ui->ACButton->setToolTip(tr("Change Generator AC level"));
    ui->RholdButton->setToolTip(tr("Switch R-Range Hold state: ON OFF"));
    ui->ModeButton->setToolTip(tr("Change Circuit Mode: Parallels, Series, Auto"));
    ui->setFreqButton->setToolTip(tr("Change Frequency"));
    ui->TrimButton->setToolTip(tr("Long pressed to save the lastest Trims"));

    barreEtat = statusBar();
    QFont theFont = barreEtat->font();

    theFont.setPixelSize(13);
    barreEtat->setFont(theFont);

    ui->SchematicLabel->setPixmap(QPixmap(":/AU2019/Resources/StartScreen" ));

    // If a port name, try to open the port.
    if (!portDeviceName.isEmpty())
        OpenSerialPort();               // this function send the synchronization message

    FreqValidator = new QIntValidator(50, 2000001, this);
    mVDCValidator = new QIntValidator(0, 5001, this);
    mADCValidator = new QIntValidator(0, 50, this);
    DDSValidator = new QIntValidator(1120, 1240, this);

}


//-----------------------------------------------------------------------------
// MainWindow Destructor
//-----------------------------------------------------------------------------
MainWindow::~MainWindow()
{
    delete settings;
    delete port;
    delete ui;
    delete FreqValidator;
    delete mVDCValidator;
    delete mADCValidator;
    delete DDSValidator;
    delete setPortNameAction;
    delete closeThePortAction;
    //delete prefAction;
}


//-----------------------------------------------------------------------------
// closeEvent
//-----------------------------------------------------------------------------
void MainWindow::closeEvent(QCloseEvent *event)
{
    if (onMeasurement)	// -> stop measurements
    {
        qDebug() << "send HALT";
        port->write(HALT);
        if (!port->waitForBytesWritten())
            port->flush();        
    }
    setDelay(100);
    port->close();
    setDelay(100);

    // Save a few settings
    settings->setValue("myWidget/geometry", saveGeometry());
    settings->setValue("myWidget/windowState", saveState());

    qDebug() << "close event";
    event->accept();
}



//-----------------------------------------------------------------------------
// SLOT CloseApplication
//-----------------------------------------------------------------------------
void MainWindow::CloseApplication(void)
{
    close();
    qDebug() << "close";
}



//-----------------------------------------------------------------------------
// createActions
//-----------------------------------------------------------------------------
void MainWindow::createActions(void)
{
    setPortNameAction = new QAction(tr("Select port..."), this);
    connect(setPortNameAction, SIGNAL(triggered()), this, SLOT(GetPortName()), Qt::DirectConnection);

    closeThePortAction = new QAction(tr("Close the port"), this);
    connect(closeThePortAction, SIGNAL(triggered()), this, SLOT(OpenSerialPort()), Qt::DirectConnection);

    FirmwareUpdateAction = new QAction(tr("Firmware update..."), this);
    connect(FirmwareUpdateAction, SIGNAL(triggered()), this, SLOT(setFirmwareUpdate()), Qt::DirectConnection);

    TextsUpdateAction = new QAction(tr("Texts update ..."), this);
    connect(TextsUpdateAction, SIGNAL(triggered()), this, SLOT(setTextsUpdate()), Qt::DirectConnection);

    openQLimitWidgetAction = new QAction(tr("Set Q limit..."), this);
    connect(openQLimitWidgetAction, SIGNAL(triggered()), this, SLOT(openQLimitWidget()), Qt::DirectConnection);

    openSeriesWidgetAction = new QAction(tr("Set Sorting parameters..."));
    connect(openSeriesWidgetAction, SIGNAL(triggered()), this, SLOT(openSeriesWidget()), Qt::DirectConnection);

    SortAction = new QAction(tr("Sort"),this);
    connect(SortAction, SIGNAL(triggered()), this, SLOT(Sort()), Qt::DirectConnection);

    SinGenOffset = new QAction(tr("Set sinus generator offset"));
    connect(SinGenOffset, SIGNAL(triggered()), this, SLOT(SetSinGenOff()), Qt::DirectConnection);

    DDS_VRef = new QAction(tr("Define the DDS Vref measured value"));
    connect(DDS_VRef, SIGNAL(triggered()), this, SLOT(SetDDS_VRef()), Qt::DirectConnection);

    CMRR = new QAction(tr("CMRR of Voltage diffential opamp."));
    connect(CMRR, SIGNAL(triggered()), this, SLOT(SetCMRR()), Qt::DirectConnection);

    PGA2_Gain3 = new QAction(tr("PGA2: gain 3 calibration"));
    connect(PGA2_Gain3, SIGNAL(triggered()), this, SLOT(SetPGA2_G3()), Qt::DirectConnection);

    PGA2_Gain10 = new QAction(tr("PGA2: gain 10 calibration"));
    connect(PGA2_Gain10, SIGNAL(triggered()), this, SLOT(SetPGA2_G10()), Qt::DirectConnection);

    Calib_R1 = new QAction(tr("Range 1 calibration"));
    connect(Calib_R1, SIGNAL(triggered()), this, SLOT(SetCalib_Range1()), Qt::DirectConnection);

    Calib_R2 = new QAction(tr("Range 2 calibration"));
    connect(Calib_R2, SIGNAL(triggered()), this, SLOT(SetCalib_Range2()), Qt::DirectConnection);

    Calib_R3 = new QAction(tr("Range 3 calibration"));
    connect(Calib_R3, SIGNAL(triggered()), this, SLOT(SetCalib_Range3()), Qt::DirectConnection);

    Calib_R4 = new QAction(tr("Range 4 calibration"));
    connect(Calib_R4, SIGNAL(triggered()), this, SLOT(SetCalib_Range4()), Qt::DirectConnection);

    ShortTRIM_AllFreq = new QAction(tr("<Short-circuit> Trim, all freq."));
    connect(ShortTRIM_AllFreq, SIGNAL(triggered()), this, SLOT(ShortTrimAllFreq()), Qt::DirectConnection);

    OpenTRIM_AllFreq = new QAction(tr("<Open-circuit> Trim, all freq."));
    connect(OpenTRIM_AllFreq, SIGNAL(triggered()), this, SLOT(OpenTrimAllFreq()), Qt::DirectConnection);

    //prefAction = new QAction(tr("Preferences"), this);
    //prefAction->setMenuRole(QAction::PreferencesRole);

#if defined (Q_OS_MACX)
    exitAction = new QAction("&Quit", this);	// WARNING: don't translate. It's automatic
#else
    exitAction = new QAction(tr("&Quit"), this);
#endif
    exitAction->setShortcuts(QKeySequence::Quit);
    connect(exitAction, SIGNAL(triggered()),  this, SLOT(CloseApplication()));

    aboutAction = new QAction(tr("About AU2019"), this);
    aboutAction->setMenuRole(QAction::AboutRole);
    connect(aboutAction, SIGNAL(triggered()), this, SLOT(aboutAct()));

    aboutQtAction = new QAction(tr("About Qt"), this);
    aboutQtAction->setMenuRole(QAction::AboutQtRole);
    connect(aboutQtAction, SIGNAL(triggered()), this, SLOT(aboutQtAct()));
}


//-----------------------------------------------------------------------------
// createMenus
//-----------------------------------------------------------------------------
void MainWindow::createMenus(void)
{
    // menu Port
    portMenu = menuBar()->addMenu(tr("Port"));
    portMenu->addAction(setPortNameAction);
    portMenu->addAction(closeThePortAction);
    portMenu->addSeparator();
    //portMenu->addAction(prefAction);
    //portMenu->addSeparator();
    portMenu->addAction(exitAction);

    // menu Settings
    settingsMenu = menuBar()->addMenu(tr("Settings"));    // "Paramètres"
    settingsMenu->addAction(SortAction);
    settingsMenu->addSeparator();
    settingsMenu->addAction(openQLimitWidgetAction);
    settingsMenu->addAction(openSeriesWidgetAction);
    settingsMenu->addSeparator();
    settingsMenu->addAction(FirmwareUpdateAction);
    settingsMenu->addSeparator();
    settingsMenu->addAction(TextsUpdateAction);
    settingsMenu->addSeparator();

    // Sub menu Calibrations
    reglagesMenu = settingsMenu->addMenu(tr("Calibrations"));
    reglagesMenu->addAction(SinGenOffset);
    reglagesMenu->addAction(DDS_VRef);
    reglagesMenu->addAction(CMRR);
    reglagesMenu->addAction(PGA2_Gain3);
    reglagesMenu->addAction(PGA2_Gain10);
    reglagesMenu->addAction(Calib_R1);
    reglagesMenu->addAction(Calib_R2);
    reglagesMenu->addAction(Calib_R3);
    reglagesMenu->addAction(Calib_R4);
    reglagesMenu->addAction(OpenTRIM_AllFreq);
    reglagesMenu->addAction(ShortTRIM_AllFreq);

    helpMenu = menuBar()->addMenu(tr("Help"));
    helpMenu->addAction(aboutAction);
    helpMenu->addAction(aboutQtAction);

    closeThePortAction->setEnabled(false);
}



//-----------------------------------------------------------------------------
// SLOT GetPortName
// Called by menu "Select port..."
//-----------------------------------------------------------------------------
// For Unix machines (MacOSX and Linux) drivers are on "/dev" directory
// -    On MacOSX, the port name is "xxx.usbserial-zzzzzzzz"
// -    On Linux (Ubuntu) the port name is "ttyUSBx"
// For Windows machines, Com ports are COM1...COM10...etc.
//
void MainWindow::GetPortName(void)
{
    QStringList serialDeviceList;

    serialDeviceList.clear();
    foreach (const QSerialPortInfo &info, QSerialPortInfo::availablePorts()) {
        serialDeviceList.append(info.portName());
        qDebug() << info.portName() << "  location: " << info.systemLocation();
    }

#if defined(Q_OS_WIN)
    int j = serialDeviceList.size();
    if (j == 0)
        serialDeviceList.append("COMx");	// minimum one entry to be edited
#else
    serialDeviceList = serialDeviceList.filter("USB", Qt::CaseInsensitive) ;
    int j = serialDeviceList.size();
    if (j == 0)
        serialDeviceList.append("");	// minimum one entry to be edited
#endif

    bool ok;
    this->setEnabled(false);   // deleting parent...
    QString portName = QInputDialog::getItem(this, "Serial port", "Select the serial port", serialDeviceList, 0, true, &ok);
    this->setEnabled(true);

    if (ok && !portName.isEmpty())
    {
        if (!port->isOpen())
        {
            portDeviceName = portName;
            port->setPortName(portDeviceName);
        }
        settings->setValue("port_name", portName);
    }
}



//-----------------------------------------------------------------------------
// SLOT OpenSerialPort
// Called by button openPort or by menu "Close the port"
//-----------------------------------------------------------------------------
//
// when port opened, program continu echanging messages between GUI and hardware
//
void MainWindow::OpenSerialPort(void)
{
    if (port->isOpen())     // port already open, close it
    {
        if (onMeasurement)
            RunStopMeasure();
        port->close();
        ui->openPort->show();
        ui->openPort->setText("Open port");
        ui->openPort->setFocus();
        ui->runButton->setEnabled(false);
        setPortNameAction->setEnabled(true);
        closeThePortAction->setEnabled(false);
        return;
    }

    QString message = "connected to ";

    if ( !port->open(QIODevice::ReadWrite) )
    {
        QString messageError = port->errorString();
        qDebug() << "Serial device : " << port->portName() << " open fail." << messageError;
        ui->openPort->setEnabled(true);


        QString message = "No connection to port ";
        message.append(portDeviceName + '\n');
        if (messageError == "Permission denied")
        {
            message.append(messageError);
        }
        else
        {
            message.append(" - check connection");
            message.append('\n');
            message.append(" - check port's name");
        }

        this->setEnabled(false);   // deleting parent...
        QMessageBox::warning(this, "",message);
        this->setEnabled(true);
    }
    else
    {
            qDebug() << "Serial device : " << port->portName() << " opened.";

            if (!port->setBaudRate(QSerialPort::Baud115200)) {
                qDebug() << "Set baud rate " <<  QSerialPort::Baud115200 << " error.";
            }

            if (!port->setDataBits(QSerialPort::Data8)) {
                qDebug() << "Set data bits " <<  QSerialPort::Data8 << " error.";
            }
            if (!port->setParity(QSerialPort::NoParity)) {
                qDebug() << "Set parity " <<  QSerialPort::NoParity << " error.";
            }
            if (!port->setStopBits(QSerialPort::OneStop)) {
                qDebug() << "Set stop bits " <<  QSerialPort::OneStop << " error.";
            }
            if (!port->setFlowControl(QSerialPort::NoFlowControl)) {
                qDebug() << "Set flow " <<  QSerialPort::NoFlowControl << " error.";
            }

/*
            qDebug() << "= Port parameters =";
            qDebug() << "Device name            : " << port->portName();
            qDebug() << "Baud rate              : " << port->baudRate();
            qDebug() << "Data bits              : " << port->dataBits();
            qDebug() << "Parity                 : " << port->parity();
            qDebug() << "Stop bits              : " << port->stopBits();
            qDebug() << "Flow                   : " << port->flowControl();
*/
            ui->openPort->hide();
            ui->runButton->show();
            inputQString = "P ";
            inputQString[0] = QChar (0x3d5);    // Phi
            ui->label_Phase->setText(inputQString);
            ui->PG2_PhiLabel->setText(inputQString);

            inputQString = "+";
            inputQString[0] = QChar (923);
            ui->UPpushButton->setText(inputQString);

            //FirmwareUpdateAction->setEnabled(true);
            closeThePortAction->setEnabled(true);
            setPortNameAction->setEnabled(false);

            message.append(portDeviceName);
            barreEtat->showMessage(message, 3000);   // ms
            //barreEtat->showMessage(message);
//#ifdef  DEBUG_TEST
            onMeasurement = false;
//#else
            //onMeasurement = true;
//#endif
            messageReceived = false;

            ui->hzLabel->hide();
            ui->DC_Label->hide();
            ui->FreqLineEdit->setMaxLength(7);
            ui->FreqLineEdit->hide();
            ui->DCLineEdit->hide();
            ui->DCLineEdit->setMaxLength(4);


            // -----> hardware is awaiting for first message (synchronization action)

            // Discards all characters from the input buffer
            //port->clear(QSerialPort::Input);

#ifdef NO_BOOTLOADER
            qDebug() << "send F_VERS";
            port->write(F_VERS);			// "F_VERS\n" synchronization with firmware

#else
            qDebug() << "send START";
            port->write(START);             // "START\n" synchronization with bootloader
#endif
            if (!port->waitForBytesWritten())
                port->flush();
            //setDelay(1);
    }
}	// OpenSerialPort


//-----------------------------------------------------------------------------
// ClearDataInWindow
//-----------------------------------------------------------------------------
void MainWindow::ClearDataInWindow(void)
{
    ui->primaryValue->setText("");
    ui->secondaryValue->hide();
    ui->ModeButton->hide();
    ui->Phase->hide();
    ui->Quality->hide();
    ui->AutoLabel->hide();
    ui->Impedance->hide();
    ui->Vx->hide();
    ui->Ix->hide();
    ui->Frequency->hide();
    ui->DC->hide();
    ui->DC_Label->hide();
    ui->DCButton->hide();
    ui->AC->hide();
    ui->ACButton->hide();
    ui->RH_OnOffLabel->hide();
    ui->RholdButton->hide();
    ui->label_Z->hide();
    ui->label_Ix->hide();
    ui->label_QD->hide();
    ui->label_Vx->hide();
    ui->label_Phase->hide();
    ui->runButton->hide();
    ui->ModeButton->hide();
    ui->setFreqButton->hide();
    //ui->FreqLineEdit->hide();
    ui->TrimButton->hide();

    savedChoice = 0;
}


//-----------------------------------------------------------------------------
// ShowDataInWindow
//-----------------------------------------------------------------------------
void MainWindow::ShowDataInWindow(void)
{
    ui->primaryValue->setText("");
    ui->secondaryValue->show();
    ui->ModeButton->show();
    ui->Phase->show();
    ui->Quality->show();
    ui->AutoLabel->show();
    ui->Impedance->show();
    ui->Vx->show();
    ui->Ix->show();
    ui->Frequency->show();
    ui->DC->show();
    ui->AC->show();
    ui->DCButton->show();
    //ui->DC_Label->show();
    ui->ACButton->show();
    ui->RH_OnOffLabel->show();
    ui->RholdButton->show();
    ui->label_Z->show();
    ui->label_Ix->show();
    ui->label_QD->show();
    ui->label_Vx->show();
    ui->label_Phase->show();
    ui->runButton->show();
    ui->ModeButton->show();
    ui->setFreqButton->show();
    //ui->FreqLineEdit->show();
    ui->TrimButton->show();

    savedChoice = 0;
}


//-----------------------------------------------------------------------------
// showProgressDialog
//-----------------------------------------------------------------------------
void MainWindow::showProgressDialog(void)
{
    progressDialog = new QProgressDialog(this);
    progressDialog->setCancelButton(nullptr);
    progressDialog->setLabelText(tr("Will take few minutes..."));
    progressDialog->setRange(0, FREQ_MEM_SIZE);
    progressDialog->setMinimumDuration(0);
}


//-----------------------------------------------------------------------------
// showOKExitDialog
//-----------------------------------------------------------------------------
void MainWindow::showOKExitDialog(void)
{
    QMessageBox msgBox;
    QByteArray theText;

    msgBox.setText(tr("Save the data?"));
    msgBox.setStandardButtons(QMessageBox::Save | QMessageBox::Discard);
    msgBox.setDefaultButton(QMessageBox::Save);
    int ret = msgBox.exec();
    // Discards all characters from the input buffer
    port->clear(QSerialPort::Input);
    switch (ret)
    {
        case QMessageBox::Save:
            theText = KEY_4;    // OK
            port->write(theText);
            if (!port->waitForBytesWritten())
                port->flush();
            qDebug()    << "Send OK (K4)";
            break;

        case QMessageBox::Discard:
            theText = KEY_5;    // EXIT
            port->write(theText);
            if (!port->waitForBytesWritten())
                port->flush();
            qDebug()    << "Send Exit (K5)";
            break;
    }
    port->flush();
}



//-----------------------------------------------------------------------------
// SLOT setFirmwareUpdate
//-----------------------------------------------------------------------------
void MainWindow::setFirmwareUpdate(void)
{
    QMessageBox msgBox;

    this->setEnabled(false);   // deleting parent...
    msgBox.setText(tr("Do you really want to update the firmware of the device?"));
    msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::Cancel);
    msgBox.setDefaultButton(QMessageBox::Cancel);
    int ret = msgBox.exec();
    this->setEnabled(true);

    if (ret != QMessageBox::Yes)
    {
        return;
    }

    // if running, stop measurements
    if (onMeasurement)
    {
        measurementState = true;
        RunStopMeasure();
    }

    msgBox.setText(tr("Erase the Calibration Datas?"));
    msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
    msgBox.setDefaultButton(QMessageBox::No);
    ret = msgBox.exec();

    if (ret == QMessageBox::Yes)
    {
        msgBox.setText(tr("Are you sure?"));
        msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
        msgBox.setDefaultButton(QMessageBox::No);
        ret = msgBox.exec();
        if (ret == QMessageBox::Yes)
            EraseBank2 = true;
        else
            EraseBank2 = false;
    }
    else
        EraseBank2 = false;

    qDebug() << "enter GetFileNameHex";
    qDebug() << "EraseBank2 = " << EraseBank2;
    bool ok = GetFileNameHex();
    if (ok)
    {
        // reset the windows title (without firmware version)
        QString message = tr ("   LCR Meter AU2019  version ");
        message.append(AU2019_VERSION);
        setWindowTitle(message);
        setDelay(1000);
        // reset the hardware
        qDebug() << "send FIRMW_UPDATE";
        onFirmwareUpdate = true;
        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        port->write(FIRMW_UPDATE);   // "FWUPDA\n"
        if (!port->waitForBytesWritten())
            port->flush();
    }
    else    // restore inital state
    {
        if (onMeasurement != measurementState)
        {
            port->flush();
            setDelay(100);
            RunStopMeasure();
        }
    }
} // setFirmwareUpdate


//-----------------------------------------------------------------------------
// GetFileNameHex
//-----------------------------------------------------------------------------
bool MainWindow::GetFileNameHex(void)
{
    this->setEnabled(false);   // deleting parent...
    nomFichierHex = QFileDialog::getOpenFileName(this, tr("Select the file"), QString(), tr("Text files (*.hex)"));
    this->setEnabled(true);
    if (nomFichierHex.isEmpty())
    {
        qDebug() << "cancel";        
        return false;
    }
    qDebug() << "ok get name fichier hex";
    return true;
}


//-----------------------------------------------------------------------------
// SendFichierHex
//-----------------------------------------------------------------------------
void MainWindow::SendFichierHex(void)
{
    char buf[128];
    qint64 lineLength, bytesLoaded = 0;
    QString message;

    this->setEnabled(false);   // deleting parent...

    QFile file(nomFichierHex);
    qint64 TotalSize = file.bytesAvailable();

    QString nomFichier = nomFichierHex;
    int slashPos = nomFichier.lastIndexOf('/');     // works for all OS
    nomFichier.remove(0, slashPos + 1);             // remove path
    message = tr("loading ");
    message.append(nomFichier);

    QProgressDialog progress(nomFichier,nullptr,0,100,this,0);
    //progress.setModal(true);
    progress.setWindowModality(Qt::WindowModal);
    progress.setMinimumDuration(1000);

    if (file.open(QFile::ReadOnly))
    {
        qDebug() << "send file hex...";
        while (!file.atEnd())
        {
           lineLength = file.readLine(buf, sizeof(buf));
           if (lineLength != -1)
           {
               port->write(buf);
               if (!port->waitForBytesWritten())
                   port->flush();
               bytesLoaded += lineLength;
               progress.setValue(bytesLoaded * 100 / TotalSize);
               setDelay(4);               
           }
        }
        qDebug() << "end of file";
        file.close();
        qDebug() << "close the file";
    }
    this->setEnabled(true);   // deleting parent...

}   // SendFichierHex



//-----------------------------------------------------------------------------
// SLOT setTextsUpdate
//-----------------------------------------------------------------------------
void MainWindow::setTextsUpdate(void)
{
    QMessageBox msgBox;

    msgBox.setText(tr("Do you really want to update the texts of the device?"));
    msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::Cancel);
    msgBox.setDefaultButton(QMessageBox::Cancel);

    this->setEnabled(false);   // deleting parent...
    int ret = msgBox.exec();
    this->setEnabled(true);

    if (ret != QMessageBox::Yes)
    {        
        return;
    }

    // if running, stop measurements
    if (onMeasurement)
    {
        measurementState = true;
        RunStopMeasure();
    }

    qDebug() << "enter TextsFileName";
    bool ok = GetTextsFileName();

    if (ok)
    {
        // reset the windows title (without firmware version)
        QString message = tr ("   LCR Meter AU2019  version ");
        message.append(AU2019_VERSION);
        setWindowTitle(message);
        setDelay(1000);
        // reset the hardware
        qDebug() << "send TEXTS_UPDATE";
        onTextsUpdate = true;
        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        port->write(TEXTS_UPDATE);   // "TXTUPDA\n"
        if (!port->waitForBytesWritten())
            port->flush();
    }
    else if (onMeasurement != measurementState) // restore inital state
    {
        port->flush();
        setDelay(100);
        RunStopMeasure();
    }


} // setTextsUpdate


//-----------------------------------------------------------------------------
// GetTextsFileName
//-----------------------------------------------------------------------------
bool MainWindow::GetTextsFileName(void)
{
    this->setEnabled(false);
    nomFichierTexts = QFileDialog::getOpenFileName(this, tr("Select the file"), "/home", tr("Text files (*.txt)"));
    this->setEnabled(true);
    if (nomFichierTexts.isEmpty())
    {
        qDebug() << "cancel";
        return false;
    }
    qDebug() << "Name fichier txt is ok";
    return true;
}



//-----------------------------------------------------------------------------
// SendFichierTexts
//-----------------------------------------------------------------------------
void MainWindow::SendFichierTexts(void)
{
    char bufIn[45];
    //char bufOut[45];
    //char chaine1[45];
    //char chaine2[45];
    qint64 lineLength;
    qint64 bytesLoaded = 0;
    int blankPos, nbText;
    bool ok;

    QByteArray message, message1, message2;
    QByteArray messageRead, messageSend;

#define DELAY 150

    this->setEnabled(false);   // deleting parent...

    QFile file(nomFichierTexts);
    qint64 TotalSize = file.bytesAvailable();

    QString nomFichier = nomFichierTexts;
    int slashPos = nomFichier.lastIndexOf('/');     // works for all OS
    nomFichier.remove(0, slashPos + 1);             // remove path
    QString message3 = tr("loading ");
    message3.append(nomFichier);

    QProgressDialog progress(nomFichier,nullptr,0,100,this,0);
    progress.setWindowModality(Qt::WindowModal);
    progress.setMinimumDuration(1000);
    // The QIODevice::Text flag passed to open() tells Qt to convert
    // Windows-style line terminators ("\r\n") into C++-style terminators ("\n")
    if (file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        while (!file.atEnd())
        {
            // read first line for number of languages
            do
            {
                lineLength = file.readLine(bufIn, sizeof(bufIn));
                messageRead = bufIn;
                ok = messageRead.startsWith("//");  // Comment line, skip line
            }
            while (ok);

            bytesLoaded += lineLength;
            qDebug() << "line in = " << bufIn;

            messageRead = bufIn;
            message = messageRead;

            if (messageRead.startsWith (':'))                       // ":04 13 LANG_ARRAY" (if 4 languages)
                                                                    // or ":11 36 CONFIG_ARRAY" or ":42 36 TEXT_ARRAY" or ":06 36 MENU_ARRAY"
            {
                messageRead.remove(0,1);                            // remove ":"
                qDebug() << "line  = " << messageRead;
                blankPos = messageRead.lastIndexOf(' ');
                messageRead.remove(blankPos,100);                   // "0X 13" or "11 36"" or "42 36" or "06 36"
                blankPos = messageRead.indexOf(' ');                // always 2
                message1 = messageRead.left(blankPos);              // "0X" or "11" or "42" or "06"
                message2 = messageRead.right(blankPos + 1);         // "13" or "36" or "36" or "36"

                if ( message.endsWith(LANGARRAY) )                  // "0X 13 LANG_ARRAY"
                {
                    NbLANG = message1.toInt(&ok,10);                // X
                    LongLigneLANG = message2.toInt(&ok,10);         // 13
                    messageSend = NB_LANG;                          // "NB_LANG "
                    messageSend.append(message1);                   // "NB_LANG 0X"
                    messageSend.append('\n');                       // "NB_LANG 0X\n"
                    qDebug() << "to send = " << messageSend;                    
                    port->write(messageSend);
                    if (!port->waitForBytesWritten())
                        port->flush();
                    setDelay(DELAY);
                    for (nbText = 0; nbText < NbLANG; nbText++)
                    {
                        if (!file.atEnd())
                        {
                            do
                            {
                                lineLength = file.readLine(bufIn, sizeof(bufIn));
                                messageRead = bufIn;
                                ok = messageRead.startsWith("//");  // Comment line, skip line
                            }
                            while (ok);

                            if (lineLength != -1)
                            {

                                message = STR_LANG_ARRAY;               // "Z " -> identifier for a Language_Array's string
                                message1 = QByteArray::number(nbText);  // "x" or "xy" or "xyz"
                                if (nbText < 10)
                                    message1.prepend("00");             // "00x"
                                else if (nbText < 100)
                                    message1.prepend("0");              // "0xy"
                                message.append(message1);               // "Z 00x"
                                message.append(" ");                    // "Z 00x "
                                message.append(messageRead);            // "Z 00x English     \n"
                                qDebug() << message;

                                port->write(message);
                                if (!port->waitForBytesWritten())
                                    port->flush();
                                bytesLoaded += lineLength;
                                progress.setValue(bytesLoaded * 100 / TotalSize);
                                setDelay(DELAY);
                            }
                        }
                    } // for (nbText...)
                    setDelay(DELAY);
                } // if ( messageRead.endsWith(LANGARRAY) )
                else if ( message.endsWith(CONFIGARRAY) )           // "11 36 CONFIG_ARRAY\n"
                {
                    NbLigneCONFIG = message1.toInt(&ok,10);         // 11
                    LongLigneCONFIG = message2.toInt(&ok,10);       // 36
                    for (nbText = 0; nbText < NbLigneCONFIG * NbLANG; nbText++)
                    {
                        if (!file.atEnd())
                        {
                            do
                            {
                                lineLength = file.readLine(bufIn, sizeof(bufIn));
                                messageRead = bufIn;
                                ok = messageRead.startsWith("//");  // Comment line, skip line
                            }
                            while (ok);

                            if (lineLength != -1)
                            {
                                message = STR_CONFIG_ARRAY;             // "X " -> identifier for a Config_Array's string
                                message1 = QByteArray::number(nbText);  // "x" or "xy" or "xyz"
                                if (nbText < 10)
                                    message1.prepend("00");             // "00x"
                                else if (nbText < 100)
                                    message1.prepend("0");              // "0xy"

                                message.append(message1);               // "X 00x"
                                message.append(" ");                    // "X 00x "
                                message.append(messageRead);            // "X 00X Set sinus generator offset         \n"
                                qDebug() << message;
                                port->write(message);
                                if (!port->waitForBytesWritten())
                                    port->flush();
                                bytesLoaded += lineLength;
                                progress.setValue(bytesLoaded * 100 / TotalSize);
                                setDelay(DELAY);
                            }
                        }
                    } // for (nbText...)
                    setDelay(DELAY);
                } // if ( messageRead.endsWith(CONFIGARRAY) )
                else if ( message.endsWith(TEXTARRAY) )           // "42 36 TEXT_ARRAY\n"
                {
                    NbLigneTEXT = message1.toInt(&ok,10);         // 42
                    LongLigneTEXT = message2.toInt(&ok,10);       // 36
                    for (nbText = 0; nbText < NbLigneTEXT * NbLANG; nbText++)
                    {
                        if (!file.atEnd())
                        {
                            do
                            {
                                lineLength = file.readLine(bufIn, sizeof(bufIn));
                                messageRead = bufIn;
                                ok = messageRead.startsWith("//");  // Comment line, skip line
                            }
                            while (ok);

                            if (lineLength != -1)
                            {
                                message = STR_TEXT_ARRAY;               // "W " -> identifier for a Text_Array's string
                                message1 = QByteArray::number(nbText);  // "x" or "xy" or "xyz"
                                if (nbText < 10)
                                    message1.prepend("00");             // "00x"
                                else if (nbText < 100)
                                    message1.prepend("0");              // "0xy"

                                message.append(message1);               // "W xyz"
                                message.append(" ");                    // "W xyz "
                                message.append(messageRead);            // "W xyz PS Test Error, code %u             \n"
                                qDebug() << message;
                                port->write(message);
                                if (!port->waitForBytesWritten())
                                    port->flush();
                                bytesLoaded += lineLength;
                                progress.setValue(bytesLoaded * 100 / TotalSize);
                                setDelay(DELAY);
                            }
                        }
                    } // for (nbText...)
                    setDelay(DELAY);
                } // if ( messageRead.endsWith(TEXTARRAY) )
                else if ( message.endsWith(MENUARRAY) )           // "06 36 MENU_ARRAY\n"
                {
                    NbLigneMENU = message1.toInt(&ok,10);         // 06
                    LongLigneMENU = message2.toInt(&ok,10);       // 36
                    for (nbText = 0; nbText < NbLigneMENU * NbLANG; nbText++)
                    {
                        if (!file.atEnd())
                        {
                            do
                            {
                                lineLength = file.readLine(bufIn, sizeof(bufIn));
                                messageRead = bufIn;
                                ok = messageRead.startsWith("//");  // Comment line, skip line
                            }
                            while (ok);

                            if (lineLength != -1)
                            {
                                message = STR_MENU_ARRAY;               // "Y " -> identifier for a Text_Array's string
                                message1 = QByteArray::number(nbText);  // "x" or "xy" or "xyz"
                                if (nbText < 10)
                                    message1.prepend("00");             // "00x"
                                else if (nbText < 100)
                                    message1.prepend("0");              // "0xy"

                                message.append(message1);               // "Y 00x"
                                message.append(" ");                    // "Y 00x "
                                message.append(messageRead);            // "Y 00x Language                           \n"
                                qDebug() << message;
                                port->write(message);
                                if (!port->waitForBytesWritten())
                                    port->flush();
                                bytesLoaded += lineLength;
                                progress.setValue(bytesLoaded * 100 / TotalSize);
                                setDelay(DELAY);
                            }
                        }
                    } // for (nbText...)
                    setDelay(DELAY);
                } // if ( messageRead.endsWith(TEXTARRAY) )
            } // if (messageRead.startsWith (':'))
        } //  (!file.atEnd())
        file.close();
        qDebug() << "end of file, close the file";

        // send END_TEXTS message to hardware with numbers for lineText, lineMenu and LineConfig
        message = END_TEXTS;                            // "E_TXT "
        message1 = QByteArray::number(NbLigneTEXT);     // "42"
        message.append(message1);                       // "E_TXT 42"
        message.append(" ");                            // "E_TXT 42 "
        message1 = QByteArray::number(NbLigneMENU);     // "6"
        if (NbLigneMENU < 10)
            message1.prepend("0");                      // "06"
        message.append(message1);                       // "E_TXT 42 06"
        message.append(" ");                            // "E_TXT 42 06 "
        message1 = QByteArray::number(NbLigneCONFIG);   // "11"
        if (NbLigneCONFIG < 10)
            message1.prepend("0");                      // "11"
        message.append(message1);                       // "E_TXT 42 06 11"
        message.append("\n");                            // "E_TXT 42 06 11\n"
        qDebug() << message;
        port->write(message);
        if (!port->waitForBytesWritten())
            port->flush();
        setDelay(DELAY);
    } // if (file.open...)

    this->setEnabled(true);   // deleting parent...

    // restore inital state
    if (onMeasurement != measurementState)
    {
        port->flush();
        setDelay(DELAY);
        RunStopMeasure();
    }

}   // SendFichierHex



//-----------------------------------------------------------------------------
// SLOT aboutAct
//-----------------------------------------------------------------------------
void MainWindow::aboutAct(void)
{
    this->setEnabled(false);   // deleting parent (this) not allowed during the execution of the dialog
    QString version = tr("LCR Meter AU2019 - Version ");
    version.append(AU2019_VERSION );
    version.append("\n  - Firmware Version");
    version.append(firmwareVersion);
    //qDebug() << "Firmware: " << firmwareVersion;
    version.append("\n  - Bootloader Version");
    version.append(bootloaderVersion);
    version.append("\n\n  2021 - Jean-Jacques Aubry");
    QMessageBox::about(this, tr("About LCR Meter AU2019"), version);
    this->setEnabled(true);
}


//-----------------------------------------------------------------------------
// SLOT aboutQtAct
//-----------------------------------------------------------------------------
void MainWindow::aboutQtAct(void)
{
    this->setEnabled(false);   // deleting parent...
    QMessageBox::aboutQt(this, "");
    this->setEnabled(true);
}



//-----------------------------------------------------------------------------
// SLOT Sort
//-----------------------------------------------------------------------------
void MainWindow::Sort(void)
{
    if (!initMessageReceived)
        return;

    QByteArray theText;

    ClearDataInWindow();
    ui->SortDockWidget->show();
    onSorting = true;

    if (port->isOpen())
    {
        theText = SORT;
        qDebug() << "Send " << theText;
        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        port->write(theText);
        if (!port->waitForBytesWritten())
            port->flush();
    }
}

//-----------------------------------------------------------------------------
// SLOT QuitSort
//-----------------------------------------------------------------------------
void MainWindow::QuitSort(void)
{
    if (!initMessageReceived)
        return;

    QByteArray theText;

    ui->SortDockWidget->hide();
    ShowDataInWindow();
    onSorting = false;

    if (port->isOpen())
    {
        theText = KEY_5;
        qDebug() << "Send " << theText;
        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        port->write(theText);
        if (!port->waitForBytesWritten())
            port->flush();
    }
}


//-----------------------------------------------------------------------------
// SLOT SetCalib_Range1
// Called by the menu "Calibration of the range 1"
//-----------------------------------------------------------------------------
void MainWindow::SetCalib_Range1(void)
{
    if (!initMessageReceived)
        return;

    qDebug() << "on calib R1";
    SetCalibAllRanges(1);
}

//-----------------------------------------------------------------------------
// SLOT SetCalib_Range2
// Called by the menu "Calibration of the range 2"
//-----------------------------------------------------------------------------
void MainWindow::SetCalib_Range2(void)
{
    if (!initMessageReceived)
        return;

    qDebug() << "on calib R2";
    SetCalibAllRanges(2);
}

//-----------------------------------------------------------------------------
// SLOT SetCalib_Range3
// Called by the menu "Calibration of the range 3"
//-----------------------------------------------------------------------------
void MainWindow::SetCalib_Range3(void)
{
    if (!initMessageReceived)
        return;

    qDebug() << "on calib R3";
    SetCalibAllRanges(3);
}

//-----------------------------------------------------------------------------
// SLOT SetCalib_Range4
// Called by the menu "Calibration of the range 4"
//-----------------------------------------------------------------------------
void MainWindow::SetCalib_Range4(void)
{
    if (!initMessageReceived)
        return;

    qDebug() << "on calib R4";
    SetCalibAllRanges(4);
}

//-----------------------------------------------------------------------------
// SetCalibAllRanges
//-----------------------------------------------------------------------------
void MainWindow::SetCalibAllRanges(int choix)
{
    qDebug() << "on CalibAllRanges";

    QByteArray theText;

    if (port->isOpen())
    {
        switch (choix)
        {
            case 1:
                theText = CALIB_RANGE1;
                break;

            case 2:
                theText = CALIB_RANGE2;
                break;

            case 3:
                theText = CALIB_RANGE3;
                break;

            case 4:
                theText = CALIB_RANGE4;
                break;

        }
        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        port->write(theText);
        if (!port->waitForBytesWritten())
            port->flush();
    }
}




//-----------------------------------------------------------------------------
// SLOT OpenTrimAllFreq
// Called by the menu "<Open-circuit> Trim, all freq."
//-----------------------------------------------------------------------------
void MainWindow::OpenTrimAllFreq(void)
{
    if (!initMessageReceived)
        return;

    QByteArray theText = TRIM_OPEN_ALL;

    qDebug() << "on Open Trim all Freq";

    if (port->isOpen())
    {
        qDebug() << "Send " << theText;
        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        port->write(theText);
        if (!port->waitForBytesWritten())
            port->flush();
    }
}

//-----------------------------------------------------------------------------
// SLOT ShortTrimAllFreq
// Called by the menu "<Short-circuit> Trim, all freq."
//-----------------------------------------------------------------------------
void MainWindow::ShortTrimAllFreq(void)
{
    if (!initMessageReceived)
        return;

    QByteArray theText = TRIM_SHORT_ALL;

    qDebug() << "on short Trim all Freq";

    if (port->isOpen())
    {
        qDebug() << "Send " << theText;
        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        port->write(theText);
        if (!port->waitForBytesWritten())
            port->flush();
    }
}

//-----------------------------------------------------------------------------
// SLOT SetPGA2_G3
// Called by the menu "PGA2: gain 3 calibration"
//-----------------------------------------------------------------------------
void MainWindow::SetPGA2_G3(void)
{
    if (!initMessageReceived)
        return;

    qDebug() << "on setPGA2-3";
    PGA2_inTest = 3;
    SetPGA2_GX(PGA2_inTest);
}

//-----------------------------------------------------------------------------
// SLOT SetPGA2_G10
// Called by the menu "PGA2: gain 10 calibration"
//-----------------------------------------------------------------------------
void MainWindow::SetPGA2_G10(void)
{
    if (!initMessageReceived)
        return;

    qDebug() << "on setPGA2-10";
    PGA2_inTest = 10;
    SetPGA2_GX(PGA2_inTest);
}

//-----------------------------------------------------------------------------
// SetPGA2_GX
//-----------------------------------------------------------------------------
void MainWindow::SetPGA2_GX(int choix)
{
    qDebug() << "on setPGA2-X";

    QByteArray theText;
    QString Qphase;

    //ClearDataInWindow();

    if (port->isOpen())
    {
        onAdjustPhiPGA2 = true;
        ui->PhaseG2label->setText("");
        ui->PhaseG2dockWidget->show();
        if (choix == 3)
            theText = G3_CALIBRATION;
        else
            theText = G10_CALIBRATION;
        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        port->write(theText);
        if (!port->waitForBytesWritten())
            port->flush();
    }
}

//-----------------------------------------------------------------------------
// SLOT Send_OK
// Called when a button 'OK' is clicked
//-----------------------------------------------------------------------------

void MainWindow::Send_OK(void)
{
    if (!initMessageReceived)
        return;

    QByteArray theText;

    theText = KEY_4;    // OK
    // Discards all characters from the input buffer
    port->clear(QSerialPort::Input);
    port->write(theText);
    if (!port->waitForBytesWritten())
        port->flush();
    if (onAdjustPhiPGA2)
    {
        ui->PhaseG2dockWidget->hide();
        onAdjustPhiPGA2 = false;
    }
}

//-----------------------------------------------------------------------------
// SLOT Send_Exit
// Called when a button 'EXIT' is clicked
//-----------------------------------------------------------------------------

void MainWindow::Send_Exit(void)
{
    if (!initMessageReceived)
        return;

    QByteArray theText;

    theText = KEY_5;    // EXIT
    // Discards all characters from the input buffer
    port->clear(QSerialPort::Input);
    port->write(theText);
    if (!port->waitForBytesWritten())
        port->flush();
    if (onAdjustPhiPGA2)
    {
        ui->PhaseG2dockWidget->hide();
        onAdjustPhiPGA2 = false;
    }
}



//-----------------------------------------------------------------------------
// SLOT SetDDS_VRef
// Called by the menu "Measured value of Vref (DDS)"
//-----------------------------------------------------------------------------
void MainWindow::SetDDS_VRef(void)
{
    if (!initMessageReceived)
        return;

    ui->DDS_VRefDockWidget->show();

    ui->DDS_VRefLineEdit->clear();
    //ui->DDS_VRefLineEdit->show();
    //ui->DDS_VRefLineEdit->setFocus();
    ui->DDS_VRefLineEdit->setValidator(DDSValidator);
    ui->DDS_VRefLineEdit->setPlaceholderText(" 1120 to 1240 ");
    ui->DDS_VRefLineEdit->setText(DDSVRef);
    onEditDSSVRef = true;
}

//-----------------------------------------------------------------------------
// SLOT getDDSVRef
// Called when the keyboard 'Return/Enter' is pressed
//-----------------------------------------------------------------------------
//
void MainWindow::getDDSVRef(void)
{
    QByteArray theText;
    QString oldDDSVRef = DDSVRef;

    if (onEditDSSVRef)
    {
        theText = NEW_DDSVREF;
        DDSVRef = ui->DDS_VRefLineEdit->text();
        if (DDSVRef != oldDDSVRef)
        {
            theText.append(DDSVRef);
            theText.append("\n");
            qDebug() << "new DDS VRef " << theText;
            // Discards all characters from the input buffer
            port->clear(QSerialPort::Input);
            port->write(theText);
            if (!port->waitForBytesWritten())
                port->flush();
        }
        onEditDSSVRef = false;
    }

    ui->DDS_VRefLineEdit->clearFocus();
    ui->DDS_VRefDockWidget->hide();
}



//-----------------------------------------------------------------------------
// SLOT SendMenuUp
// Called when button 'UP' is clicked
//-----------------------------------------------------------------------------
void MainWindow::SendMenuUp(void)
{
    if (!initMessageReceived)
        return;

    QByteArray theText;

    theText = MOVE_UP;
    // Discards all characters from the input buffer
    port->clear(QSerialPort::Input);
    port->write(theText);
    if (!port->waitForBytesWritten())
        port->flush();
    qDebug() << "send Move Up";
}

//-----------------------------------------------------------------------------
// SLOT SendMenuUp
// Called when button 'DOWN' is clicked
//-----------------------------------------------------------------------------
void MainWindow::SendMenuDown(void)
{
    if (!initMessageReceived)
        return;

    QByteArray theText;

    theText = MOVE_DOWN;
    // Discards all characters from the input buffer
    port->clear(QSerialPort::Input);
    port->write(theText);
    if (!port->waitForBytesWritten())
        port->flush();
    qDebug() << "send Move Down";
}


//-----------------------------------------------------------------------------
// SLOT setCMRRFrequency
// Called when a Radio button in the 'CMRRDockWidget' is toggled
//-----------------------------------------------------------------------------
void MainWindow::setCMRRFrequency(bool checked)
{
    if (!initMessageReceived)
        return;

    QByteArray theText;

    // Discards all characters from the input buffer
    port->clear(QSerialPort::Input);

    if (checked)
    {
        if (ui->radioButton1MHz->isChecked())
        {
            theText = MOVE_DOWN;    // for FREQ 1M;
            port->write(theText);
            if (!port->waitForBytesWritten())
                port->flush();
            qDebug() << "send Move Down";
        }
        else if (ui->radioButton10kHz->isChecked())
        {
            theText = MOVE_UP;      // for FREQ 10k;
            port->write(theText);
            if (!port->waitForBytesWritten())
                port->flush();
            qDebug() << "send Move Up";
        }

        //setDelay(200);
    }
}


//-----------------------------------------------------------------------------
// SLOT SetCMRR
// Called by the menu "CMRR of Voltage diff. opamp"
//-----------------------------------------------------------------------------
void MainWindow::SetCMRR(void)
{
    if (!initMessageReceived)
        return;
    QByteArray theText;

    if (port->isOpen())
    {
        ui->CMRRDockWidget->show();
        theText = CMRR_INPUT_AMP;
        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        port->write(theText);
        if (!port->waitForBytesWritten())
            port->flush();
    }
}


//-----------------------------------------------------------------------------
// SLOT closeCMRRWidget
// Called when button 'OK' on 'CMRRDockWidget' is clicked
//-----------------------------------------------------------------------------

void MainWindow::closeCMRRWidget(void)
{
    QByteArray theText;

    ui->CMRRDockWidget->close();
    theText = KEY_5;
    // Discards all characters from the input buffer
    port->clear(QSerialPort::Input);
    port->write(theText);
    if (!port->waitForBytesWritten())
        port->flush();
}


//-----------------------------------------------------------------------------
// SLOT SetSinGenOff
// Called by menu "Set sinus generator offset"
//-----------------------------------------------------------------------------
void MainWindow::SetSinGenOff()
{
    if (!initMessageReceived)
        return;

    QByteArray theText;

    if (port->isOpen())
    {
        theText = SINUS_GEN_OFS;
        port->write(theText);
        port->flush();
        QMessageBox msgBox;
        msgBox.setText(tr("Clic on OK when operation done"));
        msgBox.exec();
        setDelay(500);
        theText = KEY_5;
        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        port->write(theText);
        if (!port->waitForBytesWritten())
            port->flush();
    }
}


//-----------------------------------------------------------------------------
// SLOT openQLimitWidget
// Called by menu "Set Q limit..."
//-----------------------------------------------------------------------------
void MainWindow::openQLimitWidget(void)
{
    ui->QLimitOrSeriesComboBox->clear();
    ui->QLimitOrSeriesComboBox->addItems(QlimitList);
    ui->QLimitOrSeriesComboBox->setCurrentIndex(QlimitIndex);

    ui->QLimitSeriesDockWidget->show();
    onQLimitChoise = true;
    // QLimitSeriesDockWidget
    // QLimitOrSeriesComboBox
    // QLimitSeriesOKpushButton
}


//-----------------------------------------------------------------------------
// SLOT openSeriesWidget
// Called by menu "Choose accuracy for sorting..."
//-----------------------------------------------------------------------------
void MainWindow::openSeriesWidget(void)
{
    ui->QLimitOrSeriesComboBox->clear();
    ui->QLimitOrSeriesComboBox->addItems(SeriesList);
    ui->QLimitOrSeriesComboBox->setCurrentIndex(SeriesIndex);
    ui->QLimitSeriesDockWidget->show();
    onSeriesChoise = true;
    // QLimitSeriesDockWidget
    // QLimitOrSeriesComboBox
    // QLimitSeriesOKpushButton
}


//-----------------------------------------------------------------------------
// SLOT SetQLimitOrSeries
// Called when the 'OK' button of 'QLimitOrSeriesComboBox' is clicked
//-----------------------------------------------------------------------------
void MainWindow::SetQLimitOrSeries(void)
{
    QString message;
    QByteArray theText;
    int index;

    if (!initMessageReceived)
        return;

    index = ui->QLimitOrSeriesComboBox->currentIndex();
    message = ui->QLimitOrSeriesComboBox->currentText();
    if (onQLimitChoise && index == lastQIndex)
            message = max_Q;

    qDebug() << "returned Qlimit or Series = " << message << "  Index = " << index;

    if (onQLimitChoise)
    {
        if (message != Q_Limit)
        {
            Q_Limit = message;
            QlimitIndex = index;
            qDebug() << "new Qlimit = " << message;
            theText = NEW_QLIMIT;
            theText.append(message);
            theText.append("\n");
            if (port->isOpen())
            {
                qDebug() << "send " << theText;
                // Discards all characters from the input buffer
                port->clear(QSerialPort::Input);
                port->write(theText);
                if (!port->waitForBytesWritten())
                    port->flush();
            }
        }
        onQLimitChoise = false;
    }
    else if (onSeriesChoise)
    {        
        QTextStream(&theText)  << NEW_SORT_PARAM << index;        // index = 2 -> theText = "SORT_P 2"
        theText.append("\n");
        if (port->isOpen())
        {
            Series = message;
            SeriesIndex = index;
            qDebug() << "send " << theText;            
            // Discards all characters from the input buffer
            port->clear(QSerialPort::Input);
            port->write(theText);
            if (!port->waitForBytesWritten())
                port->flush();
        }
        onSeriesChoise = false;
    }
    ui->QLimitSeriesDockWidget->hide();
    //qDebug() << "Close  QLimitOrSeriesComboBox";
}



//-----------------------------------------------------------------------------
// SLOT setTrimPressed
// Called at the end of the singleShot()
//-----------------------------------------------------------------------------
void MainWindow::setTrimLongPressed(void)
{
    longPressed = true;
}


//-----------------------------------------------------------------------------
// SLOT setTrimPressed
// Called when the 'TRIM' is pressed
//-----------------------------------------------------------------------------
void MainWindow::setTrimPressed(void)
{
    longPressed = false;
    QTimer::singleShot(1500, this, SLOT(setTrimLongPressed()));
}


//-----------------------------------------------------------------------------
// SLOT setTrimReleased
// Called when the 'TRIM' is released
//-----------------------------------------------------------------------------
void MainWindow::setTrimReleased(void)
{
    if(longPressed)
    {
        //qDebug() << "TRIM long released";
        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        port->write(TRIM_LONG);
        //qDebug() << "send message " << TRIM_LONG;
        if (!port->waitForBytesWritten())
            port->flush();
    }
    else
    {
        //qDebug() << "TRIM short released";
        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        port->write(TRIM_SHORT);
        //qDebug() << "send message " << TRIM_SHORT;
        if (!port->waitForBytesWritten())
            port->flush();
    }
}


//-----------------------------------------------------------------------------
// SLOT setMode
// Called when the 'MODE' is clicked
//-----------------------------------------------------------------------------
void MainWindow::setMode(void)
{
    // Discards all characters from the input buffer
    port->clear(QSerialPort::Input);
    port->write(MODE_D);
    if (!port->waitForBytesWritten())
        port->flush();
    qDebug() << "send message " << MODE_D;
}


//-----------------------------------------------------------------------------
// SLOT setAVG
// Called when the 'AVG' is clicked
//-----------------------------------------------------------------------------
void MainWindow::setAVG(void)
{
    // Discards all characters from the input buffer
    port->clear(QSerialPort::Input);
    if (AVG_slow)
    {
        port->write(AVG_FAST);
        qDebug() << "send message " << AVG_FAST;
    }
    else
    {
        port->write(AVG_SLOW);
        qDebug() << "send message " << AVG_SLOW;
    }
    if (!port->waitForBytesWritten())
        port->flush();
}


//-----------------------------------------------------------------------------
// SLOT setRHold
// Called when the 'RHold' is clicked
//-----------------------------------------------------------------------------
void MainWindow::setRHold(void)
{
    // Discards all characters from the input buffer
    port->clear(QSerialPort::Input);
    port->write(R_HOLD);
    if (!port->waitForBytesWritten())
        port->flush();
    qDebug() << "send message " << R_HOLD;
}


//-----------------------------------------------------------------------------
// SLOT setACLevel
// Called when the 'ACButton' is clicked
//-----------------------------------------------------------------------------
void MainWindow::setACLevel(void)
{
    QByteArray theText;
    char level[2];

    switch (ACLevel) {
    case 1:
        ACLevel = 2;
        break;

    case 2:
        ACLevel = 3;
        break;

    case 3:
        ACLevel = 4;
        break;

    default:
    case 4:
        ACLevel = 1;
        break;
    }

    theText = AC_LEVEL;
    sprintf(level, "%u", ACLevel);
    theText.append(level);
    theText.append('\n');
    // Discards all characters from the input buffer
    port->clear(QSerialPort::Input);
    port->write(theText);
    if (!port->waitForBytesWritten())
        port->flush();
    qDebug() << "send message AC_LEVEL: " << theText;
}


//-----------------------------------------------------------------------------
// SLOT setDCBias
// Called when the 'DCButton' is clicked
//-----------------------------------------------------------------------------
//
// New DC Bias, in mV or mA, entered in the line Edit
// Int value in range [0,5000] mV or [0,50] mA
//
void MainWindow::setDCBias(void)
{
    if (primaryKind != C_KIND && primaryKind != L_KIND)
     {
        QMessageBox msgBox;
        msgBox.setText(tr("No DC bias for resistor"));
        msgBox.exec();
        return;
     }

    ui->DC->hide();
    ui->DCLineEdit->clear();

    if (primaryKind == C_KIND) {
        ui->DC_Label->setText("mV");
        ui->DCLineEdit->setPlaceholderText(" 0 to 5000 ");
        ui->DCLineEdit->setValidator(mVDCValidator);
    }
    else {
        ui->DC_Label->setText("mA");
        ui->DCLineEdit->setPlaceholderText(" 0 to 50 ");
        ui->DCLineEdit->setValidator(mADCValidator);
    }
    ui->DC_Label->show();
    ui->DCLineEdit->show();
    ui->DCLineEdit->setFocus();

    onEditDC = true;
}


//-----------------------------------------------------------------------------
// SLOT getDCBias
// Called when the keyboard 'Return/Enter' is pressed
//-----------------------------------------------------------------------------
//
void MainWindow::getDCBias(void)
{
    QByteArray theText;

    if (onEditDC)
    {
        theText = DC_BIAS;
        theText.append(ui->DCLineEdit->text());
        theText.append("\n");
        qDebug() << "new DC bias " << theText;

        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        port->write(theText);
        if (!port->waitForBytesWritten())
            port->flush();
        onEditDC = false;
    }

    ui->DCLineEdit->clearFocus();
    ui->DCLineEdit->hide();
    ui->DC_Label->hide();
    ui->DC->show();
}


//-----------------------------------------------------------------------------
// SLOT setFreq
// Called when the 'Freq' is clicked
//-----------------------------------------------------------------------------
//
// New frequency, in Hz, entered in the line Edit
// Int value in range [50,2000000] i.e. 50Hz to 2MHz
//
void MainWindow::setFreq(void)
{
    //inRun = onMeasurement;

    if (!onEditFrequency)
    {
        onEditFrequency = true;
        ui->Frequency->hide();
        ui->FreqLineEdit->clear();

        ui->hzLabel->show();
        //ui->runButton->clearFocus();
        ui->FreqLineEdit->show();
        ui->FreqLineEdit->setFocus();
        ui->FreqLineEdit->setValidator(FreqValidator);
        ui->FreqLineEdit->setPlaceholderText(" 50 to 2000000 ");
    }
    else
    {
        onEditFrequency = false;
        getFreq();
    }

}


//-----------------------------------------------------------------------------
// SLOT getFreq
// Called when the keyboard 'Return/Enter' is pressed
//-----------------------------------------------------------------------------
//
void MainWindow::getFreq(void)
{
    QByteArray theText;

    if (onEditFrequency)
    {
        theFreqText = NEW_FREQ;
        theFreqText.append(ui->FreqLineEdit->text());
        theFreqText.append("\n");
        qDebug() << "new freq " << theFreqText;
        settings->setValue("Frequency", theFreqText);


        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        port->write(theFreqText);
        if (!port->waitForBytesWritten())
            port->flush();
        onEditFrequency = false;
    }

    ui->FreqLineEdit->clearFocus();
    ui->FreqLineEdit->hide();
    ui->hzLabel->hide();
    ui->Frequency->show();
}


//-----------------------------------------------------------------------------
// SLOT RunStopMeasure
// Called by the program after opening the port,
//    or by a click on the 'runButton' if 'DEBUG_TEST' is defined
//-----------------------------------------------------------------------------
//
// It's like a toggle
//
void MainWindow::RunStopMeasure(void)
{
    // Discards all characters from the input buffer
    port->clear(QSerialPort::Input);

    if (onMeasurement)	// stop measurements
    {
        qDebug() << "send HALT";
        port->write(HALT);
        if (!port->waitForBytesWritten())
            port->flush();
        onMeasurement = false;
        ui->runButton->setFocus();
        ui->runButton->setText("RUN");
        ui->runButton->setToolTip(tr("Run measuremments"));
        setDelay(200);
    }
    else
    {
        qDebug() << "send RUN";
        port->write(RUN);
        if (!port->waitForBytesWritten())
            port->flush();
        onMeasurement = true;
        ui->runButton->clearFocus();
        ui->runButton->setText("HALT");
        ui->runButton->setToolTip(tr("Halt measuremments"));
        setDelay(200);
    }
}


//-----------------------------------------------------------------------------
// SLOT slotRead
// Called when the SIGNAL 'readyRead' is emited (when valid data are in Rx buffer).
//-----------------------------------------------------------------------------
//
void MainWindow::slotRead(void)
{
    int wPos;
    QString y;

    qint64 bw = port->readLine(inputString, 100);
    //port->clear(QSerialPort::Input);
    //setDelay(1);

    inputQString = inputString;                 // inputString is a 'C' string (array of char)
                                                // so change it to a QString
    //qDebug() << "--> full message received " << inputQString ;
    if (bw != -1)                               // it's a valid data
    {
        wPos = inputQString.indexOf('\n');       // remove the end of string marker
        if (wPos > 1)
        {
            y = inputQString.left(wPos);
            inputQString = y;
            messageReceived = true;
            ReadRequest();
        }
        else
        {
            port->clear(QSerialPort::Input);
            return;
        }
     }
}   // slotRead


//-----------------------------------------------------------------------------
// ReadRequest
//-----------------------------------------------------------------------------
//
// Filter the received string
//
void MainWindow::ReadRequest(void)
{
     QString message;
     int spacePos;
     QString message1;
     QString FlashVersion;
     QString PSError;
     bool ok;
     QMessageBox msgBox;

    //qDebug() << "--> message received " << inputQString ;

    if ( inputQString.contains(message_PRIMARY) )
    {
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        RemplaceKey();
        if (onSorting)
        {
            ui->SortingPrimaryValue->setText(inputQString);
            ui->SortingPrimaryValue->show();
            spacePos = inputQString.indexOf(' ');
            inputQString = inputQString.left(spacePos);     // inputQString = "101.0 O "
            ValueForSort = inputQString.toFloat(&ok);
            if (ValueForSort < MaxValueForSort && ValueForSort > MinValueForSort)
            {
                ui->SortResultLabel->setText(tr("PASS"));
            }
            else
            {
                ui->SortResultLabel->setText(tr("FAIL"));
            }
        }
        else
            ui->primaryValue->setText(inputQString);
        //qDebug() << "--> primary " << inputQString;
        if (onValueChoise)
        {
            ui->UPpushButton->setEnabled(true);
            ui->DownpushButton->setEnabled(true);
        }

        return;
    }


    if ( inputQString.contains(message_SECONDARY) )
    {
        if (onSorting)
            return;
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        RemplaceKey();
        //qDebug() << "--> secondary " << inputQString;
        if (circuitKind == PLAIN)
        {
            ui->secondaryValue->hide();
            //ui->label_Phase->hide();
            //ui->Phase->hide();
            //ui->label_QD->hide();
            //ui->Quality->hide();
            //ui->ModeButton->hide();
        }
        else
        {
            ui->secondaryValue->show();
            ui->label_Phase->show();
            ui->Phase->show();
            ui->label_QD->show();
            ui->Quality->show();
            ui->ModeButton->show();
        }
        ui->secondaryValue->setText(inputQString);
        return;
    }


    if ( inputQString.contains(message_Q) )
    {
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        ui->label_QD->setText("Q ");
        ui->Quality->setText(inputQString);
        return;
    }


    if ( inputQString.contains(message_D) )
    {
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        ui->label_QD->setText("D ");
        ui->Quality->setText(inputQString);
        return;
    }


    if ( inputQString.contains(message_PHI) )
    {
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        RemplaceKey();
        if (onAdjustPhiPGA2)
        {
            ui->PhaseG2label->setText(inputQString);
            testPhase();
        }
        else
            ui->Phase->setText(inputQString);
        return;
    }


    if ( inputQString.contains(message_CIRCUIT) )   // inputQString = "CIR primaryKind secondaryKind circuitKind"
    {
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);          // "primaryKind secondaryKind circuitKind"
        spacePos = inputQString.indexOf(' ');
        message = inputQString.left(spacePos);      // "primaryKind"
        primaryKind = message.toInt(&ok,10);

        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);          // "secondaryKind circuitKind"
        message = inputQString.left(spacePos);      // "secondaryKind"
        secondaryKind = message.toInt(&ok,10);

        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);          // "circuitKind"
        message = inputQString; //.left(spacePos);
        circuitKind = message.toInt(&ok,10);
        Display_Symboles();
        return;
    }


    if ( inputQString.contains(message_SP_MODE) )   // inputQString = "message_SP_MODE AutoModel SP_mode"
    {
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);          // "AutoModel SP_mode"
        spacePos = inputQString.indexOf(' ');
        message = inputQString.left(spacePos);      // "AutoModel"
        AutoModel = message.toInt(&ok,10);

        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        message = inputQString.left(spacePos);      // "SP_mode"
        SP_mode = message.toInt(&ok,10);

        if (AutoModel == 0)
            ui->AutoLabel->show();
        else
            ui->AutoLabel->hide();
        if (AutoModel == 0)                         // Auto mode
        {
            if (SP_mode == 1)                        // series
                ui->ModeButton->setText("PARALLEL");
            else if (SP_mode == 2)                   // parallel
                ui->ModeButton->setText("SERIES");
        }
        else
        {
                ui->ModeButton->setText("AUTO");
        }
        return;
    }


    if ( inputQString.contains(message_Z) )
    {
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        RemplaceKey();
        //qDebug() << "Z = " << inputQString ;
        ui->Impedance->setText(inputQString);
        return;
    }


    if ( inputQString.contains(message_VX) )
    {
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        RemplaceKey();
        ui->Vx->setText(inputQString);
        return;
    }


    if ( inputQString.contains(message_IX) )
    {
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        RemplaceKey();
        ui->Ix->setText(inputQString);
        return;
    }

    if ( inputQString.contains(message_RUI) )
    {
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        qDebug() << inputQString;
        ui->RangeLabel->setText(inputQString);
        return;
    }

    if ( inputQString.contains(message_FREQ) )
    {
        //qDebug() << "--> Freq received " << inputQString ;
        if (firstTimeFreqReceived)
        {
            if (settings->contains("Frequency"))
            {
                setDelay(1000);
                theFreqText = settings->value("Frequency").toByteArray();
                //qDebug() << "new freq " << theFreqText;
                // Discards all characters from the input buffer
                port->clear(QSerialPort::Input);
                port->write(theFreqText);
                if (!port->waitForBytesWritten())
                    port->flush();
            }
            firstTimeFreqReceived = false;
            return;
        }

        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        ui->Frequency->setText(inputQString);
        return;
    }


    if ( inputQString.contains(message_DC) )
    {
        //qDebug() << "--> received " << inputQString ;
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        //qDebug() << "--> received " << inputQString ;
        if (inputQString != "0.0 V") {
            ui->DC->setStyleSheet("color: red");
            ui->TrimButton->hide();
        }
        else {
            ui->DC->setStyleSheet("color: black");
            ui->TrimButton->show();
        }
        ui->DC->setText(inputQString);
        return;
    }


    if ( inputQString.contains(message_AC) )
    {
        //qDebug() << "--> received " << inputQString ;
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        ui->AC->setText(inputQString);
        if (inputQString == "1V RMS  ")
            ACLevel = 1;
        else if (inputQString ==  "0.5V RMS")
            ACLevel = 2;
        else if (inputQString == "0.2V RMS")
            ACLevel = 3;
        else if (inputQString == "0.1V RMS")
            ACLevel = 4;
        return;
    }


    if ( inputQString.contains(message_R_HOLD) )
    {
        //qDebug() << "--> received " << inputQString ;
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        ui->RH_OnOffLabel->setText(inputQString);
        return;
    }


    if ( inputQString.contains(message_TEXT) )  // "J "
    {
        qDebug() << "--> received " << inputQString ;
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        int index = inputQString.toInt();

        // some index are not used
        switch(index)
        {

        case 0:
        message = " ";                                                  // not used!
        break;

        case 1:
        message = tr("INITIALISATION, WAIT...");                       // not used!
        break;

        case 2:
        message = tr("No jumper fitted from J10 to J13");
        break;

        case 3:
        message = tr("Adjust C51 for |Phi| < 0.3");
        break;

        case 4:
        message = tr("Adjust C106 for |Phi| < 0.1");
        break;

        case 5:
        message = tr("Save the gain?");
        break;

        case 6:
        message = tr("Select normalized value");
        ClearDataInWindow();
        ui->UPpushButton->show();
        ui->DownpushButton->show();
        ui->OKpushButton->show();
        ui->EXITpushButton->show();
        onValueChoise = true;
        break;

        case 7:
        message = tr("-> Adjust R146 for DC null on TP7");
        break;

        case 8:
        message = tr("Saving the Trim data...");
        break;

        case 9:
        message = tr("No Trim data to save ");
        break;

        case 10:
        message = tr("Save the data?");
        break;

        case 11:
        message = tr ("No DC bias for resistor");
        break;

        case 12:
        message = tr("Calculating the gain and phase");
        break;

        case 13:
        message = tr("  -> Put a jumper in J10");
        break;

        case 14:
        message = tr("  -> Put a jumper in J11");
        break;

        case 15:
        message = tr("  -> Put a jumper in J12");
        break;

        case 16:
        message = tr("  -> Put a jumper in J13");
        break;

        case 17:
        message = tr("Not the right jumper, exit");
        break;

        case 18:
        message = tr("Okay, will take few minutes");
        break;

        case 19:
        message = tr("Do the range 1 calibration");
        break;

        case 20:
        message = tr("Do the range 2 calibration");
        break;

        case 21:
        message = tr("Do the range 3 calibration");
        break;

        case 22:
        message = tr("Do the range 4 calibration");
        break;

        case 23:
        message = tr("Error, exit");
        break;

        case 24:
        message = tr("Do PGA2 gain 3 calibration");
        break;

        case 25:
        message = tr("Do PGA2 gain 10 calibration");
        break;

        case 26:
        message = tr("Short circuit trim. Wait...");
        break;

        case 27:
        message = tr("Open circuit trim. Wait...");
        break;

        case 28:
        message = tr("Wait...");
        break;

        case 29:
        message = tr("  -> Open or Short the circuit");
        break;

        case 30:
        message = tr("Use saved frequency?");
        break;

        case 31:
        message = tr("-- FAIL --");
        break;

        case 32:
        message = tr ("PASS");
        break;

        case 33:
        message = tr("Short circuit before enter menu");
        break;

        case 34:
        message = tr("Open circuit before enter menu");
        break;

        case 35:
        message = tr("Adjust R31 for minimum voltage");
        break;

        case 36:
        message = tr("Adjust C44 for minimum voltage");
        break;

        case 37:
        message = tr("J9 set, J8 off, J17 set ");
        break;

        case 38:
        message = tr("DC Bias voltage: 0 to 5V");
        break;

        case 39:
        message = tr("DC Bias current: 0 to 50mA");                     // not used!
        break;

        case 40:
        message = tr("AC Drive level: 0.1V RMS to 1V RMS");             // not used!
        break;

        case 41:
        message = tr("Measured voltage value on TP6");
        break;

        }   // switch

        ui->SchematicLabel->setText(message);
        savedChoice = -1;
    }


    if ( inputQString.contains(message_END) )               // when "Select normalized value" is finished
    {
        qDebug() << "--> received " << inputQString ;
        ui->UPpushButton->hide();
        ui->DownpushButton->hide();
        ui->OKpushButton->hide();
        ui->EXITpushButton->hide();
        ShowDataInWindow();
        onValueChoise = false;
    }

    if ( inputQString.contains(message_MAX) )
    {
        QString StringValue;
        bool ok;

        if (onValueChoise)
        {
           ui->UPpushButton->setEnabled(false);
        }
        else if (onSorting)
        {
            spacePos = inputQString.indexOf(' ');           // inputQString = "MAX 101.0 O "
            inputQString.remove(0,spacePos+1);              // inputQString = "101.0 O "
            RemplaceKey();
            spacePos = inputQString.indexOf(' ');
            StringValue = inputQString.left(spacePos);     // inputQString = "101.0 O "
            MaxValueForSort = StringValue.toFloat(&ok);
            qDebug() << "max = " << inputQString << ok << MaxValueForSort;
            inputQString.prepend("<  ");
            ui->HighValueLabel->setText(inputQString);
        }
    }

    if ( inputQString.contains(message_MIN) )
    {
        QString StringValue;
        bool ok;

        if (onValueChoise)
        {
           ui->DownpushButton->setEnabled(false);
        }
        else if (onSorting)
        {
            spacePos = inputQString.indexOf(' ');
            inputQString.remove(0,spacePos+1);
            RemplaceKey();
            spacePos = inputQString.indexOf(' ');
            StringValue = inputQString.left(spacePos);
            MinValueForSort = StringValue.toFloat(&ok);
            qDebug() << "min = " << inputQString << ok << MinValueForSort;
            inputQString.prepend(">  ");
            ui->LowValueLabel->setText(inputQString);
        }
    }


    if ( inputQString.contains(message_INDEX) )     // for progress dialog index
    {
        //qDebug() << "--> received " << inputQString ;
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        progressIndex = inputQString.toInt();
        if (progressIndex == 0)
        {
            this->setEnabled(false);   // deleting parent...
            showProgressDialog();
            onFrequenciesSettings = true;
        }
        else if (progressIndex >= FREQ_MEM_SIZE - 1) // it's a possibility to loss the last value!
        {
            if (onFrequenciesSettings)
            {
                onFrequenciesSettings = false;
                delete progressDialog;
                setDelay(1000);
                showOKExitDialog();
                this->setEnabled(true);   // deleting parent...
            }
        }
        else
            progressDialog->setValue(progressIndex);
     }


    if ( inputQString.contains(message_MEASURE) )
    {
        //qDebug() << "--> received " << inputQString ;
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        ui->CMRRLabel->setText(inputQString);

        return;
    }

    if ( inputQString.contains(message_AVGS) )
    {
        ui->AVGLabel->setText("SLOW");
        AVG_slow = true;
        return;
    }

    if ( inputQString.contains(message_AVGF) )
    {
        ui->AVGLabel->setText("FAST");
        AVG_slow = false;
        return;
    }

    if (inputQString.contains(message_UPDATE_READY))
    {
        qDebug() << "--> received " << "UPD_RDY";
        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        if(EraseBank2)
        {
            port->write(UPDATE2);
            if (!port->waitForBytesWritten())
                port->flush();
            qDebug() << "send UPD2";
        }
        else
        {
            port->write(UPDATE);
            if (!port->waitForBytesWritten())
                port->flush();
            qDebug() << "send UPD";
         }
         return;
    }


    // messages send by the Bootloader: Memory error or jumper on J16
    if (inputQString.contains(message_MEMORY_FAIL) || inputQString.contains(message_NEED_UPDATE))
    {
        bool ok = false;

        onFirmwareUpdate = true;
        if (inputQString.contains(message_MEMORY_FAIL))
        {
            qDebug() << "--> received " << "MEM_FAIL";
            QMessageBox::critical(this, "", tr("Program memory checksum error. You must <strong>NECESSARILY</strong> reload the program."));
        }
        else
        {
            qDebug() << "--> received " << "ND_UPD";
            QMessageBox::critical(this, "", tr("User want to update the firmware."));
            forcedUpdateByUser = true;
        }

        msgBox.setText(tr("Erasing the Calibration Datas?"));
        msgBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
        msgBox.setDefaultButton(QMessageBox::No);


        if (msgBox.exec() == QMessageBox::Yes)
            EraseBank2 = true;
        else
            EraseBank2 = false;

        ok = GetFileNameHex();
        if (!ok)
        {
            QMessageBox::information(this,"",tr("Closing the application. You must also shutdown the device"));
            CloseApplication();
        }
        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        if (EraseBank2)
            port->write(UPDATE2);
        else
            port->write(UPDATE);
        if (!port->waitForBytesWritten())
            port->flush();
        qDebug() << "send UPDx";
        //setDelay(100);
        return;
    }


    if (inputQString.contains(message_READY_RECEIVE))
    {
        qDebug() << "--> received " << "RDY_RCV";
        qDebug() << "send the .hex file";
        SendFichierHex();
        return;
    }

    if (inputQString.contains(message_READY_RECEIVE_TXT))   // "RDY_TXT "
    {
        qDebug() << "--> received " << "RDY_TXT";
        qDebug() << "send the .txt file";
        SendFichierTexts();
        return;
    }

    if (inputQString.contains(message_ERROR_TXT))       // "ERR_TXT "
    {
        qDebug() << "--> received " << "ERR_TXT";
        QMessageBox::critical(this, "", tr("The file sent could not be exploited. Check it out and do it again"));
        return;
    }


    // test for synchro message with the bootloader
#ifdef BOOTLOADER
    if (inputQString.contains(message_SYNCHRO))     // "NEED_S "
    {
        qDebug() << "--> NEED_S received " << inputQString ;
        initMessageReceived = true;

        // send again first message if hardware loss the first sending
        qDebug() << "send START_BOOTLOADER";
        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        port->write(START);		// "START" synchronization with bootloader
        if (!port->waitForBytesWritten())
            port->flush();
        //setDelay(200);
        return;
    }
#endif

    if (inputQString.contains(message_FIRMVERSION))    // "FVER "
    {
        spacePos = inputQString.indexOf(' ');
        if (spacePos != 0)
            inputQString.remove(0,spacePos);

        qDebug() << "Firmware version: " << inputQString ;
        firmwareVersion = inputQString;

        message = "   LCR Meter AU2019  version ";
        message.append(AU2019_VERSION);
        message.append("    -     Firmware version ");
        message.append(firmwareVersion);
        setWindowTitle(message);
        initMessageReceived = true;
        onMeasurement = true;
        message = ui->runButton->text();
        //qDebug() << "text RUN button " << message ;
        if (message != "HALT")
        {
            ui->runButton->setFocus();
            ui->runButton->setText("HALT");
            ui->runButton->setToolTip(tr("Halt measuremments"));
        }

        // send again first message if hardware loss the first sending
        qDebug() << "send F_VERS";
        // Discards all characters from the input buffer
        port->clear(QSerialPort::Input);
        port->write(F_VERS);            // "F_VERS\n" synchronization with firmware
        if (!port->waitForBytesWritten())
            port->flush();

        setDelay(200);
        return;
    }


    if (inputQString.contains(message_BOOTVERSION))    // "BVER "
    {
        qDebug() << "Bootloader  version: " << inputQString ;
        spacePos = inputQString.indexOf(' ');
        if (spacePos != 0)
            inputQString.remove(0,spacePos);
        qDebug() << "Bootloader  version: " << inputQString ;
        bootloaderVersion = inputQString;
        Display_the_Ranges();
        setDelay(200);
        Display_the_Ranges();
        return;
    }


    // message send by the bootloader before the jump to the firmware code
#ifdef BOOTLOADER
    if (inputQString.contains(message_GO_APP))     // "GO_APP "
    {
        //qDebug() << "--> GO_APP received " << inputQString ;
        if (onFirmwareUpdate)
        {
            onFirmwareUpdate = false;
            if (forcedUpdateByUser)
            {
                forcedUpdateByUser = false;
                msgBox.setText(tr("Don't forget to remove J16 jumper"));
                msgBox.setStandardButtons(QMessageBox::Ok);
                //msgBox.setDefaultButton(QMessageBox::Ok);
                msgBox.exec();
            }
            RunStopMeasure();
        }
        return;
    }
#endif


    if (inputQString.contains(message_UART))    // "MUART "
    {
        spacePos = inputQString.indexOf(' ');
        if (spacePos != 0)
            inputQString.remove(0,spacePos);
        qDebug() << "UART  message: " << inputQString ;
        int i = inputQString.toInt();
        switch (i)
        {
            case 0:
                message = tr("No BLE_module detected. Load LCR6 firmware");
                message1 = tr("Put a jumper on J16 and restart");
                msgBox.setInformativeText(message1);
                break;
            case 1:
                message = tr("BLE_module baudrate: 115200 bauds");
                break;
            case 2:
                message = tr("BLE_module baudrate: 9600 bauds");
                break;
            case 3:
                message = tr("BLE_module: unknown baudrate");
                break;
        }
        qDebug() << message;
        msgBox.setText(message);
        msgBox.setStandardButtons(QMessageBox::Ok);
        //msgBox.setDefaultButton(QMessageBox::Ok);
        msgBox.exec();

        return;
    }


    if ( inputQString.contains(message_SAVED_PARAMETERS) )   // inputQString = "PAR QLimit Series LanguageIndex UART DDSVREF"
    {
        qDebug() << "params " << inputQString;

        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);          // remove "PAR " -> inputQString = "QLimit Series UART DDSVREF"

        // QLimit
        spacePos = inputQString.indexOf(' ');
        message = inputQString.left(spacePos);      // "QLimit"
        Q_Limit = message;
        //qDebug() << "Q_limit = " << Q_Limit;
        // set-up the current index
        QlimitIndex = QlimitList.indexOf(Q_Limit);
        if (QlimitIndex == -1)                      // no match
        {
            QlimitIndex = 1;
            Q_Limit = "1000";
        }

        QlimitList.replace(lastQIndex, "no limit");

        //qDebug() << "Qlimit index = " << QlimitIndex;

        // Series
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);          // remove "QLimit " -> inputQString = "Series UART DDSVREF"
        spacePos = inputQString.indexOf(' ');
        message = inputQString.left(spacePos);      // "Series"
        Series = message;
        //qDebug() << "Series = " << Series;
        // set-up the current index
        SeriesIndex = SeriesList.indexOf(Series);   // check if Series is on the list
        if (SeriesIndex == -1)                      // no match
        {
            SeriesIndex = 2;
            Series = "E24 -> 5%";
        }
        //qDebug() << "Series index = " << SeriesIndex;

        // UART
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);          // remove "Series " -> inputQString = "UART DDSVREF"
        spacePos = inputQString.indexOf(' ');
        message = inputQString.left(spacePos);      // "UART"
        //qDebug() << "UART " << message;
        int UART = message.toInt();
        if (UART == 2)
            UARTBaudrate = 115200;
        else
            UARTBaudrate = 9600;
        //qDebug() << "BaudRate " << UARTBaudrate;

        // DDSVREF
        inputQString.remove(0,spacePos+1);          // remove "UART " -> inputQString = "DDSVREF"
        DDSVRef = inputQString;
        //qDebug() << "DDS_VREF = " << DDSVRef;

        Display_Symboles();
        return;
    }

/*
    // Error compatibility languages in firmware
    // Received message is chaine generated by sprintf(chaine, "ERF %u %u", (int)flashVersion, (int)LANGUAGE_VERSION );
    if (inputQString.contains(message_ERF))
    {
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        spacePos = inputQString.indexOf(' ');
        FlashVersion = inputQString.left(spacePos);
        inputQString.remove(0,spacePos+1);
        message = "Flash Version = " + FlashVersion + "    Firmware Version = " + inputQString;
        message1 = "Incompatibility of languages version in Flash";
        do
        {
            barreEtat->showMessage(message1, 2000);   // ms
            barreEtat->showMessage(message, 2000);   // ms
        }
        while (1);
    }
*/

    // Error Power Supplies
    // Received message is chaine generated by sprintf(chaine, "ERPS %u", (uint)i );
    if (inputQString.contains(message_ERPS))
    {
        spacePos = inputQString.indexOf(' ');
        inputQString.remove(0,spacePos+1);
        spacePos = inputQString.indexOf(' ');
        PSError = inputQString.left(spacePos);
        message = "Error = " + PSError;
        message1 = "Power supplies error";
        do
        {
            barreEtat->showMessage(message1, 2000);   // ms
            barreEtat->showMessage(message, 2000);   // ms
        }
        while (1);
    }
}   // ReadRequest


//-----------------------------------------------------------------------------
// RemplaceKey
//-----------------------------------------------------------------------------
//
// Remplace 'O', 'D', 'u' in the inputQString by printable Qt Key
//
void MainWindow::RemplaceKey(void)
{

    int PosChar = inputQString.indexOf('O');
    if (PosChar != -1)
        inputQString[PosChar] = QChar (0x3a9);  // Omega

    PosChar = inputQString.indexOf('u');
    if (PosChar != -1)
        inputQString[PosChar] = Qt::Key_mu;

    PosChar = inputQString.indexOf('D');
    if (PosChar != -1)
        inputQString[PosChar] = Qt::Key_degree;

}


//-----------------------------------------------------------------------------
// testPhase
//-----------------------------------------------------------------------------
void MainWindow::testPhase(void)
{
    QString Qphase;
    int spacePos;
    bool ok = false;
    qreal Phi;

    Qphase = ui->PhaseG2label->text();
    spacePos = Qphase.indexOf(' ');
    Qphase = Qphase.left(spacePos);      // "SP_mode"
    //setDelay(200);
    Phi = Qphase.toFloat();
    qDebug() << "phase = " << Qphase << "  Phi = " << Phi;
    if (PGA2_inTest == 10)
        ok = qFabs(Phi) < 0.3;
    else
        ok = qFabs(Phi) < 0.2;
    ui->PG2OKpushButton->setEnabled(ok);
}


//-----------------------------------------------------------------------------
// Display_Symboles
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
void MainWindow::Display_Symboles(void)
{
    char choice = 0;
    QString PNG_file;

    if (circuitKind == PLAIN)               // 3
    {
        switch (primaryKind) {
        case R_KIND:
            PNG_file = "R_seul.png";
            choice = 1;
            break;
        case C_KIND:
            PNG_file = "C_seul.png";
            choice = 2;
            break;
        case L_KIND:
            PNG_file = "L_seul.png";
            choice = 3;
            break;
        default:
            PNG_file = "";
            choice = 0;
        }
     }
    else if (circuitKind == SERIES)         // 0
    {
        switch (primaryKind) {
        case R_KIND:
            if (secondaryKind == C_KIND)    // 3
            {
                PNG_file = "RC_serie.png";
                choice = 4;
            }
            else
            {
                PNG_file = "RL_serie.png";
                choice = 5;
            }
            break;
        case C_KIND:
            PNG_file = "CR_serie.png";
            choice = 6;
            break;
        case L_KIND:
            PNG_file = "LR_serie.png";
            choice = 7;
            break;

        default:
            PNG_file = "";
            choice = 0;
        }
    }
    else if (circuitKind == PARALLEL)       // 1
    {
        switch (primaryKind) {
        case R_KIND:
            if (secondaryKind == C_KIND)
            {
                PNG_file = "RC_para.png";
                choice = 8;
            }
            else
            {
                PNG_file = "RL_para.png";
                choice = 9;
            }
            break;
        case C_KIND:
            PNG_file = "CR_para.png";
            choice = 10;
            break;
        case L_KIND:
            PNG_file = "LR_para.png";
            choice = 11;
            break;
        default:
            PNG_file = "";
            choice = 0;
        }
    }

    if (choice != savedChoice)
    {
        ui->SchematicLabel->setPixmap(QPixmap(":/AU2019/Resources/" + PNG_file));
        savedChoice = choice;
    }

} // Display_Symboles


//-----------------------------------------------------------------------------
// SLOT Display_the_Ranges()
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters: None
//
void MainWindow::Display_the_Ranges(void)
{
    QByteArray theText = "AFFG ";

    if (!initMessageReceived)
        return;

    if (ui->RcheckBox->isChecked())
    {
        displayRange = true;
        theText += "1\n";
    }
    else
    {
        displayRange = false;
        theText += "0\n";
    }
    qDebug() << theText;
        // OK
    // Discards all characters from the input buffer
    port->clear(QSerialPort::Input);
    port->write(theText);
    if (!port->waitForBytesWritten())
        port->flush();



}


//-----------------------------------------------------------------------------
// setDelay()
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters: delay needed in ms. max is 1000 ms (1s)
//
void MainWindow::setDelay( uint i)
{
    if (i > 1000)
        i = 1000;
    if (i == 0)
        i++;
    QThread::currentThread()->msleep(i);

//#ifdef Q_OS_WIN
    //Sleep(i);	// ms
//#else
    //usleep(i * 1000);	// us
//#endif
}
