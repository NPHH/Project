// --------------------------------------------------------------------------------------------------
// This program is the GUI part of AU2019 LCR meter.
// USB is used for the communincation between the LCR6 board and the Computer.
// The USB UART interface Integrated Circuit is a FT232R from FTDI Chips.
//
// A Virtual Com Port driver (VCP  driver) must be installed on Windows, Linux (if kernel version < 2.6.31).
//
// Sources files are with texts in english language.
// Put your translation file (AU2019_xx.qm) for your "locale" in the AU2019 application directory.
// Put also the localized qt_xx.qm file (required for translation of dialogs and buttons) in same directory.
//
// Without translation file for your "locale", application is in english (texts and numbers)
//
// You can also force a language by editing the "settings" file and write in the [General] field:
//      MyLocale="fr_FR" for French/France
//   or
//      MyLocale="de_CH" for German/Switzerland
//   etc...
//
// Obviously it is necessary that the corresponding translation files exist in the application directory!
//
// To force to stay in English, without taking account of translation files, write MyLocale="C"
//
// Settings file is located
// - OSX and Linux: $HOME/.config/FRAUBRJ/AU2019 x.x.x.ini
// - Windows: %APPDATA%\FRAUBRJ\AU2019 x.x.x.ini
//
// If the version of the AU2019 program changes, you will need to edit this file again.
//
// --------------------------------------------------------------------------------------------------


#include "mainwindow.h"
#include <QApplication>

#ifdef  OK_LANGUAGE
#include <QTranslator>
#endif

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

#ifdef  OK_LANGUAGE
    QSettings * mySettings;
    QTranslator translator1, translator2;
    QString locale, localeAppName, localeQtName, thePath, AppName;
    int slashPos;

    // look in setting file for specific locale
    mySettings = new QSettings( QSettings::IniFormat, QSettings::UserScope, "FRAUBRJ", "AU2019 " + QString( AU2019_VERSION ) );

    if (mySettings->contains("myLocale"))
        locale = mySettings->value("myLocale").toString( );
    else
        locale = QLocale::system().name();

    delete mySettings;
    qDebug() << "locale = " << locale;

    if (locale == "C" || locale.contains("en_US"))
    {
       QLocale::setDefault(QLocale::C);    // set "locale" to English/UnitedStates
    }
    else
    {
        int pos = locale.indexOf('_');
        locale = locale.left(pos);
        AppName = QCoreApplication::arguments().at(0);	// with full path
        slashPos = AppName.lastIndexOf(QDir::separator ());
        AppName.remove(0, slashPos + 1);	// remove path
        qDebug() << "AppName = " << AppName;

        QDir dir(QCoreApplication::applicationDirPath());

#if defined (Q_OS_MACX)
        // go up to application directory, where the translation files are located
        // dir is the "MacOS" directory, the directory of the Unix file
        dir.cdUp();						// "Contents" directory
        dir.cdUp();						// "AU2019.app" directory
#endif

        thePath = dir.absolutePath();
        slashPos = thePath.lastIndexOf(QDir::separator ());
        thePath.remove(slashPos + 1, 100);

        localeQtName = thePath + "qt_" + locale + ".qm";
        qDebug() << "localeQtName = " << localeQtName;
        localeAppName = thePath + AppName + "_" + locale  + ".qm";
        qDebug() << "localeAppName = " << localeAppName;

        if (translator1.load(localeAppName))
        {
            qDebug() << "ok, locale file for translation";
            a.installTranslator(&translator1);
            if (translator2.load(localeQtName))
            {
                a.installTranslator(&translator2);
                //localFind = true;
            }
        }
        else
        {
            qDebug() << "no locale file for translation";
            QLocale::setDefault(QLocale::C);    // set "locale" to English/UnitedStates
        }
    }

#else
    QLocale::setDefault(QLocale::C);    // set "locale" to English/UnitedStates
#endif

    MainWindow w;
    w.show();

    return a.exec();
}
