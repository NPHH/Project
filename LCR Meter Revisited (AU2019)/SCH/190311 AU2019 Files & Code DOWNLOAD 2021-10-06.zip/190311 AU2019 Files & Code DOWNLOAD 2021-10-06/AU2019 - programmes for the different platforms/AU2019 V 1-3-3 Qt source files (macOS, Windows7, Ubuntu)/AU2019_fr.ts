<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr_FR">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="31"/>
        <source>MainWindow</source>
        <translation></translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="230"/>
        <source>Z </source>
        <translation>Z </translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="251"/>
        <source>Q </source>
        <translation>Q </translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="272"/>
        <source>P </source>
        <translation>P </translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="320"/>
        <source>Vx</source>
        <translation>Vx</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="368"/>
        <source>Ix </source>
        <translation>Ix </translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="413"/>
        <source>Hz</source>
        <translation>Hz</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="462"/>
        <source>AUTO</source>
        <translation>AUTO</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="485"/>
        <source>Open Port</source>
        <translation>Ouvrir le Port</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="512"/>
        <source>RUN</source>
        <translation>Démarrer</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="538"/>
        <source>MODE</source>
        <translation>MODE</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="621"/>
        <source>R Hold</source>
        <translation>R Hold</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="641"/>
        <source>AC</source>
        <translation>Amplitude</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="658"/>
        <source>DC</source>
        <translation>Polarisation</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="697"/>
        <location filename="mac_ui/mainwindow.ui" line="1123"/>
        <source>mV</source>
        <translation>mV</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="744"/>
        <source>TRIM</source>
        <translation>TRIM</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="776"/>
        <source>Freq</source>
        <translation>Fréq</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="797"/>
        <location filename="mac_ui/mainwindow.ui" line="824"/>
        <source>V</source>
        <translation>V</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="847"/>
        <location filename="mac_ui/mainwindow.ui" line="989"/>
        <location filename="mac_ui/mainwindow.ui" line="1056"/>
        <location filename="mac_ui/mainwindow.ui" line="1233"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="870"/>
        <location filename="mac_ui/mainwindow.ui" line="1256"/>
        <location filename="mac_ui/mainwindow.ui" line="1372"/>
        <source>EXIT</source>
        <translation>QUIT</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="945"/>
        <source> 10 kHz</source>
        <translation> 10 KHz</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="960"/>
        <source> 1 Mhz</source>
        <translation> 1 MHz</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="1141"/>
        <source>1120 to 1240</source>
        <translation>de 1120 à 1240</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="1210"/>
        <source>P</source>
        <translation>P</translation>
    </message>
    <message>
        <location filename="mac_ui/mainwindow.ui" line="1396"/>
        <location filename="mainwindow.cpp" line="1659"/>
        <source>FAIL</source>
        <translation>PAS BON</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="24"/>
        <location filename="mainwindow.cpp" line="644"/>
        <source>   LCR Meter AU2019  version </source>
        <translation>   LCR-Mètre AU2019  version </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="82"/>
        <source>Measurement frequency</source>
        <translation>Fréquence de mesure</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="83"/>
        <source>Dominant parameter value</source>
        <translation>Valeur du paramètre dominant</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="84"/>
        <source>Secondary parameter value</source>
        <translation>Valeur du paramètre secondaire</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="85"/>
        <source>R-Range Hold state</source>
        <translation>État du maintient de la gamme</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="86"/>
        <source>Impedance</source>
        <translation>Impédance</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="87"/>
        <source>Quality or Dissipation factor</source>
        <translation>Facteur de Qualité ou de Dissipation</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="88"/>
        <source>Phase angle</source>
        <translation>Angle de phase</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="89"/>
        <source>DUT voltage</source>
        <translation>Tension DUT</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="90"/>
        <source>DUT current</source>
        <translation>Courant DUT</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="91"/>
        <source>DUT DC bias</source>
        <translation>Polarisation continue du DUT</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="92"/>
        <source>Generator AC level</source>
        <translation>Amplitude générateur sinusoïdale</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="93"/>
        <source>Change DC bias</source>
        <translation>Changer la polarisation continue</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="94"/>
        <source>Change Generator AC level</source>
        <translation>Changer l&apos;amplitude du générateur sinusoïdale</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="95"/>
        <source>Switch R-Range Hold state: ON OFF</source>
        <translation>Changer l&apos;état du maintient de la gamme: EN HORS</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="96"/>
        <source>Change Circuit Mode: Parallels, Series, Auto</source>
        <translation>Changer le mode du circuit: Parallèle, Série, Auto</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="97"/>
        <source>Change Frequency</source>
        <translation>Changer la fréquence</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="179"/>
        <source>Select port...</source>
        <translation>Sélectionner le Port...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="182"/>
        <source>Close the port</source>
        <translation>Fermer le Port</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="185"/>
        <source>Firmware update...</source>
        <translation>Mise à jour du programme...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="188"/>
        <source>Set Q limit...</source>
        <translation>Fixer la limit de Q...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="191"/>
        <source>Set Sorting parameters...</source>
        <translation>Fixer les paramètres du tri...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="194"/>
        <source>Sort</source>
        <translation>Trier</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="197"/>
        <source>Set sinus generator offset</source>
        <translation>Réglage de l&apos;offset du générateur sinus</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="200"/>
        <source>Define the DDS Vref measured value</source>
        <translation>Valeur mesurée de Vref du DDS</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="203"/>
        <source>CMRR of Voltage diffential opamp.</source>
        <translation>CMRR de l&apos;ampli. différentiel de mesure U</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="206"/>
        <source>PGA2: gain 3 calibration</source>
        <translation>PGA2: calibration en gain 3</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="209"/>
        <source>PGA2: gain 10 calibration</source>
        <translation>PGA2: calibration en gain 10</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="212"/>
        <source>Range 1 calibration</source>
        <translation>Calibration de la gamme 1</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="215"/>
        <source>Range 2 calibration</source>
        <translation>Calibration de la gamme 2</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="218"/>
        <source>Range 3 calibration</source>
        <translation>Calibration de la gamme 3</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="221"/>
        <source>Range 4 calibration</source>
        <translation>Calibration de la gamme 4</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="224"/>
        <source>&lt;Open-circuit&gt; Trim, all freq.</source>
        <translation>Trim &lt;circuit-ouvert&gt; toutes fréq.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="227"/>
        <source>&lt;Short-circuit&gt; Trim, all freq.</source>
        <translation>Trim &lt;court-circuit&gt; toutes fréq.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1924"/>
        <source>INITIALISATION, WAIT...</source>
        <translation>INITIALISATION EN COURS...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1928"/>
        <source>No jumper fitted from J10 to J13</source>
        <translation>Aucun cavalier de J10 à J13</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1932"/>
        <source>Adjust C51 for |Phi| &lt; 0.3</source>
        <translation>Régler C51 pour |Phi| &lt; 0.3</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1936"/>
        <source>Adjust C106 for |Phi| &lt; 0.1</source>
        <translation>Régler C106 pour |Phi| &lt; 0.1</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1940"/>
        <source>Save the gain?</source>
        <translation>Sauvegarder le gain?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1944"/>
        <source>Select normalized value</source>
        <translation>Sélectionner la valeur normalisée</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1954"/>
        <source>-&gt; Adjust R146 for DC null on TP7</source>
        <translation>-&gt; Régler R146 pour 0V en TP7</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1958"/>
        <source>Saving the Trim data...</source>
        <translation>Sauvegarde des donnees du Trim...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1962"/>
        <source>No Trim data to save </source>
        <translation>Pas de données Trim à sauvegarder</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1974"/>
        <source>Calculating the gain and phase</source>
        <translation>Calcul du gain et de la phase</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1978"/>
        <source>  -&gt; Put a jumper in J10</source>
        <translation>  -&gt; mettre un Cavalier en J10</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1982"/>
        <source>  -&gt; Put a jumper in J11</source>
        <translation>  -&gt; mettre un Cavalier en J11</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1986"/>
        <source>  -&gt; Put a jumper in J12</source>
        <translation>  -&gt; mettre un Cavalier en J12</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1990"/>
        <source>  -&gt; Put a jumper in J13</source>
        <translation>  -&gt; mettre un Cavalier en J13</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1994"/>
        <source>Not the right jumper, exit</source>
        <translation>Pas le bon cavalier, quitter</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2002"/>
        <source>Do the range 1 calibration</source>
        <translation>Faire la calibration gamme 1</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2006"/>
        <source>Do the range 2 calibration</source>
        <translation>Faire la calibration gamme 2</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2010"/>
        <source>Do the range 3 calibration</source>
        <translation>Faire la calibration gamme 3</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2014"/>
        <source>Do the range 4 calibration</source>
        <translation>Faire la calibration gamme 4</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2018"/>
        <source>Error, exit</source>
        <translation>Erreur, quitter</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2022"/>
        <source>Do PGA2 gain 3 calibration</source>
        <translation>Faire la calibration PGA2 gain 3</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2026"/>
        <source>Do PGA2 gain 10 calibration</source>
        <translation>Faire la calibration PGA2 gain 10</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2030"/>
        <source>Short circuit trim. Wait...</source>
        <translation>Trim en court-circuit. Patientez...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2034"/>
        <source>Open circuit trim. Wait...</source>
        <translation>Trim en circuit ouvert. Patientez...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2038"/>
        <source>Wait...</source>
        <translation>Patientez...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2042"/>
        <source>  -&gt; Open or Short the circuit</source>
        <translation>  -&gt; Ouvrir ou Fermer le circuit</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2046"/>
        <source>before pressing the TRIM button</source>
        <translation>avant d&apos;appuyer sur le bouton TRIM</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2050"/>
        <source>-- FAIL --</source>
        <translation>-- Echec du TRIM --</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2058"/>
        <source>Short circuit before enter menu</source>
        <translation>Commencez par fermer le circuit </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2062"/>
        <source>Open circuit before enter menu</source>
        <translation>Commencez par ouvrir le circuit</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2066"/>
        <source>Adjust R31 for minimum voltage</source>
        <translation>Régler R31 pour tension minimale</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2070"/>
        <source>Adjust C44 for minimum voltage</source>
        <translation>Régler C44 pour tension minimale</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2074"/>
        <source>J9 set, J8 off, J17 set </source>
        <translation>Pas J8, J9 mis, J17 mis</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2078"/>
        <source>DC Bias voltage: 0 to 5V</source>
        <translation>Tension de polarisation: 0 a 5V</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2082"/>
        <source>DC Bias current: 0 to 50mA</source>
        <translation>Courant de polarisation: 0 a 50mA</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2086"/>
        <source>AC Drive level: 0.1V RMS to 1V RMS</source>
        <translation>Tension d&apos;essai: 0,1 Veff a 1 Veff</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2090"/>
        <source>Measured voltage value on TP6</source>
        <translation>Valeur de la tension en TP6</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2094"/>
        <source>Use saved frequency?</source>
        <translation>Utiliser la valeur enregistrée?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2098"/>
        <source>Save the frequency?</source>
        <translation>Enregistrer la fréquence?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2367"/>
        <source>No BLE_module detected. Load LCR6 firmware</source>
        <translation>Pas de module BLE détecté. Chargez le programme LCR6</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2368"/>
        <source>Put a jumper on J16 and restart</source>
        <translation>Mettre un cavalier en J16 et redémarrer</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2372"/>
        <source>BLE_module baudrate: 115200 bauds</source>
        <translation>Module BLE à 115200 bauds</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2375"/>
        <source>BLE_module baudrate: 9600 bauds</source>
        <translation>Module BLE à 9600 bauds</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2378"/>
        <source>BLE_module: unknown baudrate</source>
        <translation>Module BLE: baudrate inconnu</translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="vanished">Préférences</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="233"/>
        <source>About AU2019</source>
        <oldsource>&amp;About AU2019</oldsource>
        <translation>À propos de AU2019</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="237"/>
        <source>About Qt</source>
        <translation>À propos de Qt</translation>
    </message>
    <message>
        <source>&amp;About Qt</source>
        <oldsource>About Qt</oldsource>
        <translation type="vanished">&amp;À propos de Qt</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="249"/>
        <source>Port</source>
        <translation>Port</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="258"/>
        <source>Settings</source>
        <translation>Paramètres</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="268"/>
        <source>Calibrations</source>
        <translation>Calibrages</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="281"/>
        <source>Help</source>
        <translation>Aide</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="556"/>
        <source>Will take few minutes...</source>
        <translation>Patientez quelques minutes...</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="570"/>
        <source>Save the data?</source>
        <translation>Enregister les données?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="605"/>
        <source>Do you really want to update the firmware of the device?</source>
        <translation>Voulez-vous vraiement faire une mise à jour du programme interne?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="617"/>
        <location filename="mainwindow.cpp" line="2244"/>
        <source>Erasing the Calibration Datas?</source>
        <translation>Voulez-vous effacer les calibrations?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="625"/>
        <source>Are you sure?</source>
        <translation>Êtes vous sûr?</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="665"/>
        <source>Select the file</source>
        <translation>Choisir le fichier</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="665"/>
        <source>Text files (*.hex)</source>
        <translation>Fichier texte (*.hex)</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="696"/>
        <source>loading </source>
        <translation>Chargement </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="750"/>
        <source>LCR Meter AU2019 - Version </source>
        <translation>LCR Mètre AU2019 - Version </translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="758"/>
        <source>About LCR Meter AU2019</source>
        <translation>À propos du LCR Mètre AU2019</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1237"/>
        <source>Clic on OK when operation done</source>
        <translation>Appuyez sur OK à la fin de l&apos;opération</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1434"/>
        <location filename="mainwindow.cpp" line="1970"/>
        <source>No DC bias for resistor</source>
        <translation>Pas de polarisation pour une résistance</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="1655"/>
        <location filename="mainwindow.cpp" line="2054"/>
        <source>PASS</source>
        <translation>BON</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2235"/>
        <source>Program memory checksum error. You must &lt;strong&gt;NECESSARILY&lt;/strong&gt; reload the program.</source>
        <translation>Erreur mémoire du programme. Vous devez &lt;strong&gt;OBLIGATOIREMENT&lt;/strong&gt; recharger un programme.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2240"/>
        <source>User want to update the firmware.</source>
        <translation>L&apos;utilisateur veut faire une mise-à-jour du programme.</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2257"/>
        <source>Closing the application. You must also shutdown the device</source>
        <translation>Fermeture de l&apos;application. Vous devez aussi arrêter l&apos;appareil</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="2345"/>
        <source>Don&apos;t forget to remove J16 jumper</source>
        <translation>N&apos;oubliez pas de retirer le cavalier en J16</translation>
    </message>
</context>
</TS>
