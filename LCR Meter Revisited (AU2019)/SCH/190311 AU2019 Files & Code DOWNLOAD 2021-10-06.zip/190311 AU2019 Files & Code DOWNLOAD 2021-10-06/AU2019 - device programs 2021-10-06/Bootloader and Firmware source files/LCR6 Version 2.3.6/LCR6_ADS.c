//-----------------------------------------------------------------------------
// LCR6_ADS.c
//-----------------------------------------------------------------------------
// 
// Author: Jean-Jacques Aubry 2013-2020

//
// Target: C8051F120 
// Compiler: KEIL C51 V9.60.0.0 
//
// Version (see 'FirmwareVersion' in LCR6.h)
// 
// ADS1246 functions
//


#include "LCR6_ADS.h"

extern bit  wait_ms (unsigned int x);
extern void wait_us(unsigned int us);
extern uchar xdata ADS_sps;

#define MAX_POSITIF         0x7FFFFF    // +8388607
#define MAX_NEGATIF         0x800000    // -8388608

//-----------------------------------------------------------------------------
// SPI_Transfer
//-----------------------------------------------------------------------------
//
// Return Value : the byte received
// Parameters   : the byte to transmit
//
// Simultaneously transmits and receives one byte using the SPI protocol (not the MCU SPI0 implementation).
// bits are latched on SCLK rising.
// ADS_SCLK is idle-low.
// the ADS must be selected (ADS_CS_ = 0)
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
uchar SPI_Transfer (uchar SPI_byte)
{
	uchar SPI_count;
	char a;

	for (SPI_count = 8; SPI_count > 0; SPI_count--) 	// single byte SPI loop
	{
        ADS_SCLK = 1;						// set SCK high

        // wait time according CPU speed
		for (a = SPI_WAIT; a > 0; a--) {};

		ADS_DIN = SPI_byte & 0x80;		    // put current outgoing bit on MOSI
		SPI_byte = SPI_byte << 1;		    // shift next bit into MSB
		ADS_SCLK = 0;					    // set SCK low

	    // wait time according CPU speed
		for (a = SPI_WAIT; a > 0; a--) {};

		SPI_byte |= ADS_DOUT;			    // capture current bit on MISO
	}
    return (SPI_byte);
}



//-----------------------------------------------------------------------------
// ADS_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Configure the ADS1246
// ADS_SCLK is idle-low.
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
void  ADS_Init (void)
{
    SFRPAGE = CONFIG_PAGE;

	ADS_SCLK = 0;
	ADS_DIN = 0;
    ADS_sps = ADS_SPS_20;

	ADS_Reset();

	// ** Write MUX register
	ADS_Write_Register(MUX, MUX_VALUE);	    // connections to inputs

	// ** Write SYS0 register
	ADS_Write_Register(SYS0, ADS_sps);      // PGA=1, SPS=ADS_sps
}



//-----------------------------------------------------------------------------
// ADS_Read_Register
//-----------------------------------------------------------------------------
//
// Return Value : the 8 bits data
// Parameters   : the address of the register to read.
//
// Read one byte from the register
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
uchar ADS_Read_Register(uchar address)
{
	uchar the_data;

	ADS_CS_BARRE = 0;							// select the ADS - set up time is 10ns
	ADS_START = 1;
	wait_us(1);									// min START pulse width
	ADS_START = 0;
	SPI_Transfer(SDATAC);
	SPI_Transfer(RREG | address & 0x0F);
	SPI_Transfer(0);							// one byte
	the_data = SPI_Transfer(NOP);
	wait_us(2);									// SCLK low to CS high (hold time)
	ADS_CS_BARRE = 1;							// deselects the ADS
	wait_us(2);									// min CS high pulse width

	return the_data;	
}



//-----------------------------------------------------------------------------
// ADS_Write_Register
//-----------------------------------------------------------------------------
//
// Return Value : none
// Parameters   : the register address, the value
//
// Write one byte in the register
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
void ADS_Write_Register(uchar address, uchar value)
{
	ADS_CS_BARRE = 0;							// select the ADS; set up time is 10ns
	ADS_START = 1;
	wait_us(1);									// min START pulse width
	ADS_START = 0;

	SPI_Transfer(SDATAC);
	SPI_Transfer(WREG | address & 0x0F);
	SPI_Transfer(0);							// one byte							
	SPI_Transfer(value);
	wait_us(2);									// SCLK low to CS high (hold time)
	ADS_CS_BARRE = 1;							// deselects the ADS
	wait_us(2);									// min CS high pulse width
}



//-----------------------------------------------------------------------------
// ADS_Reset (soft command)
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
void  ADS_Reset (void)
{
	ADS_CS_BARRE = 1;						// reset SPI interface
	wait_us(2);
	ADS_CS_BARRE = 0;	

	SPI_Transfer(WRESET);
	wait_us(1000);							// >= 0.6ms
}



//-----------------------------------------------------------------------------
// ADS_SelfOffset_Calibration
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
void  ADS_SelfOffset_Calibration (void)
{
	ADS_CS_BARRE = 0;							// select the ADS - set up time is 10ns
	ADS_START = 1;
	wait_us(1);									// min START pulse width
	ADS_START = 0;
	SPI_Transfer(SELFOCAL);
	while (ADS_DRDY_BARRE);					    // wait for end of conversion
	wait_us(2);
	ADS_CS_BARRE = 1;							// deselects the ADS
    wait_us(2);									// min CS high pulse width
}


//-----------------------------------------------------------------------------
// ADS_Read_measure
//-----------------------------------------------------------------------------
//
// Return Value :   false if overflow on positive or negative value
//				    true if valid data
// Parameters   :   address to load the measured value
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
// Duration of 50.8 ms with ADS_SPS = 20SPS
// Duration of 25.2 ms with ADS_SPS = 40SPS
// Duration of 12.8 ms with ADS_SPS = 80SPS
//
bit ADS_Read_measure(long* result)
{
    long outdata = 0;

	ADS_START = 1;								// Start pulse
	wait_us(1);									// min START pulse width is 750 ns with 4 MHz internal oscillator
	ADS_START = 0;
 	while (ADS_DRDY_BARRE);		// wait for end of conversion
	wait_us(1);

	ADS_CS_BARRE = 0;							// select the ADS; set up time is 10ns
	SPI_Transfer(RDATA);						// RDATA issued
	outdata = SPI_Transfer(NOP); 			    // write NOP, Read First Byte
	outdata <<= 8; 							    // left Bit-Shift outdata by 8 bits
	outdata |= SPI_Transfer(NOP); 		        // write NOP, Read Second Byte and Mask to outdata
	outdata <<= 8;
	outdata |= SPI_Transfer(NOP); 		        // write NOP, Read Third Byte and Mask to outdata
	wait_us(2);									// SCLK low to CS high (hold time)
	ADS_CS_BARRE = 1;
		
	if ((outdata == MAX_POSITIF) || (outdata == MAX_NEGATIF))	// output clips at max positive or min negative value
    {
		return false;
    }

	if (outdata > MAX_NEGATIF) // negatif
	{
		outdata = -((outdata^0xFFFFFF) + 1);
	}

    *result = outdata;
	return true;
} // ADS_Read_measure


//-----------------------------------------------------------------------------
// Get_Best_ADS_Measure
//-----------------------------------------------------------------------------
//
// Return Value :   0 if overflow on positive or negative value
// Parameters   : adresse of measurement result
//
// Set ADS gain to max possible without overflow
//
bit Get_Best_ADS_Measure (long* theresult)
{
    uchar ADS_PGA_index, Gain;
    float y, measure;
    long x, A;
    bit overflow;

	ADS_SetPGA_Range(0);
    Gain = 1;

    overflow = !ADS_Read_measure(&x); // x is long
    if (overflow)
        return false;

    measure = (x * ADS_VREF) / 0x800000;
    y = fabs(measure);

    if (y > ADS_VREF_DIV_2) goto Fin;   // > 1.25V, PGA = 1 is ok

    if (y > ADS_VREF_DIV_4)             // > 0.625V, PGA = 2 is ok
        ADS_PGA_index = 1;
    else if (y > ADS_VREF_DIV_8)        // > 0.3125V, PGA = 4 is ok
        ADS_PGA_index = 2;
    else if (y > ADS_VREF_DIV_16)       // ... PGA = 8 is ok
        ADS_PGA_index = 3;
    else if (y > ADS_VREF_DIV_32)       // ... PGA = 16 is ok
        ADS_PGA_index = 4;        
    else if (y > ADS_VREF_DIV_64)       // ... PGA = 32 is ok
        ADS_PGA_index = 5;
    else if (y > ADS_VREF_DIV_128)      // ... PGA = 64 is ok
        ADS_PGA_index = 6;
    else       
        ADS_PGA_index = 7;              // PGA = 128

	ADS_SetPGA_Range(ADS_PGA_index);
	overflow = !ADS_Read_measure(&x);
	if (overflow)
	{
        ADS_PGA_index--;
        ADS_SetPGA_Range(ADS_PGA_index);
        overflow = !ADS_Read_measure(&x);	// if overflow, x is not updated
        if (overflow)  // must not occur!
        {
            return false;
        } 
    }

    //Gain = 1 << ADS_PGA_index, and x /= Gain;
    A = x >> ADS_PGA_index;
    x = A;

Fin:
    *theresult = x;
    return true;
} // Get_Best_ADS_Measure



//-----------------------------------------------------------------------------
// ADS_SetPGA_Range
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : the range, 0 to 7 -> PGA gain = 2^range
//
void ADS_SetPGA_Range(uchar range)
{
	uchar value;

    // read SYS0 register -> bits 0 to 3 for SPS, bits 4 to 7 for PGA gain
    value = ADS_Read_Register(SYS0);
    value &= 0x0F;      // 00001111 -> clear current PGA value
	if (range > 7)
		range = 7;

	value |= (range << 4);

	ADS_Write_Register(SYS0, value);
    wait_us(100);
}


//-----------------------------------------------------------------------------
// ADS_SetSPS
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : SPS, 0 to 8 -> SPS_05 to SPS_1000
//
// update global ADS_sps
//
void ADS_SetSPS(uchar SPS)
{
	uchar value;

	if (SPS > 8)
		SPS = 8;

    // read SYS0 register -> bits 0 to 3 for SPS, bits 4 to 7 for PGA gain
    value = ADS_Read_Register(SYS0);

    // SPS changed?
    if ((value &= 0x0F) != SPS)
    {
        value &= 0xF0;      // 11110000 -> clear current SPS value
	    value |= SPS;

	    ADS_Write_Register(SYS0, value);
        ADS_sps = SPS;
        wait_us(100);
    }
}
