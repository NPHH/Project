//-----------------------------------------------------------------------------
// LCR6_INIT.h
//-----------------------------------------------------------------------------
// 
// Author: Jean-Jacques Aubry  2013-2020
//
// Target: C8051F120 
// Compiler: KEIL C51 V9.60.0.0 
//
// Version (see 'FirmwareVersion' in LCR6.h)
//
//

#ifndef _LCR6_INIT_H
#define _LCR6_INIT_H

#include "LCR6_Defines.h"

#ifdef NO_BOOTLOADER_MODE	// no Bootloader, synchronization with external GUI
    void 	SYSCLK_Init (void);
    void 	PORT_Init (void); 
    void 	UART0_Init (void);
    void    UART1_Init (void);
    void    Timer3_Init (void);
#endif

extern char * FLASH_Read (char *dest, FLADDR src, unsigned numbytes, bit SFLE);
void    Timer4_Init(void);
void    DAC_Init(void);
void    ADC0_Init (void);
void    REF_Init(void);
void    Comparator1_Init (void);
void    Comparator0_Init (void);

void 	Ext_Interrupt_Init (void);
void 	Init_MCU_Peripherals (void);

#endif