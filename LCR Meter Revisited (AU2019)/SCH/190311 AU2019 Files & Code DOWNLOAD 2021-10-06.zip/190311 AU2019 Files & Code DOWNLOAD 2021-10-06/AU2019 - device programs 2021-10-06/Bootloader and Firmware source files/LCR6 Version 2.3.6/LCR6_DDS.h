//-----------------------------------------------------------------------------
// LCR6_DDS.h
//-----------------------------------------------------------------------------
// 
// Author: Jean-Jacques Aubry  2013-2020
//
// Target: C8051F120 
// Compiler: KEIL C51 V9.60.0.0  
//
// Version (see 'FirmwareVersion' in LCR6.h)
//
// AD9834 functions
//

#ifndef _LCR6_DDS_H
#define _LCR6_DDS_H

#include "LCR6_Defines.h"
#include <intrins.h>			// NOP

void	DDS_Init(void);
void    DDS_Init_Control_Register (void);
void	DDS_Send (unsigned int value, uchar DDSx);
void 	DDS_Reset(void);
void 	DDS_Load_PhaseReg(uint PHI_REG0_value, char DDSx);
void 	DDS_Load_FreqReg(ulong FREQ_REG);
void	DDS_SetFrequency(float frequency);

void 	DDS1_OFF(void);
void 	DDS1_ON(void);

#endif