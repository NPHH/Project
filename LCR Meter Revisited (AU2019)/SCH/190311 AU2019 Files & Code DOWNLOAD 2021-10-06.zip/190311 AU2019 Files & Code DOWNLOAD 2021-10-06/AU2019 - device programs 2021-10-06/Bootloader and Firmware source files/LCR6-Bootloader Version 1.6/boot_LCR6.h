//-----------------------------------------------------------------------------
// boot_LCR6.h
//-----------------------------------------------------------------------------

// Copyright 2018 - 2020   Jean-Jacques Aubry.
// Target:         C8051F120
//


#ifndef _BOOTGLOBALS_H
#define _BOOTGLOBALS_H

#include <c8051f120.h>		// SFR declarations
#include <ctype.h>			// tolower() and toint()
#include <intrins.h>		// _nop_()

#include "LCR6_common.h"

typedef unsigned char uchar;
typedef unsigned int uint;
typedef unsigned long FLADDR;
typedef unsigned long ulong;

#define false 				0
#define true 				1

#define GO_APPLICATION      "GO_APP \n"
#define NEED_SYC            "NEED_S \n" 
#define UPDATE_RDY          "UD_RDY \n"  
#define MEM_FAIL            "M_FAIL \n"
#define NEED_UPD            "ND_UPD \n"  
#define RDY_RECEIVE         "RDY_RCV \n"
#define UPDATE1             "UPD"
#define UPDATE2             "UPD2"
#define START               "START"

//-----------------------------------------------------------------------------
// 16-bit SFR Definitions for 'F12x
//-----------------------------------------------------------------------------
sfr16 ADC0 	    = 0xbe;					// ADC0 data
sfr16 RCAP2     = 0xca;                 // Timer2 capture/reload
sfr16 RCAP3     = 0xca;                 // Timer3 capture/reload
sfr16 RCAP4     = 0xca;                 // Timer4 capture/reload
sfr16 TMR2      = 0xcc;                 // Timer2
sfr16 TMR3      = 0xcc;                 // Timer3
sfr16 TMR4      = 0xcc;                 // Timer4



//-----------------------------------------------------------------------------
// Global Constants
//-----------------------------------------------------------------------------
#define CHAR_SIZE					1
#define INT_SIZE					2
#define LONG_SIZE					4
#define FLOAT_SIZE					4

#define NO_KEY_PRESSED				0
#define UART_BUFFERSIZE 			32

#define TRUE						1 
#define FALSE						0

#define MODE_6800

#ifdef MODE_6800
	#define LCD_RW_					LCD_WR0
	#define LCD_E					LCD_WR1
#else
	#define LCD_WR_					LCD_WR0
	#define LCD_RD_					LCD_WR1
#endif

#define NORMAL_STARTUP				1
#define SOFWARE_RESET				-1
#define PROG_MEMORY_ERROR			-2
#define USER_UPDATE     			-3




// ------------------------------------------
// defined in F120_FlashPrimitives.h
// ------------------------------------------
#ifndef FLASH_PAGESIZE
#define FLASH_PAGESIZE 1024L
#endif

#ifndef FLASH_SCRATCHSIZE
#define FLASH_SCRATCHSIZE 256
#endif

#ifndef FLASH_TEMP
#define FLASH_TEMP 0x1F400L            // address of temp page
#endif

#ifndef FLASH_LAST
#define FLASH_LAST 0x1F800L            // last page of FLASH
#endif




//----------------------------------------------------------------------------- 
// Function PROTOTYPES 
//-----------------------------------------------------------------------------
extern void START_APPLICATION(void);   // Function prototype for app's Reset 
                                       // vector entry point
                                       // Defined in STARTUP.A51
// Support Subroutines 
char Check_for_Application_Startup();
char receive_code(void); 
char Check_Program_Memory(void);
bit  myStrcmp (char * text);
void myPrintf (char * text);
char putchar (char c);
char getkey (void);
uchar hex2char();
    
// FLASH read/write/erase routines
void FLASH_Clear (FLADDR dest, unsigned numbytes, bit SFLE);
void FLASH_Update (FLADDR dest, char *src, unsigned numbytes, bit SFLE);
void FLASH_Write (FLADDR dest, char *src, unsigned numbytes, bit SFLE);
char * FLASH_Read (char *dest, FLADDR src, unsigned numbytes, bit SFLE);
void FLASH_ByteWrite (FLADDR addr, char byte, bit SFLE);
unsigned char FLASH_ByteRead (FLADDR addr, bit SFLE);
void FLASH_PageErase (FLADDR addr, bit SFLE);    
void erase_flash(FLADDR debut, FLADDR fin);
extern void FLASH_Copy (FLADDR dest, bit destSFLE, FLADDR src, bit srcSFLE,
                 unsigned numbytes);


// Initialization Subroutines 
void SYSCLK_Init (void); 
void PORT_Init (void); 
void UART0_Init (void);
void UART1_Init (void);
void Timer3_Init (void);
void read_input_from_UARTx (void);
void wait_us(uint time_us);
bit  wait_ms (unsigned int time_ms);

#endif