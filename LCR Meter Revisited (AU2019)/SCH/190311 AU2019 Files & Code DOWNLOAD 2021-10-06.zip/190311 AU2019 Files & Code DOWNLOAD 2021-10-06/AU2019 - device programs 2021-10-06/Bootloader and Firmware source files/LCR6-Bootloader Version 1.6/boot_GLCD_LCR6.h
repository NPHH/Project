//-----------------------------------------------------------------------------
// boot_GLCD_LCR6.h
//-----------------------------------------------------------------------------

// Copyright 2018 Jean-Jacques Aubry.
// Target:         C8051F120
// v 1.00
//
// Display is MCCOG240128A GLCD from "MIDAS Display"
// using a UC1608 LCD driver
//

#ifndef _BOOT_GLCD_H
#define _BOOT_GLCD_H

#include "boot_LCR6.h"


// ------- UC1608 Commands
#define GLCD_RESET					0xE2	// 1110 0010 -> System Reset	
#define GLCD_DISPLAY_ON				0xAF	// 1010 1111 -> ON	
#define GLCD_DISPLAY_OFF			0xAE	// 1010 1110 -> OFF
#define GLCD_START_LINE				0x40	// 01xx xxxx -> start line address
#define GLCD_PAGE_ADDRESS			0xB0	// 1011 xxxx -> page address
#define GLCD_COLUMN_ADDRESS_HI	    0x10	// 0001 xxxx -> column address upper bit
#define GLCD_COLUMN_ADDRESS_LO	    0x00	// 0000 xxxx -> column address lower bit

// MAPPING is 0xC0 + Mirror if needed
#define GLCD_MAPPING				0xC0	// 1100 0000 -> select normal
#define GLCD_MIRROR_ROW				0x8	    // 1000 -> select mirror row
#define GLCD_MIRROR_COL				0x4	    // 0100 -> select mirror column
#define GLCD_DISPLAY_NORMAL		    0xA6	// 1010 0110 -> normal Display
#define GLCD_DISPLAY_REVERSE		0xA7	// 1010 0111 -> reverse Display
#define GLCD_DISPLAY_ALL_ON		    0xA5	// 1010 0101 -> Display all points ON
#define GLCD_DISPLAY_NORMAL_MODE	0xA4	// 1010 0100 -> Normal Display mode
#define GLCD_BIAS_10_7				0xE8	// 1110 1000 -> LCD drive voltage bias ratio 10.7
#define GLCD_BIAS_11_3				0xE9	// 1110 1001 -> LCD drive voltage bias ratio 11.3
#define GLCD_BIAS_12_0				0xEA	// 1110 1010 -> LCD drive voltage bias ratio 12.0
#define GLCD_BIAS_12_7				0xEB	// 1110 1011 -> LCD drive voltage bias ratio 12.7



// ------- GLCD is 240 x 128 dots
#define LCD_ROWS					16		// 16 rows x 8 bits = 128 dots
#define LCD_COLS					240	    // 240 columns x 1 bit = 240 dots


#define GLCD_PIXEL_OFF   			0
#define GLCD_PIXEL_ON    			1
#define GLCD_PIXEL_INV   			2

#define FONT_OFFSET			        0x20    // font array start offset


//----------------------------------------------------------------------------- 
// Function PROTOTYPES 
//-----------------------------------------------------------------------------

extern  bit  wait_ms (unsigned int time_ms);
void	GLCD_WriteData(uchar value);
void	GLCD_WriteCommand(uchar command, uchar flag);
void	GLCD_Init(void);

void	GLCD_clear(void);
void	GLCD_set_pos(uchar row, uchar col);
void	GLCD_read_column(uchar col);
void	GLCD_write_column(uchar col);
void	GLCD_show_icon(uchar code *bitmap, uchar width, uchar height, uchar x, uchar y, uchar mode);
uchar	GLCD_draw_text( int x, uchar y, uchar *text , uchar mode );


#endif