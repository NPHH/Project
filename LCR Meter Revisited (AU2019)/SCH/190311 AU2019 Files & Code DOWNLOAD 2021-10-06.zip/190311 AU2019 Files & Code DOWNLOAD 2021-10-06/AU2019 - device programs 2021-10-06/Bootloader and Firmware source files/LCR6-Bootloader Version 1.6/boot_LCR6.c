//----------------------------------------------------------------------------- 
// boot_LCR6.c 
//----------------------------------------------------------------------------- 
// by JJA
// 2019-2020
//
// This program is a Firmware Updater for MCU 'C8051F12x'.
// Part of code is from SiLab's application note AN112.
//
// It resides in FLASH at addresses 0x0000, and it's max size is 7 pages (7 x 0x400). 
//   So add this directive in menu 'Project/Tool Chain Integration...' -> tab 'linker': CODE(0x0-0x1BFF)
//       
//
// Program to update is located at address 0x1C00-0xFFFF, so interrupts while be redirected
//      at address START_APPLICATION (0x1C00) with the use of file STARTUP.A51
//
// If a firmware-update is needed, the LCR-meter must be connected to a PC via USB (J1) and
//  the system is controlled via the hardware UART0 , operating at a baud rate determined 
//  by the constant <BAUDRATE0>, using Timer2 overflows as the baudrate source.
// 
//
// Note: Because this program writes to FLASH, the MONEN pin should be tied high.
// 
// Target: C8051F12x 
// Compiler: KEIL C51 V9.60.0.0
//
// Version (see 'Bootloader_Ver')


#include "boot_LCR6.h"
#include "boot_GLCD_LCR6.h"


//----------------------------------------------------------------------------- 
// Global VARIABLES 
//-----------------------------------------------------------------------------
bit     code_erased = false; 			// flag used to indicate that the FLASH erase operation is complete
bit     f_valid = true;					// flag to indicate that the FLASH programming operation is complete

bit     okUSB = false;
bit     use_USB = false;                
bit     GLCD_onJ14 = true;              // Extension card for standalone mode with display (GLCD) and buttons
bit     BT_onJ14 = false;               // Bluetooth Low Energy extension card
bit     standalone;                     // Mode when GLCD_onJ14 is true and no PC connected
bit     use_Bluetooth = false;

uchar   Uart;

ulong   program_checksum;
ulong   UART1_baudrate;                 // Bauderate for communication with the BLE module
uint    program_size;

uchar   xdata UART_InputBuffer[UART_BUFFERSIZE];
int     UART_InputBuffer_Size = 0;


char code text1[] = "Wait for the GUI...";
char code text2[] = "Wait for an UPDATE...";

// -> don't forget to update bootVersion[] 
float   Bootloader_Ver = 1.6;           // 1.6  Some optimizations of the code following Titune's remarks!          
                                        // 1.5  BACKLIGHT = 0 before updating EEPROM (save power!)            
                                        // 1.4  bug corrected in myStrcmp()
                                        //      No synchro for external GUI if <use_Bluetooth> is true    
                                        // 1.3  possibility to load in one step a merged file (Bootloader.hex + LCR6.hex)     
                                        // 1.2  modification for use of KEIL suite Version 9.60.0.0.
                                        //      And, to save code space, characters until 0x7f.
            
char    code bootVersion[] = "< BOOTLOADER  V 1.6 >"; 


//----------------------------------------------------------------------------- 
// myStrcmp
//-----------------------------------------------------------------------------
//
// to not use the strcmp() function in <string.h>, and thus save space
//
bit myStrcmp (char * text)
{
    char i, longtext, longbuf, c;
    //bit returnValue = false;

    longtext = 0;
    longbuf = 0;

    while (UART_InputBuffer[longtext] != 0)
        longtext++;
    while (text[longbuf] != 0)
        longbuf++;
    if (longtext != longbuf)
        return false;
    for (i = 0; i < longtext; i++)
    {
        c = text[i];
        if (c != UART_InputBuffer[i])
            return false;
    }
    return true;    
} // myStrcmp


//----------------------------------------------------------------------------- 
// myPrintf
//-----------------------------------------------------------------------------
//
// to not use the printf() function in <stdio.h>, and thus save space
//
void myPrintf (char * text)
{
    char i, longtext, c;

    longtext = 0;
    while (text[longtext] != 0)
        longtext++;
    for (i = 0; i < longtext; i++)
    {
        c = text[i]; 
        putchar(c);
    }
    putchar('\n');
} // myPrintf




//----------------------------------------------------------------------------- 
// MAIN Routine 
//-----------------------------------------------------------------------------
void main (void)
{
	char input, status;
    uchar c_value = 0;
	bit ok, use_USB, eraseBank2; 
    

    // start_bootloader 
	WDTCN = 0xde; 								// disable watchdog timer
	WDTCN = 0xad;

	EA = 0;										// disable interrupts
    EA = 0;	                                    // this is a dummy instruction with two-byte opcode.

    // at Start-Up, Port pins are inputs and Weak Pullups are enabled
    // so, if one extension is connected, there's a 0 on the corresponding pin 

    GLCD_onJ14 = (!TEST_GLCD);                  // TEST_GLCD = 0 -> GLCD extension card is connected

    if (GLCD_onJ14)                             // only one extention card possible
        BT_onJ14 = false;
    else
        BT_onJ14 = (!TEST_BT);                  // TEST_BT == 0 -> BLE extension card is connected

	PORT_Init (); 								// initialize crossbar and GPIO (SFR page is CONFIG_PAGE)
                                                // set BLE_STATUS & GLCD_STATUS according extension card detected
                                                // set BACKLIGHT to 1

    SYSCLK_Init ();							    // initialize oscillator
    Timer3_Init();                              // used by wait_us()

    SFRPAGE = CONFIG_PAGE;                      // set SFRPAGE to F (Ports 4 to 7 are available on this page)

    if (GLCD_onJ14)
    {
        GLCD_Init();
        GLCD_clear();
    	GLCD_draw_text( 12, 22, bootVersion, GLCD_PIXEL_ON);
    }

	//for (input = 0; input < UART_BUFFERSIZE; input++)   // Cleans the UART buffer (not necessary but help with debugging!)
		//UART_InputBuffer[input] = 0;

    UART_InputBuffer[0] = '\0';                     // the Buffer is empty

    c_value = FLASH_ByteRead(DISPLAY_MODE_ADD, 0);  // read the saved display mode: standolone or external

    if ( c_value == 0xFF )                          // first time with new firmware
    {
        c_value = (uchar)GLCD_onJ14;                // if true -> set for standalone mode
             
        FLASH_Write(DISPLAY_MODE_ADD, (char *) &c_value, CHAR_SIZE, 0);
    }
    else if (L1 == 0)                               // KEY_1 pressed at start-up, so change the kind of GUI
    {
        if (c_value == 0)
            c_value = 1;                            // standalone mode
        else if (c_value >= 1)
            c_value = 0;
        
        FLASH_Update(DISPLAY_MODE_ADD, (char *) &c_value, CHAR_SIZE, 0);
    }
 
    wait_ms(1000);								// some time for PWRN ready
    okUSB = (PWRN == 0);

    //FLASH_PageErase(PROGRAM_SIZE_ADD, 0);       // ***** TEST ONLY

    input = Check_for_Application_Startup();	// check startup condition

    // input = NORMAL_STARTUP   -> go to LCR6 firmware (after synchro with the GUI if not on standalone mode)
    // input = PROG_MEMORY_ERROR, or USER_UPDATE: memory is corrupted, or you want to force the update (i.e. firmware does not respond)
    //                          -> GUI on PC is needed, and we have to sync with it                                                                               
    // input = SOFWARE_RESET :  -> it's a command generated by the LCR6 firmware in response to a request for a
    //                          'Firmware Update' from the PC program. Commmunication via USB is already done.

 
    use_USB = ( (okUSB && !GLCD_onJ14) || (okUSB && GLCD_onJ14 && c_value == 0) || (okUSB && input <= PROG_MEMORY_ERROR));
    use_Bluetooth = (!use_USB && BT_onJ14);
    standalone = GLCD_onJ14  && !use_USB;

    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -    
    // use_USB is true:
    //      if connected to PC and no GLCD, 
    //      or if connected to PC and GLCD and c_value (Display_mode) = 0,
    //      or J16 = 0 (user want to update firmware) 
    //      or memory error (firmware update needed)
    //      ->  the system is controlled via the hardware UART0 , operating at a baud rate determined by
    //          the constant <BAUDRATE0>, using Timer2 overflows as the baudrate source.
    //
    // To use Bluetooth extension, the LCR-meter must be powered by external power-supply, not connected to a PC.
    //      ->  the system is controlled via the hardware UART1 , operating at a baud rate determined by
    //          the constant <BAUDRATE1>, using Timer1 overflows as the baudrate source.
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
    
    
    ok = FALSE;

    if (BT_onJ14)   // BLE card in J14
    {
        FLASH_Read((char *) &UART1_baudrate, UART1_BAUDRATE_ADD, LONG_SIZE, 0);
        if (UART1_baudrate == 0xFFFFFFFF )	    // no initialization
	    {
		    UART1_baudrate = BAUDRATE_1;		// set default to 115200 bauds
		    FLASH_Write(UART1_BAUDRATE_ADD, (char *) &UART1_baudrate, LONG_SIZE, 0);
	    }
    }

    if (use_Bluetooth)
    {
        UART1_Init ();					        // initialize UART1 with UART1_baudrate
        Uart = 1;
    }
    else if (use_USB)                           // if not Bluetooth we can use USB
    {
        UART0_Init ();							// initialize UART0
        Uart = 0;
    }

    if (!use_USB && !(GLCD_onJ14 || BT_onJ14))  // error, a GUI is needed!
    {
        while (1)   // blink LED on J23 - cycle 1s, 50% On 50% Off
        {
            J23 = !J23;
            wait_ms(500);
        }
    }

 	if (input == NORMAL_STARTUP)
	{
        if (!standalone && !use_Bluetooth)
        {
            if (GLCD_onJ14)
                GLCD_draw_text( 18, 44, text1, GLCD_PIXEL_ON);  // "Waiting for the GUI..."
            
            // wait for synchro with the GUI
		    while (!ok)
		    {
                myPrintf(NEED_SYC);
                read_input_from_UARTx();
                ok = myStrcmp(START);
                if (!ok)
                    wait_ms(1000);
            }

            myPrintf(GO_APPLICATION);
        }

        wait_ms(400);   // 100
        START_APPLICATION();          // Jump to Application FW
	}


	// - - - - - - - - - - - - - - - - - - - - - - - - - -
	//  an update is needed, continu with bootloader
	// - - - - - - - - - - - - - - - - - - - - - - - - - -

	if (input != SOFWARE_RESET) 	// it's not sofware reset, wait for synchro with GUI
	{   
        if (GLCD_onJ14)
            GLCD_draw_text( 18, 66, text2, GLCD_PIXEL_ON);  // "Waiting for an update..."
		while (!ok)
		{
            myPrintf(NEED_SYC);
            read_input_from_UARTx();
            ok = myStrcmp(START);
            if (!ok)
                wait_ms(1000);
		}
	}

	if (input == SOFWARE_RESET)
        myPrintf(UPDATE_RDY);
	else if (input == USER_UPDATE)
        myPrintf(NEED_UPD);
	else
        myPrintf(MEM_FAIL);

	ok = false;
	eraseBank2 = false;

	while (!ok)
	{
		read_input_from_UARTx();
        ok = myStrcmp(UPDATE1);
        if (myStrcmp(UPDATE2))
        {
			ok = true;
			eraseBank2 = true;
		}

     	if ( ok )
		{
            BACKLIGHT = 0;  // version 1.5 -> to save energy during update
			if (eraseBank2)
			{
				erase_flash(PAGE1_FLASH_ADDR, PAGE8_FLASH_ADDR);
			}

			// 1 - erase program size and cheksum
			FLASH_PageErase(PROGRAM_SIZE_ADD, 0);

			// 2 - erase application memory space
		  	erase_flash(PROG_BEGIN_FLASH_ADD, PROG_END_FLASH_ADD);
                 
            status = receive_code();	// write received code in FLASH memory
            if (status != 0)
                f_valid = FALSE;

			if (f_valid )
			{
				// write new program size
				FLASH_Write (PROGRAM_SIZE_ADD, (char *) &program_size, INT_SIZE, 0);
				// write new checksum
				FLASH_Write (PROGRAM_CHECKSUM_ADD, (char *) &program_checksum, LONG_SIZE, 0);
                // write bootloader version. 																
				FLASH_Write (BOOTLOADER_VERSION_ADD, (char *) &Bootloader_Ver, FLOAT_SIZE, 0);
				// check FLASH program checksum
				if(!Check_Program_Memory())
					f_valid = FALSE;
                // not the standalone mode after firmware update
                c_value = 0;
                FLASH_Update(DISPLAY_MODE_ADD, (char *) &c_value, CHAR_SIZE, 0);
		    }
                
            BACKLIGHT = 1;    // version 1.5 -> restores display lighting

 	  		if (f_valid )
			{
                myPrintf(GO_APPLICATION);
                START_APPLICATION();          // Jump to Application FW
			}
            else
                myPrintf(MEM_FAIL);
            
			ok = FALSE;
     	}   
   } // end while	
} // end main




//-----------------------------------------------------------------------------
// Check_for_Application_Startup
//-----------------------------------------------------------------------------
//
// return NORMAL_STARTUP if we can safety go to application program
// return SOFWARE_RESET if it's a call from application program
// return PROG_MEMORY_ERROR if application program memory checksum fail
// return USER_UPDATE if jumper J16 set (inconditional update)
//
char Check_for_Application_Startup()
{
    char SFRPAGE_SAVE = SFRPAGE;
    bit power_on;
    
    if (J16 == 0)
        return USER_UPDATE;

    SFRPAGE = 0;
    power_on = ((RSTSRC & 0x03) != 0);      // PORSF (Power-On reset) or PINRSF (reset pin) at 1

	if (!power_on)
    { 
        if (RSTSRC == 0x10)	                // 0001 0000 Reset source is Software-Reset
        {
            SFRPAGE = SFRPAGE_SAVE;
		    return SOFWARE_RESET;
        }
    }

    SFRPAGE = SFRPAGE_SAVE;

	if(!Check_Program_Memory())			    // check memory integrity
		return PROG_MEMORY_ERROR;

	return NORMAL_STARTUP;
}



//----------------------------------------------------------------------------- 
// hex2char 
//----------------------------------------------------------------------------- 
//
// This routine converts a two byte ascii representation of a char to an 
// 8-bit variable; 
// 
unsigned char hex2char()
{
	unsigned char retval; 
	char byteH, byteL;

	// get a two-byte ASCII representation of a char from the UART 
	byteH = getkey(); 
	byteL = getkey();
	// convert to a single 8 bit result 
	retval = (char) toint(byteH) * 16; 
	retval += (char) toint(byteL); 
	return retval;
}




//-----------------------------------------------------------------------------
// receive_code
//-----------------------------------------------------------------------------
// This routine receives the new firmware through the UART in HEX record 
// format.
//
// Hex Record Format:
//
// +--------+--------+------+-------+--------+------(n bytes)------+----------+
// | RECORD | RECLEN |    OFFSET    | RECORD |                     | CHECKSUM |
// |  MARK  |  (n)   |   (2 BYTES)  |  TYPE  |        DATA         |          |
// |  ':'   |        |              |        |                     |          |
// +--------+--------+------+-------+--------+------(n bytes)------+----------+
//
//		return 0 if ok
//      return 1 if code not erased
//		return 2 if Error in HEX file
//      return 3 if Exceeded Code Space
//      return 4 if Line checksum failed
//
char receive_code(void)
{
	char SFRPAGE_SAVE = SFRPAGE;

  	char xdata * data pwrite;       // pointer used for writing FLASH
  	char code * data pread;         // pointer used for reading FLASH
  	unsigned char len;              // holds the HEX record length field
  	unsigned char record_type;      // holds the HEX record type field
  	unsigned int offset;            // holds the HEX record offset field: this is the starting address of
                                    //      the code image contained in the record

    char checksum;                  // holds the HEX record checksum field 
  	char flash_checksum;            // holds the checksum calculated after the FLASH has been programmed
 	                                    
  	bit EA_state;                   //temporary holder used to restore interrupts to their previous state
                                   

    uchar c;                		// temporary char
  	unsigned int i;                 // temporary int
	unsigned int last_address; 		// last program address

    // make sure FLASH has been erased
  	if(!code_erased)
     	return 1;
	else 
	{
        myPrintf(RDY_RECEIVE);
		code_erased = FALSE;                // clear the code_erased flag      
  	}
	
	offset = PROG_BEGIN_FLASH_ADD;			// initial address to write
	program_size = 0;
	last_address = offset - 1;

    // wait for the user send HEX file
    do
	{
     
     	while( c = getkey() != ':' );      // ignore all characters until reaching the record mark field
                                         	 
     	// get the record length
     	len = hex2char();

     	// get the starting address (offset field in HEX record)
     	offset = hex2char();             	// get the MSB
     	offset <<= 8;                       
     	offset |= hex2char();               // get the LSB

      // get the record type
     	record_type = hex2char();
     	if( !(record_type == 0 || record_type == 1 ) )
        	return 2;
		if( record_type == 1)	            // last record (end of file ), no data
			break;

		if (offset + len > last_address)
			last_address = offset + len - 1;

        pwrite = (char xdata *) offset;     // initialize the write pointer
		
        if (pwrite < PROG_BEGIN_FLASH_ADD)
            break;

        EA_state = EA;                      // save the interrupt enable bit state

		EA = 0;                             // disable interrupts (precautionary) 
		SFRPAGE = LEGACY_PAGE;
		  
     	FLSCL |= 0x81;                      // enable FLASH write/erase
          
     	// write the record into flash
     	for (i = 0; i < len; i++)
		{
        
        	// check for valid pointer
            if (pwrite < PROG_END_FLASH_ADD)
		  	{ 
				c = hex2char();
				PSCTL |= 0x01;              // PSWE = 1
           	    *pwrite = c;         		// write one byte to FLASH
				PSCTL &= ~0x01;             // PSWE = 0
           	    pwrite++;                   // increment FLASH write pointer
        	} 
		  	else 
		  	{
     			FLSCL &= ~0x01;                         // disable FLASH write/erase
                //printf(" Exceeded Code Space. \n");     // print error message
				SFRPAGE = SFRPAGE_SAVE;		            // Restore SFR page
     			EA = EA_state;                          // restore interrupts to previous state
				return 3;
        	}
     	}
     
     	FLSCL &= ~0x01;                     // disable FLASH write/erase
		SFRPAGE = SFRPAGE_SAVE;				// Restore SFR page
     	EA = EA_state;                      // restore interrupts to previous state
           
     	// verify the checksum
     	pread =  (char code *) offset;      // initialize the read pointer
     	checksum = hex2char();              // get the HEX record checksum field
     	flash_checksum = 0;                 // set the flash_checksum to zero

        // add the data field stored in FLASH to the checksum
     	for( i = 0; i < len; i++)
     	{
			c = *pread++;
        	flash_checksum += c;
     	} 
     	// add the remaining fields
     	flash_checksum += len;
     	flash_checksum += (char) (offset >> 8);
     	flash_checksum += (char) (offset & 0x00FF);
     	flash_checksum += record_type;
     	flash_checksum += checksum;
     
     	// verify the checksum (the flash_checksum should equal zero)     
     	if(flash_checksum != 0)
        	return 4;
    } 
	while( record_type != 1); 

	program_size = last_address - PROG_BEGIN_FLASH_ADD;

    // calculate program checksum
    program_checksum = 0;
    pread =  (char code *) PROG_BEGIN_FLASH_ADD;      // initialize the read pointer
    for (i = 0; i <= program_size; i++)
	{
		c = *pread++;
		program_checksum += c;
	}
  	f_valid = TRUE;                                     // indicate that download is valid 
	return 0;
}



//-----------------------------------------------------------------------------
// Check_Program_Memory
//-----------------------------------------------------------------------------
//
// This routine check validity of program memory
//		return 1 if ok
//		return 0 if error;
//
char Check_Program_Memory(void)
{
	char code * data pread;                // FLASH read pointer
	unsigned int i; 
	uchar c;
	unsigned long checksum;

	FLASH_Read ((char *)&program_size, PROGRAM_SIZE_ADD, 2, 0);
    
    // no program_size registered, when merged file (Bootloader + Firmware) loaded (-> added in Rev 1.3)
    if (program_size == 0xFFFF)                            
    {
        // search the last byte of the program (byte != 0xFF)
        pread = (char code *) PROG_END_FLASH_ADD;           // initialize the pointer
        do
        {
            c = *pread--;
        }
        while (c == 0xFF);
        pread++;                                            // pointer on last byte of program
         
        program_size = pread - PROG_BEGIN_FLASH_ADD;                             
        // write new program size
		FLASH_Write (PROGRAM_SIZE_ADD, (char *) &program_size, INT_SIZE, 0);

        // calculate program checksum
        checksum = 0;
        pread =  (char code *) PROG_BEGIN_FLASH_ADD;      // initialize the read pointer
        for (i = 0; i <= program_size; i++)
	    {
		    c = *pread++;
		    checksum += c;
	    }
        
		// write new checksum
		FLASH_Write (PROGRAM_CHECKSUM_ADD, (char *) &checksum, LONG_SIZE, 0);
        // write bootloader version. 
        FLASH_Write (BOOTLOADER_VERSION_ADD, (char *) &Bootloader_Ver, FLOAT_SIZE, 0);
        return 1;
    } // if (program_size == 0xFFFF)
     
	if (program_size >= PROG_END_FLASH_ADD - PROG_BEGIN_FLASH_ADD)	// Memory corrupted
		return 0;

	checksum = 0;
	pread = (char code *) PROG_BEGIN_FLASH_ADD;                        // initialize the pointer
	for (i = 0; i <= program_size; i++)
	{
		c = *pread++;
		checksum += c;
	}

	FLASH_Read ((char *)&program_checksum, PROGRAM_CHECKSUM_ADD, LONG_SIZE, 0);
	if (program_checksum == checksum)
		return 1;
	else						                	                    // Checksum fail
		return 0;
}



//-----------------------------------------------------------------------------
// Support Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// putchar
//-----------------------------------------------------------------------------
//
//  Copyright KEIL ELEKTRONIK GmbH 1990 - 2002                         
//
//
// Modified by BW
// Modified by JJA - 2019
//
// This routine overloads the standard putchar() library function
// 
// As TI0 and TI1 are at the same address but in different pages (respectively UART0_PAGE and UART1_PAGE), same
// for SBUF0 and SBUF1, it is enough to define the page to be used to manage with the same addresses both UART.
//
char putchar (char c)
{
   char SFRPAGE_SAVE = SFRPAGE;

   if (Uart == 0)
   {
      SFRPAGE = UART0_PAGE;
   }
   else if (Uart == 1)
   {
      SFRPAGE = UART1_PAGE;
   }

   while (!TI0);                       // Wait for transmit complete
   TI0 = 0;

   SBUF0 = c;                          // Send character

   SFRPAGE = SFRPAGE_SAVE;
   return c;
}


//-----------------------------------------------------------------------------
// getkey
//-----------------------------------------------------------------------------
//
//  Copyright KEIL ELEKTRONIK GmbH 1990 - 2002 
//                       
// Modified by BW
// Modified by JJA - 2019
//
// This routine overloads the standard _getkey() library function 
//
// As RI0 and RI1 are at the same address but in different pages (respectively UART0_PAGE and UART1_PAGE), same
// for SBUF0 and SBUF1, it is enough to define the page to be used to manage with the same addresses both UART.
//
char getkey (void)
{
    char c;
    char SFRPAGE_SAVE = SFRPAGE;

    if (Uart == 0) 
    {
        SFRPAGE = UART0_PAGE;
    } 
    else if (Uart == 1)
    {
        SFRPAGE = UART1_PAGE;
    }

    while (!RI0);                   // Wait for byte to be received
    {
        RI0 = 0;
        c = SBUF0;                  // Read the byte
    }
        
    SFRPAGE = SFRPAGE_SAVE;
    return (c);
}



//-----------------------------------------------------------------------------
// read_input_from_UARTx
//-----------------------------------------------------------------------------

void read_input_from_UARTx (void)
{
	char c;
	bit ok = FALSE;

	UART_InputBuffer_Size = 0;
    UART_InputBuffer[0] = '\0';

  	while (!ok)
	{
		c = getkey ();
        
		if ((c == '\0') || (c == '\n') || (c == '\r') || (c == '/'))    // || (c == '/') added for BLE test
		{
			ok = TRUE;
			UART_InputBuffer[UART_InputBuffer_Size] = '\0';     // End-Of-Line char
		}
		else if (UART_InputBuffer_Size < UART_BUFFERSIZE)
		{
			UART_InputBuffer[UART_InputBuffer_Size] = c;
			UART_InputBuffer_Size++;         					// Update array's size
		}
	}
}



//-----------------------------------------------------------------------------
// Initialization Subroutines
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// SYSCLK_Init ()
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// This routine initializes the system clock to use the internal 24.5 MHz oscillator
// Also enables missing clock detector reset.
// If PLL used, set FLSCL et PLL0 registers according.
//
void SYSCLK_Init (void)
{

#ifdef USE_PLL
	unsigned char n;                    // n used for short delay counter
#endif

    SFRPAGE = CONFIG_PAGE;              // Set SFR page F
	OSCICN = 0x83;						// 1000 0011 -> Configure internal oscillator for
                           				// 					its highest frequency (24.5 MHz)
    SFRPAGE = LEGACY_PAGE;              // Set SFR page 0
    RSTSRC = 0x06;						// 0000 0110 -> Enable missing clock detector
                                        //           -> Enable VDDMON as reset source 
#ifdef USE_PLL
    FLSCL   = FLSCL_FLRT;               // Set FLASH read time according to SYSCLK (in page 0)

    SFRPAGE = CONFIG_PAGE;              // Set SFR page F
    PLL0CN |= 0x01;                     // Enable Power to PLL
    PLL0DIV = PLL_DIV;                  // Set PLL divider value using macro
    PLL0MUL = PLL_MUL;                  // Set PLL multiplier value using macro
    PLL0FLT = PLLFLT_ICO|PLLFLT_LOOP;   // Set the PLL filter loop and ICO bits
    for (n = 0xFF; n != 0; n--);        // Wait at least 5us
    PLL0CN  |= 0x02;                    // Enable the PLL
    while(!(PLL0CN & 0x10));            // Wait until PLL frequency is locked
    CLKSEL  = 0x02;                     // Select PLL as SYSCLK source
#else
    SFRPAGE = CONFIG_PAGE;
    CLKSEL = 0x00;                      // Select internal oscillator as SYSCLK source (default value after reset)
#endif
}


//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Configure the Crossbar and GPIO ports
//
void PORT_Init (void)
{
	uint count;

    SFRPAGE = CONFIG_PAGE;	// Switch to configuration page (0x0F)
							// also it's page of Port 4, 5, 6 & 7

    XBR0		= 0x04;		// 0000 0100 -> TX0 & RX0 routed to port pins (UART0EN = 1)
    XBR1        = 0x00;     // reset value
    XBR2		= 0x40;		// 0100 0000 -> Enable crossbar and weak pull-ups 

    // ---------- Port 0
    if (GLCD_onJ14)         // route INT0 & INT1 on J14 (pin 23 & pin 24)
    {
        XBR1		= 0x14;		// 0001 0100 -> INT0 & INT1 routed to port pin.
        P0MDOUT 	= 0xF1;		// 1111 0001 -> set P0.0(TX0) to push-pull, P0.1(RX0), P0.2(INT0/), P0.3(INT1/) to open-drain 
	    P0			= 0x8E;		// 1000 1110 -> set P0.1(RX0), P0.2(INT0/), P0.3(INT1/) to input (writing 1)
								//			 -> set P0.6(BLE_STATUS) to 0 
                                //           -> set P0.7(GLCD_STATUS) to 1  
    }
    else if (BT_onJ14)      // route TX1 & RX1 on J14 (pin 23 & pin 24)
    {
        
        XBR2		= 0x44;		// 0100 0100 -> TX1 & RX1  routed to port pins (UART1E = 1)
                                //              Enable crossbar and weak pull-ups 
        P0MDOUT 	= 0xF5;		// 1111 0101 -> set P0.0(TX0) and P0.2(TX1) to push-pull, P0.1(RX0), P0.3(RX1) to open-drain (writing 0) 
	    P0			= 0x4A;		// 0100 1010 -> set P0.1(RX0), P0.3(RX1) to input (writing 1)
								//			 -> set P0.6(BLE_STATUS) to 1 
                                //           -> set P0.7(GLCD_STATUS) to 0  
    }
    else    // no extention board, init UART0 for USB connection
    {
        P0MDOUT 	= 0xFD;		// 1111 1101 -> set P0.0(TX0) to push-pull, P0.1(RX0) to open-drain 
	    P0			= 0x02;		// 0000 0010 -> set P0.1(RX0) to input (writing 1)
								//			 -> set P0.6(BLE_STATUS) to 0 
                                //           -> set P0.7(GLCD_STATUS) to 0        
    }


	// ---------- Port 5
	P5MDOUT	    = 0x7F;			// 0111 1111 -> set P5.7(ADS_DRDY_BARRE) to open-drain (writing 0)
	P5			= 0xC6;			// 1100 0110 -> set P5.7(ADS_DRDY_BARRE) to input (writing 1)
                                //              set PGA2_G_3(P5^3) & PGA2_G_10(P5^4) to 0, disabling U21 & U22
	// ---------- Port 1
	P1MDOUT	    = 0xF0;			// 1111 0000 -> set P1.0 to P1.3(BOUTON_Lx) to open-drain (writing 0)
	P1			= 0x0F;			// 0000 1111 -> set P1.0 to P1.3(BOUTON_Lx) to input (writing 1)

	// ---------- Port 2
    P2MDOUT	    = 0xFF;		    // 1111 1111 -> P2 port as output (LCD-DBx)
	P2 		    = 0x00;			

	// ---------- Port 3
	P3MDOUT	    = 0xB2;		    // 1011 0010 -> set P3.0(SYNCH_OUT) P3.2(TEST_GLCD) P3.3(J16) P3.6(ENCOD_SW) to open-drain
	P3			= 0xCD;			// 1100 1101 -> set P3.0(SYNCH_OUT) P3.2(TEST_GLCD) P3.3(J16) P3.6(ENCOD_SW) to input (writing 1)
                                //              set P3.7(BACKLIGHT) (output) to 1;

	// ---------- Port 4
	P4MDOUT	    = 0x80;		    // 1000 0000 -> set P4.0 to P4.6(RSELECT_SWx & INPUT_CP0) to open-drain
	P4			= 0x7F;			// 0111 1111 -> set P4.0 to P4.6(RSELECT_SWx & INPUT_CP0) to 1, P4.7(DC_BIAS_U_I) to 0
									
	// ---------- Port 6
	P6MDOUT	    = 0xFE;		    // 1111 1110 -> set P6.0(ADS_DOUT) to open-drain
	P6			= 0xE9;			// 1110 1001 -> set P6.0(ADS_DOUT) to input (writing 1)
								//				set P6.3(FSYNC_DDS1_), P6.5(SCLK_DDS), P6.6(FSYNC_DDS2_), P6.7(RESET_DDS_) to 1

	// ---------- Port 7
	P7MDOUT	    = 0x7F;		    // 0111 1111 -> set P7.7(PWRN) to open-drain
    P7			= 0xA8;			// 1010 1000 -> set P7.7(PWRN) to input, P7.5(ENABLE_BOOST) to 1, P7.4(MAX_BOOST) to 0, P7.3(J23) to 1

	for (count = 10000; count > 0; count--);	
} // PORT_Init


//-----------------------------------------------------------------------------
// UART0_Init   Variable baud rate, Timer 2, 8-N-1
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Configure UART0 for operation at <BAUDRATE_0> in mode 1 (8-N-1) using Timer2 as
// baud rate source.
//
void UART0_Init (void)
{

    SFRPAGE = TMR2_PAGE;

    TMR2CN = 0x00;                      // Timer2 in 16-bit auto-reload up timer mode
                                       
    TMR2CF = 0x08;                      // 0000 1000 -> SYSCLK is time base; no output, up count only
                                       
    RCAP2 = - ((long) (SYSCLK/BAUDRATE_0/16));
    TMR2 = RCAP2;
    TR2= 1;                             // Timer2 enabled

    SFRPAGE = UART0_PAGE;               // 0x00 same as LEGACY_PAGE

    SCON0 = 0x50;                       // 0101 0000 ->  UART0 Mode 1: 8-bit variable baud rate, RX enabled
    SSTA0 = 0x15;                       // 0001 0101 ->  Clear all flags; disable baud rate doubler
                                        //               Use Timer2 overflow as RX and TX baud rate source

    TI0     = 1;                        // Indicate TX0 ready
    SFRPAGE = CONFIG_PAGE;

    ES0 = 1;					        // enable UART0 interrupt
    IP |= 0x10;					        // 0001 0000 -> UART0 interrupts set to high priority: PS0 = 1 (IP^4)
}



//-----------------------------------------------------------------------------
// UART1_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : the baudrate
//
// Configure UART1 for operation at <UART1_baudrate> 8-N-1 using Timer1 as
// baud rate source.
//
void UART1_Init (void)
{
    uint k = SYSCLK/UART1_baudrate/2;

    SFRPAGE = UART1_PAGE;
    SCON1   = 0x10;                     // SCON1: mode 0, 8-bit UART, enable RX

    SFRPAGE = TIMER01_PAGE;
    TMOD   &= ~0xF0;
    TMOD   |=  0x20;                    // TMOD: timer 1, mode 2, 8-bit reload

    if (k/256 < 1) {
        TH1 = -(k);
        CKCON |= 0x10;                   // T1M = 1; SCA1:0 = xx
    } else if (k/256 < 4) {
        TH1 = -(k/4);
        CKCON &= ~0x13;                  // Clear all T1 related bits
        CKCON |=  0x01;                  // T1M = 0; SCA1:0 = 01
    } else if (k/256 < 12) {
        TH1 = -(k/12);
        CKCON &= ~0x13;                  // T1M = 0; SCA1:0 = 00
    } else {
        TH1 = -(k/48);
        CKCON &= ~0x13;                  // Clear all T1 related bits
        CKCON |=  0x02;                  // T1M = 0; SCA1:0 = 10
    }

    TL1 = TH1;                          // Initialize Timer1
    TR1 = 1;                            // Timer1 enabled

    SFRPAGE = UART1_PAGE;
    TI1 = 1;                            // Indicate TX1 ready

    SFRPAGE = CONFIG_PAGE;
    EIE2 |=  0x40;					    // 0100 0000 -> ES1 = 1 enable UART1 interrupt
    EIP2 |=  0x40;				        // 0100 0000 -> PS1 = 1 UART1 interrupts set to high priority: (EIP2^6)
}


//-----------------------------------------------------------------------------
// Timer3_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Initializes Timer3 to be clocked by SYSCLK or SYSCLK/2 for use as a delay timer.
//
void Timer3_Init (void)
{
    SFRPAGE   = TMR3_PAGE;
#if (PLL_MUL>2)
    TMR3CF    = 0x18;		// 0001 1000		SYSCLK/2 & auto-reload mode
#else
    TMR3CF    = 0x08;		// 0000 1000		SYSCLK & auto-reload mode
#endif

    TMR3CN = 0x04;          // Enable Timer3 in auto-reload mode
	TR3 = 0;                // Stop Timer 3
    SFRPAGE = CONFIG_PAGE;
}


//-----------------------------------------------------------------------------
// wait_us
//-----------------------------------------------------------------------------
//
// Return Value :   none
// Parameters:      unsigned int us - number of microseconds of delay
//                  if PLL_MUL = 1 (SYSCLK = 24.5MHz it means 24.5 cycles per us ) range is 1 to 2674
//				    if PLL_MUL = 2 (SYSCLK = 49MHz it means 49 cycles per us ) range is 1 to 1337
//					if PLL_MUL = 3 (SYSCLK/2 = 36.75MHz it means 36.75 cycles per us ) range is 1 to 1783
//				    ---> range is 1 to 1000
//
// This routine uses TIMER3 and generates a delay of < Time_us > microseconds.
//
void wait_us(uint time_us)
{
    char SFRPAGE_SAVE = SFRPAGE;                // Save Current SFR page

    SFRPAGE = TMR3_PAGE;

	TMR3  =  - ((uint)(time_us * TMR3_COEFF)) ;	// Timer 3 overflows time_us later
    TR3   = 1;                       			// Start timer

    while (!TF3);                       // Wait till timer overflow

	TMR3CN &= 0x7B;						// 0111 1011 Clear timer overflow flag (TMR3CN.7) & Stop Timer.(TMR3CN.2)

    SFRPAGE = SFRPAGE_SAVE;             // Restore SFRPAGE

}


//-----------------------------------------------------------------------------
// wait_ms
//-----------------------------------------------------------------------------
//
// Return Value : false if time_ms is out of range
// Parameters   : time_ms - time delay in milliseconds;  range: 1 to 65500
//
// Creates a delay for the specified time (in milliseconds) using wait_us().
// This function does not use any SFRs (so SFRPAGE is left untouched).
//
bit wait_ms (unsigned int time_ms)
{
	if ((time_ms == 0) || (time_ms > 65500))
		return false;

    while(time_ms--)
	{
		wait_us (1000);	// 1000us per loop
	}
	return true;
}






//-----------------------------------------------------------------------------
//
// FLASH Routines (From Silicon Labs Application Notes AN201)
//
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// FLASH_Clear
//-----------------------------------------------------------------------------
//
// This routine erases <numbytes> starting from the FLASH addressed by
// <dest> by performing a read-modify-write operation using <FLASH_TEMP> as
// a temporary holding area.  This function accepts <numbytes> up to
// <FLASH_PAGESIZE>.
//
void FLASH_Clear (FLADDR dest, unsigned numbytes, bit SFLE)
{
   FLADDR dest_1_page_start;           // first address in 1st page
                                       // containing <dest>
   FLADDR dest_1_page_end;             // last address in 1st page
                                       // containing <dest>
   FLADDR dest_2_page_start;           // first address in 2nd page
                                       // containing <dest>
   FLADDR dest_2_page_end;             // last address in 2nd page
                                       // containing <dest>
   unsigned numbytes_remainder;        // when crossing page boundary,
                                       // number of <src> bytes on 2nd page
   unsigned FLASH_pagesize;            // size of FLASH page to update

   FLADDR  wptr;                       // write address
   FLADDR  rptr;                       // read address

   unsigned length;

   if (SFLE) {                         // update Scratchpad
      FLASH_pagesize = FLASH_SCRATCHSIZE;
   } else {
      FLASH_pagesize = FLASH_PAGESIZE;
   }

   // Updated to fix issue if address was Bank 2 or Bank 3
   dest_1_page_start = dest & (0x10000 | ~(FLASH_pagesize - 1));
   dest_1_page_end = dest_1_page_start + FLASH_pagesize - 1;
   dest_2_page_start = (dest + numbytes)  & (0x10000 | ~(FLASH_pagesize - 1));
   dest_2_page_end = dest_2_page_start + FLASH_pagesize - 1;

   if (dest_1_page_end == dest_2_page_end) {

      // 1. Erase Scratch page
      FLASH_PageErase (FLASH_TEMP, 0);

      // 2. Copy bytes from first byte of dest page to dest-1 to Scratch page

      wptr = FLASH_TEMP;
      rptr = dest_1_page_start;
      length = dest - dest_1_page_start;
      FLASH_Copy (wptr, 0, rptr, SFLE, length);

      // 3. Copy from (dest+numbytes) to dest_page_end to Scratch page

      wptr = FLASH_TEMP + dest - dest_1_page_start + numbytes;
      rptr = dest + numbytes;
      length = dest_1_page_end - dest - numbytes + 1;
      FLASH_Copy (wptr, 0, rptr, SFLE, length);

      // 4. Erase destination page
      FLASH_PageErase (dest_1_page_start, SFLE);

      // 5. Copy Scratch page to destination page
      wptr = dest_1_page_start;
      rptr = FLASH_TEMP;
      length = FLASH_pagesize;
      FLASH_Copy (wptr, SFLE, rptr, 0, length);

   } else {                            // value crosses page boundary
      // 1. Erase Scratch page
      FLASH_PageErase (FLASH_TEMP, 0);

      // 2. Copy bytes from first byte of dest page to dest-1 to Scratch page

      wptr = FLASH_TEMP;
      rptr = dest_1_page_start;
      length = dest - dest_1_page_start;
      FLASH_Copy (wptr, 0, rptr, SFLE, length);

      // 3. Erase destination page 1
      FLASH_PageErase (dest_1_page_start, SFLE);

      // 4. Copy Scratch page to destination page 1
      wptr = dest_1_page_start;
      rptr = FLASH_TEMP;
      length = FLASH_pagesize;
      FLASH_Copy (wptr, SFLE, rptr, 0, length);

      // now handle 2nd page

      // 5. Erase Scratch page
      FLASH_PageErase (FLASH_TEMP, 0);

      // 6. Copy bytes from numbytes remaining to dest-2_page_end to Scratch page

      numbytes_remainder = numbytes - (dest_1_page_end - dest + 1);
      wptr = FLASH_TEMP + numbytes_remainder;
      rptr = dest_2_page_start + numbytes_remainder;
      length = FLASH_pagesize - numbytes_remainder;
      FLASH_Copy (wptr, 0, rptr, SFLE, length);

      // 7. Erase destination page 2
      FLASH_PageErase (dest_2_page_start, SFLE);

      // 8. Copy Scratch page to destination page 2
      wptr = dest_2_page_start;
      rptr = FLASH_TEMP;
      length = FLASH_pagesize;
      FLASH_Copy (wptr, SFLE, rptr, 0, length);
   }
}



//-----------------------------------------------------------------------------
// FLASH_Update
//-----------------------------------------------------------------------------
//
// This routine replaces <numbytes> from <src> to the FLASH addressed by
// <dest>.  This function calls FLASH_Clear() to handle the dirty work of
// initializing all <dest> bytes to 0xff's prior to copying the bytes from
// <src> to <dest>. This function accepts <numbytes> up to <FLASH_PAGESIZE>.
//
void FLASH_Update (FLADDR dest, char *src, unsigned numbytes, bit SFLE)
{
   // 1. Erase <numbytes> starting from <dest>
   FLASH_Clear (dest, numbytes, SFLE);

   // 2. Write <numbytes> from <src> to <dest>
   FLASH_Write (dest, src, numbytes, SFLE);
}


//-----------------------------------------------------------------------------
// erase_flash
//-----------------------------------------------------------------------------
//
// This routine erases pages of FLASH beetwen debut & fin
//
void erase_flash(FLADDR debut, FLADDR fin)
{
  	bit EA_state = EA;                  // preserve EA
     
  	FLADDR i;                 			// temporary int
    EA = 0;                          	// disable interrupts

	for (i = debut; i < fin; i += 0x400)    // FLASH_PAGESIZE
		FLASH_PageErase (i, 0);
  
  	EA =  EA_state;                  	// restore interrupt state

    f_valid = FALSE;                 	// indicate that code is no longer valid
  	code_erased = TRUE;              	// indicate that FLASH has been erased
}


//-----------------------------------------------------------------------------
// FLASH_PageErase
//-----------------------------------------------------------------------------
//
// This routine erases the FLASH page containing the linear FLASH address
// <addr>.
//
void FLASH_PageErase (FLADDR addr, bit SFLE)
{
   char SFRPAGE_SAVE = SFRPAGE;        // preserve SFRPAGE
   bit EA_SAVE = EA;                    // preserve EA
   char PSBANK_SAVE = PSBANK;           // preserve PSBANK
   char xdata * data pwrite;            // FLASH write pointer

   EA = 0;                              // disable interrupts

   SFRPAGE = LEGACY_PAGE;

   if (addr < 0x10000)                  // 64K linear address
   {
      pwrite = (char xdata *) addr;
   }
   else if (addr < 0x18000)             // BANK 2 
   {
      addr |= 0x8000;
      pwrite = (char xdata *) addr;
      PSBANK &= ~0x30;                 // COBANK = 0x2
      PSBANK |=  0x20;
   } 
   else                                 // BANK 3
   {
      pwrite = (char xdata *) addr;
      PSBANK &= ~0x30;                 // COBANK = 0x3
      PSBANK |=  0x30;
   }

   FLSCL |= 0x01;                      // enable FLASH writes/erases
   PSCTL |= 0x03;                      // PSWE = 1; PSEE = 1

   if (SFLE) {
      PSCTL |= 0x04;                   // set SFLE
   }

   RSTSRC = 0x02;                      // enable VDDMON as reset source
   *pwrite = 0;                        // initiate page erase

   if (SFLE) {
      PSCTL &= ~0x04;                  // clear SFLE
   }

   PSCTL &= ~0x03;                     // PSWE = 0; PSEE = 0
   FLSCL &= ~0x01;                     // disable FLASH writes/erases

   PSBANK = PSBANK_SAVE;               // restore PSBANK
   SFRPAGE = SFRPAGE_SAVE;             // restore SFRPAGE
   EA = EA_SAVE;                       // restore interrupts
}


//-----------------------------------------------------------------------------
// FLASH_ByteWrite
//-----------------------------------------------------------------------------
//
// This routine writes <byte> to the linear FLASH address <addr>.
// Linear map is decoded as follows:
// Linear Address       Bank     Bank Address
// ------------------------------------------------
// 0x00000 - 0x07FFF    0        0x0000 - 0x7FFF
// 0x08000 - 0x0FFFF    1        0x8000 - 0xFFFF
// 0x10000 - 0x17FFF    2        0x8000 - 0xFFFF
// 0x18000 - 0x1FFFF    3        0x8000 - 0xFFFF
//
void FLASH_ByteWrite (FLADDR addr, char byte, bit SFLE)
{
   char SFRPAGE_SAVE = SFRPAGE;        // preserve SFRPAGE
   bit EA_SAVE = EA;                   // preserve EA
   char PSBANK_SAVE = PSBANK;          // preserve PSBANK
   char xdata * data pwrite;           // FLASH write pointer

   EA = 0;                             // disable interrupts

   SFRPAGE = LEGACY_PAGE;

   if (addr < 0x10000)                 // 64K linear address 
   {
      pwrite = (char xdata *) addr;
   }
   else if (addr < 0x18000)            // BANK 2
   {        
      addr |= 0x8000;
      pwrite = (char xdata *) addr;
      PSBANK &= ~0x30;                 // COBANK = 0x2
      PSBANK |=  0x20;
   }
   else                                 // BANK 3
   {
      pwrite = (char xdata *) addr;
      PSBANK &= ~0x30;                 // COBANK = 0x3
      PSBANK |=  0x30;
   }

   FLSCL |= 0x01;                      // enable FLASH writes/erases
   PSCTL |= 0x01;                      // PSWE = 1

   if (SFLE) {
      PSCTL |= 0x04;                   // set SFLE
   }

   RSTSRC = 0x02;                      // enable VDDMON as reset source
   *pwrite = byte;                     // write the byte

   if (SFLE) {
      PSCTL &= ~0x04;                  // clear SFLE
   }
   PSCTL &= ~0x01;                     // PSWE = 0
   FLSCL &= ~0x01;                     // disable FLASH writes/erases

   PSBANK = PSBANK_SAVE;               // restore PSBANK
   SFRPAGE = SFRPAGE_SAVE;             // restore SFRPAGE
   EA = EA_SAVE;                       // restore interrupts
}


//-----------------------------------------------------------------------------
// FLASH_ByteRead
//-----------------------------------------------------------------------------
//
// This routine reads a <byte> from the linear FLASH address <addr>.
//
unsigned char FLASH_ByteRead (FLADDR addr, bit SFLE)
{
   char SFRPAGE_SAVE = SFRPAGE;       // preserve SFRPAGE
   bit EA_SAVE = EA;                    // preserve EA
   char PSBANK_SAVE = PSBANK;           // preserve PSBANK
   char code * data pread;              // FLASH read pointer
   unsigned char byte;

   EA = 0;                              // disable interrupts

   SFRPAGE = LEGACY_PAGE;

   if (addr < 0x10000)                  // 64K linear address
   {
      pread = (char code *) addr;
   } 
   else if (addr < 0x18000)             // BANK 2 
   {
      addr |= 0x8000;
      pread = (char code *) addr;
      PSBANK &= ~0x30;                 // COBANK = 0x2
      PSBANK |=  0x20;
   } 
   else                                 // BANK 3 
   {
      pread = (char code *) addr;
      PSBANK &= ~0x30;                  // COBANK = 0x3
      PSBANK |=  0x30;
   }

   if (SFLE) {
      PSCTL |= 0x04;                   // set SFLE
   }

   byte = *pread;                      // read the byte

   if (SFLE) {
      PSCTL &= ~0x04;                  // clear SFLE
   }

   PSBANK = PSBANK_SAVE;               // restore PSBANK
   SFRPAGE = SFRPAGE_SAVE;             // restore SFRPAGE
   EA = EA_SAVE;                       // restore interrupts

   return byte;
}



//-----------------------------------------------------------------------------
// FLASH_Write
//-----------------------------------------------------------------------------
//
// This routine copies <numbytes> from <src> to the linear FLASH address
// <dest>.
//
void FLASH_Write (FLADDR dest, char *src, unsigned numbytes, bit SFLE)
{
   FLADDR i;

   for (i = dest; i < dest+numbytes; i++) {
      FLASH_ByteWrite (i, *src++, SFLE);
   }
}


//-----------------------------------------------------------------------------
// FLASH_Read
//-----------------------------------------------------------------------------
//
// This routine copies <numbytes> from the linear FLASH address <src> to
// <dest>.
//
char * FLASH_Read (char *dest, FLADDR src, unsigned numbytes, bit SFLE)
{
   FLADDR i;

   for (i = 0; i < numbytes; i++) {
      *dest++ = FLASH_ByteRead (src+i, SFLE);
   }
   return dest;
}


//-----------------------------------------------------------------------------
// FLASH_Copy
//-----------------------------------------------------------------------------
//
// This routine copies <numbytes> from <src> to the linear FLASH address
// <dest>.
//
void FLASH_Copy (FLADDR dest, bit destSFLE, FLADDR src, bit srcSFLE,
                 unsigned numbytes)
{
   FLADDR i;

   for (i = 0; i < numbytes; i++) {

      FLASH_ByteWrite ((FLADDR) dest+i,
                       FLASH_ByteRead((FLADDR) src+i, srcSFLE),
                       destSFLE);
   }
}
