 //-----------------------------------------------------------------------------
// LCR6_Defines.h
//-----------------------------------------------------------------------------
// 
// Author: Jean-Jacques Aubry 2013-2020
//
// Target: C8051F120 
// Compiler: KEIL C51 V9.60.0.0  
//
// Version (see 'FirmwareVersion' in LCR6.h)
//


#ifndef _DEFINES_H
#define _DEFINES_H

#include <c8051f120.h>					        // SFR declarations
#include <string.h> 
#include <stdio.h> 						        // sprintf()
#include <math.h>
#include <stdlib.h>						        // atof()
#include <intrins.h>					    	// _nop_() _chkfloat_()

// -----------------------------------------------------------------------
// *** WARNING **** Must be adapted to your environment! 
#include "C:/LCR6_COMMON_FILE/LCR6_common.h" 
// -----------------------------------------------------------------------


typedef unsigned char uchar;
typedef unsigned int uint;
typedef unsigned long ulong;
typedef unsigned long FLADDR;

// -----------------------------------------------------------------------
// *** WARNING **** must be definided when no Bootloader in memory,
// synchronisation process with GUI is done here, not in the Bootloader code

//#define NO_BOOTLOADER_MODE      // use this mode only for debugging!                    

// ------------------------------------------------------------------------

#define DEBUG_1                 // if defined and according 'display_Range' bit, display <Range, Voltage PGA2 gain, Current PGA2 gain>
                                // ->   a longKeypressed on KEY_4 switch this display ON/OFF (for Debug...)
                                //      At startup display is OFF

//#define DEBUG_2                 // if defined, possibility tu switch ON/OFF the PGA2 --> only for test
//#define DEBUG_3                 // if defined, the rotary encoder way is reversed
//#define DEBUG_5                 // if defined, long_pressed on first button erase TRIM data


#define CHAR_SIZE			    1
#define INT_SIZE			    2
#define LONG_SIZE			    4
#define FLOAT_SIZE			    4
#define POINTER_SIZE            3
#define MINFLOAT                0.0000000000001 // 1E-13

#define FREQ_MEM_SIZE_2M        54              // number of frequencies until 2MHz
                                                // *** WARNING **** 
                                                // If the value is changed the calibrations must be redone.
 
#define UART_OUT_BUFFERSIZE 	22		        // a BLE message is limited to 20 characters
#define UART_IN_BUFFERSIZE 		50			    

#define FREQ_MEM_SIZE	    FREQ_MEM_SIZE_2M    // maximum number of frequencies is about 110 according
                                                // to have each (CF_Rx_OK + TABLE_CFX_Rx + TABLE_CFR_Rx)
                                                // calibration settings on one page (0x400) of FLASH memory,
                                                // but be careful not to exceed the XDATA memory capacity. 

#define MIN_FREQ_INDEX_START    0               // *** WARNING *** can be modified for debugging only! 
                                                // normaly 0 (start frequency is 50 Hz) 
                                                // The value to speed up calibration testing is 26 ( >= 10 kHz) or 14 ( >= 1 kHz)

#define WITHOUT_ICON 		-1				    // no icon on right
#define WITH_ICON28 		-28				    // 28 pixels icon on right

#define false 				0
#define true 				1

#define OFF 				0
#define ON 					1

#define STOP 				0
#define START 				1

#define SHORT_TRIM		    0
#define OPEN_TRIM			1

#define WITHOUT_SUFFIX 	    0
#define WITH_SUFFIX 		1

#define VOLTAGE_MODE		0
#define CURRENT_MODE		1

#define SOFT_SELECT	    	0
#define PIN_SELECT		    1

#define SENS_MINUS		    0
#define SENS_PLUS			1
				
#define QUADRATURE		    0
#define IN_PHASE			1

#define KIND_MENU		    1
#define KIND_CONFIG			2
#define KIND_SERIES         3
#define KIND_LANGUAGE       4
#define KIND_LEVEL          5

#define OK_MEASURE          -1
#define ERROR_NAN           -10
#define NOT_MODIFIED        -1
#define FOR_MATCH			-1

#define BASELINE_6X11       8           // pixel offset of text base line for font 6 x 11
#define BASELINE_8X16       13          // pixel offset of text base line for font 8 x 16
#define BASELINE_12X24      20          // pixel offset of text base line for font 12 x 24

#define X_POS				16			// pixels
#define X_POS_Z_D_PHI		56
#define X_POS_UNITS			162

// Icon for components
#define ICON_WIDTH          51
#define ICON_HEIGHT         16

#define Y_POS_PRIMARY 		6
#define Y_DELTA_ICON		20	
#define Y_POS_SECONDARY 	(Y_POS_PRIMARY + Y_DELTA_ICON)

#define Y_POS_LINE_1 	 	24						// Primary Y pos
#define Y_POS_LINE_2		(Y_POS_LINE_1 + 16)		// Secondary Y pos (40)
#define Y_POS_LINE_3 		(Y_POS_LINE_2 + 16)		// AUTO & Frequency Y pos (56)


#define Y_POS_LINE_8        126						// last line (128) - 2
#define Y_POS_LINE_7 	 	(Y_POS_LINE_8 - 12)		// 114
#define Y_POS_LINE_6 	 	(Y_POS_LINE_7 - 12)		// 102
#define Y_POS_LINE_5 	 	(Y_POS_LINE_6 - 12)		// 90
#define Y_POS_LINE_4 	 	(Y_POS_LINE_5 - 12)		// 78

// keyboard
#define NO_KEY_PRESSED		(-1)
#define KEY_1				(1)
#define KEY_2				(2)
#define KEY_3				(3)
#define KEY_4				(4)
#define KEY_5				(5)
//#define KEY_6				(6)         // KEY_2 + KEY_4
//#define KEY_7				(7)         // KEY_2 + KEY_5
#define KEY_SW				(16)        //  = 1 << 4

// Menus
#define Y_DELTA_TEXT		12          // space between menus
#define MOVE_MARK_DOWN		20
#define MOVE_MARK_UP		21
#define Y_POS_MENU_1		12
#define DISPLAYED_MENUS     10          // number of displayed menus in standalone mode

#ifdef PLL_MUL
    #if (PLL_MUL>2)
		#define SPI_WAIT    4
    #elif (PLL_MUL>1)
		#define SPI_WAIT    2
    #endif
#else 
        #define SPI_WAIT    1
#endif


//-----------------------------------------------------------------------------
// Flash Global Constants
//-----------------------------------------------------------------------------

#ifndef FLASH_PAGESIZE
#define FLASH_PAGESIZE      1024L
#endif

#ifndef FLASH_SCRATCHSIZE
#define FLASH_SCRATCHSIZE   256
#endif

#ifndef FLASH_TEMP
#define FLASH_TEMP          0x1F400L    // address of temp page
#endif

#ifndef FLASH_LAST
#define FLASH_LAST          0x1F800L    // last page of FLASH
#endif

#define TAB_FLOAT_SIZE      (FREQ_MEM_SIZE * FLOAT_SIZE)
#define TAB_CHAR_SIZE       (FREQ_MEM_SIZE * CHAR_SIZE)


// ----------------------------------------------------------
// Tables for storing calibration factors.
//
//  A Boolean (only one or one for each frequency) if the value is valid 
//  For each frequency:
//      A float for the imaginary part
//      A float for the real part
// ----------------------------------------------------------

// ---------- page_a (0x400 - 1024 bytes - one page) - Calibration settings
#define CF_R1_OK_ADD                PAGE1_FLASH_ADDR                        // 0x18000  address of Config_Factor_R1_ok: char variable
#define TABLE_CFX_R1_ADD            (CF_R1_OK_ADD + CHAR_SIZE)              // 0x18001  address of Table_CFX_R1; MAX_FREQ_MEM_SIZE float variables.
#define TABLE_CFR_R1_ADD            (TABLE_CFX_R1_ADD + TAB_FLOAT_SIZE)     // 0x180D9  address of Table_CFR_R1; MAX_FREQ_MEM_SIZE float variables.

// ---------- page_b (0x400 - 1024 bytes - one page) - Calibration settings
#define CF_R2_OK_ADD                PAGE2_FLASH_ADDR                        // 0x18400  address of Config_Factor_R2_ok: char variable
#define TABLE_CFX_R2_ADD            (CF_R2_OK_ADD + CHAR_SIZE)              // 0x18401  address of Table_CFX_R2; MAX_FREQ_MEM_SIZE float variables.
#define TABLE_CFR_R2_ADD            (TABLE_CFX_R2_ADD + TAB_FLOAT_SIZE)     // 0x184D9  address of Table_CFR_R2; MAX_FREQ_MEM_SIZE float variables.

// ---------- page_c (0x400 - 1024 bytes - one page) - Calibration settings
#define CF_R3_OK_ADD                PAGE3_FLASH_ADDR                        // 0x18800  address of Config_Factor_R3_ok: char variable
#define TABLE_CFX_R3_ADD            (CF_R3_OK_ADD + CHAR_SIZE)              // 0x18801  address of Table_CFX_R3; MAX_FREQ_MEM_SIZE float variables.
#define TABLE_CFR_R3_ADD            (TABLE_CFX_R3_ADD + TAB_FLOAT_SIZE)     // 0x188D9  address of Table_CFR_R3; MAX_FREQ_MEM_SIZE float variables.

// ---------- page_d (0x400 - 1024 bytes - one page) - Calibration settings
#define CF_R4_OK_ADD                PAGE4_FLASH_ADDR                        // 0x18C00  address of Config_Factor_R4_ok: char variable
#define TABLE_CFX_R4_ADD            (CF_R4_OK_ADD + CHAR_SIZE)              // 0x18C01  address of Table_CFX_R4; MAX_FREQ_MEM_SIZE float variables.
#define TABLE_CFR_R4_ADD            (TABLE_CFX_R4_ADD + TAB_FLOAT_SIZE)     // 0x18CD9  address of Table_CFR_R4; MAX_FREQ_MEM_SIZE float variables.

// ---------- page_e (0x400 - 1024 bytes - one page) - Calibration settings
#define PGA_G3_OK_ADD               PAGE5_FLASH_ADDR                        // 0x19000 address of PGA_G3_ok: char variable
#define TABLE_IMAG_G3_ADD           (PGA_G3_OK_ADD + CHAR_SIZE)             // 0x19001 address of Table_IMAG_G3; MAX_FREQ_MEM_SIZE float variables.
#define TABLE_REAL_G3_ADD           (TABLE_IMAG_G3_ADD + TAB_FLOAT_SIZE)    // 0x190D9 address of Table_REAL_G3; MAX_FREQ_MEM_SIZE float variables.

// ---------- page_f (0x400 - 1024 bytes - one page) - Calibration settings
#define PGA_G10_OK_ADD              PAGE6_FLASH_ADDR                        // 0x19400 address of PGA_G10_ok: char variable
#define TABLE_IMAG_G10_ADD          (PGA_G10_OK_ADD + CHAR_SIZE)            // 0x19401 address of Table_IMAG_G10; MAX_FREQ_MEM_SIZE float variables.
#define TABLE_REAL_G10_ADD          (TABLE_IMAG_G10_ADD + TAB_FLOAT_SIZE)   // 0x190D9 address of Table_REAL_G10; MAX_FREQ_MEM_SIZE float variables.

// ---------- page_g (0x400 - 1024 bytes - one page) - Calibration settings
#define TRIM_SHORT_OK_ADD           PAGE7_FLASH_ADDR                        // 0x19800 address of Trim_short_OK: MAX_FREQ_MEM_SIZE char variables.
#define TABLE_IMAG_SHORT_ADD        (TRIM_SHORT_OK_ADD + TAB_CHAR_SIZE)     // 0x19836 address of Xs_Trim_short; MAX_FREQ_MEM_SIZE float variables.
#define TABLE_REAL_SHORT_ADD        (TABLE_IMAG_SHORT_ADD + TAB_FLOAT_SIZE) // 0x1990E address of Rs_Trim_short; MAX_FREQ_MEM_SIZE float variables.

// ---------- page_h (0x400 - 1024 bytes - one page) - Calibration settings
#define TRIM_OPEN_OK_ADD            PAGE8_FLASH_ADDR                        // 0x19C00 address of Trim_open_OK: MAX_FREQ_MEM_SIZE char variables.
#define TABLE_IMAG_OPEN_ADD         (TRIM_OPEN_OK_ADD + TAB_CHAR_SIZE)      // 0x19C36 address of Xs_Trim_open; MAX_FREQ_MEM_SIZE float variables.
#define TABLE_REAL_OPEN_ADD         (TABLE_IMAG_OPEN_ADD + TAB_FLOAT_SIZE)  // 0x19D0E address of Rs_Trim_open; MAX_FREQ_MEM_SIZE float variables.



#define EXT_VREF					2.500				// default value (external LM4050A25 0.1% 2.5V 50ppm/�C)

// ----- GLCD -----------------------
#define MODE_6800

#ifdef MODE_6800
	#define LCD_RW_					LCD_WR0
	#define LCD_E					LCD_WR1
#else
	#define LCD_WR_					LCD_WR0
	#define LCD_RD_					LCD_WR1
#endif


// ----- MCU ------------------------
#define MCU_VREF					EXT_VREF
#define ADS_SCK_MAX         		(100000L)     		// Max SCK freq (Hz)
#define SAR0_CLK      				(2500000L)       	// Desired SAR clock speed for ADC0



// ----- AD9834 ------------------------
#define XTAL_OSC_FREQ			(27000000L)	        // CMOS oscillator frequency (27MHz)
#define NCO_COEFF				9.94205392593	    // 2^28 / XTAL_OSC_FREQ
#define DDS_VREF				1.18			    // default internal reference.
#define DDS1_AND_DDS2			0
#define DDS1_ONLY				1
#define DDS2_ONLY				2

// The 4 phases (spaced 90�), for the measurement of the sine
#define PHI_DDS1_0				(1024)              // Initial phase shift for DDS1
#define PHI_DDS1_90				(PHI_DDS1_0 + 1024)
#define PHI_DDS1_180			(PHI_DDS1_0 + 2048)
#define PHI_DDS1_270			(PHI_DDS1_0 + 3072)

#define PHI_DDS2_0				(0)                 // Initial phase shift for DDS2                


// ----- Regulators --------------------
#define VREF					EXT_VREF
#define LOW_LIM_MINUS_5V		-5.3
#define HIGH_LIM_MINUS_5V		-4.7
#define LOW_LIM_5V				4.8
#define HIGH_LIM_5V				5.3
#define LOW_LIM_3V				2.85
#define HIGH_LIM_3V				3.15
#define LOW_LIM_BOOST_L			6.29
#define HIGH_LIM_BOOST_L		6.68

#define LOW_LIM_BOOST_H			7.30
#define HIGH_LIM_BOOST_H		7.60

#define	AIN_MINUS_5V			1       // MUX channel 1
#define	AIN_PLUS_5V				4       // MUX channel 4
#define AIN_PLUS_3V			    5       // MUX channel 5
#define	AIN_PLUS_6V				3       // MUX channel 3
#define AIN_DCBIAS_I            6       // MUX channel 6-7


#define E6                      0
#define E12                     1
#define E24                     2
#define E48                     3
#define E96                     4


// ----- ADS1246 ------------------------

// ADRRESS of REGISTER
#define VBIAS					0x01
#define MUX						0x02
#define SYS0					0x03

// COMMANDS
#define NOP						0xFF
#define WRESET					0x06
#define RDATA					0x12
#define RDATAC					0x14
#define SDATAC					0x16
#define RREG					0x20
#define WREG					0x40

#define SELFOCAL  				0x62        // SELF_OFFSET_CALIBRATION

#define MUX_VALUE				0x00		// Normal operation
#define MUX_OFFSETCAL           0x01        // input shorted to midsupply

#define ADS_SPS_05				0x00		// 5SPS
#define ADS_SPS_10				0x01		// 10SPS
#define ADS_SPS_20				0x02		// 20SPS
#define ADS_SPS_40				0x03		// 40SPS
#define ADS_SPS_80				0x04		// 80SPS
#define ADS_SPS_160				0x05		// 160SPS
#define ADS_SPS_320				0x06		// 320SPS
#define ADS_SPS_640				0x07		// 640SPS
#define ADS_SPS_1000			0x08		// 1000SPS

#define ADS_MAX_INDEX			7			// PGA gains: 1, 2, 4, 8, 16, 32, 64, 128 = 2^�ndex

#define ADS_VREF				EXT_VREF
#define ADS_VREF_DIV_2          (ADS_VREF / 2)
#define ADS_VREF_DIV_4          (ADS_VREF / 4)
#define ADS_VREF_DIV_8          (ADS_VREF / 8)
#define ADS_VREF_DIV_16         (ADS_VREF / 16)
#define ADS_VREF_DIV_32         (ADS_VREF / 32)
#define ADS_VREF_DIV_64         (ADS_VREF / 64)
#define ADS_VREF_DIV_128        (ADS_VREF / 128)

//#define ADS_DEFAULT_TEMP        25.0


// -- used for display functions
#define BUFFER_SIZE				7				// WITHOUT null terminator

#define R_PRIMARY				1
#define L_PRIMARY				2
#define C_PRIMARY				3

#define NO_SECONDARY            0
#define R_SECONDARY				R_PRIMARY
#define L_SECONDARY				L_PRIMARY
#define C_SECONDARY				C_PRIMARY

#define SERIES					1
#define PARALLEL				2
#define PLAIN                   3

#define FONT_IS_6x11            0
#define FONT_IS_8x16            1
#define FONT_IS_12x24           2

#define NO_KIND					0
#define R_KIND					1
#define L_KIND					2
#define C_KIND					3
#define PHI_KIND				4
#define A_KIND					5
#define V_KIND					6

#define REACTIVE_CIRCUIT		1
#define RESISTIVE_CIRCUIT		2

#define Z_CHANGE_MODEL			990.0		    // Serial or parallel criteria
#define MAX_Q                   50000           // > 5000 and <= 0xFFFF (65535)


// ---- Miscellaneous --------------------
#define NB_RANGE				4			    // Rsense: 100, 1k, 10k, 100k

#define PI						3.14159265359
#define TWO_PI					6.28318530718
#define HALF_PI					1.57079632680
#define QUATER_PI				0.78539816340
#define TWO_x_SQUARE2           2.828

#define DIFF_AMP_U_GAIN         0.98024         // From the simulation of U7C gain at low frequency with LTspice.

#define BUFSIZE_DATA_MAX1		8		        // **** even number only 
#define BUFSIZE_DATA_MAX2       6
#define BUFSIZE_DATA_MAX3       4
#define BUFSIZE_DATA_MAX4       2

#define ICON1_POS               0
#define ICON2_POS               26
#define ICON3_POS               52
#define ICON4_POS               78
#define ICON5_POS               104

#define LEVEL_1V_RMS            1
#define LEVEL_500mV_RMS         2
#define LEVEL_200mV_RMS         3
#define LEVEL_100mV_RMS         4

#define R_RANGE_1               1
#define R_RANGE_2               2
#define R_RANGE_3               3
#define R_RANGE_4               4

#define	RANGE_GAIN_1			1
#define	RANGE_GAIN_3			2
#define	RANGE_GAIN_10			3


//-----------------------------------------------------------------------------
// default values.
// *** WARNING *** not documented, but there is about 1 ohm between
// pin 1 and pin 6 of the AD8099! -> external short-circuit needed.
// The PCB (MCU board) is modified from REV 2.4.
// For the previous versions, this short circuit has to be established externally.
//-----------------------------------------------------------------------------
#define R_VALUE_1    	    	100.00      // 100R 0.01% sense value
#define R_VALUE_2       	 	1000.00     // 1k 0.01% sense value
#define R_VALUE_3        		10000.0		// 10k 0.01% sense value
#define R_VALUE_4        		100000.0	// 100k 0.01% sense value

#define G1_PGA2					1.0
#define G3_PGA2					3.167		// = 1 + R81 / (R83 // R84) -> approx square root of 10
#define G10_PGA2				10.07		// = 1 + R85 / (R87 // R88) -> approx 10.0


//-----------------------------------------------------------------------------
// some MACRO
//-----------------------------------------------------------------------------
#define BOOL(x) (!(!(x)))
#define BitSet(arg,posn) ((arg) | (1 << (posn)))
#define BitClr(arg,posn) ((arg) & ~(1 << (posn)))
#define BitTst(arg,posn) BOOL((arg) & (1 << (posn)))
#define BitFlp(arg,posn) ((arg) ^ (1 << (posn)))

#define MAX(x,y) ((x) > (y) ? (x) : (y))
#define MIN(x,y) ((x) < (y) ? (x) : (y))





//-----------------------------------------------------------------------------
// DDS AD9834
//-----------------------------------------------------------------------------

// ---- control register ----

// DB15 et DB14 must be 0

// DB13 (B28):	0 for 2 times loading, 1 for one time loading
#define B28			13

// DB12 (HLB) (if B28 = 0):	0 for LSB, 1 for MSB
#define HLB			12

// DB11 (FSEL) (with PIN_SW = 1) frequency reg select: 0 for FREQ0 REG, 1 for FREQ1 REG
#define FSEL		11

// DB10 (PSEL) (with PIN_SW = 1) phase reg select: 0 for PHASE0 REG, 1 for PHASE1 REG
#define PSEL		10

// DB9 (PIN/SW) -> phase, freq & reset selected by pins (1) or bits (0)
#define PIN_SW		9

// DB8 (RESET) reset registers
#define RESET		8

// DB7 (SLEEP1) -> MCLK non activated
#define SLEEP1		7

// DB6 (SLEEP12) -> D/A non activated
#define SLEEP12	    6

// DB5 (OPBITEN) -> SIGN BIT OUT enable
#define OPBITEN	5

// DB4 (SIGN/PIB) (with OPBITEN): 0 for MSB on SIGN BIT OUT
#define SIGN_PIB	4

// DB3 (DIV2) -> output divide by 2 (0) or not (1)
#define DIV2		3

// DB2 must be 0

// DB1 (MODE): 0 for sine output, 1 (without OPBITEN) for triangle output
#define MODE		1

// DB0 must be 0


// ---- frequency register ----

// DB15 and DB14: 01 for writing FREQ0 REG (DB13 to DB0 are the LSBs or MSBs of the frequency)
// DB15 and DB14: 10 for writing FREQ1 REG (DB13 to DB0 are the LSBs or MSBs of the frequency)


// ---- phase register ----

// DB15 and DB14: always 11
// DB13: 0 for writing PHASE0 REG, 1 for  writing PHASE1 REG
// DB12: no use (0 or 1)
// DB11 to DB0 are the 12 bits of the phase



//-----------------------------------------------------------------------------
// 16-bit SFR Definitions for 'F12x
//-----------------------------------------------------------------------------
sfr16 ADC0 	    = 0xbe;					// ADC0 data
sfr16 RCAP2     = 0xca;                 // Timer2 capture/reload
sfr16 RCAP3     = 0xca;                 // Timer3 capture/reload
sfr16 RCAP4     = 0xca;                 // Timer4 capture/reload
sfr16 TMR2      = 0xcc;                 // Timer2
sfr16 TMR3      = 0xcc;                 // Timer3
sfr16 TMR4      = 0xcc;                 // Timer4

									

//-----------------------------------------------------------------------------
// Interrupt Service Routine
//-----------------------------------------------------------------------------
#define INTERRUPT_INT0              0   // External Interrupt 0
#define INTERRUPT_TIMER0            1   // Timer0 Overflow
#define INTERRUPT_INT1              2   // External Interrupt 1
#define INTERRUPT_TIMER1            3   // Timer1 Overflow
#define INTERRUPT_UART0             4   // UART0
#define INTERRUPT_TIMER2            5   // Timer2 Overflow
#define INTERRUPT_SPI0              6   // SPI0
#define INTERRUPT_SMBUS0            7   // SMBus0 Interface
#define INTERRUPT_ADC0_WINDOW       8   // ADC0 Window Comparison
#define INTERRUPT_PCA0              9   // PCA0 Peripheral
#define INTERRUPT_COMPARATOR0F      10  // Comparator0 Falling
#define INTERRUPT_COMPARATOR0R      11  // Comparator0 Rising
#define INTERRUPT_COMPARATOR1F      12  // Comparator1 Falling
#define INTERRUPT_COMPARATOR1R      13  // Comparator1 Rising
#define INTERRUPT_TIMER3            14  // Timer3 Overflow
#define INTERRUPT_ADC0_EOC          15  // ADC0 End Of Conversion
#define INTERRUPT_TIMER4            16  // Timer4 Overflow
#define INTERRUPT_ADC2_WINDOW       17  // ADC2 Window Comparison
#define INTERRUPT_ADC2_EOC          18  // ADC2 End Of Conversion
// 									19   - RESERVED
#define INTERRUPT_UART1             20  // UART1



//-----------------------------------------------------------------------------
// Communication with external GUI - commands received
//-----------------------------------------------------------------------------

// Menu configuration
#define	SINUS_GEN_OFS		0
#define	SET_DDS_VREF        1
#define	CMRR_INPUT_AMP		2
#define	G3_CALIBRATION		3
#define	G10_CALIBRATION		4
#define	CALIB_RANGE1		5
#define	CALIB_RANGE2		6
#define	CALIB_RANGE3		7
#define	CALIB_RANGE4		8
#define	TRIM_SHORT_ALL		9
#define	TRIM_OPEN_ALL		10

// Menu
#define Q_LIMIT             11
#define SORT_PARAM          12
#define SORT                13
#define AC_LEVEL            14
#define DC_BIAS             15

// Command
#define	RUN					16
#define	HALT				17
#define MODE_D              18
#define TRIM_S              19
#define TRIM_L              20
#define R_HOLD              21
#define USER_FREQ           22
#define FIRM_VERSION        23
#define KEY5                24
#define KEY4                25
#define MOVE_UP             26
#define MOVE_DOWN           27         
#define NEW_DDSVREF         28
#define	FIRMW_UPDATE		29
#define START_B	            30
#define BAUD_RATE           31
#define TXT_UPDATE          32
#define STR_TEXT_ARRAY      33
#define STR_CONFIG_ARRAY    34
#define STR_MENU_ARRAY      35
#define STR_LANG_ARRAY      36
#define NBR_LANG            37
#define END_TEXT_FILE       38
#define AVG_SLOW            39
#define AVG_FAST            40
#define AFF_GAME            41

#define	TOKEN_SIZE			42	    // adjust value according new #define
 
#endif