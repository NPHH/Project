//-----------------------------------------------------------------------------
// LCR6_Texts.h
//-----------------------------------------------------------------------------
// 
// Author: Jean-Jacques Aubry 2013-2020
//
// Target: C8051F120 
// Compiler: KEIL C51 V9.60.0.0 
//
// Version (see 'FirmwareVersion' in LCR6.h)
//

#ifndef _TEXTS6_H
#define _TEXTS6_H

#include "LCR6_Defines.h"


// code constants
char code TextI_0[]     = "LCR-Meter AU2019";							    // startup screen
char code TextI_1[] 	= "2021   J.J.Aubry";

char code TextI_2[]     = "No Language loaded. Restart in PC Mode";
char code TextI_3[]     = "Use the AU2019 prog. to load them";
char code TextI_4[]     = "Text not avalaible. Restart in PC Mode";

char * code Series_Array[] =
{
    "E6  -> 20%",
    "E12 -> 10%",
    "E24 -> 5%",
    "E48 -> 2%",
    "E96 -> 1%"
};


char * code Level_Array[] =
{
    " 1V   RMS",
    "500mV RMS",
    "200mV RMS",
    "100mV RMS"
};


/*

// ----------------------------------------------------------------------------------------------
// FOR REFERENCE ONLY - These strings are loaded in BANK2 of FLASH EEPROM by the AU2019 program
//
// Exemple with NUMBER_LANGUAGE = 2

char  code Language_Array[NUMBER_LANGUAGE][LONG_TEXT_LANG] =
{
//  "123456789012"     // max 12 characters 6x11 + line terminator

    "English     ",
    "Fran�ais    ",
};


char   code Text_Array[NUMBER_TEXT_LINES * NUMBER_LANGUAGE][LONG_TEXT] = 
{
//	"-----------------------------------" 		max 35 charaters 6x11 + line terminator
//  "12345678901234567890123456789012035"

    "PS Test Error, code %u             ",      // 0
    "INITIALISATION, WAIT...            ",      // 1
    "No jumper fitted from J10 to J13   ",      // 2
    "Adjust C51 for |Phi| < 0.3         ",      // 3
    "Adjust C106 for |Phi| < 0.1        ",      // 4
    "Save the gain?                     ",      // 5
    "Select normalized value            ",      // 6
    "-> Adjust R146 for DC null on TP7  ",      // 7
    "Saving the Trim data...            ",      // 8
    "No Trim data to save               ",      // 9
    "Save the datas?                    ",      // 10
    "No DC bias for resistor            ",      // 11
    "Calculating the gain and phase     ",      // 12
    "  -> Put a jumper in J10           ",      // 13
    "  -> Put a jumper in J11           ",      // 14
    "  -> Put a jumper in J12           ",      // 15
    "  -> Put a jumper in J13           ",      // 16
    "Not the right jumper, exit         ",      // 17
    "Okay, will take few minutes        ",      // 18
    "Do the range 1 calibration         ",      // 19
    "Do the range 2 calibration         ",      // 20
    "Do the range 3 calibration         ",      // 21
    "Do the range 4 calibration         ",      // 22
    "Error, exit                        ",      // 23
    "Do PGA2 gain 3 calibration         ",      // 24
    "Do PGA2 gain 10 calibration        ",      // 25
    "Short circuit trim. Wait...        ",      // 26
    "Open circuit trim. Wait...         ",      // 27
    "Use saved frequency?               ",      // 28
    "  -> Open or Short the circuit     ",      // 29
    "Save the frequency?                ",      // 30
    "-- FAIL --                         ",      // 31
    "PASS                               ",      // 32
    "Short circuit before enter menu    ",      // 33
    "Open circuit before enter menu     ",      // 34
    "Adjust R31 for minimum voltage     ",      // 35
    "Adjust C44 for minimum voltage     ",      // 36
    "J9 set, J8 off, J17 set            ",      // 37
    "DC Bias voltage: 0 to 5V           ",      // 38
    "DC Bias current: 0 to 50mA         ",      // 39
    "AC Drive level: 0.1V RMS to 1V RMS ",      // 40
    "Measured voltage value on TP6      ",      // 41

    // French
    "Test alim.: erreur code %u         ",      // 0
    "INITIALISATION EN COURS...         ",      // 1
    "Aucun cavalier de J10 � J13        ",      // 2
    "R�gler C51 pour |Phi| < 0.3        ",      // 3
    "R�gler C106 pour |Phi| < 0.1       ",      // 4
    "Sauvegarder le gain?               ",      // 5
    "Selectionner la valeur normalis�e  ",		// 6
    "-> R�gler R146 pour 0V en TP7      ",      // 7
    "Sauvegarde des donn�es du Trim...  ",      // 8
    "Pas de donn�es Trim a sauvegarder  ",      // 9
    "Sauvegarder les valeurs?           ",      // 10
    "Pas polar. pour une r�sistance     ",      // 11     
    "Calcul du gain et de la phase      ",      // 12
    "  -> mettre un Cavalier en J10     ",      // 13
    "  -> mettre un Cavalier en J11     ",      // 14
    "  -> mettre un Cavalier en J12     ",      // 15
    "  -> mettre un Cavalier en J13     ",      // 16
    "Pas le bon cavalier, quitter       ",      // 17
    "OK, patientez quelques minutes     ",      // 18
    "Faire la calibration gamme 1       ",      // 19
    "Faire la calibration gamme 2       ",      // 20
    "Faire la calibration gamme 3       ",      // 21
    "Faire la calibration gamme 4       ",      // 22
    "Erreur, quitter                    ",      // 23
    "Faire la calibration PGA2 gain 3   ",      // 24
    "Faire la calibration PGA2 gain 10  ",      // 25
    "Trim en court-circuit Patientez... ",      // 26
    "Trim en circuit ouvert Patientez...",      // 27
    "Utiliser la valeur enregistr�e?    ",      // 28
    "  -> Ouvrir ou Fermer le circuit   ",      // 29
    "Enregistrer la fr�quence?          ",      // 30
    "-- Echec du TRIM --                ",      // 31
    "OK                                 ",      // 32
    "Commencez par fermer le circuit    ",      // 33
    "Commencez par ouvrir le circuit    ",      // 34
    "R�gler R31 pour tension minimale   ",      // 35
    "R�gler C44 pour tension minimale   ",      // 36
    "Pas J8, J9 mis, J17 mis            ",      // 37
    "Tension de polarisation: 0 � 5V    ",      // 38
    "Courant de polarisation: 0 � 50mA  ",      // 39
    "Tension d'essai: 0,1 Veff � 1 Veff ",      // 40
    "Valeur de la tension en TP6        ",      // 41
 
    // next language

//	"-----------------------------------" 	    max 35 charaters 6x11 + line terminator

};



char  code Menu_Array[NUMBER_MENU_LINES * NUMBER_LANGUAGE][LONG_TEXT] = 
{
//	"-----------------------------------", 	    max 35 charaters 6x11 + line terminator
    "Language                           ",      // 1
    "Q limit for secondary display      ",      // 2
    "Sorting parameters                 ",      // 3
    "Sort                               ",      // 4
    "AC level                           ",      // 5
    "DC bias                            ",      // 6
    "Change Display: INVERSE/NORMAL     ",      // 7

    // French
    "Langue                             ",      // 1
    "Q limite pour affichage secondaire ",      // 2
    "Param�tres du Tri                  ",      // 3
    "Tri                                ",      // 4
    "Amplitude sinuso�de                ",      // 5
    "Polarisation continue              ",      // 6
    "Modifier Affichage: INVERSE/NORMAL ",      // 7

    // next language
};



char   code Config_Array[NUMBER_CONFIG_LINES * NUMBER_LANGUAGE][LONG_TEXT] = 
{
//	"-----------------------------------", 	    max35 charaters 6x11 + line terminator
    "Set sinus generator offset         ",      // 1
	"Measured value of Vref (DDS)       ",      // 2
    "CMRR of Voltage diff. opamp        ",      // 3
    "PGA2: gain 3 calibration           ",      // 4
    "PGA2: gain 10 calibration          ",      // 5
    "Calibration of the range 1         ",      // 6
    "Calibration of the range 2         ",      // 7
    "Calibration of the range 3         ",      // 8
    "Calibration of the range 4         ",      // 9
    "<Short-circuit> Trim, all freq.    ",      // 10
    "<Open-circuit> Trim, all freq.     ",      // 11
	
	// French	
    "R�glage offset generateur sinus    ",      // 1
	"Valeur mesur�e de Vref (DDS)       ",      // 2
    "CMRR de l'ampli diff. de mesure U  ",      // 3
    "PGA2: calibration en gain 3        ",      // 4
    "PGA2: calibration en gain 10       ",      // 5
    "Calibration de la gamme 1          ",      // 6
    "Calibration de la gamme 2          ",      // 7
    "Calibration de la gamme 3          ",      // 8
    "Calibration de la gamme 4          ",      // 9    
    "Trim <court-circuit> toutes freq.  ",      // 10;
    "Trim <circuit-ouvert> toutes freq. ",      // 11

    // next language
}

// ----------------------------------------------------------------------------------------------------

*/ 

#endif

