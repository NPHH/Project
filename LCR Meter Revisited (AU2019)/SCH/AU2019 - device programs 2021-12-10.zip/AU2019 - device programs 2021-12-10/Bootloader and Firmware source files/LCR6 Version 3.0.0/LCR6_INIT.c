//-----------------------------------------------------------------------------
// LCR6_INITc
//-----------------------------------------------------------------------------
// 
// Author: Jean-Jacques Aubry 2013-2020
//
// Target: C8051F120 
// Compiler: KEIL C51 V9.60.0.0  
//
// Version (see 'FirmwareVersion' in LCR6.h)
// 
// initialization of MCU


#include "LCR6_INIT.h"

extern bit 	wait_ms (unsigned int x);
extern void wait_us (unsigned int us);
extern bit  BT_onJ14;
extern bit  GLCD_onJ14;


//-----------------------------------------------------------------------------
// Init_MCU_Peripherals
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Some functions do not need to back up and restore the SFRPAGE.
// After initializations, in order to have direct access to the Ports P4 to P7,
// the SFRPAGE is set to CONFIG_PAGE.

//
void Init_MCU_Peripherals (void)
{

#ifdef NO_BOOTLOADER_MODE   // no Bootloader code in memory
    SYSCLK_Init();							// initialize oscillator
	PORT_Init();							// initialize crossbar and GPIO 
    UART1_Init();				            // initialize UART1
    UART0_Init();					        // initialize UART0
	Timer3_Init();
#endif  // NO_BOOTLOADER_MODE

	Timer4_Init();
	REF_Init();
    ADC0_Init();
	DAC_Init();								// Initialize and start DAC0 & DAC1
	Comparator1_Init();
	Comparator0_Init();	

    SFRPAGE = CONFIG_PAGE;  // *** WARNING *** don't forget these line!
}


#ifdef NO_BOOTLOADER_MODE   // ****************************************************************************
                            // Initalizations to be performed if no bootloader in memory

//-----------------------------------------------------------------------------
// SYSCLK_Init ()
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// This routine initializes the system clock to use the internal 24.5 MHz oscillator
// Also enables missing clock detector reset.
// If PLL used, set FLSCL et PLL0 registers according.
//
void SYSCLK_Init (void)
{

#ifdef USE_PLL
	unsigned char n;                    // n used for short delay counter
#endif

    SFRPAGE = CONFIG_PAGE;              // Set SFR page F
	OSCICN = 0x83;						// 1000 0011 -> Configure internal oscillator for
                           				// 					its highest frequency (24.5 MHz)
    SFRPAGE = LEGACY_PAGE;              // Set SFR page 0
    RSTSRC = 0x06;						// 0000 0110 -> Enable missing clock detector
                                        //           -> Enable VDDMON as reset source 
#ifdef USE_PLL
    FLSCL   = FLSCL_FLRT;               // Set FLASH read time according to SYSCLK (in page 0)

    SFRPAGE = CONFIG_PAGE;              // Set SFR page F
    PLL0CN |= 0x01;                     // Enable Power to PLL
    PLL0DIV = PLL_DIV;                  // Set PLL divider value using macro
    PLL0MUL = PLL_MUL;                  // Set PLL multiplier value using macro
    PLL0FLT = PLLFLT_ICO|PLLFLT_LOOP;   // Set the PLL filter loop and ICO bits
    for (n = 0xFF; n != 0; n--);        // Wait at least 5us
    PLL0CN  |= 0x02;                    // Enable the PLL
    while(!(PLL0CN & 0x10));            // Wait until PLL frequency is locked
    CLKSEL  = 0x02;                     // Select PLL as SYSCLK source
#else
    SFRPAGE = CONFIG_PAGE;
    CLKSEL = 0x00;                      // Select internal oscillator as SYSCLK source (default value after reset)
#endif
}



//-----------------------------------------------------------------------------
// PORT_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Configure the Crossbar and GPIO ports
//
void PORT_Init (void)
{
	uint count;

    SFRPAGE = CONFIG_PAGE;	// Switch to configuration page (0x0F)
							// also it's page of Port 4, 5, 6 & 7

    XBR0		= 0x04;		// 0000 0100 -> TX0 & RX0 routed to port pins (UART0EN = 1)
    XBR1        = 0x00;     // reset value
    XBR2		= 0x40;		// 0100 0000 -> Enable crossbar and weak pull-ups 

    // ---------- Port 0
    if (GLCD_onJ14)         // route INT0 & INT1 on J14 (pin 23 & pin 24)
    {
        XBR1		= 0x14;		// 0001 0100 -> INT0 & INT1 routed to port pin.
        P0MDOUT 	= 0xF1;		// 1111 0001 -> set P0.0(TX0) to push-pull, P0.1(RX0), P0.2(INT0/), P0.3(INT1/) to open-drain 
	    P0			= 0x8E;		// 1000 1110 -> set P0.1(RX0), P0.2(INT0/), P0.3(INT1/) to input (writing 1)
								//			 -> set P0.6(BLE_STATUS) to 0 
                                //           -> set P0.7(GLCD_STATUS) to 1  
    }
    else if (BT_onJ14)      // route TX1 & RX1 on J14 (pin 23 & pin 24)
    {
        
        XBR2		= 0x44;		// 0100 0100 -> TX1 & RX1  routed to port pins (UART1E = 1)
                                //              Enable crossbar and weak pull-ups 
        P0MDOUT 	= 0xF5;		// 1111 0101 -> set P0.0(TX0) and P0.2(TX1) to push-pull, P0.1(RX0), P0.3(RX1) to open-drain (writing 0) 
	    P0			= 0x4A;		// 0100 1010 -> set P0.1(RX0), P0.3(RX1) to input (writing 1)
								//			 -> set P0.6(BLE_STATUS) to 1 
                                //           -> set P0.7(GLCD_STATUS) to 0  
    }
    else    // no extention board, init UART0 for USB connection
    {
        P0MDOUT 	= 0xFD;		// 1111 1101 -> set P0.0(TX0) to push-pull, P0.1(RX0) to open-drain 
	    P0			= 0x02;		// 0000 0010 -> set P0.1(RX0) to input (writing 1)
								//			 -> set P0.6(BLE_STATUS) to 0 
                                //           -> set P0.7(GLCD_STATUS) to 0        
    }


	// ---------- Port 5
	P5MDOUT	    = 0x7F;			// 0111 1111 -> set P5.7(ADS_DRDY_BARRE) to open-drain (writing 0)
	P5			= 0xC6;			// 1100 0110 -> set P5.7(ADS_DRDY_BARRE) to input (writing 1)
                                //              set PGA2_G_3(P5^3) & PGA2_G_10(P5^4) to 0, disabling U21 & U22
	// ---------- Port 1
	P1MDOUT	    = 0xF0;			// 1111 0000 -> set P1.0 to P1.3(BOUTON_Lx) to open-drain (writing 0)
	P1			= 0x0F;			// 0000 1111 -> set P1.0 to P1.3(BOUTON_Lx) to input (writing 1)

	// ---------- Port 2
    P2MDOUT	    = 0xFF;		    // 1111 1111 -> P2 port as output (LCD-DBx)
	P2 		    = 0x00;			

	// ---------- Port 3
	P3MDOUT	    = 0xB2;		    // 1011 0010 -> set P3.0(SYNCH_OUT) P3.2(TEST_GLCD) P3.3(J16) P3.6(ENCOD_SW) to open-drain
	P3			= 0xCD;			// 1100 1101 -> set P3.0(SYNCH_OUT) P3.2(TEST_GLCD) P3.3(J16) P3.6(ENCOD_SW) to input (writing 1)
                                //              set P3.7(BACKLIGHT) to 1;

	// ---------- Port 4
	P4MDOUT	    = 0x80;		    // 1000 0000 -> set P4.0 to P4.6(RSELECT_SWx & INPUT_CP0) to open-drain
	P4			= 0x7F;			// 0111 1111 -> set P4.0 to P4.6(RSELECT_SWx & INPUT_CP0) to 1, P4.7(DC_BIAS_U_I) to 0
									
	// ---------- Port 6
	P6MDOUT	    = 0xFE;		    // 1111 1110 -> set P6.0(ADS_DOUT) to open-drain
	P6			= 0xE9;			// 1110 1001 -> set P6.0(ADS_DOUT) to input (writing 1)
								//				set P6.3(FSYNC_DDS1_), P6.5(SCLK_DDS), P6.6(FSYNC_DDS2_), P6.7(RESET_DDS_) to 1

	// ---------- Port 7
	P7MDOUT	    = 0x7F;		    // 0111 1111 -> set P7.7(PWRN) to open-drain
	P7			= 0xA8;			// 1010 1000 -> set P7.7(PWRN) to input, P7.5(ENABLE_BOOST) to 1, P7.4(MAX_BOOST) to 0, P7.3(J23) to 1

	for (count = 10000; count > 0; count--);	
}


//-----------------------------------------------------------------------------
// UART0_Init   Variable baud rate, Timer 2, 8-N-1
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Configure UART0 for operation at <BAUDRATE_0> in mode 1 (8-N-1) using Timer2 as
// baud rate source.
//
void UART0_Init (void)
{

   SFRPAGE = TMR2_PAGE;

   TMR2CN = 0x00;                      // Timer2 in 16-bit auto-reload up timer mode
                                       
   TMR2CF = 0x08;                      // 0000 1000 -> SYSCLK is time base; no output, up count only
                                       
   RCAP2 = - ((long) (SYSCLK/BAUDRATE_0/16));
   TMR2 = RCAP2;
   TR2= 1;                              // Timer2 enabled

   SFRPAGE = UART0_PAGE;               // 0x00 same as LEGACY_PAGE

   SCON0 = 0x50;                       // 0101 0000 ->  UART0 Mode 1: 8-bit variable baud rate, RX enabled
   SSTA0 = 0x15;                       // 0001 0101 ->  Clear all flags; disable baud rate doubler
                                       //               Use Timer2 overflow as RX and TX baud rate source

   //TI0     = 1;                        // Canceled in Vers. 2.1.0
   SFRPAGE = CONFIG_PAGE;

   ES0 = 1;					    // enable UART0 interrupt
   IP |= 0x10;					// 0001 0000 -> UART0 interrupts set to high priority: PS0 = 1 
}


//-----------------------------------------------------------------------------
// UART1_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : the baudrate
//
// Configure UART1 for operation at <UART1_baudrate> 8-N-1 using Timer1 as
// baud rate source.
//
void UART1_Init (void)
{
    ulong   UART1_baudrate;
    uint k;

    FLASH_Read((char *) &UART1_baudrate, UART1_BAUDRATE_ADD, LONG_SIZE, 0);
    k = SYSCLK/UART1_baudrate/2;

    SFRPAGE = UART1_PAGE;
    SCON1   = 0x10;                     // SCON1: mode 0, 8-bit UART, enable RX

    SFRPAGE = TIMER01_PAGE;
    TMOD   &= ~0xF0;
    TMOD   |=  0x20;                    // TMOD: timer 1, mode 2, 8-bit reload

    if (k/256 < 1) {
        TH1 = -(k);
        CKCON |= 0x10;                   // T1M = 1; SCA1:0 = xx
    } else if (k/256 < 4) {
        TH1 = -(k/4);
        CKCON &= ~0x13;                  // Clear all T1 related bits
        CKCON |=  0x01;                  // T1M = 0; SCA1:0 = 01
    } else if (k/256 < 12) {
        TH1 = -(k/12);
        CKCON &= ~0x13;                  // T1M = 0; SCA1:0 = 00
    } else {
        TH1 = -(k/48);
        CKCON &= ~0x13;                  // Clear all T1 related bits
        CKCON |=  0x02;                  // T1M = 0; SCA1:0 = 10
    }

    TL1 = TH1;                          // Initialize Timer1
    TR1 = 1;                            // Timer1 enabled

    //SFRPAGE = UART1_PAGE;
    //TI1 = 1;                            // Canceled in Vers. 2.1.0

    SFRPAGE = CONFIG_PAGE;
    EIE2 |=  0x40;					// 0100 0000 -> ES1 = 1 enable UART1 interrupt
    EIP2 |=  0x40;				    // 0100 0000 -> PS1 = 1 UART1 interrupts set to high priority: (EIP2^6)
}



//-----------------------------------------------------------------------------
// TIMER
//
//  Timer0 is not used                         
//  Timer1 is used by UART1
//  Timer2 is used by UART0
//  Timer3 is used by function wait_us()
//  Timer4 is used for detection of a long key_pressed (increment of <count_key_pressed> uchar variable).
// 
//-----------------------------------------------------------------------------


//-----------------------------------------------------------------------------
// Timer3_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Initializes Timer3 to be clocked by SYSCLK or SYSCLK/2 for use as a delay timer.
//
void Timer3_Init (void)
{
    SFRPAGE   = TMR3_PAGE;

#if (PLL_MUL>2)
    TMR3CF    = 0x18;		// 0001 1000		SYSCLK/2 & auto-reload mode
#else
    TMR3CF    = 0x08;		// 0000 1000		SYSCLK & auto-reload mode
#endif

    TMR3CN = 0x04;          // Enable Timer3 in auto-reload mode
	TR3 = 0;                // Stop Timer 3
    SFRPAGE = CONFIG_PAGE;
}


#endif // NO_BOOTLOADER_MODE  ************************************************************************





//-----------------------------------------------------------------------------
// Timer4_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// This function configures the Timer4 in 16-bit auto-reload up timer mode
// When timer4 overload, an interrupt occur. 
// The Timer4 ISR increase the variable <count_key_pressed>
//
void Timer4_Init(void)
{
    SFRPAGE = TMR4_PAGE;

	TMR4CF = 0x00;		    // SYSCLK / 12 is time base (with PLL_MUL = 3: 6.125MHz - overload each 10.7 ms)
    TMR4CN = 0x00;		    // 0000 0000 -> Timer in 16-bit auto-reload up timer mode.
	EIE2 |= 0x04;           // 0000 0100 -> ET4 = 1 enable Timer4 interrupt
    TR4 = 0;                // Stop Timer 4 (reset state TR4 = 0)	
    EIP2 |= 0x04;           // 0000 0100 -> PT4 = 1 interrupt high priority																				
}


//-----------------------------------------------------------------------------
// REF_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Configure REF0CN for external Reference
//
void REF_Init(void)
{
    SFRPAGE = REF0_PAGE;
	REF0CN = 0x02;						// 0000 0010 turn on only the bias generator.
}


//-----------------------------------------------------------------------------
// DAC_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Configure DAC0 & DAC1 for 0 volt output
//
// DACxCN = 1000 0000
// 	    b7 DACxEN = 1 -> enable DACx
//	    b6-5 unused
// 	    b4-3 = 00 	-> updates occur on write to DACxH
// 	    b2-0 = 000 	-> right-justified mode
//
void DAC_Init(void)
{
    SFRPAGE = DAC0_PAGE;
	DAC0L = 0x00;
	DAC0H = 0x00;
    DAC0CN = 0x80;						// 1000 0000
 
    SFRPAGE = DAC1_PAGE;
	DAC1L = 0x00;
	DAC1H = 0x00;
    DAC1CN = 0x80;						// 1000 0000
}


//-----------------------------------------------------------------------------
// ADC0_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Init ADC0 (12bits)
//
void ADC0_Init (void)
{
	SFRPAGE = ADC0_PAGE;
    ADC0CN = 0x00;   					    // 0000 0000
										    //  voltage ref on VREF0 pin                   
										    //  ADC0 disabled; normal tracking mode
										    //  ADC0 conversions start writing 1 on AD0BUSY
										    //  ADC0 data is right-justified.

    AMX0CF = 0x08;                          // 0000 1000                          
                                            //  AIN 6 & 7 inputs are configured as differential input pair (+ on 6)
                                            //  AIN 0 to 5 inputs are configured as single-ended inputs

    AMX0SL = 0x01;                          // Select AIN0.1 pin as input of ADC mux
    ADC0CF = (SYSCLK/2/SAR0_CLK - 1) << 3; 	// ADC0 conversion clock
	AD0EN = 1;                              // Enable ADC0
}


//-----------------------------------------------------------------------------
// Comparator0_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
//  This function initialize the Comparator0 interrupt
//	 	used to detect overload in input of the PSD  (CP0 output rising-edge)
//	
//  enable CP0 interrupts by calling Set_COMP0_Interrup()
//
void Comparator0_Init (void)
{
    SFRPAGE = CPT0_PAGE;   
  
    CPT0CN = 0x80;                      // 1000 0000 -> CP0 enabled, no hysteresis											   
	wait_ms(100);   					// Allow CP0 output to settles for 100 ms
	CP0RIF = 0;							// clear CP0 rising-edge Flag
	CPT0MD = 0x20;						// 0010 0000 -> 	CP0 rising-edge interrupt enabled
										// 					Fastest reponse time
	EIP1 |= 0x20;						// 0010 0000 ->	high priority
}


//-----------------------------------------------------------------------------
// Comparator1_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
//  This function initialize the Comparator1 interrupt
//      used to detect key-pressed action (CP1 output rising-edge)
//
void Comparator1_Init (void)
{
    SFRPAGE = CPT1_PAGE;   
  
    CPT1CN = 0x8F;                      // 1000 1111 ->	CP1 enabled, max hysteresis												   
	wait_ms(100);   					// Allow CP1 output to settle for 100 ms
	CP1RIF = 0;							// clear CP1 rising-edge Flag
	CPT1MD = 0x23;						// 0010 0011 ->	CP1 rising-edge interrupt enabled
										// 				Mode 3:	Lowest Power Consumption
	EIE1 |= 0x80;						// 1000 0000 ->	enable CP1 rising edge interrupts                             
}


//-----------------------------------------------------------------------------
// Ext_Interrupt_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// This function configures the INT0 and INT1 external interruptions
// as negative edge-triggered.
//
void Ext_Interrupt_Init (void)
{
    SFRPAGE = TIMER01_PAGE;

    TCON = 0x05;        // 0000 0101  INT0 and INT1 are edge triggered, falling edge
        		        //      IE0 = 0 -> clear INT0 pending flag
			            //      IE1 = 0 -> clear INT1 pending flag

    IE  |= 0x05;        // 0000 0101 enable INT0 and INT1 interrupts
    IP  |= 0x05;        // high priority
    
    SFRPAGE = CONFIG_PAGE;
}



