//----------------------------------------------------------------------------- 
// LCR6.c 
//----------------------------------------------------------------------------- 
// 
// Author: Jean-Jacques Aubry  2013-2021
//
// Target: C8051F120 
// Compiler: KEIL C51 V9.60.0.0 
//
// Version (see 'FirmwareVersion' in LCR6.h)
//
// Firmware for LCR-meter AU2019:
// 
// -----------------------------------------------------------------------------------------
// 1 - Can be called by <bootloader_LCR6> already in low memory (0x0000):
// 
//      starting address is 0x1C00
//      
//      - undefine NO_BOOTLOADER_MODE (LCR6_Defines.h file) for build process
//      - add the directive INTVECTOR(0x1C00) INTERVAL(3) in menu 'Project/Tool Chain Integration...' -> tab 'Compiler'
//        (update)-> in same tab, add OPTIMIZE (9,SIZE) at the end for reduction of code size
//      - add the directive CODE(0x1C00-0xFFFF) in menu 'Project/Tool Chain Integration...' -> tab 'linker'
//      - add the file STARTUP-LCR6.A51 to build
//      - in the file STARTUP-LCR6.A51 specify start application address -> CSEG    AT      1C00h
//
//      In Project/Target Build Configuration... select "Generate hex file"
//                      the LCR6.hex file is the file to be loaded by the bootloader.
//
//      Use of the on-board FT232RL (USB-to-UART converter) from FTDI for Firmware/Language update via USB connection (J1) 
//          and the program AU2019 running on a PC.
//
//
//
// 2 - Standalone code with no bootloader (for easy debugging):
//
//      starting address is 0x0000
//      
//      - define NO_BOOTLOADER_MODE (LCR6_Defines.h file) for build process
//      - remove the directive INTVECTOR(0x1C00) INTERVAL(3) in menu 'Project/Tool Chain Integration...' -> tab 'Compiler'
//       (update)-> in same tab, remove OPTIMIZE (9,SIZE)
//      - remove the directive CODE(0x1C00-0xFFFF) in menu 'Project/Tool Chain Integration...' -> tab 'linker'
//      - remove the file STARTUP-LCR6.A51 from build
//
//      Use the <USB DEBUG ADAPTER> from Silicon Labs, connected on J15 (JTAG) for loading the firmware:
//      - If using the <Flash Programming Utility> from Silicon Labs, in Project/Target Build Configuration... 
//          select "Generate hex file".
//      - if using the Silicon Labs IDE for compiling, linking and downloading the source code, 
//          in Project/Target Build Configuration...  don't select "Generate hex file". 
//
// -----------------------------------------------------------------------------------------


// ------------------------------------------------------------------------------------------
// the LCR-meter is (usually) powered by the USB connector. 
//
// to be used with the GLCD display extension board (standalone mode),
// or an external program: 
//      1 - connected by USB (PC) - no extension board or GLCD display extension board in J14
//      2 - connected by Bluetooth Low Energy (BLE) - extension board on J14 (with a HM-10 BLE module)
// ------------------------------------------------------------------------------------------

// Note: Because this program writes to FLASH, the MONEN pin is tied high.

#include 	"LCR6.h"
#include	"LCR6_GLCD.h"
#include	"LCR6_ADS.h"
#include	"LCR6_DDS.h"
#include    "LCR6_Texts.h"

extern void Init_MCU_Peripherals (void);
extern void Ext_Interrupt_Init (void);


//----------------------------------------------------------------------------- 
// MAIN 
//
// After initializations, in order to have direct access to the Ports P4 to P7,
// the SFRPAGE is set to CONFIG_PAGE.
// Thus each function will have to (back up and) restore this SFRPAGE.
//
//-----------------------------------------------------------------------------
void main (void)
{
  	uchar i;
#ifdef NO_BOOTLOADER_MODE
    char input;
#endif
    bit ok = false;

	WDTCN = 0xde; 								// disable watchdog timer
	WDTCN = 0xad;
		
	//EA = 0;				        // disable interrupts. It's startup value
	//EA = 0;						// this is a dummy instruction with two-byte opcode.

#ifdef NO_BOOTLOADER_MODE       // if no Bootloader code in memory

    // at Start-Up, Port pins are inputs and Weak Pullups are enabled
    // so, if one extension is connected, there's a 0 on the corresponding pin 
     
    GLCD_onJ14 = (!TEST_GLCD);                     // if (TEST_GLCD == 0) -> GLCD extension card is connected

    if (GLCD_onJ14)                                // only one extention card connected on J14
        BT_onJ14 = false;
    else
        BT_onJ14 = (!TEST_BT);                     // if (TEST_BT == 0) -> BLE extension card is connected 
        
    for (input = 0; input < UART_IN_BUFFERSIZE; input++)    // Cleans the UART buffer (not necessary but help with debugging!)
		UART_InputBuffer[input] = 0;
    UART_InputBuffer[0] = '\0';                     // the Buffer is empty
      
#else
    BT_onJ14 = (BLE_STATUS == 1);                  // BLE extension card is connected. BLE_STATUS is set by the Bootloader
    GLCD_onJ14 = (GLCD_STATUS == 1);               // GLCD extension card is connected. GLCD_STATUS is set by the Bootloader
#endif

	Init_MCU_Peripherals();     // on return, SFRPAGE is set to  CONFIG_PAGE (0x0F)                            
	                            // **** from this point, each function must (backup and) restore this page.
    if (GLCD_onJ14)
    {
        // Display kind (Normal or Reverse)
        DisplayNormal = FLASH_ByteRead(DISPLAY_KIND_ADD, 0);
	    if ( DisplayNormal > 1 )				    // no or bad initialization
	    {   
            DisplayNormal = 0;   // Normal display       
            FLASH_Update(DISPLAY_KIND_ADD, (char *) &DisplayNormal, CHAR_SIZE, 0);
        }

        GLCD_Init();
        GLCD_WriteCommand(GLCD_DISPLAY_NORMAL, DisplayNormal);
        display_GLCD = true;    // show the start-up screen!       
    }
    
#ifdef NO_BOOTLOADER_MODE       // if no Bootloader code in memory
    i = FLASH_ByteRead(DISPLAY_MODE_ADD, 0);

    if ( i == 0xFF )            // first time with new firmware
    {
        i = (uchar)GLCD_onJ14;  // if true -> set for standalone mode            
        FLASH_Write(DISPLAY_MODE_ADD, (char *) &i, CHAR_SIZE, 0);
    } 
	else if (L1 == 0)    // KEY_1 pressed at start-up, so change the kind of GUI
    {
        if (i == 0)
            i = 1;      // standalone mode
        else if (i >= 1)
            i = 0;        
        FLASH_Update(DISPLAY_MODE_ADD, (char *) &i, CHAR_SIZE, 0);
    }
    wait_ms(1000);   // setup-time for PWRN
#else
    i = FLASH_ByteRead(DISPLAY_MODE_ADD, 0);
#endif


    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -    
    // use_USB is true if connected to PC and no GLCD, or if connected to PC and GLCD and i (Display_mode) = 0;
    // To use Bluetooth extension, the LCR-meter must be powered by external power-supply, not connected to a PC
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

    use_USB = ( (PWRN == 0 && !GLCD_onJ14) || (PWRN == 0 && GLCD_onJ14 && i == 0 ) );
    use_Bluetooth = (!use_USB && BT_onJ14);
    standalone = GLCD_onJ14  && !use_USB;

// ******** FOR TEST of BLE when device powered by the PC and no BootLoader in memory, put a jumper on J16
#ifdef NO_BOOTLOADER_MODE 
    if (J16 == 0)           // BLE mode
    {
        use_USB = false;
        use_Bluetooth = true;
    }
#endif
// ******** 

    if (standalone)
    {
        Stop_UART0();
        Stop_UART1();
        Ext_Interrupt_Init();       // init the External Interrupts used by the encoder
    }
    else
    {
        if (use_Bluetooth)
            Stop_UART0();
        else if (use_USB)
            Stop_UART1();
    }

	ADS_Init();
	DDS_Init();
    J23 = 0;    // flash LED D12 when enter in this program
    wait_ms(100);
    J23 = 1;
    
    numberSeries = sizeof(Series_Array) / POINTER_SIZE;
    numberLevel = sizeof(Level_Array) / POINTER_SIZE;

    ok = Check_Saved_Datas();       // put in text_Menu[] initialised datas: Series, Q_limit...

    if (!ok && standalone)                                  // no language in BANK2
    {
        GLCD_draw_text(0,21, TextI_2, GLCD_PIXEL_ON);       // "No Language loaded. Restart in PC Mode."
        GLCD_draw_text(0,35, TextI_3, GLCD_PIXEL_ON);       // "Use the AU2019 prog. to load them"
        
        while (1);                                          // infinite loop       
    };

	// *** WARNING *** don't forget to enable all interrupts!
    EA = 1;		// Enable each interrupt according to its individual mask setting.

    if (standalone)
    { 
        
        GLCD_show_icon( (void *)rlc, 32, 32, 6, 6, GLCD_PIXEL_OFF );		// black background
        strcpy(chaine, TextI_0);                                            // "LCR-Meter AU2019"
        GLCD_draw_text(80,21, chaine, GLCD_PIXEL_ON);
        strcpy(chaine, "Version ");
        strcat(chaine, FirmwareVersion);                                    // "Version x.y.z"
        GLCD_draw_text(88,35, chaine, GLCD_PIXEL_ON);
        strcpy(chaine, TextI_1);                                            // "AU2021   J.J.Aubry"
        GLCD_draw_text(80,49, chaine, GLCD_PIXEL_ON);
        ReadTextinFlash(1);                                                 // "INITIALISATION, WAIT..."
        GLCD_draw_text(WITHOUT_ICON, 84, textLine, GLCD_PIXEL_ON);
    }
    else
    {
        if (GLCD_onJ14) 
            GLCD_draw_text(90,64,"< PC mode >", GLCD_PIXEL_ON);
        BACKLIGHT = 0;
        UART_InputBuffer_Size = 0;
        UART_OutputBuffer_Size = 0;
        UART_Output_First = 0;
        TX_Ready = 1;
	    RX_Ready = 0;
        strcpy(chaine, message_FIRMVERSION);        // "FVER "
        strcat(chaine, FirmwareVersion);            // "FVER x.y.z"
        Send_Message(chaine);                       // send the Firmware Version

#ifdef NO_BOOTLOADER_MODE	// no Bootloader, synchronization with external GUI
        do
        {
            if (RX_Ready == 1)					    // data received
		    {
			    RX_Ready = 0;
                sourceLevel = Checks_Message(FIRM_VERSION); // any uchar like <sourceLevel> can be used!
            }
            Send_Message(chaine);
        }
        while (sourceLevel != FIRM_VERSION);        // Awaiting to receive the message "F_VERS"
#else
        wait_ms(200);    // 10
        Send_Message(chaine);                       // send again the Firmware Version
#endif
    } // if (standalone)


    //ENABLE_BOOST = true;                          // start the Up-Converter U3 -> done in PORT_Init()

    // check if all power supplies are ok
	i = Checks_Power_Supplies();
    if (i != 0)
    {
        if (standalone)
        {
            GLCD_clear();
            ReadTextinFlash(0);                     //  "PS Test Error, code %u"
            sprintf(chaine, textLine, (uint)i );                    
            GLCD_draw_text(WITHOUT_ICON, 74, chaine, GLCD_PIXEL_ON);
        }
		else
		{
			sprintf(chaine, "ERPS %u", (uint)i );
			Send_Message(chaine);
		}
        while (1)   //infinite loop -> flashes the LED D12
        {
            J23 = 0;
            wait_ms(500);
            J23 = 1;
            wait_ms(1000);
        }
    }

    if (!standalone)
    {
        Send_Message(textMenu);                     // send initializations (Q_limit, Series... ) 
                                                    // i.e. "PAR 1000 E24 2 1180"
        wait_ms(300);
        sprintf(textMenu, "%1.1f", Bootloader_Ver);
        strcpy(chaine, message_BOOTVERSION);        // send bootloader vrsion    
        strcat(chaine, textMenu);
        Send_Message(chaine);

        if (use_USB && BT_onJ14)
        {
            wait_ms(300);
            Send_Message(message_BLE_ONJ14);
        }
    }

    Copy_TrimValues_from_CodeData();
    Display_Non_Initialized_Data_Message();
	DAC1_Update(0);
    DAC_coeff = (DDS1_Vref / MCU_VREF) * 9032; 	// 9032 = 4096 * (1 + 4700/3900) -> see function Set_DDS_Amplitude()
	ADS_SetPGA_Range(0);
    ADS_SetSPS(ADS_SPS_20);
    ADS_SelfOffset_Calibration();

#ifndef DEBUG_3
    cpt_encod = 1;
    old_cpt_encod = 0;
#else
    cpt_encod = 0;
    old_cpt_encod = 1;
#endif

	Buffer_Init();

    if (standalone && saved_index_freq > 0)
        saved_index_freq --;      // first loop while(1) increase saved_index_freq, because cpt_encod != old_cpt_encod

	Set_Frequency(saved_index_freq);
    Set_Source_Level(LEVEL_1V_RMS);
	R_Range = 0;                        // for first call of Set_Resistor_Sense_Range()
	Set_Resistor_Sense_Range(R_RANGE_1);
	Set_Measure_Mode(VOLTAGE_MODE);
	Set_PGA2_Gain(RANGE_GAIN_1, false);
	PGA2_Gain_I = G1_PGA2;
	PGA2_Gain_U = G1_PGA2;
	PGA2_Range_I = 1;
	PGA2_Range_U = 1;
    DC_mVolt = 0;           // uint
	Set_DC_BIAS(DC_mVolt);  // --> DAC0_Update(0);
    biasCurrent_Offset = Checks_Bias_Current();
    
    // ***** Switch point between internal or external Command/Display *****

    if (standalone)
        OnBoardDisplay();
    else
        ExternalDisplay();        
} // main




//-----------------------------------------------------------------------------
// Action_KEY_1
//-----------------------------------------------------------------------------
//
// --> AUTO or PARALLEL or SERIES
//
void Action_KEY_1(void)
{
#ifdef DEBUG_5
    if (longKeypressed)     // for Debug only    
        Erase_Trim_Data();
    else
#endif
    {
        if (Auto_Model == 0)		// Auto mode
        {
            if (S_P_Mode == 1)		// series 
                Auto_Model = 2;
            else if (S_P_Mode == 2)	// parallel
                Auto_Model = 1;
        }
        else
            Auto_Model = 0;
 
        Display_Mode();
        Process_Datas();
    }
} // Action_KEY_1


//-----------------------------------------------------------------------------
// Action_KEY_2
//-----------------------------------------------------------------------------
//
// --> TRIM or DCBIAS_0
//
void Action_KEY_2(void)
{
    bit   ok = true;

    if (DC_mVolt != 0)  // BIAS must be 0 for Trim
    {
        DC_mVolt = 0;
        Set_DC_BIAS(DC_mVolt);
        Display_DC_Bias(102, Y_POS_LINE_8, true);
    }
    else
    {
        if (longKeypressed)
        {   
            if (trimShortModified || trimOpenModified)
            {
                Affiche_Text(WITHOUT_ICON, Y_POS_LINE_3, 8, GLCD_PIXEL_ON);     // "Saving the Trim data..."
                Copy_TrimValues_to_CodeData();
            }
            else
            {
                Affiche_Text(WITHOUT_ICON, Y_POS_LINE_3, 9, GLCD_PIXEL_ON);     // "No Trim data to save   " 
            }
            wait_ms(1000);
        }
        else
        {
            Z_test_for_Trim();
			if (Z < 10.0)
			{
                Affiche_Text(WITHOUT_ICON, Y_POS_LINE_3, 26, GLCD_PIXEL_ON);    // "Short circuit trim. Wait..."
				Set_Trim(SHORT_TRIM);
			}
		    else if (Z > 20000)
			{
                Affiche_Text(WITHOUT_ICON, Y_POS_LINE_3, 27, GLCD_PIXEL_ON);    // "Open circuit trim. Wait..."
				Set_Trim(OPEN_TRIM);
			}
		    else
		    {
                Affiche_Text(WITHOUT_ICON, Y_POS_LINE_3, 29, GLCD_PIXEL_ON);    // " -> Open or Short circuit";
                ok = false;
			}
            wait_ms(1000);

			if (ok)
			{              
                Affiche_Text(WITHOUT_ICON, Y_POS_LINE_6, 32, GLCD_PIXEL_ON);    // "PASS"
			}   
			else
			{
                Affiche_Text(WITHOUT_ICON, Y_POS_LINE_6, 31, GLCD_PIXEL_ON);    // "FAIL"
		    }
            wait_ms(1000);
        }       
    }
} // Action_KEY_2


//-----------------------------------------------------------------------------
// Action_KEY_3
//-----------------------------------------------------------------------------
//
// --> AVERAGE
//
void Action_KEY_3(void)
{
    fast_mode = ~fast_mode;
    Buffer_Init();
    Write_Measure_Icons();

}


#ifdef DEBUG_5
//-----------------------------------------------------------------------------
// Erase_Trim_Data
//-----------------------------------------------------------------------------
//
void Erase_Trim_Data(void)
{
    FLASH_PageErase (TRIM_SHORT_OK_ADD, 0);
    FLASH_PageErase (TRIM_OPEN_OK_ADD, 0);
    Copy_TrimValues_from_CodeData();
    TrimOpenOk = false;
    TrimShortOk = false;               
}
#endif


//-----------------------------------------------------------------------------
// OnBoardDisplay
//-----------------------------------------------------------------------------
//
void OnBoardDisplay (void)
{
    char   akey;
    uchar  c_value;

    display_GLCD = false;
    Restore_Display();
        
	while (1)
	{
        // select action according key pressed on measure window
        akey = GetUserAction();
        switch (akey)
		{
			case KEY_1:                         // AUTO or PARALLEL or SERIES
                Action_KEY_1();
       			break;

			case KEY_2:                         // TRIM:    short pressed -> trim for selected freq. 
                                                //          long pressed -> save trim values for selected freq.
                                                // BIAS 0   set DC bias to 0
                if (standalone)
                     GLCD_clear();
                Action_KEY_2();
                if (standalone)
                    Restore_Display();
				break;

            case KEY_3:                         // AVERAGE
                if (longKeypressed)
                {
#ifdef DEBUG_2
                    noPGA_Gain = ~noPGA_Gain;   // only for Test!
                    
#endif
                }
                else
                    Action_KEY_3();
 			    break;

			case KEY_4:                         // HOLD action
                if (longKeypressed)
                {
                    display_Range = ~display_Range;
                }
                else
                {
                    rangeHold = ~rangeHold;
                    Display_Range_Hold();
                }
 				break;

            case KEY_5:                         // MENU or CONFIG
                if (!Menu_Mode)
				{
                    if (longKeypressed)
                    {
                        if (!userDefinedFrequency)
                        {
                            if (Menu_Kind != KIND_CONFIG)
                            {
                                First_Displayed_Menu = 1;
                                Menu_Index = 1;
                            }
                            Menu_Kind = KIND_CONFIG;
                            Menu_Mode = true;
                        }
                    }
                    else
                    {
                        if (Menu_Kind != KIND_MENU)
                        {
                            First_Displayed_Menu = 1;
                            Menu_Index = 1;
                        }
                        Menu_Kind = KIND_MENU;
                        Menu_Mode = true;
                    }
				}
			    break;

            case KEY_SW:			// the encoder switch pressed
                if (longKeypressed)
                {
                    userDefinedFrequency = ~userDefinedFrequency;
                    SelectFrequency(userDefinedFrequency);
                }
                else    // version 2.0.5 -> save index of current frequency
                {
                    c_value = Get_FreqIndex(freq);
                    FLASH_Update (SAVED_I_FREQ_ADD, (char *) &c_value, CHAR_SIZE, 0);
                }
                break;

            case MOVE_MARK_UP:
                if (!userDefinedFrequency)
                {
                    if (Freq_index < (FREQ_MEM_SIZE - 1))
                    {
		                Freq_index ++;
                        Set_Frequency(Freq_index);
                        Display_Frequency(X_POS_UNITS, Y_POS_LINE_3);
                    }
                }
                break;

            case MOVE_MARK_DOWN:
                if (!userDefinedFrequency)
                {
                    if (Freq_index >= MIN_FREQ_INDEX_START + 1 )
                    {
		                Freq_index --;
                        Set_Frequency(Freq_index);
                        Display_Frequency(X_POS_UNITS, Y_POS_LINE_3);
                    }
                }
                 break;
		} // switch

        akey = NO_KEY_PRESSED;
        Display_DC_Bias(102, Y_POS_LINE_8, true);

		if (!Menu_Mode)
		{
            Process_Measurement(RANGE_GAIN_1);
            Process_Datas();
		}
        else
            Menu_Choise();  // Selection according to Menu_Kind

        if (!display_GLCD)  // Display measured values only after the end of the first loop
        {
            display_GLCD = true;
            GLCD_Update_Display();
        }
	}; // while (1)

} // OnBoardDisplay



//-----------------------------------------------------------------------------
// ExternalDisplay
//-----------------------------------------------------------------------------
//
void ExternalDisplay(void)
{
    bit ok = false;
    bit running = true;
    bit display = true;
    char i, j;
    uchar k;
    uchar m = 0;
    int i_value;
    char nbLine[3];

    Display_Frequency(X_POS_UNITS, Y_POS_LINE_3);
    Display_Level(4, Y_POS_LINE_8);
    Display_DC_Bias(102, Y_POS_LINE_8, true);
    Display_Range_Hold();

    while (1)
    {
        i = GetUserAction();

        // refresh display from time to time
        m++;
        if (m > 9)
        {
            m = 0;
            display = true;
        }

		if (i >= 0)						            // match found
		{
			switch (i)
			{                   
			    case HALT:          // i = 17                       
					running = false;
					break;

				case RUN:           // i = 16						
					running = true;
					break;

                case MODE_D:        // i = 18
                    Action_KEY_1();
                    break;

                case TRIM_L:        // i = 20
                    longKeypressed = true;
                    Action_KEY_2();
                    break;

                case TRIM_S:        // i = 19
                    longKeypressed = false;
                    Action_KEY_2();
                    break;

                case R_HOLD:        // i = 21         
                    rangeHold = ~rangeHold;
                    Display_Range_Hold();
                    break;

                case AC_LEVEL:      // i = 14
                    k = (uchar) atoi(remainder_str);
                    Set_Source_Level(k);
                    Display_Level(4, Y_POS_LINE_8);
                    break;

                case DC_BIAS:       // i = 15
                    if (primaryKind != C_KIND && primaryKind != L_KIND)
                    {
                       DC_mVolt = 0;
                       DC_Bias_is_voltage = true;
                    }
                    else
                    {
                        DC_Bias_is_voltage = (primaryKind == C_KIND);
                        if (DC_mVolt == 0)
                            biasCurrent_Offset = Checks_Bias_Current();
                        DC_mVolt = (uint)atoi(remainder_str);
                        if (!DC_Bias_is_voltage)
                            DC_mVolt *= 100;
                    }
                    Set_DC_BIAS(DC_mVolt);
                    break;

                case USER_FREQ:     // i = 22:
                    freq = atof(remainder_str);
                    if (freq > (Tab_freq[FREQ_MEM_SIZE - 1] - 1.0))
                        freq = Tab_freq[FREQ_MEM_SIZE - 1];
                    if (freq < Tab_freq[0])
                        freq = Tab_freq[0];
                    // **** correction bug -> 3.0.0
                    Freq_index = Get_FreqIndex(freq);
                    Set_Frequency(Freq_index);
                    // ****

                    Display_Frequency(0,0);
                    break;

                case NEW_DDSVREF:   // i = 28
                    Value_to_Print = atof(remainder_str);   // value in mV
                    Value_to_Print /= 1000;                 // value in V
                    Update_DDS_VRef();
                    break;
                
                case FIRMW_UPDATE:	// i = 29 : reset the device, so jump on Bootloader code (reset vector at 0x0000)
                    GLCD_draw_text(10, 50, "Firmware Update", GLCD_PIXEL_ON);
                    wait_ms(2000);
                    SFRPAGE = 0;
					RSTSRC = 0x10;  // 0001 0000    -> SWRSEF = 1   force an internal reset
					break;

                case START_B:	    // i = 30 : simulation of Bootloader answer
					Send_Message(message_GO_APP);
					break;

                case BAUD_RATE:	    // i = 31 : set the Baudrate (for futur use!)
                    k = (uchar) atoi(remainder_str);
                    if (k == 2)
                        UART1_baudrate = 115200;
                    else
                        UART1_baudrate = 9600;
                    FLASH_Write(UART1_BAUDRATE_ADD, (char *) &UART1_baudrate, LONG_SIZE, 0);
                    break;

                case TXT_UPDATE:	// i = 32  
                    erase_flash(EEPROM_USER_DATA_ADD, END_STRING_ADD); 
					Send_Message(message_READY_RECEIVE_TXT);
                    ok_Texts = true;    
					break;

                case STR_TEXT_ARRAY:                        // i = 33

                case STR_CONFIG_ARRAY:                      // i = 34

                case STR_MENU_ARRAY:                        // i = 35

                case STR_LANG_ARRAY:                        // i = 36
                    CopyStringInBANK2(i);
                    break;

                case NBR_LANG:          // 1 = 37
                    k = (uchar) atoi(remainder_str);
                    FLASH_ByteWrite (NUMBER_LANGUAGE_ADD, k, 0);    // Flash already erased when receiving TXT_UPDATE
                    numberLanguage = k;
                    break;
                
                case END_TEXT_FILE:    // 1 = 38
                    if (!ok_Texts)
                    {
                        Send_Message(message_ERROR_TXT);
                        BACKLIGHT = 1;
                        break;
                    }
                    ok_Texts = false;
                    nbLine[2] = '\0';                   // nbLine = ""  
                                     
                    // i.e. remainder_str = "42 06 11"
                    j = 0;                              // j = 0
                    nbLine[0] = remainder_str[j];       // nbLine = "4"
                    j++;                                // j = 1                  
                    nbLine[1] = remainder_str[j];       // nbLine = "42"
                    i = atoi(nbLine);                   // i = 42
                    FLASH_ByteWrite (NUMBER_TEXT_LINES_ADD, i, 0);    // Flash already erased when receiving TXT_UPDATE

                    j+=2;                               // j = 3
                    nbLine[0] = remainder_str[j];       // nbLine = "02"
                    j++;                                // j = 4                  
                    nbLine[1] = remainder_str[j];       // nbLine = "06"
                    i = atoi(nbLine);                   // i = 6
                    FLASH_ByteWrite (NUMBER_MENU_LINES_ADD, i, 0);    // Flash already erased when receiving TXT_UPDATE

                    j+=2;                               // j = 6
                    nbLine[0] = remainder_str[j];       // nbLine = "16"
                    j++;                                // j = 7                  
                    nbLine[1] = remainder_str[j];       // nbLine = "11"
                    i = atoi(nbLine);                   // i = 11
                    FLASH_ByteWrite (NUMBER_CONFIG_LINES_ADD, i, 0);    // Flash already erased when receiving TXT_UPDATE
                    break;

                case AVG_SLOW:	                            // i = 39  					
                    fast_mode = false;
                    Send_Message(message_AVGS);    
					break;

                case AVG_FAST:	                            // i = 40  					
                    fast_mode = true;
                    Send_Message(message_AVGF);    
					break;

                case AFF_GAME:	        // i = 41
                    k = (uchar) atoi(remainder_str);
                    if (k == 0)
                        display_Range= false;
                    else
                        display_Range= true;
					break;

                // ------------------
                // Menu Configuration

                case SINUS_GEN_OFS:                         // i = 0
                    Menu_Set_Sinus_Offset();
                    break;

                //case SET_DDS_VREF:                        // i = 1   see NEW_DDSVREF               
                    //break;
              
                case CMRR_INPUT_AMP:                        // i = 2
                    Menu_Set_Voltage_Diff_Amp_CMRR();
                    break;

                case G3_CALIBRATION:
                    no_display_secondary = false;
                    Menu_PGA2_Calibration(RANGE_GAIN_3);    // i = 3
                    break;

                case G10_CALIBRATION:
                    no_display_secondary = false;
                    Menu_PGA2_Calibration(RANGE_GAIN_10);   // i = 4
                    break;

                case CALIB_RANGE1:
                    Menu_Set_CalibrationFactor(R_RANGE_1);  // i = 5
                    break;

                case CALIB_RANGE2:
                    Menu_Set_CalibrationFactor(R_RANGE_2);  // i = 6
                    break;

                case CALIB_RANGE3:
                    Menu_Set_CalibrationFactor(R_RANGE_3);  // i = 7
                    break;

                case CALIB_RANGE4:
                    Menu_Set_CalibrationFactor(R_RANGE_4);  // i = 8
                    break;

                case TRIM_SHORT_ALL:
                    Menu_Set_Trim(SHORT_TRIM);              // i = 9
                    break;

                case TRIM_OPEN_ALL:
                    Menu_Set_Trim(OPEN_TRIM);               // i = 10
                    break;
                

                // ------------------
                // Menu

                case Q_LIMIT:                               // i = 11
                    i_value = (uint) atoi(remainder_str);
                    FLASH_Update(Q_LIMIT_ADD, (char *) &i_value, INT_SIZE, 0);
                    Q_No_Display_Secondary = i_value;
                    break;

                case SORT_PARAM:                            // i = 12
                    k = (uchar) atoi(remainder_str);
                    saved_Series = k;
                    Menu_Set_Sorting_Parameters();
                    break;

                case SORT:                                  // i = 13
                    Menu_Sort();
                    break;

            } // switch (i)

            display = true;
 
        } // if (i)  
             

		if (running)
		{			
			Process_Measurement(RANGE_GAIN_1);
		    Process_Datas();
            
            if (display)
            {
                Display_Frequency(X_POS_UNITS, Y_POS_LINE_3);
                Display_DC_Bias(102, Y_POS_LINE_8, true);
                Display_Level(4, Y_POS_LINE_8);
                Display_Range_Hold();
                display = false;
            }
        }

    }; // while (1)

} // ExternalDisplay


//----------------------------------------------------------------------------- 
// CopyStringInBANK2
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : kind of array
//
void CopyStringInBANK2(char index)
{
    FLADDR Flash_ADD ;
    uchar len, i, j, longstr;
    char  xdata str[40];
    uchar a;
    int offset;


    switch (index)
    {
        case STR_TEXT_ARRAY:
            Flash_ADD = TEXT_ARRAY_ADD;
            longstr = LONG_TEXT;
        break;

        case STR_CONFIG_ARRAY:
            Flash_ADD = CONFIG_ARRAY_ADD;
            longstr = LONG_TEXT;
        break;

        case STR_MENU_ARRAY:
            Flash_ADD = MENU_ARRAY_ADD;
            longstr = LONG_TEXT;
        break;

        case STR_LANG_ARRAY:
            Flash_ADD = LANG_ARRAY_ADD;
            longstr = LONG_TEXT_LANG;
        break;
    }

    // parse the remainder_str
    len = strlen(remainder_str);
    for (i = 0; i < 4; i++)         // the first three characters of the line number.
        str[i] = remainder_str[i];
    str[i - 1] = '\0';
    offset = atoi(str);
    for ( j = i, i = 0; j < len; i++, j++)
    {
        a = remainder_str[j];
        if (a == 0xc3)              // first byte of accented char
        {
            j++;
            a = remainder_str[j];   // read second byte
            a += 0x40;
        }
        str[i] = a;
    }
   
    str[i] = '\0';                  // change '\n' to '\0'
    len = strlen(str);
    len++;                          // include the end of line character
            
    if (len != longstr)
    {
        ok_Texts = false;
        return;
    }

    if (ok_Texts)
    {
        Flash_ADD += (offset * longstr);
        FLASH_Write (Flash_ADD , str, len, 0);  // write the string  
    }
}


//----------------------------------------------------------------------------- 
// GetUserAction
//-----------------------------------------------------------------------------
//
// Return Value : required action (char). if none, return -1
// Parameters   : None
// 
// return the key pressed code or encoder movement or index in token[]
//
char GetUserAction(void)
{
    char akey = NO_KEY_PRESSED;

    if (standalone)
    {
        if (theKey != NO_KEY_PRESSED)
        { 
            akey = theKey;
            theKey = NO_KEY_PRESSED;
        }
        else if (cpt_encod != old_cpt_encod)
        {
            if (cpt_encod > old_cpt_encod)
#ifndef DEBUG_3
                akey = MOVE_MARK_UP;
            else
                akey = MOVE_MARK_DOWN;
#else
                akey = MOVE_MARK_DOWN;
            else
                akey = MOVE_MARK_UP;
#endif
            old_cpt_encod = cpt_encod;
        }
    }
    else
    {
		if (RX_Ready == 1)					// data received
		{
			RX_Ready = 0;

			akey = Checks_Message(FOR_MATCH);

            if (akey == KEY5)       // i = 24
                return KEY_5;

            if (akey == KEY4)       // i = 25
                return KEY_4;

            if (akey == MOVE_UP)    // i = 26
                return MOVE_MARK_UP;

            if (akey == MOVE_DOWN)  // i = 27
                return MOVE_MARK_DOWN;
        }
    }
    return akey;
}   // GetUserAction


//-----------------------------------------------------------------------------
// Affiche_Text
//-----------------------------------------------------------------------------
//
// Return Value : same as GLCD_draw_text()
// Parameters   : x, y, index in TextArray, mode -> same as GLCD_draw_text()
//
uchar Affiche_Text(char XX, uchar YY, uchar index , uchar mode )
{
    uchar k;

    if(standalone)
    {
        ReadTextinFlash(index);
        k = GLCD_draw_text(XX, YY, textLine, mode);
        return k;
    }
    else
    {
        sprintf(chaine, "J %u", (uint)index);   // "J 16" for "RUN" message 
        Send_Message(chaine);
        return 0;
    }       
}


//-----------------------------------------------------------------------------
// Checks_Message
//-----------------------------------------------------------------------------
//
// Return Value : The index into the token array if a match with the received message is found,
//						-1 if none
// Parameters   : if index  >= 0, check for a match with token[index] 
//						if index = FOR_MATCH (-1), try to find a match in the token array 
// 
// check if token[index] is at the beginning of UART_InputBuffer
// if exist, put the rest of UART_InputBuffer in 'remainder_str'
//
char Checks_Message(char index)
{
	char i, j, k, len, lenbuf;
	char str[10];
    char xdata theText[UART_IN_BUFFERSIZE];
	bit ok;

	if( (UART_InputBuffer_Size > 0) && (UART_InputBuffer_Size <= UART_IN_BUFFERSIZE) )
	{
		lenbuf = UART_InputBuffer_Size;
        for (i = 0; i < lenbuf; i++)
            theText[i] = UART_InputBuffer[i];
		UART_InputBuffer_Size = 0;
        UART_InputBuffer[0] = '\0';
		remainder_str[0] = '\0';
		if (index == FOR_MATCH)
		{
			for (i = 0; i < TOKEN_SIZE; i++)
			{
				strcpy(str, token[i]);
				len = strlen(str);
                len--;                      // not the '\n'
				for (j = 0; j < len; j++)
				{
					ok = (theText[j] == str[j]);
					if (!ok)
						break;
				}
				if (ok)
				{
					if (lenbuf > j)
					{
						j++; // jump 'space'
						for (k = 0; k < lenbuf - j; k++)
							remainder_str[k] = theText[j + k];
 						remainder_str[k-1] = '\0';
					}
					return i;
				}
			}
		}

#ifdef NO_BOOTLOADER_MODE	// no Bootloader

		else    // index >= 0 ( as for FIRM_VERSION) 
        {
            strcpy(str, token[index]);
            len = strlen(str);
			for (j = 0; j < len; j++)
			{
				ok = (theText[j] == str[j]);
 				if (!ok)
					break;
			}
            if (ok)
                return index;
        }
#endif

	}
	return -1;
} // Checks_Message



//-----------------------------------------------------------------------------
// Stop_UART0
//-----------------------------------------------------------------------------
//
void Stop_UART0 (void)
{
        // Timer2 used
        SFRPAGE = TMR2_PAGE;
        TR2	= 0; 
        SFRPAGE = CONFIG_PAGE;

        ES0 = 0;					// disable UART0 interrupt
	    IP &= 0xEF;					// 1110 1111 -> UART0 interrupts set to low priority: PS0 = 0 (IP^4)
}


//-----------------------------------------------------------------------------
// Stop_UART1
//-----------------------------------------------------------------------------
//
void Stop_UART1 (void)
{
        // Timer1 used
        SFRPAGE = TIMER01_PAGE;
        TR1	= 0; 
        SFRPAGE = CONFIG_PAGE;
        
        EIE2 &= 0xBF;				// 1011 1111 -> disable UART1 interrupt EIE2^6
	    EIP2 &= 0xBF;				// 1011 1111 -> UART1 interrupt is low priority level EIP2^6
}



//-----------------------------------------------------------------------------
// UART0_ISR
//-----------------------------------------------------------------------------
//
// UART0 interrupt service routine
//
void UART0_ISR(void) interrupt INTERRUPT_UART0
{
	char SFRPAGE_SAVE = SFRPAGE;
    uint i = 2000;

	SFRPAGE = UART0_PAGE;

	if (RI0 == 1)	// if receive flag set, put the byte in UART_InputBuffer
	{
		RI0 = 0;
		Byte = SBUF0;                                               // Read a character receveid

        if (UART_InputBuffer_Size < UART_IN_BUFFERSIZE)
		{
			UART_InputBuffer[UART_InputBuffer_Size] = Byte;
			UART_InputBuffer_Size++;                                // Update array's size

            if ((Byte == '\0') || (Byte == '\n') || (Byte == '\r')) // Reception complete.
            {
                while ( i > 0)  // wait a little!
                    i--;
			    RX_Ready = 1; 
            }                              
		}
	}

	if (TI0 == 1)		// if transmit flag set, send UART_OutputBuffer datas 
	{
		TI0 = 0;

		if (UART_OutputBuffer_Size > 0)		                // If buffer not empty
		{
			Byte = UART_OutputBuffer[UART_Output_First];
			SBUF0 = Byte;                                   // Transmit the character
			UART_Output_First++;                            // Update counter
			UART_OutputBuffer_Size--;                       // Decrease free array size
		}
		else
		{
			UART_Output_First = 0;
			TX_Ready = 1;                                   // Transmission complete
		}
	}

	SFRPAGE = SFRPAGE_SAVE;              	                // restore SFRPAGE	
} // UART0_ISR



//-----------------------------------------------------------------------------
// UART1_ISR
//-----------------------------------------------------------------------------
//
// UART1 interrupt service routine
//
// Called when BLE extention board connected
//
void UART1_ISR(void) interrupt INTERRUPT_UART1
{
	char SFRPAGE_SAVE = SFRPAGE;
    uint i = 50000;

	SFRPAGE = UART1_PAGE;

	if (RI1 == 1)	// if receive flag set, put the byte in UART_InputBuffer
	{
		RI1 = 0;
		Byte = SBUF1;                                               // Read a character receveid
		
        if (UART_InputBuffer_Size < UART_IN_BUFFERSIZE)
		{
			UART_InputBuffer[UART_InputBuffer_Size] = Byte;
			UART_InputBuffer_Size++;                                // Update array's size

            if ((Byte == '\0') || (Byte == '\n') || (Byte == '\r') || (Byte == '/')) // Reception complete. '/' added for BLE test
            {
                while ( i > 0)
                    i--;
			    RX_Ready = 1; 
            }                              
		}
	}

	if (TI1 == 1)		// if transmit flag set, send UART_OutputBuffer datas 
	{
		TI1 = 0;

		if (UART_OutputBuffer_Size > 0)		// If buffer not empty
		{
			Byte = UART_OutputBuffer[UART_Output_First];
			SBUF1 = Byte;                                   // Transmit the character
			UART_Output_First++;                            // Update counter
			UART_OutputBuffer_Size--;                       // Decrease free array size
		}
		else
		{
			UART_Output_First = 0;
			TX_Ready = 1;                                   // Transmission complete
		}
	}

	SFRPAGE = SFRPAGE_SAVE;              	                // restore SFRPAGE	
} // UART1_ISR



//-----------------------------------------------------------------------------
// Send_Message
//-----------------------------------------------------------------------------
//
// Return Value :   None
// Parameters   :   string to send, 
// 
// *** WARNING *** if BLE extension used, maximum of 20 characters will be send at a time.
//
void Send_Message(char * text)
{
	char i, j, k;
	char SFRPAGE_SAVE = SFRPAGE;

	if (TX_Ready == 1)
	{
		UART_OutputBuffer_Size = 0;
		UART_Output_First = 0;

        k = strlen(text);
        if (BT_onJ14 && k > 20)
            k = 20;
        for (i = k, j = 0; i > 0; i--, j++)
		{
            UART_OutputBuffer[j] = text[j];
			UART_OutputBuffer_Size++;
		}

        UART_OutputBuffer[j] = '\n';            // the end of the string
        UART_OutputBuffer_Size++;

		TX_Ready = 0;                           // Set the flag to zero

		SFRPAGE_SAVE = SFRPAGE;
        if (use_USB)
        {
			SFRPAGE = UART0_PAGE;
   	    	TI0 = 1;                            // Set transmit flag to 1 -> call the ISR
		}
		else
		{
			SFRPAGE = UART1_PAGE;
   	    	TI1 = 1;                            // Set transmit flag to 1 -> call the ISR	
		}

		SFRPAGE = SFRPAGE_SAVE;

        if (j == 0)
           j = 1;
        wait_ms(j*2);
	}
} // Send_Message


//-----------------------------------------------------------------------------
// SelectFrequency
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : user selected or not
//
void SelectFrequency(bit userselected)
{
    uchar c_value, expo, pos_point, pos_modif, len_text;
	char  akey, j;
	float f1, int_part;

    // 'normal' frequency
    if (!userselected)
    {
        Set_Frequency(Freq_index);
        Display_Frequency(X_POS_UNITS, Y_POS_LINE_3);
        Write_Measure_Icons();
        return;
    }

    // user defined frequency
    GLCD_clear();

    // check if a float is at USER_FREQUENCY_ADD
    c_value = FLASH_ByteRead(USER_FREQUENCY_ADD, 0);
    if (c_value != 0xFF)                                   // there is already a saved value
    {
        Write_OK_Exit_Icons();
        Affiche_Text(WITH_ICON28, Y_POS_LINE_1, 28, GLCD_PIXEL_ON);   // "Use saved frequency?
        do
        {
            akey = GetUserAction();
        }
        while (akey == NO_KEY_PRESSED);

        if (akey == KEY_4)      // Ok
            Value_to_Print = ReadFloatInFLASH(USER_FREQUENCY_ADD);          
        else
            Value_to_Print = freq;

        GLCD_clear();
    }
    else
         Value_to_Print = freq;
   
    Write_OK_Exit_Icons();
    GLCD_show_icon( ( void * ) Left_icon,   28, 24, 212, ICON1_POS, GLCD_PIXEL_OFF );
	GLCD_show_icon( ( void * ) Right_icon,  28, 24, 212, ICON2_POS, GLCD_PIXEL_OFF );

	akey = 0;
    len_text = 5;       // for freq formated as x.xxx or xx.xx or xxx.x (Hz or kHz or MHz)

    // ---- select font 8x16
	GLCD_select_font(( void * ) font_8x16, 8, 16);

    pos_modif =  len_text - 1;
	do
	{
        // freq is in [50.0Hz - 2.0MHz]
        if (Value_to_Print < 50.0)
            Value_to_Print = 50,0;
        if (Value_to_Print > 2000000.0)
            Value_to_Print = 2000000,0;

        // put freq in the form of x.x Hz or kHz or MHz -> freq = f1 * 10^int_part
		f1 = log10(Value_to_Print);
   		f1 = modf (f1, &int_part);          // f1 is fractionnal part of log10
		f1 = pow(10,f1);                    // f1 is formated value x.xxx to xxx.x
			
   	    expo = (char)fmod(int_part, 3.0);

		switch (expo)
		{
			case 0:
				break;
			case 1:
				f1 *= 10;
				int_part -= 1.0;
				break;

			case 2:
				f1 *= 100;
				int_part -= 2.0;
                break;
		}

		sprintf (Buffer, "%1.4f", f1);    // copy f1 in Buffer as x.xxxx
        pos_point = strpos(Buffer, '.');

        // if x.xxxx,   pos_point = 1 -> format = "%1.3f" -> x.xxx
        // if xx.xxxx   pos_point = 2 -> format = "%1.2f" -> xx.xx
        // if xxx.xxxxx pos_point = 3 -> format = "%1.1f" -> xxx.x

        sprintf (Buffer, Table_format_QD[pos_point], f1);

		//len_text = strlen(Buffer);                  // always 5
        len_text = 5;

        GLCD_draw_text( 40, Y_POS_LINE_3, Buffer, GLCD_PIXEL_ON);

		Expo[0] = '\0';
		switch ((char)int_part)
   		{
			case 0:
         		break;
      		case 3:
         		strcat(Expo, CHAR_KILO);
         		break;
      		case 6:
         		strcat(Expo, CHAR_MEGA);
         		break;
    	}
		strcat(Expo, CHAR_H);
        strcat(Expo, CHAR_z);
        strcat(Expo, "  ");

        if (pos_modif == pos_point)
			pos_modif--;

        // determine the power of 10 of the pointed digit.
		j = pos_point - pos_modif;
		if (j > 0)          // if positive , take into account the position of the decimal point
			j--;
		j += int_part;      // add exponent (3 for K, 6 for M)
        f1 = pow(10, j);    // the new value of the mantissa

		GLCD_draw_text( 40 + 8 * font_width, Y_POS_LINE_3, Expo, GLCD_PIXEL_ON);
		GLCD_draw_text( 40 + pos_modif * font_width, Y_POS_LINE_3 + 15, ",", GLCD_PIXEL_ON);			// marker (in reality '^')

        do
        {
            akey = GetUserAction();
        }
        while (akey == NO_KEY_PRESSED);

		GLCD_draw_text(40 + pos_modif * font_width, Y_POS_LINE_3 + 15, ",", GLCD_PIXEL_INV);			// erase marker
 		switch (akey)
		{
			case KEY_1: //LEFT
				if (pos_modif > 0)
					pos_modif--;
				if (pos_modif == pos_point)
					pos_modif--;
				break;
			case KEY_2: //RIGHT
				if (pos_modif <= len_text - 2)
					pos_modif++;
				if (pos_modif == pos_point)
					pos_modif++;
				break;
            case MOVE_MARK_UP:
                Value_to_Print += f1;
                break;
            case MOVE_MARK_DOWN:
                Value_to_Print -= f1;
                break;
            default:
                break;
		}                                          							                                       							
	}
    while (!( (akey == KEY_5) || (akey == KEY_4)));  // EXIT or OK

    // ---- restore default font 6x11
	GLCD_select_font(( void * ) font_6x11, 6, 11);

    if (akey == KEY_5)  // EXIT
    {
        userDefinedFrequency = false;
        Set_Frequency(Freq_index);
    }
    else                // OK
    {
        freq = Value_to_Print;
        // **** correction bug -> 3.0.0
        DDS_SetFrequency(freq);
        Set_SPS_WithFreq();
        Load_CF();
         // **** 
        GLCD_clear();
        Write_OK_Exit_Icons();
        Affiche_Text (WITH_ICON28, Y_POS_LINE_1, 30, GLCD_PIXEL_ON);   // "Save the frequency?"

        do
        {
            akey = GetUserAction();
        }
        while (akey == NO_KEY_PRESSED);

        if (akey == KEY_4)      // Ok
            FLASH_Update(USER_FREQUENCY_ADD, (char *) &Value_to_Print, FLOAT_SIZE, 0);   
    }
        
    //Load_CF();
    Restore_Display();
} // SelectFrequency


//----------------------------------------------------------------------------- 
// Update_DDS_VRef
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
// 
void Update_DDS_VRef(void)
{
    float f1;

    f1 = Value_to_Print;
    FLASH_Update (DDS_VREF_VALUE_ADD, (char *) &f1, FLOAT_SIZE, 0); // update of DDS1_Vref
    DAC_coeff = (DDS1_Vref / MCU_VREF) * 9032; 	// 9032 = 4096 * (1 + 4700/3900) -> see function Set_DDS_Amplitude()
}


//----------------------------------------------------------------------------- 
// Menu_Set_DDS_Vref
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
// 
void Menu_Set_DDS_Vref(void)
{
    char akey;

    GLCD_clear();
    Write_OK_Exit_Icons();

    Affiche_Text(WITH_ICON28, Y_POS_LINE_1, 41, GLCD_PIXEL_ON);  // "Measured voltage value on TP6      "
    Value_to_Print = DDS1_Vref;
	akey = NO_KEY_PRESSED;

    // ---- select font 8x16
	GLCD_select_font(( void * ) font_8x16, 8, 16);

    Expo[0] = '\0';
    strcat(Expo, CHAR_V);
    GLCD_draw_text( 40 + 6 * font_width, Y_POS_LINE_3, Expo, GLCD_PIXEL_ON);

	do
	{
        // DDS1_Vref is in [1.12 V - 1.24 V] according the data sheet
        if (Value_to_Print < 1.12)
            Value_to_Print = 1.12;
        if (Value_to_Print > 1.24)
            Value_to_Print = 1.24;

		sprintf (Buffer, "%1.3f", Value_to_Print);    // copy Value_to_Print in Buffer as x.xxxx

        GLCD_draw_text( 40, Y_POS_LINE_3, Buffer, GLCD_PIXEL_ON);

        do
        {
            akey = GetUserAction();
        }
        while (akey == NO_KEY_PRESSED);

 		switch (akey)
		{
            case MOVE_MARK_UP:
                Value_to_Print += 0.001;
                break;
            case MOVE_MARK_DOWN:
                Value_to_Print -= 0.001;
                break;
            default:
                break;
		}                                          							                                       							
	}
    while (!( (akey == KEY_5) || (akey == KEY_4)));  // EXIT or OK

    // ---- restore default font 6x11
	GLCD_select_font(( void * ) font_6x11, 6, 11);

    if (akey == KEY_4)  // OK
        Update_DDS_VRef();
        
    Restore_Display();
} // Menu_Set_DDS_Vref



//----------------------------------------------------------------------------- 
// ReadTextinFlash
//-----------------------------------------------------------------------------
//
// Return Value : none
// Parameters   : index of the text
// 
// read selected language from Text_Array[] in BANK2 of FLASH MEMORY
// put it on textLine[]
//
void ReadTextinFlash(char index)
{
    FLADDR  adresse;
         
    if (index < numberLineText)    // index in the range?
    {
        // Read Text in BANK2 of FLASH
        adresse = TEXT_ARRAY_ADD + ((index + current_language * numberLineText) * LONG_TEXT);
        FLASH_Read ( textLine, adresse, LONG_TEXT, 0);
        textLine[LONG_TEXT-1] = '\0';
    }
    else
    {
        GLCD_clear();
        GLCD_draw_text(0,21, TextI_4, GLCD_PIXEL_ON);       // "Text not avalaible. Restart in PC Mode."
        GLCD_draw_text(0,35, TextI_3, GLCD_PIXEL_ON);       // "Use the AU2019 prog. to load them"
        
        while (1);        
    }
} // ReadTextinFlash



//-----------------------------------------------------------------------------
// Restore_Display
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
void Restore_Display(void)
{
    GLCD_clear();
    Write_Measure_Icons();
    Display_Frequency(X_POS_UNITS, Y_POS_LINE_3);
    Display_Level(4, Y_POS_LINE_8);
    Display_DC_Bias(102, Y_POS_LINE_8, true);
    Display_Range_Hold();
    old_primary = 0;
    old_secondary = 0;
}


//-----------------------------------------------------------------------------
// Display_Level
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : x, y
//
void Display_Level(uchar x, uchar y)
{    
    char    xdata chaine2[10];

    strcpy(chaine, message_AC);     //  "AC "
    strcpy(chaine2, message_AC);    //  "AC "

    switch (sourceLevel)
    {
        case LEVEL_1V_RMS:
            strcat(chaine, " 1V RMS ");
            strcat(chaine2, "1000");
            break;   
        case LEVEL_500mV_RMS:
            strcat(chaine, "0.5V RMS");
            strcat(chaine2, "500");
            break;   
        case LEVEL_200mV_RMS:
            strcat(chaine, "0.2V RMS");
            strcat(chaine2, "200");
            break;   
        case LEVEL_100mV_RMS:
            strcat(chaine, "0.1V RMS");
            strcat(chaine2, "100");
            break;                        
    }

    if (standalone)
        GLCD_draw_text(x,y, chaine, GLCD_PIXEL_ON);
    else if (use_Bluetooth)
        Send_Message(chaine2);
    else
        Send_Message(chaine);
}


//-----------------------------------------------------------------------------
// Display_DC_Bias
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : x, y
//
void Display_DC_Bias(uchar x, uchar y, bit blink)
{    
    uchar mode;
    static bit pix;
    float current;

    if (DC_mVolt == 0)
        sprintf(chaine, message_NULL_DC_BIAS);  // "DC 0.0 V"
    else
    {
        if (DC_Bias_is_voltage)
        {
            if (standalone)
                sprintf(chaine, "DC %1.1f V", (float)DC_mVolt/1000);
            else
                sprintf(chaine, "DC %1.3f V", (float)DC_mVolt/1000);    // Version 1.5.4
        }
        else
        {
            current = Checks_Bias_Current();
            current -= biasCurrent_Offset;
            if (current > 55)
                sprintf(chaine, "DC %1.0f mA", (float)DC_mVolt/100);
            else
                sprintf(chaine, "DC %1.1f mA", current);
        }
    }

    if (standalone)
    {
        if ( (DC_mVolt != 0) && blink && (primaryKind != C_KIND && primaryKind != L_KIND) )
        {
            if (pix)
                mode = GLCD_PIXEL_ON;
            else
                mode = GLCD_PIXEL_OFF;
            pix = ~pix;
        }
        else 
            mode = GLCD_PIXEL_ON;

        while (strlen(chaine) < 12)
            strcat (chaine, " ");

        GLCD_draw_text(x,y, chaine, mode);
    }
    else
        Send_Message(chaine);
}


//-----------------------------------------------------------------------------
// Display_Range_Hold
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Display Range-Hold and PGA2_Gain-Hold status
//
void Display_Range_Hold(void)
{    
#ifdef DEBUG_2
    strcpy(chaine, "PGA ");
    if (noPGA_Gain)
        strcat(chaine, "OFF");
    else
        strcat(chaine, "ON ");
    if (standalone)
        GLCD_draw_text( 102, Y_POS_LINE_7, chaine, GLCD_PIXEL_ON);
#endif

    strcpy(chaine, message_R_HOLD);

    if (rangeHold)
        strcat(chaine, "ON ");
    else
        strcat(chaine, "OFF");

    if (standalone)
        GLCD_draw_text( 4, Y_POS_LINE_7, chaine, GLCD_PIXEL_ON);
    else
        Send_Message(chaine);
}



//-----------------------------------------------------------------------------
// Run_Menu
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : The line number (from the menu) to be run
//
void Run_Menu(char choise)
{  
    uchar saveSPS = ADS_sps;

    GLCD_clear();
    if (Menu_Kind == KIND_MENU)
    {
        switch (choise)
        {
             case 1:
                Menu_Set_Language();
                break;
            case 2:
                Menu_Set_Q_Limit();
                break;
            case 3:
                Menu_Set_Sorting_Parameters();
                break;
            case 4:
                Menu_Sort();
                break;
            case 5:
                Menu_Set_Source_Level();
                break;
            case 6:
                Menu_Set_DC_BIAS();
                break;
            case 7:
                if (DisplayNormal == 0)
                    DisplayNormal = 1;
                else
                    DisplayNormal = 0;
                FLASH_Update(DISPLAY_KIND_ADD, (char *) &DisplayNormal, CHAR_SIZE, 0);
                GLCD_WriteCommand(GLCD_DISPLAY_NORMAL, DisplayNormal);
                break;

        }
    }
    else if (Menu_Kind == KIND_CONFIG)
    {
        ADS_SetSPS(ADS_SPS_20);
        switch (choise)
        {
            case 1:
                Menu_Set_Sinus_Offset();
                break;
            case 2:
                Menu_Set_DDS_Vref();
                break;
            case 3:
                Menu_Set_Voltage_Diff_Amp_CMRR();
                break;
            case 4:
                Menu_PGA2_Calibration(RANGE_GAIN_3);
                break;
            case 5:
                Menu_PGA2_Calibration(RANGE_GAIN_10);
                break;
            case 6:
                Menu_Set_CalibrationFactor(R_RANGE_1);
                break;
            case 7:
                Menu_Set_CalibrationFactor(R_RANGE_2);
                break;
            case 8:
                Menu_Set_CalibrationFactor(R_RANGE_3);
                break;
            case 9:
                Menu_Set_CalibrationFactor(R_RANGE_4);
                break;
            case 10:
                Menu_Set_Trim(SHORT_TRIM);
                break;
            case 11:
                Menu_Set_Trim(OPEN_TRIM);
                break;
        } 
        ADS_SetSPS(saveSPS);
    }
    Menu_Index = choise; 
} // Run_Menu


//-----------------------------------------------------------------------------
// Load_Text_Menu
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// puts in textMenu[] the string located at "index" in the table XXX_ARRAY[] in BANK2
//
void Load_Text_Menu(uchar menu_Index)
{ 
    FLADDR  adresse;

    if (Menu_Kind == KIND_MENU)
    {
        adresse = MENU_ARRAY_ADD + ((menu_Index + current_language * numberLineMenu) * LONG_TEXT);
        FLASH_Read (textMenu, adresse, LONG_TEXT, 0); 
        textMenu[LONG_TEXT-1] = '\0';            
    }
    else if (Menu_Kind == KIND_CONFIG)
    {
        adresse = CONFIG_ARRAY_ADD + ((menu_Index + current_language * numberLineConfig) * LONG_TEXT);
        FLASH_Read (textMenu, adresse, LONG_TEXT, 0);
        textMenu[LONG_TEXT-1] = '\0';         
    }
    else if (Menu_Kind == KIND_SERIES)
        strcpy(textMenu, Series_Array[menu_Index]);
    else if (Menu_Kind == KIND_LEVEL)
        strcpy(textMenu, Level_Array[menu_Index]);
    else if (Menu_Kind == KIND_LANGUAGE)
    {
        adresse = LANG_ARRAY_ADD + (menu_Index * LONG_TEXT_LANG); 
        FLASH_Read ( textMenu, adresse, LONG_TEXT_LANG, 0);
        textMenu[LONG_TEXT_LANG-1] = '\0';
    }
} // Load_Text_Menu


//-----------------------------------------------------------------------------
// Display_Menus
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
void Display_Menus(void)
{    
    uchar    i, j, k;
    uchar   mode;

    if (Menu_Kind == KIND_MENU)
        k = MIN(DISPLAYED_MENUS, numberLineMenu);
    else if (Menu_Kind == KIND_CONFIG)
        k = MIN(DISPLAYED_MENUS, numberLineConfig);
    else if (Menu_Kind == KIND_SERIES)
        k = MIN(DISPLAYED_MENUS, numberSeries);
    else if (Menu_Kind == KIND_LEVEL)
        k = MIN(DISPLAYED_MENUS, numberLevel);
    else if (Menu_Kind == KIND_LANGUAGE)
        k = MIN(DISPLAYED_MENUS, numberLanguage);

	for (i = First_Displayed_Menu, j = 0; i < First_Displayed_Menu + k; i++, j += Y_DELTA_TEXT)
    {
		if (i == Menu_Index)
            mode = GLCD_PIXEL_OFF;
        else
            mode = GLCD_PIXEL_ON;
        
        Load_Text_Menu(i - 1);
        GLCD_draw_text( 0, Y_POS_MENU_1 + j, textMenu, mode);
    }
} // Display_Menus



//-----------------------------------------------------------------------------
// Menus_Move
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : MOVE_MARK_DOWN or MOVE_MARK_UP
// 
void Menus_Move(uchar move)
{
    uchar k, nbMenu;
	uchar display_Index = Menu_Index - First_Displayed_Menu + 1; // 1 in first line

    if (Menu_Kind == KIND_MENU)
    {
        k = MIN(DISPLAYED_MENUS, numberLineMenu);
        nbMenu = numberLineMenu;
    }
    else if (Menu_Kind == KIND_CONFIG)
    {
        k = MIN(DISPLAYED_MENUS, numberLineConfig);
        nbMenu = numberLineConfig;
    }
    else if (Menu_Kind == KIND_SERIES)
    {
        k = MIN(DISPLAYED_MENUS, numberSeries);
        nbMenu = numberSeries;
    }
    else if (Menu_Kind == KIND_LEVEL)
    {
        k = MIN(DISPLAYED_MENUS, numberLevel);
        nbMenu = numberLevel;
    }
    else if (Menu_Kind == KIND_LANGUAGE)
    {
        k = MIN(DISPLAYED_MENUS, numberLanguage);
        nbMenu = numberLanguage;
    }
#ifndef DEBUG_3
	if (move == MOVE_MARK_DOWN)
#else
    if (move == MOVE_MARK_UP)
#endif
	{
		if (display_Index < k ) // only move index
		{
            Load_Text_Menu(Menu_Index - 1);
			GLCD_draw_text( 0, Y_POS_MENU_1 + Y_DELTA_TEXT * (display_Index - 1), textMenu, GLCD_PIXEL_ON);
			Menu_Index++;
			display_Index++;
            Load_Text_Menu(Menu_Index - 1);
			GLCD_draw_text( 0, Y_POS_MENU_1 + Y_DELTA_TEXT * (display_Index - 1), textMenu, GLCD_PIXEL_OFF);
		}
		else if (Menu_Index < nbMenu ) // shift menus
		{
			First_Displayed_Menu++;
			Menu_Index++;
			Display_Menus();
		}   
	}
#ifndef DEBUG_3
	else if (move == MOVE_MARK_UP)
#else
	else if (move == MOVE_MARK_DOWN)
#endif
	{
		if (display_Index > 1) // only move index
		{
            Load_Text_Menu(Menu_Index - 1);
			GLCD_draw_text( 0, Y_POS_MENU_1 + Y_DELTA_TEXT * (display_Index - 1), textMenu, GLCD_PIXEL_ON);
			Menu_Index--;
			display_Index--;
            Load_Text_Menu(Menu_Index - 1);
			GLCD_draw_text( 0, Y_POS_MENU_1 + Y_DELTA_TEXT * (display_Index - 1), textMenu, GLCD_PIXEL_OFF);
		}
		else if (Menu_Index > 1) // shift menus
		{
			First_Displayed_Menu--;
			Menu_Index--;
			Display_Menus();
		}
	}
} // Menus_Move



//-----------------------------------------------------------------------------
// Menu_Choise
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
void Menu_Choise(void)
{
    char   akey = NO_KEY_PRESSED;
    uchar   nbMenu;

    GLCD_clear();
    Write_OK_Exit_Icons();
    old_cpt_encod = cpt_encod;
 
    if (Menu_Kind == KIND_CONFIG)
    {
        nbMenu = numberLineConfig;
    }
    else if (Menu_Kind == KIND_MENU)
    {
        nbMenu = numberLineMenu;
    }
    else
        return;

    Display_Menus();

    do
    {
        akey = GetUserAction();
        switch (akey)
        {
            case MOVE_MARK_UP:
                Menus_Move(MOVE_MARK_UP);
                break;

            case MOVE_MARK_DOWN:
                Menus_Move(MOVE_MARK_DOWN);
                break;
            case KEY_4:
                Run_Menu(Menu_Index);
                akey = KEY_5;
                break;
        }
    }
    while (akey != KEY_5);

    Menu_Mode = false;
    Load_CF();
    Restore_Display();
} // Menu_Choise


//-----------------------------------------------------------------------------
// Menu_Set_CalibrationFactor
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : the range (R_RANGE_1 to R_RANGE_4)
//
// Calculation of parameters of measurement path. TRIM operations have to be redone.
//
// Jumper fitted on J8 & J9
// Jumper J1x fitted according 'range' ( -> connection of the on-board 0.01% precision resistor)
//
void Menu_Set_CalibrationFactor(uchar range)
{
    uchar i, j, k, oldLevel;
    uchar pos = 60;
    uchar In_Freq_index = Freq_index;
    bit pix = false;
    bit okvalue, onlyErase;
    char akey, returnValue;
    float RsLow, RsHigh;
    float newReductionLevel = 1.0;

   
    oldLevel = sourceLevel;
    Set_Source_Level(LEVEL_1V_RMS);
    Affiche_Text(WITH_ICON28, pos, 12 + range, GLCD_PIXEL_ON); // "  -> Put a jumper in J1x    "
     	
    wait_ms(400);
    
    Freq_index = Get_FreqIndex (1000);  // 1kHz
	Set_Frequency(Freq_index);
    i = 0;
    Buffer_Init();

    // High and low limits depending on the range.
    RsLow = 98.5 * pow(10,range-1);     // 98.5*10E0, ..., 98.5*10E3
    RsHigh = 101 * pow(10,range-1);   // 101*10E0, ..., 101*10E3

    Saved_rangeHold = rangeHold;        // update version 2.3.7
    rangeHold = false;

    // Check that the correct resistor is connected.
    do
    {
        Process_Measurement(RANGE_GAIN_1);
        if (errorMeasure == 0)
        {
    	    Div_Complex(Vp, Vq, Ip, Iq, &Rs, &Xs);
	        Buffer_Add_Data(Rs, Xs);
            i++;
            Buffer_Read(&Rs, &Xs);
            okvalue = (Rs > RsLow && Rs < RsHigh);
        }
    }
    while (i < 3 && !okvalue);

    if (standalone)
        GLCD_clear();

    if (okvalue)
    {
        Affiche_Text(WITHOUT_ICON, pos, 18, GLCD_PIXEL_ON); // "Okay, will take few minutes"
        Set_Resistor_Sense_Range(range);
        Set_PGA2_Gain(RANGE_GAIN_1, true);
        in_calibration = true;

        DisplayProgressionBar(0); // with external display, don't wait to show progress bar!

        for (j = MIN_FREQ_INDEX_START; j < FREQ_MEM_SIZE; j++)
        {
            Set_Frequency(j);
            if (wait_steady_PSD <= 5)       // freq >= 5 kHz, k = 8
                k = BUFSIZE_DATA_MAX1;
            else if (wait_steady_PSD <= 22) // freq >= 500 Hz, k = 6
                k = BUFSIZE_DATA_MAX2;
             else                           // freq < 500 Hz, k = 4
                k = BUFSIZE_DATA_MAX3;

            if (standalone)
                Write_Frequency(MIN_FREQ_INDEX_START, 22, GLCD_PIXEL_ON, userDefinedFrequency);
            i = 0;
            Set_Measure_Mode(CURRENT_MODE);
            Buffer_Init();
	        do
	        {	
	            returnValue = Set_Measure(&Ip, &Iq);
                if (returnValue == OK_MEASURE)
                {
 	                Buffer_Add_Data(Ip, Iq);
                    i++;
                }
                else    // version 2.2.0
                {
                    newReductionLevel *= 1.05;
                    Set_DDS_Amplitude(newReductionLevel);
                }

            }
            while (i < k);
            Buffer_Read(&Ip, &Iq);

            i = 0;
            Set_Measure_Mode(VOLTAGE_MODE);
            Buffer_Init();
	        do
	        {	
	            returnValue = Set_Measure(&Vp, &Vq);
                if (returnValue == OK_MEASURE)
                {
 	                Buffer_Add_Data(Vp, Vq);
                    i++;
                }
            }   
            while (i < k);
            Buffer_Read(&Vp, &Vq);

            Div_Complex(Vp, Vq, Ip, Iq, &Rs, &Xs);

            Tab_Real[j] = Rs;
            Tab_Imag[j] = Xs;
            DisplayProgressionBar(j+1);
        } // for
        
        Set_Source_Level(oldLevel);
        if (standalone)
        {
            GLCD_clear_Row(WITHOUT_ICON, pos);
            Write_OK_Exit_Icons();
        }
        Affiche_Text(WITH_ICON28, pos, 10, GLCD_PIXEL_ON);  // "Save the data?"
        do
        {
            akey = GetUserAction();
        }
        while (!( (akey == KEY_5) || (akey == KEY_4)) );    // EXIT or OK
        wait_ms(400);
        in_calibration = false;
        onlyErase = (akey == KEY_5);
    
        Copy_CalibrationFactor_to_CodeData(range, onlyErase);
    }
    else
    {
        Affiche_Text(WITH_ICON28, pos, 17, GLCD_PIXEL_ON);  // "Not the right jumper, exit"
        wait_ms(2000);
    }

    rangeHold = Saved_rangeHold;        // update version 2.3.7

    Set_Frequency(In_Freq_index);
    Get_Standard_Values();
} // Menu_Set_CalibrationFactor


//-----------------------------------------------------------------------------
// Get_Averaged_Values
//-----------------------------------------------------------------------------
//
// Return Value : false if error (key pressed)
// Parameters   : VOLTAGE_MODE or CURRENT_MODE
//
// Obtain the average value for Vp, Vq (VOLTAGE_MODE)
//                          or  Ip, Iq (CURRENT_MODE)
//
bit Get_Averaged_Values (bit mode)
{
	char i, k;
	char returnValue;
	float A, B;

    if (wait_steady_PSD <= 5)       // freq >= 5 kHz, k = 8
        k = BUFSIZE_DATA_MAX1;
    else if (wait_steady_PSD <= 22) // freq >= 500 Hz, k = 4
        k = BUFSIZE_DATA_MAX3;
    else                           // freq < 500 Hz, k = 2
        k = BUFSIZE_DATA_MAX4;

   	Measure_Mode = VOLTAGE_MODE;
	Buffer_Init();
    for (i = k; i > 0; i--)
	{
		returnValue = Set_Measure(&A, &B);
		if (returnValue == OK_MEASURE)
			Buffer_Add_Data(A, B);
        else
        {
            return false;
        }
	}

	Buffer_Read(&A, &B);

	if (mode == VOLTAGE_MODE)
	{
		Vp = A;
		Vq = B;
	}
	else
	{
		Ip = A;
		Iq = B;
	}
   	return true;
}  //Get_Averaged_Values



//-----------------------------------------------------------------------------
// Gain_Calibration
//-----------------------------------------------------------------------------
//
// Return Value : false if error (key pressed)
// Parameters   : RANGE_GAIN_3 or RANGE_GAIN_10
//
// Returns the measured average values for the PAG2 gain of  <1> (in Ip and Iq)
// and the measured average values for the PAG2 gain of <PGA_Gain> (in Vp and Vq)
//
bit Gain_Calibration(uchar PGA_Gain)
{
	// 1 - for gain = 1;
	Set_PGA2_Gain(RANGE_GAIN_1, false);
	if(!Get_Averaged_Values (CURRENT_MODE))	// -> measurement results in Ip & Iq
        return false;

	// 2 - for gain = 3 or 10;
	Set_PGA2_Gain(PGA_Gain, false);
	if(!Get_Averaged_Values (VOLTAGE_MODE))	// -> measurement results in Vp & Vq
        return false;

	return true;
} // Gain_Calibration


//-----------------------------------------------------------------------------
// Menu_PGA2_Calibration
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : RANGE_GAIN_3 (gain of 3.16) or RANGE_GAIN_10 (gain of 10)
//
// 1k resistor connected.
//
void Menu_PGA2_Calibration(uchar PGA_Gain)
{
	uchar In_Freq_index = Freq_index;
    char akey = NO_KEY_PRESSED;
    uchar i = 0;
    uchar row = 54;
    uchar index;
    float Input;
    float xdata RA, XA, RB, XB, RC, XC;
    bit ok, okvalue, onlyErase, ok1, ok2;
    bit pix = true;

    Affiche_Text(WITH_ICON28, row, 14, GLCD_PIXEL_ON);      // "-> Put a jumper in J11" 
    wait_ms(1000);  
    Freq_index = Get_FreqIndex (1000);
    Set_Frequency(Freq_index);
    if (standalone)
        Write_Frequency(0, 20, GLCD_PIXEL_ON, userDefinedFrequency);
    else
        Display_Frequency(X_POS_UNITS, Y_POS_LINE_3);   // added for VER 2.3.5
     
	do
    {	
        Process_Measurement(RANGE_GAIN_1);
	    if (errorMeasure == 0)
        {
    	    Div_Complex(Vp, Vq, Ip, Iq, &Rs, &Xs);
            Z = sqrt(Xs * Xs + Rs * Rs);
            Display_Z();
            ok =( Z < 1100.0 && Z > 990.0);
            i++;
        }
    }
    while ( !ok && (i < 3));

    if (!ok)
        return;

    in_calibration = true;
    // proceed for phase adjustment  
    Set_Resistor_Sense_Range(R_RANGE_2);
	Set_Measure_Mode(VOLTAGE_MODE);
    Freq_index = Get_FreqIndex (1000000);	                            // 1MHz
    Set_Frequency(Freq_index);

    if (standalone)
    {
        Write_Blank_Icons(5);
        GLCD_clear_Row(WITH_ICON28, row);
        Write_Frequency(0, 20, GLCD_PIXEL_ON, userDefinedFrequency);
        GLCD_show_icon( ( void * ) EXit_icon, 28, 24, 212, ICON5_POS, GLCD_PIXEL_OFF );
    }
    else
        Display_Frequency(X_POS_UNITS, Y_POS_LINE_3);   // added for VER 2.3.5

    if (PGA_Gain == RANGE_GAIN_10)
    {
		Input = 10;
        Affiche_Text(WITH_ICON28, row, 3, GLCD_PIXEL_ON);  // "Set C51 for |Phi| < 0.2"   
    }
	else
    {
		Input = 3.2;
        Affiche_Text(WITH_ICON28, row, 4, GLCD_PIXEL_ON);  // "Set C106 for |Phi| < 0.1"
    }

    Set_DDS_Amplitude(Input);
	do
	{
        ok = Gain_Calibration (PGA_Gain);   
		if (ok)
        {
            Div_Complex(Vp, Vq, Ip, Iq, &Rs, &Xs);
            Phi = atan(Xs / Rs) * 180 / PI;     	// degree
            if (standalone)
            {
		        sprintf(chaine,"Phi = %1.3f   ", Phi);
                if (pix)
		            GLCD_draw_text(0,110, chaine, GLCD_PIXEL_ON);
                else
                    GLCD_draw_text(0,110, chaine, GLCD_PIXEL_OFF);
                pix = ~pix;

                if (PGA_Gain == RANGE_GAIN_10)
                    okvalue = fabs(Phi) < 0.3;
                else
                    okvalue = fabs(Phi) < 0.2;

                if (okvalue)
                {
                    GLCD_show_icon( ( void * ) OK_icon, 28, 24, 212, ICON4_POS, GLCD_PIXEL_ON );
                }
                else
                {
                    GLCD_show_icon( ( void * ) BLANK_icon, 28, 24, 212, ICON4_POS, GLCD_PIXEL_ON );
                }
            }
            else
            {
                okvalue = true;
                sprintf(chaine, "PHI %1.3f ", Phi);
                strcat(chaine,"D");
                Send_Message(chaine);
            }
        }	
        akey = GetUserAction();	
	}
	while ( !( (akey == KEY_5) || (akey == KEY_4 && okvalue) ) );   // "Exit" or  "Ok"

    if (akey == KEY_5)  // Exit
    {
        in_calibration = false;
        Set_DDS_Amplitude(1.0);
        Set_Frequency(In_Freq_index);
        return;
    }

    if (standalone)
        GLCD_clear();

    Affiche_Text(WITHOUT_ICON, row, 12, GLCD_PIXEL_ON);  // "Calculating the gain and phase"

    DisplayProgressionBar(0); // with external display, don't wait to show progress bar!

    for (index = MIN_FREQ_INDEX_START; index < FREQ_MEM_SIZE; index++)
    {
        Set_Frequency(index);
        if (standalone)
            Write_Frequency(0, 20, GLCD_PIXEL_ON, userDefinedFrequency);

        // 1 - measure the 1kohm resistor with G = 10 or 3.16 and reduction input level 
        Set_DDS_Amplitude(Input);
        Set_PGA2_Gain(PGA_Gain, false);         // G = 10 or 3.16 for the voltage
        ok1 = Get_Averaged_Values(VOLTAGE_MODE);
        Set_PGA2_Gain(RANGE_GAIN_1, false);     // G = 1 for the current
        ok2 = Get_Averaged_Values(CURRENT_MODE); 
        ok = ok1 && ok2;              
		if (ok)
        {
		    Div_Complex(Vp, Vq, Ip, Iq, &RA, &XA);  // no need to normalyse Ip and Iq         
        }
        else
        {
            GLCD_clear_Row(WITH_ICON28, row);
            Affiche_Text(WITHOUT_ICON, row, 23, GLCD_PIXEL_ON);  // "Error, exit"
            wait_ms(2000);
            break;
        }

        //2 - measure the 1kohm resistor with G = 1
        Set_PGA2_Gain(RANGE_GAIN_1, false);
        ok1 = Get_Averaged_Values(VOLTAGE_MODE);
        ok2 = Get_Averaged_Values(CURRENT_MODE);
        ok = ok1 && ok2;              
		if (ok)
        {
		    Div_Complex(Vp, Vq, Ip, Iq, &RB, &XB);  // no need to normalyse Ip and Iq               
        }
        else
        {
            GLCD_clear_Row(WITH_ICON28, row);
            Affiche_Text(WITHOUT_ICON, row, 23, GLCD_PIXEL_ON);  // "Error, exit"
            wait_ms(2000);
            break;
        }

        DisplayProgressionBar(index+1);

        // G = ZA/ZB
        Div_Complex(RA, XA, RB, XB, &RC, &XC);
        Tab_Real[index] = RC;
        Tab_Imag[index] = XC;
    } // for


    if (ok)
    {
        if (standalone)
        {
            GLCD_clear_Row(WITH_ICON28, row);
            Write_OK_Exit_Icons();
        }
        Affiche_Text(WITH_ICON28, row, 5, GLCD_PIXEL_ON);   // "Save the gain?"
	    
	    do
        {
            akey = GetUserAction();
        }
        while (!( (akey == KEY_5) || (akey == KEY_4) ));     // EXIT or OK

        onlyErase = (akey == KEY_5);   	
        Copy_CalibrationFactor_to_CodeData(PGA_Gain + 3, onlyErase);   // 5 for RANGE_GAIN_3, 6 for RANGE_GAIN_10	
    }

    in_calibration = false;
	Set_PGA2_Gain(RANGE_GAIN_1, false);
	DAC1_Update(0);                     // equivalent to Set_DDS_Amplitude(1.0);
	Set_Frequency(In_Freq_index);
    Get_Standard_Values();
} // Menu_PGA2_Calibration


//-----------------------------------------------------------------------------
// DisplayProgressionBar
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : index in [0, FREQ_MEM_SIZE]. index = 0 is for showing the Bar!
//
// icon is 28 pixels width and display width is 240 pixels. Each character is 6 pixels width
//
void DisplayProgressionBar(uchar index)
{
    uchar pos;
    
    if (standalone)
    {
        if (index == 0)
        {
            GLCD_draw_rect(4, 70, 208, 81, GLCD_PIXEL_ON);          // Version 2.1.0
            pos = 4;            // last pixel on 10
        }
        else if (index < 10)    // 1 to 9
            pos = 10 + (index - 1) * 5;      // -> index = 1 to 9 (9 pos), so last pixel on 10 + (8 * 5) + 6 = 56
        else if (index < 22)    // 10 to 21
            pos = 56 + (index - 10) * 4;    // -> index = 10 to 21 (12 pos), so write pos from  56 to 56 + (11 * 4) + 6 = 106
        else                    // 22 to 54
            pos = 106 + (index - 22) * 3;   // -> index = 22 to 54 (33 pos), so write pos from  106 to 106 + (32 * 3) + 6 = 208

        GLCD_draw_text(pos, 80, " ", GLCD_PIXEL_OFF); 
    }
    else
    {
        sprintf(chaine, "IND %u", (uint)index);
        Send_Message(chaine);
    }   
}


//-----------------------------------------------------------------------------
// Menu_Set_Sinus_Offset
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
//		K5 to exit
//
void Menu_Set_Sinus_Offset (void)
{
	char akey = NO_KEY_PRESSED;

    if (standalone)
        Write_Ok_Icons();
    DDS1_OFF();
    DC_mVolt = 0;
    DAC0_Update(0);

    Affiche_Text(WITH_ICON28,72, 7, GLCD_PIXEL_ON);   // "-> adjust R146 for DC null on TP7"
	do
	{	
		akey = GetUserAction();
	}
	while (akey != KEY_5);

	DDS1_ON();
}	// Menu_Set_Sinus_Offset


//-----------------------------------------------------------------------------
// Menu_Set_Voltage_Diff_Amp_CMRR
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// No jumper on J8, jumper fitted on J9, jumper fitted on J17
//
//		K5 to exit
//
void Menu_Set_Voltage_Diff_Amp_CMRR (void)
{
    char akey = NO_KEY_PRESSED;
    uchar oldFreqIndex = Freq_index;
    char chaine1[7];
    char chaine2[15];
    bit firstTime = true;

    Set_PGA2_Gain(RANGE_GAIN_1, false);
    Set_Measure_Mode(VOLTAGE_MODE);
    Set_Resistor_Sense_Range(1);

    if (standalone)
    {
        strcpy(chaine1, "Freq:");
        GLCD_draw_text(0,22, chaine1, GLCD_PIXEL_ON);
        strcpy(chaine1, "10 kHz");
        strcpy(chaine2, " 1 MHz");
        Write_Ok_Icons();
    }

    Affiche_Text(WITH_ICON28, 60, 37, GLCD_PIXEL_ON);  // "J9 set, J8 off, J17 set"

    do
    {
        if (firstTime)
        {
            firstTime = false;
            akey = MOVE_MARK_UP;
        }
        else
            akey = GetUserAction();

        if (akey == MOVE_MARK_UP)
        {
            Freq_index = Get_FreqIndex (10000);
            Set_Frequency(Freq_index);
            if (standalone)
            {         
	            GLCD_draw_text(40,22, chaine1, GLCD_PIXEL_OFF);
                GLCD_draw_text(40,35, chaine2, GLCD_PIXEL_ON);
            }
            Affiche_Text(WITH_ICON28, 72,35, GLCD_PIXEL_ON);  // "Adjust R31 for minimum voltage" 
        }
        else if (akey == MOVE_MARK_DOWN)
        {
            Freq_index = Get_FreqIndex (1000000);
            Set_Frequency(Freq_index);
            if (standalone)
            {          
	            GLCD_draw_text(40,22, chaine1, GLCD_PIXEL_ON);
                GLCD_draw_text(40,35, chaine2, GLCD_PIXEL_OFF);
            }                
            Affiche_Text(WITH_ICON28, 72, 36, GLCD_PIXEL_ON);  // "Adjust C44 for minimum voltage"
        }

        Set_Best_PGA2_Gain();
        Set_Measure(&Vp, &Vq);
        Vpp = sqrt(Vp * Vp + Vq * Vq) * HALF_PI;
        Vpp *= ADS_VREF / 0x800000; 
        sprintf (chaine, " %1.2f mV", Vpp * 1000);
        if (standalone)
        {
            strcat(chaine, "    ");
            GLCD_draw_text(WITH_ICON28, 90, chaine, GLCD_PIXEL_ON);
        } 
        else
        {
            strcpy(chaine2, message_MEASURE);
            strcat(chaine2, chaine);
            Send_Message(chaine2);
        }        	
    }
    while (akey != KEY_5);  // EXIT

    wait_ms(100);

	if (standalone)
        GLCD_clear();
    Set_Frequency(oldFreqIndex);
}	// Menu_Set_Voltage_Diff_Amp_CMRR


//-----------------------------------------------------------------------------
// Menu_Set_Language
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
void Menu_Set_Language (void)
{
    char akey = NO_KEY_PRESSED;
    uchar newLanguage = current_language;

    Write_OK_Exit_Icons();
    Menu_Kind = KIND_LANGUAGE;
    Menu_Index = newLanguage + 1;     // first index in Menu is 1
    Display_Menus();

    do
    {
        akey = GetUserAction();
        if (akey == MOVE_MARK_DOWN || akey == MOVE_MARK_UP)
            Menus_Move(akey);
    }
    while (!( (akey == KEY_5) || (akey == KEY_4)));     // Exit or OK

    if (akey == KEY_5)          // Exit 
        return;

    newLanguage = Menu_Index - 1;
    FLASH_Update(LANGUAGE_ADD, (char *) &newLanguage, CHAR_SIZE, 0);
    current_language = newLanguage;
} // Menu_Set_Language


//-----------------------------------------------------------------------------
// Menu_Sort
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
void Menu_Sort(void)
{
    float upperValue;
    float lowerValue;
    float xdata sortingValue;
    bit ok = false;
    char intPart, sortingKind;
    char akey = NO_KEY_PRESSED;

    sortingValue = ReadFloatInFLASH(SORTING_VAL_ADD);
    sortingKind = FLASH_ByteRead(SORTING_KIND_ADD, 0);

   switch (saved_Series)
    {
        case E96:
            upperValue = 1.01;
            lowerValue = 0.99;
            break;
        case E48:
            upperValue = 1.02;
            lowerValue = 0.98;
            break;
        case E24:
            upperValue = 1.05;
            lowerValue = 0.95;
            break;
        case E12:
            upperValue = 1.1;
            lowerValue = 0.9;
            break;
        case E6:
            upperValue = 1.2;
            lowerValue = 0.8;
            break;
    }

    upperValue *= sortingValue;
    lowerValue *= sortingValue;

    DisplayInverse = true;

    GLCD_select_font(( void * ) font_8x16, 8, 16);

    Value_to_Print = upperValue;

    intPart = Convert_Value_to_String(0, WITH_SUFFIX, sortingKind, false);
    Load_Expo(intPart, sortingKind, false);    // ex: Expo = "mH" or "H " or "kHz "
    if (standalone)
        strcpy(chaine, "< ");
    else
        chaine[0] = '\0';
    strcat(chaine, Buffer);
    strcat(chaine, " ");
    strcat(chaine, Expo);
    if (standalone)
        GLCD_draw_text(100, 45, chaine, GLCD_PIXEL_ON);
    else
    {
        strcpy(textMenu, message_MAX);
        strcat(textMenu, chaine);
        Send_Message(textMenu);
    }
    
    Value_to_Print = lowerValue;
    intPart = Convert_Value_to_String(0, WITH_SUFFIX, sortingKind, false);
    Load_Expo(intPart, sortingKind, false);
    if (standalone)
        strcpy(chaine, "> ");
    else
        chaine[0] = '\0';
    strcat(chaine, Buffer);
    strcat(chaine, " ");
    strcat(chaine, Expo);
    if (standalone)
        GLCD_draw_text(100, 60, chaine, GLCD_PIXEL_ON);
    else
    {
        strcpy(textMenu, message_MIN);
        strcat(textMenu, chaine);
        Send_Message(textMenu);
    }

    // ---- restore default font 6x11
	GLCD_select_font(( void * ) font_6x11, 6, 11);

    inSorting = true;
    if (standalone)
        Write_Exit_Icons();
    do
    {
        Process_Measurement(RANGE_GAIN_1);
	    Process_Datas();

        if ( (primaryValue <= upperValue) && (primaryValue >= lowerValue) )
        {
            if (standalone)
                GLCD_show_icon( ( void * ) PASS_Icon_48x24, 48, 24, 96, ICON4_POS, GLCD_PIXEL_ON );     // "PASS"
        }
        else
        {
            if (standalone)
                GLCD_show_icon( ( void * ) FAIL_Icon_48x24, 48, 24, 96, ICON4_POS, GLCD_PIXEL_OFF );    // "FAIL"
        }

        akey = GetUserAction();
    }
    while (akey != KEY_5);

    DisplayInverse = false;
    inSorting = false;
} // Menu_Sort


//-----------------------------------------------------------------------------
// DisplayValueInSeries
//-----------------------------------------------------------------------------
//
// Return Value : normalized mantisse
// Parameters   : index, series, reste
//
float DisplayValueInSeries(char index, char series, char reste)
{
    float mantisse;
    char i;

    if (series == 1)
        mantisse = Tab_E96[index];
    else if (series == 2)
        mantisse = Tab_E24[index];
  
    while (reste != 0)
    {
        mantisse /= 10;
        reste --;
    }

    if (mantisse < 10)
        i = 2;
    else if (mantisse < 100)
        i = 1;
    else
        i = 0;

    sprintf(Buffer, Table_format[i], mantisse); 
    strcat(Buffer, " ");
    strcat(Buffer, PrimaryExpo);
    if (standalone)
    {
        GLCD_clear_Row(WITH_ICON28, 72);
        GLCD_draw_text(WITH_ICON28,72, Buffer, GLCD_PIXEL_ON);
    }
    else
    {
        strcpy(chaine, message_PRIMARY);    // chaine = "PRIMAR "
        strcat(chaine, Buffer);
        Send_Message(chaine);
    }

    return mantisse;
} // DisplayValueInSeries


//-----------------------------------------------------------------------------
// SearchValueInSeries
//-----------------------------------------------------------------------------
//
// Return Value : index
// Parameters   : value, series, step
//
char SearchValueInSeries(uint value, char series, char step)
{
    char i = 0;

    if (series == 1 )
    {
        while ((Tab_E96[i] <= value) && (i < 97) )
        {
            i += step;
        }
        i -= step;
    }
    else if (series == 2 )
    {
        while ((Tab_E24[i] <= value) && (i < 25) )
        {
            i += step;
        }
        i -= step;
    }

    return i;
} // SearchValueInSeries


//-----------------------------------------------------------------------------
// Menu_Set_Sorting_Parameters
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
void Menu_Set_Sorting_Parameters(void)
{
    char akey = NO_KEY_PRESSED;
    char series, index, step, max;
    char reste = 0;
    uint value;
    float mantisse;
    bit change = true;

    if (standalone)
    {
        Write_OK_Exit_Icons();
        Menu_Kind = KIND_SERIES;
        Menu_Index = saved_Series + 1;  // first index in Menu is 1
        Display_Menus();

        do
        {
            akey = GetUserAction();
            if (akey == MOVE_MARK_DOWN || akey == MOVE_MARK_UP)
                Menus_Move(akey);
        }
        while (!( (akey == KEY_5) || (akey == KEY_4)));     // Exit or OK

        if (akey == KEY_5)          // Exit 
            return;

        akey = NO_KEY_PRESSED;
        saved_Series = Menu_Index - 1;
    }

    switch (saved_Series)
    {
        case E96:
            series = 1;
            max = 96;
            step = 1;
            break; 
        case E48:
            series = 1;
            max = 96;
            step = 2;
            break; 
        case E24:
            series = 2;
            max = 24;
            step = 1;
            break; 
        case E12:
            series = 2;
            max = 24;
            step = 2;
            break; 
        case E6:
            series = 2;
            max = 24;
            step = 4;
            break; 

    }

    if (standalone)
    {
        GLCD_clear();
        Write_OK_Exit_Icons();
    }

    Affiche_Text(WITH_ICON28, 50, 6, GLCD_PIXEL_ON);   //"Select normalized value"

    // search for DUT normalized value (100 to 999)
    mantisse = atof(PrimaryString);
    if (mantisse == 0.0)
        mantisse = 0.01;
    while (mantisse < 100)
    {
        mantisse *= 10;
        reste ++;
    };
    value = (uint) mantisse;

    index = SearchValueInSeries(value, series, step);
	GLCD_select_font(( void * ) font_8x16, 8, 16);

    change = true;
          
    // for first display
    mantisse = DisplayValueInSeries(index, series, reste);

    do
    {
        akey = GetUserAction();

        if (akey == MOVE_MARK_DOWN)
        {
            if (index > 0)
            {
                index -= step;
                change = true; 
            }
        }
        else if (akey == MOVE_MARK_UP)
        {
            if (index < max)
            {
                index += step;
                change = true; 
            } 
        }

        if (index == 0)
            Send_Message(message_MIN);
        if (index == max)
            Send_Message(message_MAX);

        if (change)
        {
           mantisse = DisplayValueInSeries(index, series, reste);
           change = false; 
        }
    }
    while (!( (akey == KEY_5) || (akey == KEY_4)));

    if (!standalone)
    {
        strcpy(chaine, message_END);    // chaine = "END "
        Send_Message(chaine);
    }
        

    // ---- restore default font 6x11
	GLCD_select_font(( void * ) font_6x11, 6, 11);

    if (akey == KEY_5)          // Exit 
        return;

    primaryValue = mantisse * pow(10, primaryIntPart);

    FLASH_Update(SERIES_ADD, (char xdata *) &saved_Series, CHAR_SIZE, 0);
    FLASH_Update(SORTING_VAL_ADD, (char xdata *) &primaryValue, FLOAT_SIZE, 0);
    FLASH_Update(SORTING_KIND_ADD, (char xdata *) &primaryKind, CHAR_SIZE, 0);
} // Menu_Set_Sorting_Parameters


//-----------------------------------------------------------------------------
// Menu_Set_Q_Limit
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Set the min Q for displaying the secondary parameter. (D = 1/Q)
// possible values are: 100, 200, 500, 1000, 2000, 5000, 50000
//
void Menu_Set_Q_Limit(void)
{
    char akey = NO_KEY_PRESSED;

    uint newQ = Q_No_Display_Secondary;

    Write_OK_Exit_Icons();
    sprintf(chaine, " Q = %u ",(uint)newQ);
    GLCD_draw_text(WITH_ICON28,72, chaine, GLCD_PIXEL_OFF);

    do
    {
        akey = GetUserAction();

        if (akey == MOVE_MARK_DOWN)
        {
            switch (newQ)
            {
                case MAX_Q:
                    newQ = 5000;
                    break;
                case 5000:
                    newQ = 2000;
                    break;
                case 2000:
                    newQ = 1000;
                    break;
                case 1000:
                    newQ = 500;
                    break;
                case 500:
                    newQ = 200;
                    break;
                case 200:
                    newQ = 100;
                    break;
                
            }
        }
        else if (akey == MOVE_MARK_UP)
        {
            switch (newQ)
            {
                case 100:
                    newQ = 200;
                    break;
                case 200:
                    newQ = 500;
                    break;
                case 500:
                    newQ = 1000;
                    break;
                case 1000:
                    newQ = 2000;
                    break;
                case 2000:
                    newQ = 5000;
                    break;
                case 5000:
                    newQ = MAX_Q;
                    break;
                
            }
        }
        if (newQ == MAX_Q)
            strcpy(chaine, " no limit  ");
        else
            sprintf(chaine, " Q = %u  ",(uint)newQ);
        GLCD_draw_text(WITH_ICON28, 72, chaine, GLCD_PIXEL_OFF);
    }
    while (!( (akey == KEY_5) || (akey == KEY_4)));     // Exit or OK


    if (akey == KEY_4)  // Ok
    {
        FLASH_Update(Q_LIMIT_ADD, (char *) &newQ, INT_SIZE, 0);
        Q_No_Display_Secondary = newQ;
    }
} // Menu_Set_Q_Limit


//-----------------------------------------------------------------------------
// Write_Measure_Icons
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Draw the icons to the right of the measuring screen
//
void Write_Measure_Icons (void)
{
    char str[14];    // room for "Average: FAST"

    GLCD_show_icon( ( void * ) Blank_Icon_48x24, 48, 24, 192, ICON1_POS, GLCD_PIXEL_ON );
    if (DC_mVolt == 0)
	    GLCD_show_icon( ( void * ) Trim_Icon_48x24, 48, 24, 192, ICON2_POS, GLCD_PIXEL_ON );
    else
        GLCD_show_icon( ( void * ) Bias0_Icon_48x24, 48, 24, 192, ICON2_POS, GLCD_PIXEL_ON );
    if (fast_mode)
    {
        GLCD_show_icon( ( void * ) SLOW_Icon_48x24, 48, 24, 192, ICON3_POS, GLCD_PIXEL_ON );
        strcpy(str, "Average FAST");
        GLCD_draw_text( 102, Y_POS_LINE_7, str, GLCD_PIXEL_ON);
    }
    else
    {
        GLCD_show_icon( ( void * ) FAST_Icon_48x24, 48, 24, 192, ICON3_POS, GLCD_PIXEL_ON );
        strcpy(str, "Average SLOW");
        GLCD_draw_text( 102, Y_POS_LINE_7, str, GLCD_PIXEL_ON);
    }
    GLCD_show_icon( ( void * ) R_Hold_Icon_48x24, 48, 24, 192, ICON4_POS, GLCD_PIXEL_ON );
	GLCD_show_icon( ( void * ) Menu_Icon_48x24, 48, 24, 192, ICON5_POS, GLCD_PIXEL_ON );
} // Write_Measure_Icons


//-----------------------------------------------------------------------------
// Write_Blank_Icons
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : Number of BLANK icon
//
// draws 'Number' BLANK icons to the right of the measuring screen
//
void Write_Blank_Icons (char number)
{
    char i;

    for (i = 0; i < number; i++)
        GLCD_show_icon( ( void * ) BLANK_icon, 28, 24, 212, 26*i, GLCD_PIXEL_OFF );
}// Write_Blank_Icons


//-----------------------------------------------------------------------------
// Write_Ok_Icons
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// write Ok icon on the the right of the measuring screen
//
void Write_Ok_Icons (void)
{
    Write_Blank_Icons(4);
	GLCD_show_icon( ( void * ) OK_icon, 28, 24, 212, ICON5_POS, GLCD_PIXEL_OFF );
} // Write_Ok_Icons


//-----------------------------------------------------------------------------
// Write_OK_Exit_Icons
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// write Ok & Exit icons on the right of the measuring screen
//
void Write_OK_Exit_Icons (void)
{
    Write_Blank_Icons(3);
	GLCD_show_icon( ( void * ) OK_icon,    28, 24, 212, ICON4_POS, GLCD_PIXEL_OFF );
	GLCD_show_icon( ( void * ) EXit_icon,  28, 24, 212, ICON5_POS, GLCD_PIXEL_OFF );
} // Write_OK_Exit_Icons


//-----------------------------------------------------------------------------
// Write_Exit_Icons
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// write Exit icon on the right of the measuring screen
//
void Write_Exit_Icons (void)
{
    Write_Blank_Icons(4);
	GLCD_show_icon( ( void * ) EXit_icon,   28, 24, 212, ICON5_POS, GLCD_PIXEL_OFF );
} // Write_Exit_Icons


//-----------------------------------------------------------------------------
// Set_Frequency
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : the index in Tab_freq[]
//
void Set_Frequency (uchar index)
{
	last_freq = freq;
	last_Freq_index = Freq_index;
	freq = Tab_freq[index];
	DDS_SetFrequency(freq);
	Freq_index = index;
    Set_SPS_WithFreq();

    Load_CF();
} // Set_Frequency


//-----------------------------------------------------------------------------
// Get_FreqIndex
//-----------------------------------------------------------------------------
//
// Return Value : the index in Tab_freq[]
// Parameters   : the frequency (Hz)
//
uchar Get_FreqIndex (float frequency)
{
    uchar index = FREQ_MEM_SIZE - 1;

    while ((Tab_freq[index] > frequency) && (index > MIN_FREQ_INDEX_START) )
        index--;
    return (index);
} // Get_FreqIndex


//-----------------------------------------------------------------------------
// Buffer_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Initializes the ring buffer.
//
void Buffer_Init (void)
{
	in_Buffer = 0;
	buffer_full = false;
	Buf_counter = 0;
    buffer_Rs[0] = 0.0;
	buffer_Xs[0] = 0.0;
} // Buffer_Init


//-----------------------------------------------------------------------------
// Buffer_Add_Data
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// add data to buffer.
//
void Buffer_Add_Data (float rs, float xs)
{
    char bufsize;

    if (fast_mode)
        bufsize = 2;
    else
        bufsize = BUFSIZE_DATA_MAX1;
	buffer_Rs[in_Buffer] = rs;
	buffer_Xs[in_Buffer] = xs;
    in_Buffer++;
    if (in_Buffer >= bufsize)		// end of circular buffer?
    {
		in_Buffer = 0;					// wrap around
		buffer_full = true;
    }
} // Buffer_Add_Data


//-----------------------------------------------------------------------------
// Buffer_Read
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : pointers to variables to update
//
// reads the buffer data and averages the values
//
void Buffer_Read(float* rs, float* xs)
{
    uchar i, imax;
    float x = 0.0;
	float y = 0.0;
    char bufsize;

    if (fast_mode)
        bufsize = 2;
    else
        bufsize = BUFSIZE_DATA_MAX1;

    if (buffer_full)
        imax = bufsize;
    else
        imax = in_Buffer;

    for (i = 0; i < imax; i++)
    {
        x += buffer_Rs[i];
	    y += buffer_Xs[i];
    }

    *rs = x / imax;
	*xs = y / imax;
} // Buffer_Read


//-----------------------------------------------------------------------------
// /INT0 ISR
//-----------------------------------------------------------------------------
//
// Whenever a negative edge appears on INT0 input (ENCOD_A), ...
// The interrupt pending flag is automatically cleared by vectoring to the ISR
//
// Called when the rotary encoder is moved
//
void INT_A_ISR (void) interrupt INTERRUPT_INT0
{
    uint count;

    IE &= 0xFA;                         // 1111 1010 -> disable INT0 and INT1 interrupts
    count = count0;
    do
        count--;
    while(count != 0);

    if (ENCOD_A == 0)
        Set_Encoder_action();
    IE |= 0x05;                         // 0000 0101 -> enable INT0 and INT1 interrupts
} // /INT0 ISR


//-----------------------------------------------------------------------------
// /INT1 ISR
//-----------------------------------------------------------------------------
//
// Whenever a negative edge appears on INT1 input (ENCOD_B), ...
// The interrupt pending flag is automatically cleared by vectoring to the ISR
//
// Called when the rotary encoder is moved
//
void INT_B_ISR(void) interrupt INTERRUPT_INT1
{
    uint count;

    IE &= 0xFA;                         // 1111 1010 -> disable INT0 and INT1 interrupts
    count = count0;
    do
        count--;
    while(count != 0);
    
    if (ENCOD_B == 0)
        Set_Encoder_action();
    IE |= 0x05;                         // 0000 0101 -> enable INT0 and INT1 interrupts
}


//-----------------------------------------------------------------------------
// Set_Encoder_action
//-----------------------------------------------------------------------------
//
// Called by INT0 and INT1 interrups routine
//
void Set_Encoder_action(void)
{
    if (ENCOD_A == 1 && ENCOD_B == 1) encodPOS = 3;
    if (ENCOD_A == 0 && ENCOD_B == 1) encodPOS = 2;
    if (ENCOD_A == 0 && ENCOD_B == 0) encodPOS = 0;
    if (ENCOD_A == 1 && ENCOD_B == 0) encodPOS = 1;

    if (encodPOS == 0)
    {
#ifndef DEBUG_3
        if (encodOldPOS == 1) 
            cpt_encod++;
        else if (encodOldPOS == 2) 
            cpt_encod--;
#else
        if (encodOldPOS == 1) 
            cpt_encod--;
        else if (encodOldPOS == 2) 
            cpt_encod++;
#endif
    }
    else
        encodOldPOS = encodPOS;
} // Set_Encoder_action


//-----------------------------------------------------------------------------
// COMP0 ISR
//-----------------------------------------------------------------------------
//
// Whenever a positive edge appears on CP0+ input (positive edge on output)
//
// Detection of overvoltage in PSD input.
//
void COMP0_RISING_ISR (void) interrupt INTERRUPT_COMPARATOR0R
{
    EIE1 &= 0xDF;								    // 1101 1111 ->	disable CP0 rising edge interrupts
	CP0RIF = 0;										// clear CP0 rising-edge Interrup Flag
	overVoltage = true;

    SFRPAGE = CONFIG_PAGE;
} // COMP0 ISR


//-----------------------------------------------------------------------------
// Set_COMP0_Interrup
//-----------------------------------------------------------------------------
//
void Set_COMP0_Interrup (void)
{
    SFRPAGE = CPT0_PAGE;   
	CP0RIF = 0;									// clear CP0 rising-edge Flag
	EIE1 |= 0x20;								// 0010 0000 ->	enable CP0 rising edge interrupts

	SFRPAGE = CONFIG_PAGE;

    // open-circuit on CP0+ allowing the over-voltage detection.
    INPUT_CP0 = 1;
    wait_us(50);
} // Set_COMP0_Interrup


//-----------------------------------------------------------------------------
// Clear_COMP0_Interrup
//-----------------------------------------------------------------------------
//
void Clear_COMP0_Interrup (void)
{
    EIE1 &= 0xDF;								// 1101 1111 ->	disable CP0 rising edge interrupts
    SFRPAGE = CPT0_PAGE;  
	CP0RIF = 0;									// clear CP0 rising-edge Flag

	SFRPAGE = CONFIG_PAGE;
    // short-circuit on CP0+ -> comparator CP0 is inhibited.
    INPUT_CP0 = 0;
    wait_us(50);
} // Clear_COMP0_Interrup


//-----------------------------------------------------------------------------
// COMP1R_ISR
//-----------------------------------------------------------------------------
//
// Whenever a negative edge appears on CP1- input (positive edge on output)
//
//	Detection of key, or the encoder button, pressed.
//  For debug purposes, there is a short flash of D12
//
//  if <long Keypressed> there is a short blink of the display
//
void COMP1R_ISR (void) interrupt INTERRUPT_COMPARATOR1R
{
    uint count;
	char Key, SW, KeyMem, Port_1;
    bit signal = true;

    EIE1 &= 0x7F;								// 0111 1111 ->	disable CP1 rising edge interrupts

    SFRPAGE = CPT1_PAGE;   
	CP1RIF = 0;									// clear CP1 rising-edge Flag

	SFRPAGE = CONFIG_PAGE;

    J23 = 0;
    for (count = 40000; count > 0; count--);
    J23 = 1;

    Port_1 = ~P1;                               
    SW = ~ENCOD_SW;                             // P3.6

 	SW &= 0x01; 
	KeyMem = (Port_1 & 0x07) | (SW << 4);       // Keys are mapped on P1.0 to P1.2  

    // Test if the key is pressed for a long time
    count_key_pressed = 0;
    longKeypressed = false;
    
    SFRPAGE = TMR4_PAGE;
    permitCP1_ISR = false;
	TR4 = 1;							    	// Start Timer4
	do
	{
        Port_1 = ~P1; 
		SW = ~ENCOD_SW;
        SW &= 0x01;
		Key = (Port_1 & 0x07) | (SW << 4);
        if (count_key_pressed > LONG_PRESSED && signal)
        {
            signal = false;
            BACKLIGHT = ~BACKLIGHT;
            for (count = 50000; count > 0; count--);
            BACKLIGHT = ~BACKLIGHT;
            longKeypressed = true;
        }
	}
	while(Key != 0);

    TR4 = 0;								    // Stop Timer4
    TF4 = 0;
    TMR4 = 0;                                   // reset counter 4
    permitCP1_ISR = true;
    count_key_pressed = 0;
    TR4 = 1;   							    	// Start Timer4

    theKey = KeyMem;
    // Re-Enabling CP1 rising edge interrupts is performed by the Timer4 ISR with a time-delay
    SFRPAGE = CONFIG_PAGE;
} // COMP1R_ISR



//-----------------------------------------------------------------------------
// TIMER4_ISR
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Here we process the Timer4 interrupt, called each 10.7 ms (SYSCLK / 12 time base)
//
void TIMER4_ISR(void) interrupt INTERRUPT_TIMER4
{
	TF4 = 0;                         	// reset Interrupt flag

	if (count_key_pressed < LONG_PRESSED + 2)
    {
        count_key_pressed++;
    }

    if (permitCP1_ISR)
    {
        if ( count_key_pressed > (LONG_PRESSED / 10) )
        {
            TR4 = 0;								    // Stop Timer4
            TF4 = 0;
            TMR4 = 0;                                   // reset counter 4

            permitCP1_ISR = false;

            SFRPAGE = CPT1_PAGE;
            CP1RIF = 0;									// clear CP1 rising-edge Flag   
	        EIE1 |= 0x80;								// 1000 0000 ->	enable CP1 rising edge interrupts
        }
    }

    SFRPAGE = CONFIG_PAGE;
} // TIMER4_ISR



//-----------------------------------------------------------------------------
// Set_PGA2_Gain
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : Index:   RANGE_GAIN_1 (1) for gain = 1, 
//						   RANGE_GAIN_3 (2) for gain = 3.16, 
//						   RANGE_GAIN_10 (3) for gain = 10.
//
//                GainUpdate: if false only change gain without set PGA2_Gain_I & PGA2_Gain_U
//
// put on PGA2_Gain_I or PGA2_Gain_U the real value
//
// **** It is assumed that SFRPAGE = CONFIG_PAGE.
//
void Set_PGA2_Gain(unsigned char index, bit GainUpdate)
{
    float the_gain;

    // disable the 3 amplifiers -> set the P5^x pins to 0
    P5 &= 0xE3;		// 1110 0011    PGA2_G_10, PGA2_G_3, PGA2_G_0 to 0
    wait_us(10);

    switch(index)
    {
        default:
        case RANGE_GAIN_1:
            P5 |= 0x04;     // 0000 0100
            if (GainUpdate)
                the_gain = G1_PGA2;
            break;

        case RANGE_GAIN_3:
            P5 |= 0x08;     // 0000 1000
            if (GainUpdate)
                the_gain = G3_PGA2;
            break;

        case RANGE_GAIN_10:
            P5 |= 0x10;     // 0001 0000
            if (GainUpdate)
                the_gain = G10_PGA2;
            break;
    }

    wait_us(1000);

    if (GainUpdate)
    {
        if (Measure_Mode == CURRENT_MODE)
        {
	        PGA2_Gain_I = the_gain;
            PGA2_Range_I = index;
        }
        else if (Measure_Mode == VOLTAGE_MODE)
        {
	        PGA2_Gain_U = the_gain;
            PGA2_Range_U = index;
        }
    }
} // Set_PGA2_Gain


//-----------------------------------------------------------------------------
// Set_Measure_Mode
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : VOLTAGE_MODE (0) or CURRENT_MODE (1)
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
void Set_Measure_Mode (char mode)
{
    SFRPAGE = CONFIG_PAGE;

	// Close the good switch
    if (mode == CURRENT_MODE)
    {
        UISELECT_U = 1;
        wait_us(50);			
	    UISELECT_I = 0; 
    }        
    else if (mode == VOLTAGE_MODE)
    {
        UISELECT_I = 1;
        wait_us(50);			
	    UISELECT_U = 0; 
    }
                     
	Measure_Mode = mode;
} // Set_Measure_Mode


//-----------------------------------------------------------------------------
// Set_Best_Sense_Resistor
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// With PGA2 gain of 1, increase R_Range, and see if an overvoltage occured
//
void Set_Best_Sense_Resistor (void)
{
	uchar i, j;

    j = R_Range;
    overVoltage = false;
    for (i = 1; i <= NB_RANGE; i++)
	{
		Set_Resistor_Sense_Range(i);
        Set_COMP0_Interrup();
        if (!wait_overflow())
            overVoltage = true; // 
		Clear_COMP0_Interrup();
		if (overVoltage )
		{
			if (i > 1)
				i--;
			Set_Resistor_Sense_Range(i);
			overVoltage = false;
			break;
		}		
	}
    if (R_Range != j)
        Buffer_Init();
} // Set_Best_Sense_Resistor


//-----------------------------------------------------------------------------
// Set_Best_PGA2_Gain
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Set PGA2 gain to 3 (and 10), and see if an overvoltage occured
//
void Set_Best_PGA2_Gain (void)
{
    overVoltage = false;
    Set_PGA2_Gain(RANGE_GAIN_1, true);
    wait_us(300);
	Set_COMP0_Interrup();
	Set_PGA2_Gain(RANGE_GAIN_3, true);
	if (!wait_overflow())
        overVoltage = true;
	Clear_COMP0_Interrup();
	if (overVoltage)
	{
		Set_PGA2_Gain(RANGE_GAIN_1, true);
	}
	else
	{
		Set_COMP0_Interrup();		
		Set_PGA2_Gain(RANGE_GAIN_10, true);
		wait_overflow();
		Clear_COMP0_Interrup();
		if (overVoltage)
		{
			Set_PGA2_Gain(RANGE_GAIN_3, true);
		}
	}
	overVoltage = false;
} // Set_Best_PGA2_Gain


//-----------------------------------------------------------------------------
// Set_Phase
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : 0 or 90 or 180 or 270
//
void Set_Phase (int degre)
{
    int deltaPhase;

    if (freq > 1500000)
        deltaPhase = -200;
    else if (freq > 1000000)
        deltaPhase = -100;
    else
        deltaPhase = 0;

	switch(degre)
    {
        case 90:
            DDS_Load_PhaseReg(PHI_DDS1_90 + deltaPhase, DDS1_ONLY);
         	break;
        case 180:
         	DDS_Load_PhaseReg(PHI_DDS1_180 + deltaPhase, DDS1_ONLY);
         	break;
      	case 270:
         	DDS_Load_PhaseReg(PHI_DDS1_270 + deltaPhase, DDS1_ONLY);
         	break;
        default:
      	case 0:
         	DDS_Load_PhaseReg(PHI_DDS1_0 + deltaPhase, DDS1_ONLY);
         	break;
   }
} // Set_Phase


//-----------------------------------------------------------------------------
// Set_Measure
//-----------------------------------------------------------------------------
//
// Return Value :   OK_MEASURE (-1) if valide measurements, error code if not.
// Parameters   :   pointer on InPhase data, pointer on InQuadrature data.
//
// Four measurements, offset by 90�, are sufficient to calculate all the parameters of the sinusoid input.
//
// take in account the gain of the differential voltage amplifier.

char Set_Measure(float* InPhase_result, float* InQuadrature_result)
{
    bit ok;
    float xdata resultP, resultQ;
    long resultA, resultB;

    // 1 - Quadrature measurements
	// Phi 90�
    Set_Phase(90);
    wait_ms(wait_steady_PSD);
    ok = Get_Best_ADS_Measure(&resultA);
	if (!ok)
	    return 9;

	// Phi 270�
    Set_Phase(270);
	wait_ms(wait_steady_PSD);
    ok = Get_Best_ADS_Measure(&resultB);
	if (!ok)
	    return 27;
    resultQ = (float)((resultA - resultB) >> 1);

    // 2 - In phase measurements
	// Phi 180�
    Set_Phase(180);
	wait_ms(wait_steady_PSD);
    ok = Get_Best_ADS_Measure(&resultA);
	if (!ok)
	    return 18;

	// Phi 0�
    Set_Phase(0);
	wait_ms(wait_steady_PSD);
    ok = Get_Best_ADS_Measure(&resultB);
	if (!ok)
	    return 0;
    resultP = (float)((resultA - resultB) >> 1);

    if (Measure_Mode == VOLTAGE_MODE)
    {
        resultP /= DIFF_AMP_U_GAIN;
        resultQ /= DIFF_AMP_U_GAIN;
    }
    else    // CURRENT_MODE
    {
        // current at DUT level (I/=Rsense)    
        resultP /= Rsense;
        resultQ /= Rsense;

    }

    *InPhase_result = resultP;
    *InQuadrature_result = resultQ;

	return OK_MEASURE;
} // Set_Measure



//-----------------------------------------------------------------------------
// Process_Measurement
//-----------------------------------------------------------------------------
//
// Return Value : none
// Parameters:    PGA2 range (RANGE_GAIN_1, RANGE_GAIN_3 or RANGE_GAIN_10
//                used during calibration  
//
// It's assumed that CP0 rising edge interrupts disabled
//
// When the function returns, the variables Vp, Vq, Ip and Iq are the values 
// of the phase and quadrature components of the voltage and current in input of the PSD.
//
void Process_Measurement (uchar theRange)
{
    char returnValue;
    char xdata chaine1[14];
    char i;


	// Set ADS_PGA gain to 1, and PGA2 gain to 1, avoiding overload
	Set_PGA2_Gain(RANGE_GAIN_1, false);
	ADS_SetPGA_Range(0);


	// ******* CURRENT mode *************************
    Set_Measure_Mode(CURRENT_MODE);         // current measurement
    if (!in_calibration && !rangeHold)
    {
        Set_Best_Sense_Resistor();	
    }
    else    // don't change the R_Range
        wait_us(10);

    if (!inSorting && !in_calibration)
    {
        if (display_Range)
            sprintf(chaine1, "R%u  U%u  I%u ", (int)R_Range, (int)PGA2_Gain_U, (int)PGA2_Gain_I);
        else
            sprintf(chaine1, "             ");

        i = strcmp (saved_chaine, chaine1);
        strcpy (saved_chaine, chaine1);
        if (i != 0) // do not display the same message again!
        {
            if (standalone)
                GLCD_draw_text( 102, Y_POS_LINE_6, chaine1, GLCD_PIXEL_ON);
            else
            {
                strcpy(chaine, message_RUI);
                strcat(chaine, chaine1);
                Send_Message(chaine);
            }
        }
    }

#ifdef DEBUG_2
    if (!in_calibration && !noPGA_Gain)
#else
    if (!in_calibration)
#endif
        Set_Best_PGA2_Gain();
    else 
        Set_PGA2_Gain(RANGE_GAIN_1, true);  // always gain = 1, during calibration

    //if (!in_calibration)
    {
        SYNCH_CDE = 1;
        while (!SYNCH_OUT);
        SYNCH_CDE = 0;
    }
    SYNCHRO_SCOPE = 1;
    returnValue = Set_Measure(&Ip, &Iq);
    if (returnValue != OK_MEASURE)
    {
        errorMeasure++;
        return;
    }

	// ******* VOLTAGE mode ************************** 
	Set_PGA2_Gain(RANGE_GAIN_1, false);
	Set_Measure_Mode(VOLTAGE_MODE);         // voltage measurement

    if (!in_calibration)
    {
#ifdef DEBUG_2
        if(!noPGA_Gain)       
            Set_Best_PGA2_Gain();
        else
            Set_PGA2_Gain(RANGE_GAIN_1, true);
#else
        Set_Best_PGA2_Gain();
#endif
    }
    else
        Set_PGA2_Gain(theRange, true);      // gain = <theRange>, during calibration

    //if (!in_calibration)
    {
        SYNCH_CDE = 1;
        while (!SYNCH_OUT);
        SYNCH_CDE = 0;
    }

    SYNCHRO_SCOPE = 0;
    returnValue = Set_Measure(&Vp, &Vq);
    if (returnValue != OK_MEASURE)
    {
        errorMeasure++;
        return;
    }

    errorMeasure = 0;
} // Process_Measurement




//-----------------------------------------------------------------------------
// ReadFloatInFLASH
//-----------------------------------------------------------------------------
//
// Return Value : Float read in FLASH
// Parameters   : the address to read 
//
float ReadFloatInFLASH(FLADDR source)
{
    float theData;

    FLASH_Read((char *) &theData, source, FLOAT_SIZE, 0);
    return theData;
}


//-----------------------------------------------------------------------------
// Load_CF_fromTable
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
void Load_CF_fromTable(char freqindex)
{
    int k = freqindex * FLOAT_SIZE;

    // read Table_CFxxxx[k] in Flash

    CFX_R1 = ReadFloatInFLASH(TABLE_CFX_R1_ADD + k);
    CFR_R1 = ReadFloatInFLASH(TABLE_CFR_R1_ADD + k);
    CFX_R2 = ReadFloatInFLASH(TABLE_CFX_R2_ADD + k);
    CFR_R2 = ReadFloatInFLASH(TABLE_CFR_R2_ADD + k);
    CFX_R3 = ReadFloatInFLASH(TABLE_CFX_R3_ADD + k);
    CFR_R3 = ReadFloatInFLASH(TABLE_CFR_R3_ADD + k);
    CFX_R4 = ReadFloatInFLASH(TABLE_CFX_R4_ADD + k);
    CFR_R4 = ReadFloatInFLASH(TABLE_CFR_R4_ADD + k);
    REAL_G3 = ReadFloatInFLASH(TABLE_REAL_G3_ADD + k);
    IMAG_G3 = ReadFloatInFLASH(TABLE_IMAG_G3_ADD + k);
    REAL_G10 = ReadFloatInFLASH(TABLE_REAL_G10_ADD + k);
    IMAG_G10 = ReadFloatInFLASH(TABLE_IMAG_G10_ADD + k);

    TrimShortOk = (Tab_Trim_Short_OK[freqindex] == 1);
    XsTrimShort = Tab_Xs_Trim_Short[freqindex];
    RsTrimShort = Tab_Rs_Trim_Short[freqindex];

    TrimOpenOk = (Tab_Trim_Open_OK[freqindex] == 1);
    XsTrimOpen = Tab_Xs_Trim_Open[freqindex];
    RsTrimOpen = Tab_Rs_Trim_Open[freqindex];
}


//-----------------------------------------------------------------------------
// Load_CF
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Put in CFX_xx, CFR_xx etc, the correction data for the current frequency
//
void Load_CF(void)
{
    int k;
    uchar lowindex, highindex, i;
    float xdata freqLow, freqHigh, pourcent;
    float xdata correction;

    if (!userDefinedFrequency)
    {
        Load_CF_fromTable(Freq_index);
        return;
    }

    for (i = MIN_FREQ_INDEX_START; i < FREQ_MEM_SIZE; i++)
    {
        if (Tab_freq[i] == freq)
        {
            Load_CF_fromTable(i);
            return;
        }
    }

    lowindex = Get_FreqIndex(freq);
    highindex = lowindex + 1;
    freqLow = Tab_freq[lowindex];
    freqHigh = Tab_freq[highindex];
    pourcent = (freq - freqLow) / (freqHigh - freqLow);

    k = highindex * FLOAT_SIZE;

    Load_CF_fromTable(lowindex);
    
    correction = ( ReadFloatInFLASH(TABLE_CFX_R1_ADD + k) - CFX_R1 ) * pourcent;
    CFX_R1 += correction;

    correction = ( ReadFloatInFLASH(TABLE_CFR_R1_ADD + k) - CFR_R1 ) * pourcent;
    CFR_R1 += correction;

    correction = ( ReadFloatInFLASH(TABLE_CFX_R2_ADD + k) -  CFX_R2 ) * pourcent;
    CFX_R2 += correction;

    correction = ( ReadFloatInFLASH(TABLE_CFR_R2_ADD + k) - CFR_R2 ) * pourcent;
    CFR_R2 += correction;

    correction = ( ReadFloatInFLASH(TABLE_CFX_R3_ADD + k) - CFX_R3 ) * pourcent;
    CFX_R3 += correction;

    correction = ( ReadFloatInFLASH(TABLE_CFR_R3_ADD + k) - CFR_R3 ) * pourcent;
    CFR_R3 += correction;

    correction = ( ReadFloatInFLASH(TABLE_CFX_R4_ADD + k) - CFX_R4 ) * pourcent;
    CFX_R4 += correction;

    correction = ( ReadFloatInFLASH(TABLE_CFR_R4_ADD + k) - CFR_R4 ) * pourcent;
    CFR_R4 += correction;

    correction = ( ReadFloatInFLASH(TABLE_REAL_G3_ADD + k) - REAL_G3 ) * pourcent;
    REAL_G3 += correction;

    correction = ( ReadFloatInFLASH(TABLE_IMAG_G3_ADD + k) - IMAG_G3 ) * pourcent;
    IMAG_G3 += correction;

    correction = ( ReadFloatInFLASH(TABLE_REAL_G10_ADD + k) - REAL_G10 ) * pourcent;
    REAL_G10 += correction;

    correction = ( ReadFloatInFLASH(TABLE_IMAG_G10_ADD + k) - IMAG_G10 ) * pourcent;
    IMAG_G10 += correction;

    TrimShortOk = (Tab_Trim_Short_OK[highindex] == 1) && (Tab_Trim_Short_OK[lowindex] == 1);
    if (TrimShortOk)
    {
        RsTrimShort = (Tab_Rs_Trim_Short[highindex] - Tab_Rs_Trim_Short[lowindex]) * pourcent + Tab_Rs_Trim_Short[lowindex];
        XsTrimShort = (Tab_Xs_Trim_Short[highindex] - Tab_Xs_Trim_Short[lowindex]) * pourcent + Tab_Xs_Trim_Short[lowindex];
    }

    TrimOpenOk = (Tab_Trim_Open_OK[highindex] == 1) && (Tab_Trim_Open_OK[lowindex] == 1);
    if (TrimOpenOk)
    {
        RsTrimOpen = (Tab_Rs_Trim_Open[highindex] - Tab_Rs_Trim_Open[lowindex]) * pourcent + Tab_Rs_Trim_Open[lowindex];
        XsTrimOpen = (Tab_Xs_Trim_Open[highindex] - Tab_Xs_Trim_Open[lowindex]) * pourcent + Tab_Xs_Trim_Open[lowindex];
    }
} // Load_CF



//-----------------------------------------------------------------------------
//Process_Gain_Corrections
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None 
//
// process corrections on Vp, Vq, Ip & Iq according PGA2 gains
// The new values for Vp, Vq, Ip and Iq are those in the input of PGA2
//
void Process_Gain_Corrections(void)
{
    if (!PGA_G3_ok || !PGA_G10_ok) // no calibration, apply amplitude correction only.
    {
        if (PGA2_Gain_U != 1)
        {
            Vp /= PGA2_Gain_U;
            Vq /= PGA2_Gain_U;
        }

        if (PGA2_Gain_I != 1)
        {
            Ip /= PGA2_Gain_I;
            Iq /= PGA2_Gain_I;
        }

        return;
    }

    // calibration done
    if (PGA2_Range_I == 2)          // gain 3
    {
        Gain_Ip = REAL_G3;
        Gain_Iq = IMAG_G3;
    }
    else if (PGA2_Range_I == 3)     // gain 10
    {
        Gain_Ip = REAL_G10;
        Gain_Iq = IMAG_G10;
    }
    else if (PGA2_Range_I == 1)     // gain 1
    {
        Gain_Ip = 1.0;
        Gain_Iq = 0.0;
    }

    if (PGA2_Range_U == 2)          // gain 3
    {
        Gain_Up = REAL_G3;
        Gain_Uq = IMAG_G3;
    }
    else if (PGA2_Range_U == 3)     // gain 10
    {
        Gain_Up = REAL_G10;
        Gain_Uq = IMAG_G10;
    }
    else if (PGA2_Range_U == 1)     // gain 1
    {
        Gain_Up = 1.0;
        Gain_Uq = 0.0;
    }

    if (PGA2_Range_U != RANGE_GAIN_1 || PGA2_Range_I != RANGE_GAIN_1) // one path is with a gain != 1
    {
        if (PGA2_Gain_I != 1) // if that�s the path of the current
            Div_Complex(Ip, Iq, Gain_Ip, Gain_Iq, &Ip, &Iq);

        if (PGA2_Gain_U != 1) // if that�s the path of the voltage
            Div_Complex(Vp, Vq, Gain_Up, Gain_Uq, &Vp, &Vq);
    }
}   // Process_Gain_Corrections


//-----------------------------------------------------------------------------
// Get_Standard_Values
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None 
//
// Get Rstdm and Xstdm values according range
//
void Get_Standard_Values(void)
{
    if (Calibration_Factor_R1_ok && (R_Range == 1))
    {
        Rstdm = CFR_R1;
        Xstdm = CFX_R1;
    }
    else if (Calibration_Factor_R2_ok && (R_Range == 2))
    {
        Rstdm = CFR_R2;
        Xstdm = CFX_R2;
    }
    else if (Calibration_Factor_R3_ok && (R_Range == 3))
    {
        Rstdm = CFR_R3;
        Xstdm = CFX_R3;
     }
     else if (Calibration_Factor_R4_ok && (R_Range == 4))
     {
        Rstdm = CFR_R4;
        Xstdm = CFX_R4;
     }
     else
     {
        Rstdm = Rsense;
        Xstdm = 0.0;
     }
} // Get_Standard_Values


//-----------------------------------------------------------------------------
// Do_CF
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : with_Trim 
//
// if <with_Trim> process corrections with Calibration Factor and calculate Xs & Rs
// according Zdut = Zstd * (Zopen - Zstdm) * (Zxm - Zshort) / [(Zstdm - Zshort) * (Zopen - Zxm)]
//
void Do_CF(bit with_Trim)
{
    static float Z0;
    float a;
    float Rsm, Xsm;             // the measured values
    float RA, XA, RB, XB;
    float xdata NumReal, NumImag, DenReal, DenImag;


    Div_Complex(Vp, Vq, Ip, Iq, &Rsm, &Xsm);            // measured values: Zxm = (Vp+jVq)/(Ip+jIq) = Rsm + jXsm

    Z = sqrt(Xsm * Xsm + Rsm * Rsm);
	a = Z / Z0;

	if ( a > 1.1 || a < 0.9)
	{
        Buffer_Init();
	}
    	
    Z0 = Z;

    // averaging
    Buffer_Add_Data(Rsm, Xsm);
	Buffer_Read(&Rsm, &Xsm);

    if (TrimShortOk && TrimOpenOk && with_Trim)
    {    
        // ***** OPEN/SHORT/LOAD compensation:
        // Zdut = Zstd * (Zopen - Zstdm)*(Zxm - Zshort) / [(Zstdm - Zshort) * (Zopen - Zxm)]

        // 1 -> Num = (Zopen - Zstdm)*(Zxm - Zshort)

        // (Zopen - Zstdm)
        RA = RsTrimOpen - Rstdm;
        XA = XsTrimOpen - Xstdm;
        // (Zxm - Zshort)
        RB = Rsm - RsTrimShort;
        XB = Xsm - XsTrimShort;

        Mul_Complex(RA, XA, RB, XB, &NumReal, &NumImag);

        // 2 -> Den = (Zstdm - Zshort) * (Zopen - Zxm)

        // (Zstdm - Zshort)
        RA = Rstdm - RsTrimShort;
        XA = Xstdm - XsTrimShort;
        // (Zopen - Zxm)
        RB = RsTrimOpen - Rsm;
        XB = XsTrimOpen - Xsm;

        Mul_Complex(RA, XA, RB, XB, &DenReal, &DenImag);

        // 3 -> (Num / Den)
        Div_Complex(NumReal, NumImag, DenReal, DenImag, &Rs, &Xs);

        // 4 -> result * Zstd
        Rs *= R_Standard;
        Xs *= R_Standard;

    }// if (TrimShortOk && TrimOpenOk)
    else
    {
        Rs = Rsm;
        Xs = Xsm;
    }
} // Do_CF



//-----------------------------------------------------------------------------
// Process_Datas
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None 
//
// process Corrections with Calibration Factor and calculate Xs & Rs
// process Vpp et Ipp calculation of test signal
//
void Process_Datas(void)
{
    static uchar theRange = 0;
    static uchar indexFreq = 0;

    if (errorMeasure > 10)
    {
        Display_Error();
        return;
    }

    if (R_Range != theRange || Freq_index != indexFreq)
    {
        Get_Standard_Values();      // Get Rstdm and Xstdm values according range (and frequency)
        if (!in_calibration)
        {
            theRange = R_Range;
            indexFreq = Freq_index; 
        }
    }

    Pulsation = TWO_PI * freq;

    Process_Gain_Corrections();     // process corrections on Vp, Vq, Ip & Iq according PGA2 gains

    Vpp = sqrt(Vp * Vp + Vq * Vq) * HALF_PI / reductionLevel;
	Ipp = sqrt(Ip * Ip + Iq * Iq) * HALF_PI / reductionLevel;
    Vpp *= ADS_VREF / 0x800000;
    Ipp *= ADS_VREF / 0x800000;

    Do_CF(true);                    // process corrections with Calibration Factor and calculate Xs & Rs

    isCapacitive = Xs < 0;
	Q = fabs(Xs / Rs); 
    if (Q_No_Display_Secondary == MAX_Q)
        no_display_secondary = false;
    else
        no_display_secondary = (Q > Q_No_Display_Secondary) || (Q < 1.0 / Q_No_Display_Secondary);

    if (Q > 1.0)
		Auto_parameter = REACTIVE_CIRCUIT;		// L or C is dominant param. 
	else	  
		Auto_parameter = RESISTIVE_CIRCUIT;		// R is dominant param.

	Phi = atan(Xs / Rs);
    if (Xs < 0.0 && Phi > 0.0 && Q_No_Display_Secondary != MAX_Q)
        no_display_secondary = true;	
    SP_coeff = 1 + 1 / (Q * Q);
	Z = sqrt(Xs * Xs + Rs * Rs);

    if (isCapacitive)
     	Cs = -1 / Pulsation / Xs;
  	else
     	Ls = Xs / Pulsation;
 
    if (Auto_Model == 0)
    {
        if (Z > Z_CHANGE_MODEL) 	 
            S_P_Mode = 2;							// parallel
        else      
            S_P_Mode = 1;							// series
    }
    else
        S_P_Mode = Auto_Model;

    // ----- Display the results -----------
    if (Auto_parameter == RESISTIVE_CIRCUIT)
    {
        highAccuracy = false;
		if(!Process_Circuit_Rs())
            return;
    }
    else if (Auto_parameter == REACTIVE_CIRCUIT)
    {
        highAccuracy = false;
		if(!Process_Circuit_Xs( ))
            return;
    }

    if (!inSorting)
    {
        if (!Display_Z())
            return;
        if (!Display_Q_D(false))
            return;
        if (!Display_PHI())
            return;
        if (!Display_Vx_Ix())
            return;
        if (!Display_Mode())
            return;
    }
} // Process_Datas


//-----------------------------------------------------------------------------
// Display_Error
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None 
// 
void Display_Error(void)
{
    // clear Circuit
    GLCD_show_icon((void *) blank, ICON_WIDTH, ICON_HEIGHT, X_POS, Y_POS_PRIMARY, GLCD_PIXEL_ON);
    GLCD_show_icon((void *) blank, ICON_WIDTH, ICON_HEIGHT, X_POS, Y_POS_SECONDARY, GLCD_PIXEL_ON);
    GLCD_draw_VLine( X_POS - 1, Y_POS_PRIMARY + ICON_HEIGHT/2, Y_POS_SECONDARY + ICON_HEIGHT/2, GLCD_PIXEL_OFF );
	GLCD_draw_VLine( X_POS + ICON_WIDTH, Y_POS_PRIMARY + ICON_HEIGHT/2, Y_POS_SECONDARY + ICON_HEIGHT/2, GLCD_PIXEL_OFF );

    strcpy(chaine, "            ");

    // clear Z
    GLCD_draw_text( 4, Y_POS_LINE_4, chaine, GLCD_PIXEL_ON);

    // clear Q_D
    GLCD_draw_text( 4, Y_POS_LINE_6, chaine, GLCD_PIXEL_ON);

    // clear PHI
    GLCD_draw_text( 4, Y_POS_LINE_5, chaine, GLCD_PIXEL_ON);

    // clear Vx & Ix
    GLCD_draw_text( 102, Y_POS_LINE_4, chaine, GLCD_PIXEL_ON);
    GLCD_draw_text( 102, Y_POS_LINE_5, chaine, GLCD_PIXEL_ON);

    strcpy(Expo, "  ");

    // clear primary
    // ---- select font 12x24
	GLCD_select_font(( void * ) font_12x24, 12, 24);
    strcpy(Buffer, "-------");
    GLCD_draw_text( X_POS_UNITS - 10 - (BUFFER_SIZE * font_width), Y_POS_LINE_1, Buffer, GLCD_PIXEL_ON);
    // ---- select font 8x16
	GLCD_select_font(( void * ) font_8x16, 8, 16);
    GLCD_draw_text( X_POS_UNITS, Y_POS_LINE_1, Expo, GLCD_PIXEL_ON);

    // clear secondary
    strcpy(Buffer, "       ");
	GLCD_draw_text( X_POS_UNITS - 10 - (BUFFER_SIZE * font_width), Y_POS_LINE_2, Buffer, GLCD_PIXEL_ON);		
	GLCD_draw_text( X_POS_UNITS, Y_POS_LINE_2, Expo, GLCD_PIXEL_ON);

	// ---- restore default font 6x11
	GLCD_select_font(( void * ) font_6x11, 6, 11);

    old_primary = 0;
    old_secondary = 0;
} // Display_Error



//-----------------------------------------------------------------------------
// Process_Circuit_Xs
//-----------------------------------------------------------------------------
//
// Return Value : true if done, false if exit due to ISR (rotary encoder or button pressed)
// Parameters   : None 
// 
// L or C as primary, and R as secondary
//
// Refresh GLCD According S_P_Mode,
//
bit Process_Circuit_Xs(void)
{
    uchar genre;

	// ---------- Primary value 
    if (isCapacitive)                           // (Xs < 0.0)
    {
        if (S_P_Mode == 1)			        	// series
            Value_to_Print = Cs;
        else									// parallel
			Value_to_Print = Cs / SP_coeff;		// "Cp "

		genre = C_PRIMARY;
    }
    else
    {
        if (S_P_Mode == 1)				        // series
            Value_to_Print = Ls;
        else									// parallel
		    Value_to_Print = Ls * SP_coeff;		// "Lp "
		genre = L_PRIMARY;
     }

    primaryValue = Value_to_Print;
    primaryKind = genre;

    if (primaryKind == C_KIND)
        DC_Bias_is_voltage = true;
    else
        DC_Bias_is_voltage = false;

    if (!inSorting)
    {
	    if (!Display_Circuit(genre, R_SECONDARY, S_P_Mode))
            return false;
    }

	if (!Display_Primary_Value(genre))
        return false;

	// ---------- Secondary value 
    if (!inSorting)
    {
        if (S_P_Mode == 1)					        // series
            Value_to_Print = Rs;
        else										// parallel
		    Value_to_Print = Rs * (1 + Q * Q);		// "Rp "

	    if (!Display_Secondary_Value(R_SECONDARY))
            return false;
	}		
    return true;

} // Process_Circuit_Xs



//-----------------------------------------------------------------------------
// Process_Circuit_Rs
//-----------------------------------------------------------------------------
//
// Return Value : true if done, false if exit due to ISR (rotary encoder or button pressed)
// Parameters   : None 
// 
// Rs and Ls, or Rp and Cp 
//
// Refresh LCD According S_P_Mode, QD_LCR_Cde
//
bit Process_Circuit_Rs(void)
{
	uchar genre;

	// ---------- Primary value 
	if (S_P_Mode == 1)					            // series
		Value_to_Print = Rs;
	else										    // parallel
		Value_to_Print = 	Rs * (1 + Q * Q);	    // "Rp "

	if (!Display_Primary_Value(R_PRIMARY))
        return false;
		
    primaryValue = Value_to_Print;
    primaryKind = R_PRIMARY;

	// ---------- Secondary value 
    if (!inSorting)
    {
	    if (isCapacitive) // (Xs < 0.0) 
	    {
		    if (S_P_Mode == 1)			            // series
			    Value_to_Print = Cs;
		    else								    // parallel
			    Value_to_Print = Cs / SP_coeff;		// "Cp "
		    genre = C_KIND;
	    }
        else
	    {
		    if (S_P_Mode == 1)			            // series
			    Value_to_Print = Ls;
		    else								    // parallel
			    Value_to_Print = Ls * SP_coeff;		// "Lp "
		    genre = L_KIND;	
	    }

	    if (!Display_Circuit(R_PRIMARY, genre, S_P_Mode))
            return false;

	    if (!Display_Secondary_Value(genre))
            return false;
    }
    return true;
} // Process_Circuit_Rs



//-----------------------------------------------------------------------------
// Display_Circuit
//-----------------------------------------------------------------------------
//
// Return Value : true if done, false if exit due to ISR (rotary encoder or button pressed)
// Parameters   : primary & secondary kind of componant
//				  parallel or series mode 
//
// draw equivalant circuit schematic
//
bit Display_Circuit(uchar primary, uchar secondary, uchar mode)
{
	uchar genre;

    if (!standalone)
    {
        if (no_display_secondary)
            mode = PLAIN;
        sprintf(chaine, "CIR %u %u %u", (uint)primary, (uint)secondary, (uint)mode);
        Send_Message(chaine);
        return true;
    }

    if (primary != old_primary)
    {
    	switch (primary)    // draw new icon
	    {
		    case R_PRIMARY:
			    GLCD_show_icon((void *) resistor, ICON_WIDTH, ICON_HEIGHT, X_POS, Y_POS_PRIMARY, GLCD_PIXEL_ON);
			    break;
		    case L_PRIMARY:
			    GLCD_show_icon((void *) self, ICON_WIDTH, ICON_HEIGHT, X_POS, Y_POS_PRIMARY, GLCD_PIXEL_ON);
			    break;
		    case C_PRIMARY:
			    GLCD_show_icon((void *) capa, ICON_WIDTH, ICON_HEIGHT, X_POS, Y_POS_PRIMARY, GLCD_PIXEL_ON);
			    break;
	    }
        old_primary = primary;
	}

	if (no_display_secondary)
    {
        if( old_secondary != NO_SECONDARY)      // erase old icon and wires
	    {
		    GLCD_show_icon((void *) blank, ICON_WIDTH, ICON_HEIGHT, X_POS, Y_POS_SECONDARY, GLCD_PIXEL_ON);
		    GLCD_draw_VLine( X_POS - 1, Y_POS_PRIMARY + ICON_HEIGHT/2, Y_POS_SECONDARY + ICON_HEIGHT/2, GLCD_PIXEL_OFF );
		    GLCD_draw_VLine( X_POS + ICON_WIDTH, Y_POS_PRIMARY + ICON_HEIGHT/2, Y_POS_SECONDARY + ICON_HEIGHT/2, GLCD_PIXEL_OFF );
            old_secondary = NO_SECONDARY;
	    }
        return true;
    }

    if (secondary != old_secondary)
    {
	    switch (secondary)
	    {
		    case R_SECONDARY:
			    GLCD_show_icon((void *) resistor, ICON_WIDTH, ICON_HEIGHT, X_POS, Y_POS_SECONDARY, GLCD_PIXEL_ON);
			    break;
		    case L_SECONDARY:
			    GLCD_show_icon((void *) self, ICON_WIDTH, ICON_HEIGHT, X_POS, Y_POS_SECONDARY, GLCD_PIXEL_ON);
			    break;
	    	case C_SECONDARY:
			    GLCD_show_icon((void *) capa, ICON_WIDTH, ICON_HEIGHT, X_POS, Y_POS_SECONDARY, GLCD_PIXEL_ON);
			    break;
        }
        old_secondary = secondary;
	}

	GLCD_draw_VLine( X_POS - 1, Y_POS_PRIMARY + ICON_HEIGHT/2, Y_POS_SECONDARY + ICON_HEIGHT/2, GLCD_PIXEL_ON );
    
    if (mode == PARALLEL)
        genre = GLCD_PIXEL_ON;
    else
		genre = GLCD_PIXEL_OFF;

	GLCD_draw_VLine( X_POS + ICON_WIDTH, Y_POS_PRIMARY + ICON_HEIGHT/2, Y_POS_SECONDARY + ICON_HEIGHT/2, genre );
    return true;
} // Display_Circuit



//-----------------------------------------------------------------------------
// Display_Primary_Value
//-----------------------------------------------------------------------------
//
// Return Value : true if done, false if exit due to ISR (rotary encoder or button pressed)
// Parameters   : kind of componant
//						
// display the primary value with suffix and unity
//
bit Display_Primary_Value(uchar theGenre)
{
	uchar genre;
	uchar accuracy;
    char int_part;

	if (highAccuracy)
        accuracy = 6;
    else
        accuracy = 3;

    if (inSorting)
        accuracy = 0;

    // ---- default font is 6x11
	genre = theGenre;
	int_part = Convert_Value_to_String(accuracy, WITH_SUFFIX, genre, false);   // ex: Buffer = "3.2" -> [0x33,0x2E,0x32,0x00]

    // save values for later use
    primaryIntPart = int_part;
    strncpy (PrimaryString, Buffer, 4);     // copy 4 bytes de Buffer dans PrimaryString

    if (!standalone)
    {       
        strcpy(chaine, message_PRIMARY);    // chaine = "PRIMAR "
        strcat(chaine, Buffer);             // ex: chaine = "PRIMAR 3.2"
        Load_Expo(int_part, genre, true);   // ex: Expo = " mH"
        strcat(chaine, Expo);               // ex: chaine = "PRIMAR 3.2 mH"
        Send_Message(chaine);
    }

	Justify_Right_Buffer();                 // ex: Buffer = "    3.2" -> [0x20,0x20,0x20,0x20,0x33,0x2E,0x32,0x00]

    // ---- select font 12x24
	GLCD_select_font(( void * ) font_12x24, 12, 24);

    if (standalone)
        GLCD_draw_text( X_POS_UNITS - 10 - (BUFFER_SIZE * font_width), Y_POS_LINE_1, Buffer, GLCD_PIXEL_ON);

	// ---- select font 8x16
	GLCD_select_font(( void * ) font_8x16, 8, 16);
    Load_Expo(int_part, genre, false);      // ex: Expo = "mH"
    strcpy (PrimaryExpo, Expo);
    if (standalone)
	    GLCD_draw_text( X_POS_UNITS, Y_POS_LINE_1, Expo, GLCD_PIXEL_ON);

    // ---- restore default font 6x11
	GLCD_select_font(( void * ) font_6x11, 6, 11);

    return true;
} // Display_Primary_Value


//-----------------------------------------------------------------------------
// Display_Secondary_Value
//-----------------------------------------------------------------------------
//
// Return Value : true if done, false if exit due to ISR (rotary encoder or button pressed)
// Parameters   : kind of componant
//						
// display the secondary value with suffix and unity
//
//
bit Display_Secondary_Value(uchar theGenre)
{
    char int_part;

    // ---- select font 8x16
    if (standalone)
	    GLCD_select_font(( void * ) font_8x16, 8, 16);

    if (no_display_secondary) // && standalone)
    {
		strcpy(Buffer, "       ");
        strcpy(Expo, "  ");
    }
    else
    {
        int_part = Convert_Value_to_String(0, WITH_SUFFIX, theGenre, true);     // ex: Buffer = "121.6"
        Load_Expo(int_part, theGenre, !standalone);                             // ex: Expo = " kO" 
    }
 
    if (!standalone)
    {
        strcpy(chaine, message_SECONDARY);      // chaine = "SECOND "
        strcat(chaine, Buffer);                 // ex: chaine = "SECOND 121.6"
        strcat(chaine, Expo);                   // ex: chaine = "SECOND 121.6 kO"   
        Send_Message(chaine);
        return true;
    }

    Justify_Right_Buffer();
	GLCD_draw_text( X_POS_UNITS - 10 - (BUFFER_SIZE * font_width), Y_POS_LINE_2, Buffer, GLCD_PIXEL_ON);		
	GLCD_draw_text( X_POS_UNITS, Y_POS_LINE_2, Expo, GLCD_PIXEL_ON);

	// ---- restore default font 6x11
	GLCD_select_font(( void * ) font_6x11, 6, 11);
    return true;
} // Display_Secondary_Value


//-----------------------------------------------------------------------------
// Display_Frequency
//-----------------------------------------------------------------------------
//
// Return Value : true if done, false if exit due to ISR (rotary encoder or button pressed)
// Parameters   : x, y
//
// write the formated frequency
//
bit Display_Frequency (uchar x, uchar y)
{
    float xdata thefreq;
    uchar mode;
    uchar index;

    if (userDefinedFrequency || !standalone)
    {
        index = Get_FreqIndex(freq);
        if (Tab_freq[index] == freq)
            index = 0;
        else
            index = 6;
        thefreq = freq;
    }
    else
    {
        index = 0;
        thefreq = Tab_freq[Freq_index];	
    }

    if (thefreq >= 1000000)
    {
		sprintf(Buffer, Table_format[1+index], thefreq/1000000);    // x.x or x.xxx or x.xxxx MHz
        strcpy(Expo, "MHz");
    }
	else if (thefreq >= 10000)
    {
		sprintf(Buffer, Table_format[0+index], thefreq/1000);       // x or x.xx or x.xxx kHz
        strcpy(Expo, "kHz");
    }
	else if (thefreq >= 1000)
    {
		sprintf(Buffer, Table_format[1+index], thefreq/1000);       // x.x or x.xxx  or x.xxxx kHz
        strcpy(Expo, "kHz");
    }
	else
    {
		sprintf(Buffer, Table_format[0+index], thefreq);            // x or x.xx  or x.xxx  Hz
        strcpy(Expo, "Hz ");
    }

    if (!standalone)
    {
        strcpy(chaine, message_FREQ);
        strcat(chaine, Buffer);
        strcat(chaine, " ");
        strcat(chaine, Expo);
        Send_Message(chaine);
        return true;
    }
        
    // ---- select font 8x16
	GLCD_select_font(( void * ) font_8x16, 8, 16);

    if (DisplayInverse || userDefinedFrequency)
        mode = GLCD_PIXEL_OFF;
    else
        mode = GLCD_PIXEL_ON;

    Justify_Right_Buffer();
    	
    GLCD_draw_text( x - 10 - (BUFFER_SIZE * font_width), y, Buffer, mode);		

	// ---- restore default font 6x11
	GLCD_select_font(( void * ) font_6x11, 6, 11);
    GLCD_draw_text(x, y, Expo, GLCD_PIXEL_ON);
    return true;
} // Display_Frequency


//-----------------------------------------------------------------------------
// Display_Mode
//-----------------------------------------------------------------------------
//
// Return Value : true if done, false if exit due to ISR (rotary encoder or button pressed)
// Parameters   : None
//						
// display the mode AUTO if Auto_Model == 0
//
bit Display_Mode(void)
{   
    char str[15];

    if (!standalone)
    {
        sprintf(str, "SP_MODE %u %u", (int)Auto_Model, (int)S_P_Mode);
        Send_Message(str); 
        return true;
    }

	if (Auto_Model == 0)
		strcpy(str, "AUTO");
	else
		strcpy(str, "    ");

	GLCD_draw_text( 30, Y_POS_LINE_3, str, GLCD_PIXEL_ON);

    if (Auto_Model == 0)			// Auto mode
    {
        if (S_P_Mode == 1)			// series 
            GLCD_show_icon( ( void * ) Parall_Icon_48x24, 48, 24, 192, ICON1_POS, GLCD_PIXEL_ON );      // -> display parallel
        else if (S_P_Mode == 2)		// parallel
            GLCD_show_icon( ( void * ) Series_Icon_48x24, 48, 24, 192, ICON1_POS, GLCD_PIXEL_ON );      // -> display series
    }
    else
    {
        GLCD_show_icon( ( void * ) Auto_Icon_48x24, 48, 24, 192, ICON1_POS, GLCD_PIXEL_ON );            //  -> display AUTO
    }

    return true;
} // Display_Mode


//-----------------------------------------------------------------------------
// FormatsChaine
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
void FormatsChaine()
{
    char i;

    if (standalone)
    {
        strcat(chaine, "= ");
        strcat(chaine, Buffer);
        strcat(chaine, " ");
        strcat(chaine, Expo);
        i = strlen (chaine);
        while (i < 13)
        {
            strcat(chaine, "  ");
            i++;
        }
    }
    else
    {
        strcat (chaine, Buffer);
        strcat(chaine, Expo);                
    }
} // FormatsChaine


//-----------------------------------------------------------------------------
// Display_Z
//-----------------------------------------------------------------------------
//
// Return Value : true if done, false if exit due to ISR (rotary encoder or button pressed)
// Parameters   : None
//						
// display parameter Z
//
bit Display_Z(void)
{
    char int_part;

    Value_to_Print = Z;
    int_part = Convert_Value_to_String(3, WITH_SUFFIX, R_KIND, true);
    Load_Expo(int_part, R_KIND, !standalone);        // ex: Expo = " mH" or "mH" (standalone)
    strcpy (chaine, message_Z);     // "Z "

    FormatsChaine();
    if (standalone)
    {
        //FormatsChaine();
        GLCD_draw_text( 4, Y_POS_LINE_4, chaine, GLCD_PIXEL_ON);
    }
    else
    {
        //FormatsChaine();
        Send_Message(chaine);
    }

    return true;
} // Display_Z


//-----------------------------------------------------------------------------
// Display_Q_D
//-----------------------------------------------------------------------------
//
// Return Value : true if done, false if exit due to ISR (rotary encoder or button pressed)
// Parameters   : if TRUE, diplay Q instead of D, or inverse
//						
// display parameter Q or D
//
bit Display_Q_D(bit inverse)
{
	uchar i;
    bit display_Q;

	if (inverse)
	{
		if (primaryKind == C_PRIMARY)
		{ 
			Value_to_Print = Q;
			strcpy(chaine,"Q ");
            display_Q = true;
		}
		else
		{
			Value_to_Print = 1/Q;
			strcpy(chaine,"D ");
            display_Q = false;
		}
	}
	else
	{
		if (primaryKind == C_PRIMARY)
		{
			Value_to_Print = 1/Q;
			strcpy(chaine,"D ");
            display_Q = false;
		}
		else
		{
			Value_to_Print = Q;
			strcpy(chaine,"Q ");
            display_Q = true;
		}
	} 

	if (Value_to_Print < 1)
		i = 1;
	else if (Value_to_Print < 10)
		i = 2;
	else if (Value_to_Print < 100)
		i = 3;
	else if (Value_to_Print < 1000)
		i = 4;
	else if (Value_to_Print < 10000)
		i = 5;
	else
		i = 0; 

	if (i)
    {
		sprintf(Buffer, Table_format_QD[i-1], Value_to_Print);
        if (standalone)
            strcat (chaine, "= ");
    }
	else
        strcpy(Buffer, "> 10k");

    if (!standalone)
    {
        if (display_Q)
            strcpy(chaine, message_Q);
        else
            strcpy(chaine, message_D);

        strcat(chaine, Buffer);
        Send_Message(chaine);
    }
    else
    {
        strcat(chaine, Buffer);		
        i = strlen(chaine);
        while (i < 13)
        {
            strcat(chaine, " ");
            i++;
        }	    GLCD_draw_text( 4, Y_POS_LINE_6, chaine, GLCD_PIXEL_ON);
    }
    return true;
} // Display_Q_D



//-----------------------------------------------------------------------------
// Display_PHI
//-----------------------------------------------------------------------------
//
// Return Value : true if done, false if exit due to ISR (rotary encoder or button pressed)
// Parameters   :none
//						
// display parameter PHI or Xs or Ix
//
bit Display_PHI(void)
{
    char int_part;
	uchar format = 3;

    Value_to_Print = Phi * 180 / PI ;	        // degree
    int_part = Convert_Value_to_String(format, WITH_SUFFIX, NO_KIND, true);
    Load_Expo(int_part, PHI_KIND, !standalone); // ex: Expo = " m�" or "m�" (standalone) 
    if (standalone)
    {
 	    strcpy(chaine, CHAR_PHI_6x11);  // chaine = "�"
        strcat(chaine, " ");
        FormatsChaine();                // chaine = "� = -x.x  m� "        
        GLCD_draw_text( 4, Y_POS_LINE_5, chaine, GLCD_PIXEL_ON);
    }
    else
    {
        strcpy(chaine, message_PHI);
        FormatsChaine();               
        Send_Message(chaine);
    }
    return true;	
} // Display_PHI


//-----------------------------------------------------------------------------
// Display_Vx_Ix
//-----------------------------------------------------------------------------
//
// Return Value : true if done, false if exit due to ISR (rotary encoder or button pressed)
// Parameters   : None
//						
// display Voltage and current (DUT)
//
bit Display_Vx_Ix(void)
{
    char int_part;

    Value_to_Print = Vpp / TWO_x_SQUARE2;
    int_part = Convert_Value_to_String(0, WITH_SUFFIX, NO_KIND, true);
    Load_Expo(int_part, V_KIND, !standalone);
    strcpy (chaine, message_VX);    // chaine = "Vx "
    
    if (standalone)
    {
        FormatsChaine();
        GLCD_draw_text( 102, Y_POS_LINE_4, chaine, GLCD_PIXEL_ON);
    }
    else
    {
        FormatsChaine(); 
        Send_Message(chaine);
    }

    Value_to_Print = Ipp / TWO_x_SQUARE2;
    int_part = Convert_Value_to_String(0, WITH_SUFFIX, NO_KIND, true);
    Load_Expo(int_part, A_KIND, !standalone);
    strcpy (chaine, message_IX);    // chaine = "Ix "

    if (standalone)
    {
        FormatsChaine();
        GLCD_draw_text( 102, Y_POS_LINE_5, chaine, GLCD_PIXEL_ON);
    }
    else
    {
        FormatsChaine(); 
        Send_Message(chaine);
    }
    return true;
} // Display_Vx_Ix


//-----------------------------------------------------------------------------
// Set_Trim
//-----------------------------------------------------------------------------
//
// Return Value : result
// Parameters   : kind = SHORT_TRIM or OPEN_TRIM
// 
//	Set Xs & Rs trim values for the current frequency
//
uchar Set_Trim(bit kind)
{
    Measure_value_for_Trim();

	if (kind == SHORT_TRIM)							// short
    {
            RsTrimShort = Rs;
            XsTrimShort = Xs;
            TrimShortOk = true;

            if (!userDefinedFrequency)
            {
			    Tab_Rs_Trim_Short[Freq_index] = RsTrimShort;
			    Tab_Xs_Trim_Short[Freq_index] = XsTrimShort;
                Tab_Trim_Short_OK[Freq_index] = TrimShortOk;
                trimShortModified = true;
            }
	}
	else											// open
	{
            RsTrimOpen = Rs;
            XsTrimOpen = Xs;
            TrimOpenOk = true;

            if (!userDefinedFrequency)
            {
			    Tab_Rs_Trim_Open[Freq_index] = RsTrimOpen;
			    Tab_Xs_Trim_Open[Freq_index] = XsTrimOpen;
                Tab_Trim_Open_OK[Freq_index] = TrimOpenOk;	        // true
                trimOpenModified = true;
            }
	}
	return 1;
} // Set_Trim


//-----------------------------------------------------------------------------
// Write_Frequency
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : x, y, mode, extended (used for user defined frequency)
//
// write the formated frequency
//
void Write_Frequency (uchar x, uchar y, uchar GLCD_mode, bit extended)
{
    if (!extended)
    {
	    if (freq == 1200 || freq == 1500 || freq == 2500)
		    sprintf(chaine, "Freq  %1.1f kHz  ", freq/1000);
        else if (freq == 1200000 || freq == 1500000 || freq == 2500000)
		    sprintf(chaine, "Freq  %1.1f MHz  ", freq/1000000);
    	else if (freq >= 999995)
		    sprintf(chaine, "Freq  %1.0f MHz   ", freq/1000000);
	    else if (freq >= 1000)
		    sprintf(chaine, "Freq  %1.0f kHz   ", freq/1000);
    	else 
		    sprintf(chaine, "Freq  %1.0f Hz    ", freq);
    }
    else
    {
        if (freq >= 999995)
		    sprintf(chaine, "Freq  %1.1f MHz   ", freq/1000000);
	    else if (freq >= 1000)
		    sprintf(chaine, "Freq  %1.1f kHz   ", freq/1000);
    	else 
		    sprintf(chaine, "Freq  %1.1f Hz    ", freq);
    }
	GLCD_draw_text(x,y, chaine, GLCD_mode);
} // Write_Frequency


//-----------------------------------------------------------------------------
// Z_test_for_Trim
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
// 
void Z_test_for_Trim(void)
{
    uchar saveFreqIndex;

    saveFreqIndex = Get_FreqIndex(freq);
    Set_Frequency(26);          // 10kHz
    in_calibration = true;
    Process_Measurement(RANGE_GAIN_1);
    Do_CF(false);
    Z = sqrt(Xs * Xs + Rs * Rs); 
    in_calibration = false;
    Set_Frequency(saveFreqIndex);   
} // Z_test_for_Trim


//-----------------------------------------------------------------------------
// Measure_value_for_Trim
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
// 
void Measure_value_for_Trim(void)
{
    char i, k, returnValue;
    uchar initialLevel = sourceLevel;
    float newReductionLevel = 1.0;

    if (wait_steady_PSD <= 5)       // freq >= 5 kHz, k = 8
        k = BUFSIZE_DATA_MAX1;
    else if (wait_steady_PSD <= 22) // freq >= 500 Hz, k = 4
        k = BUFSIZE_DATA_MAX3;
    else                            // freq < 500 Hz, k = 2
        k = BUFSIZE_DATA_MAX4;

    i = 0;
    Set_Measure_Mode(CURRENT_MODE);
    Set_PGA2_Gain(RANGE_GAIN_1, false);
    Set_Best_Sense_Resistor();
    Set_Best_PGA2_Gain();     // **********
    Buffer_Init();
	do
	{	
        returnValue = Set_Measure(&Ip, &Iq);
        if (returnValue == OK_MEASURE)
        {
 	        Buffer_Add_Data(Ip, Iq);
            i++;
        }
        else
        {
            newReductionLevel *= 1.05;
            Set_DDS_Amplitude(newReductionLevel);
        }
    }
    while (i < k);
    Buffer_Read(&Ip, &Iq);

    i = 0;
    Set_PGA2_Gain(RANGE_GAIN_1, false);
    Set_Measure_Mode(VOLTAGE_MODE);
    Set_Best_PGA2_Gain();     // **********
    Buffer_Init();
	do
    {	
	    returnValue = Set_Measure(&Vp, &Vq);
        if (returnValue == OK_MEASURE)
        {
 	        Buffer_Add_Data(Vp, Vq);
            i++;
         }
    }   
    while (i < k);
    Buffer_Read(&Vp, &Vq);

    Process_Gain_Corrections();   
    Div_Complex(Vp, Vq, Ip, Iq, &Rs, &Xs);              // (Vp + jVq) / (Ip + jIq) = Rs + jXs
    Get_Standard_Values();
    Div_Complex(Rs, Xs, Rstdm, Xstdm, &Rs, &Xs);
    Rs *= Rsense;
    Xs *= Rsense;
    Set_Source_Level(initialLevel);
} // Measure_value_for_Trim


//-----------------------------------------------------------------------------
// Menu_Set_Trim
//-----------------------------------------------------------------------------
//
// Return Value : result
// Parameters   : kind = SHORT_TRIM (0) or OPEN_TRIM (1)
// 
//	Set Xs & Rs trim values for all frequencies
//
bit Menu_Set_Trim(bit kind)
{
	uchar saveFreqIndex;
    uchar pos = 60;
	uchar j;
    char akey;
    char i = 0;
	bit ok = false;
    bit onlyErase;
	char returnValue = 1;
    bit pix = false;

    saveFreqIndex = Freq_index;

    // Verifies that the connected impedance is valid for the test.
    Z_test_for_Trim();  

    if (kind == SHORT_TRIM && Z > 10.0)
    {
        Affiche_Text(WITHOUT_ICON, Y_POS_LINE_3, 33, GLCD_PIXEL_ON);    // "Short circuit before enter menu"
        wait_ms(2000);
        ok = false;
    }
    else if (kind == OPEN_TRIM && Z < 50000.0)
    {
        Affiche_Text(WITHOUT_ICON, Y_POS_LINE_3, 34, GLCD_PIXEL_ON);    // "Open circuit before enter menu"
        wait_ms(2000);
        ok = false;
    }
    else
        ok = true;

    if (!ok)
    {
        Set_Frequency(saveFreqIndex);
        if (standalone)
            Restore_Display();
        return false;
    }

    // Connected impedance is valid
    Affiche_Text(WITHOUT_ICON, pos, 18, GLCD_PIXEL_ON); // "Okay, will take few minutes"
    in_calibration = true;
    DisplayProgressionBar(0); // with external display, don't wait to show progress bar!

    for (j = MIN_FREQ_INDEX_START; j < FREQ_MEM_SIZE; j++)
    {
        Set_Frequency(j);
        if (standalone)
            Write_Frequency(0, 22, GLCD_PIXEL_ON, userDefinedFrequency);

        Measure_value_for_Trim();

        Tab_Real[j] = Rs;
        Tab_Imag[j] = Xs;
        DisplayProgressionBar(j+1);
    } // for
        
    in_calibration = false;
    if (standalone)
    {
        GLCD_clear_Row(WITHOUT_ICON, pos);
        Write_OK_Exit_Icons();
    }

    Affiche_Text(WITH_ICON28, pos, 10, GLCD_PIXEL_ON);      // "Save the data?"

    do
    {
        akey = GetUserAction();
    }
    while (!( (akey == KEY_5) || (akey == KEY_4) ));        // EXIT or OK

    wait_ms(400);
    Set_Frequency(saveFreqIndex);

    onlyErase = (akey == KEY_5);
    
    if (kind == SHORT_TRIM)
        i = 8;
    else
        i = 7;  // OPEN_TRIM

    Copy_CalibrationFactor_to_CodeData(i, onlyErase);
    Copy_TrimValues_from_CodeData();
    Load_CF();
	return true;
} // Set_Trim


//-----------------------------------------------------------------------------
// Copy_TrimValues_from_CodeData
//-----------------------------------------------------------------------------
//
// Return Value : none
// Parameters   : none
//
void Copy_TrimValues_from_CodeData(void)
{
    char i;
    uchar c_value;
    float f_value;

    for (i = MIN_FREQ_INDEX_START; i < FREQ_MEM_SIZE; i++) 
    {
        c_value = FLASH_ByteRead(TRIM_OPEN_OK_ADD + (i * CHAR_SIZE), 0);
        Tab_Trim_Open_OK[i] = c_value;

        FLASH_Read((char *) &f_value, TABLE_IMAG_OPEN_ADD + (i * FLOAT_SIZE), FLOAT_SIZE, 0);
        Tab_Xs_Trim_Open[i] = f_value;

        FLASH_Read((char *) &f_value, TABLE_REAL_OPEN_ADD + (i * FLOAT_SIZE), FLOAT_SIZE, 0);
        Tab_Rs_Trim_Open[i] = f_value;

        c_value = FLASH_ByteRead(TRIM_SHORT_OK_ADD + (i * CHAR_SIZE), 0);
        Tab_Trim_Short_OK[i] = c_value;

        FLASH_Read((char *) &f_value, TABLE_IMAG_SHORT_ADD + (i * FLOAT_SIZE), FLOAT_SIZE, 0);
        Tab_Xs_Trim_Short[i] = f_value;

        FLASH_Read((char *) &f_value, TABLE_REAL_SHORT_ADD + (i * FLOAT_SIZE), FLOAT_SIZE, 0);
        Tab_Rs_Trim_Short[i] = f_value;

    }
} // Copy_TrimValues_from_CodeData


//-----------------------------------------------------------------------------
// Copy_TrimValues_to_CodeData
//-----------------------------------------------------------------------------
//
// Return Value : none
// Parameters   : none
//
void Copy_TrimValues_to_CodeData(void)
{
    char i;

    if (trimOpenModified)
    {        
        for (i = MIN_FREQ_INDEX_START; i < FREQ_MEM_SIZE; i++) 
        {
            Tab_Real[i] = Tab_Rs_Trim_Open[i];
            Tab_Imag[i] = Tab_Xs_Trim_Open[i];
        }
        Copy_CalibrationFactor_to_CodeData(7, false);
        trimOpenModified = false;
    }
    if (trimShortModified)
    {        
        for (i = MIN_FREQ_INDEX_START; i < FREQ_MEM_SIZE; i++) 
        {
            Tab_Real[i] = Tab_Rs_Trim_Short[i];
            Tab_Imag[i] = Tab_Xs_Trim_Short[i];
        }
        Copy_CalibrationFactor_to_CodeData(8, false);
        trimShortModified = false;
    }
} // Copy_TrimValues_to_CodeData


//-----------------------------------------------------------------------------
// Copy_CalibrationFactor_to_CodeData
//-----------------------------------------------------------------------------
//
// Return Value : none
// Parameters   : the range: 1 to 4 for Rsense, 5 & 6 for PGA gain (3 or 10), 7 for OPEN_Trim, 8 for SHORT_Trim
//                If the bit onlyErase is true, the old data is erased, but the new data is not backed up.  
//
void Copy_CalibrationFactor_to_CodeData(uchar range,  bit onlyErase)
{
    uchar  i, c_value;
    bit trim = false;
    float ImagValue;
    float RealValue;
    FLADDR Real_adresse;
    FLADDR Imag_adresse;
    FLADDR ok_adresse;

    switch(range)
    {
        case 1: // R_RANGE_1: Rsense = 100R
            ok_adresse = CF_R1_OK_ADD;
            Imag_adresse = TABLE_CFX_R1_ADD;
            Real_adresse = TABLE_CFR_R1_ADD;
            break;
        case 2: // R_RANGE_2: Rsense = 1k
            ok_adresse = CF_R2_OK_ADD;
            Imag_adresse = TABLE_CFX_R2_ADD;
            Real_adresse = TABLE_CFR_R2_ADD;
            break;
        case 3: // R_RANGE_3: Rsense = 10k
            ok_adresse = CF_R3_OK_ADD;
            Imag_adresse = TABLE_CFX_R3_ADD;
            Real_adresse = TABLE_CFR_R3_ADD;
            break;
        case 4: // R_RANGE_4: Rsense = 100k
            ok_adresse = CF_R4_OK_ADD;
            Imag_adresse = TABLE_CFX_R4_ADD;
            Real_adresse = TABLE_CFR_R4_ADD;
            break;
        case 5: // PGA gain of 3
            ok_adresse = PGA_G3_OK_ADD;
            Imag_adresse = TABLE_IMAG_G3_ADD;
            Real_adresse = TABLE_REAL_G3_ADD;
            break;
        case 6: // PGA gain of 10
            ok_adresse = PGA_G10_OK_ADD;
            Imag_adresse = TABLE_IMAG_G10_ADD;
            Real_adresse = TABLE_REAL_G10_ADD;
            break;
        case 7: // OPEN_Trim
            trim = true;
            ok_adresse = TRIM_OPEN_OK_ADD;
            Imag_adresse = TABLE_IMAG_OPEN_ADD;
            Real_adresse = TABLE_REAL_OPEN_ADD;
            break;
        case 8: // SHORT_Trim
            trim = true;
            ok_adresse = TRIM_SHORT_OK_ADD;
            Imag_adresse = TABLE_IMAG_SHORT_ADD;
            Real_adresse = TABLE_REAL_SHORT_ADD;
            break;

    }

    if (standalone)
        BACKLIGHT = 0;      // Saves about 90 mA on the current provided by the USB port during FLAH access.
    
    FLASH_PageErase (ok_adresse, 0);

    if (!onlyErase)
    {
        c_value = 1; // true
        for (i = MIN_FREQ_INDEX_START; i < FREQ_MEM_SIZE; i++) 
        {
            RealValue = Tab_Real[i];
            ImagValue = Tab_Imag[i];
            FLASH_Write (Real_adresse + (i * FLOAT_SIZE), (char *) &RealValue, FLOAT_SIZE, 0);
            FLASH_Write (Imag_adresse + (i * FLOAT_SIZE), (char *) &ImagValue, FLOAT_SIZE, 0);
            if (trim)
                FLASH_Write (ok_adresse + (i * CHAR_SIZE), (char *) &c_value, CHAR_SIZE, 0); // write true;
        }
        if (!trim)
            FLASH_Write (ok_adresse, (char *) &c_value, CHAR_SIZE, 0); // write true;
    }
       
    Check_Calibration_Datas();  // set new PGA_GX_ok, Calibration_Factor_RX_ok 

    if (standalone)
        BACKLIGHT = 1;  
} // Copy_CalibrationFactor_to_CodeData



// *********************************************
// Support Subroutines
// *********************************************

//-----------------------------------------------------------------------------
// wait_overflow
//-----------------------------------------------------------------------------
//
// Return Value : false if wait_ms() return false
// Parameters   : none
//
// wait at least one periode of frequency
//
bit wait_overflow(void)
{
	uint wait;

	if (overflow_time >= 1000)
	{
		wait = ceil(overflow_time / 1000);
		if (!wait_ms(wait))
            return false;
	}
	else
		wait_us (overflow_time);
    return true;
} // wait_overflow


//-----------------------------------------------------------------------------
// wait_ms
//-----------------------------------------------------------------------------
//
// Return Value : false if loop stoped by external event
// Parameters   : time_ms - time delay in milliseconds;  range: 1 to 65500
//
// Creates a delay for the specified time (in milliseconds) using wait_us().
// This function does not use any SFRs (so SFRPAGE is left untouched).
//
bit wait_ms (unsigned int time_ms)
{
	if ((time_ms == 0) || (time_ms > 65500))
		return false;

    while(time_ms--)
	{
        if (overVoltage)    // a key is pressed or an overvoltage occurds during the wait time, so return immediatly
			return false;

		wait_us (1000);	    // 1000us per loop
	}
	return true;
} // wait_ms


//-----------------------------------------------------------------------------
// wait_us
//-----------------------------------------------------------------------------
//
// Return Value :   none
// Parameters:      unsigned int us - number of microseconds of delay
//                  if PLL_MUL = 1 (SYSCLK = 24.5MHz it means 24.5 cycles per us ) range is 1 to 2674
//				    if PLL_MUL = 2 (SYSCLK = 49MHz it means 49 cycles per us ) range is 1 to 1337
//					if PLL_MUL = 3 (SYSCLK/2 = 36.75MHz it means 36.75 cycles per us ) range is 1 to 1783
//				    ---> range is 1 to 1000
//
// This routine uses TIMER3 and generates a delay of < Time_us > microseconds.
//
void wait_us(uint time_us)
{
    char SFRPAGE_SAVE = SFRPAGE;                // Save Current SFR page

    SFRPAGE = TMR3_PAGE;

	TMR3  =  - ((uint)(time_us * TMR3_COEFF)) ;	// Timer 3 overflows time_us later
    TR3   = 1;                       			// Start timer

    while (!TF3 && !overVoltage);        // Wait till timer overflow or an overvoltage occurs

	TMR3CN &= 0x7B;						// 0111 1011 Clear timer overflow flag (TMR3CN.7) & Stop Timer.(TMR3CN.2)

    SFRPAGE = SFRPAGE_SAVE;             // Restore SFRPAGE

}// wait_us


//-----------------------------------------------------------------------------
// Get_ADC0_Count
//-----------------------------------------------------------------------------
//
// Return Value : ADC count (averaged)
// Parameters   : the channel 
//                  0 to 5 for single-ende inputs AIN0 to AIN5, 6 for differential input pair AIN6[+] & AIN7[-]
//
// use ADC0 of MCU
//
uint Get_ADC0_Count(uchar channel)
{
	uint ADC0_data;
	uchar i;
	ulong m;
    char SFRPAGE_SAVE = SFRPAGE;        // Save Current SFR page

#define LOOPS 16

	SFRPAGE = ADC0_PAGE;             	// Switch to ADC0 Page
	AMX0SL = channel;					// select channel
	//AD0EN = 1;					    // Enable ADC already done in ADC0_Init()
	wait_ms(100);
	i = 0;
	m = 0;
	while (i < LOOPS)									 
	{
		AD0INT = 0;                     // clear ADC conversion complete flag

  		AD0BUSY = 1;                    // Start conversion
  		while (!AD0INT);            	// wait for conversion is complete
		ADC0_data = ADC0;				// (ADC0H * 256 + ADC0L);
		m += ADC0_data;
		i++;
		wait_ms(10);
	}
   
    SFRPAGE = SFRPAGE_SAVE;                // Restore SFRPAGE

	return m / LOOPS;
} // Get_ADC0_Count


//-----------------------------------------------------------------------------
// Checks_Bias_Current
//-----------------------------------------------------------------------------
//
// Return Value : the value in mA (on channel 6)
// Parameters   : none
//
//		Ra (100k) connected to +5V
//		Rb (110k) connected to -5V or I_VOLTAGE
//      Rs (50R) the sense resistor ( << 100k + 110k)
//
// Is = (measure / Rs) * (1 + Rb / Ra) = measure * 0.042 (A) = measure * 42 (mA)
//
float Checks_Bias_Current(void)
{
	float value;
	int count;

    //wait_ms(1000);
	count = Get_ADC0_Count(AIN_DCBIAS_I);

    if (count >= 0xF800) // negatif if >= -2048
	{
		count = -((count^0xFFFF) + 1);
	}

//	value = VREF * count / 2048;        // differential: max = + VREF x (2047/2048) 
                                        //               min = - VREF
//  value *= 42;
    value = VREF * count * 0.020508;    // mA
    // take in account current gain of Q8 (BFR106)
    if (value < 5)
        value *= 0.98;   // gain <= 50
    else if (value < 15)
        value *= 0.984;   // gain <= 60
    else
        value *= 0.987;   // gain = 80
	return value;
} // Checks_Bias_Current


//-----------------------------------------------------------------------------
// Checks_Minus_Voltage
//-----------------------------------------------------------------------------
//
// Return Value : the value
// Parameters   : the channel (0 to 7), values of R1 and R2 (ohms or (same!) integer multiple < 65535)
//
//						R1 connected to VREF
//						R2 connected to voltage source
//
float Checks_Minus_Voltage(uchar channel, uint R1, uint R2)
{
	float value, ratio = (float)R2 / R1;
	uint count;

	count = Get_ADC0_Count(channel);
	value = VREF * ((float)count / 4096 * (1 + ratio) - ratio);
	return value;
} // Checks_Minus_Voltage


//-----------------------------------------------------------------------------
// Checks_Plus_Voltage
//-----------------------------------------------------------------------------
//
// Return Value : the value
// Parameters   : the channel (0 to 7), values of R1 and R2 (ohms or (same!) integer multiple < 65535)
//
//						R1 connected to voltage source
//						R2 connected to ground
//
float Checks_Plus_Voltage(uchar channel, uint R1, uint R2)
{
	float value, ratio = (float)R1 / R2;
	uint count;

	count = Get_ADC0_Count(channel);
	value = VREF * count / 4096 * (1 + ratio);
	return value;
} // Checks_Plus_Voltage


//-----------------------------------------------------------------------------
// Checks_Power_Supplies
//-----------------------------------------------------------------------------
//
// Return Value : 0 for no defects, otherwise the sequence number of the default
// Parameters   : none
//
char Checks_Power_Supplies(void)
{
	bit ok;
	char return_value = 0;
	float value;

	// 1 - line -5V
	value = Checks_Minus_Voltage(AIN_MINUS_5V, 56, 160);
	ok = (value < HIGH_LIM_MINUS_5V) && (value > LOW_LIM_MINUS_5V);
	if (!ok)
		return_value = 1;   // 0000 0001
	// 2 - line +5V
	value = Checks_Plus_Voltage(AIN_PLUS_5V, 3000, 2000);
	ok = (value < HIGH_LIM_5V) && (value > LOW_LIM_5V);
	if (!ok)
		return_value |= 2;  // 0000 001x	
	// 3 - line +3V
	value = Checks_Plus_Voltage(AIN_PLUS_3V, 1000, 2000);
	ok = (value < HIGH_LIM_3V) && (value > LOW_LIM_3V);
	if (!ok)
		return_value |= 4;;  // 0000 01xx
	// 4 - line +6.5V
	value = Checks_Plus_Voltage(AIN_PLUS_6V, 3600, 1600);
	ok = (value < HIGH_LIM_BOOST_L) && (value > LOW_LIM_BOOST_L);
	if (!ok)
		return_value |= 8;  ;  // 0000 1xxx	
    MAX_BOOST = 1;
    wait_ms(500);
	value = Checks_Plus_Voltage(AIN_PLUS_6V, 3600, 1600);
	ok = (value < HIGH_LIM_BOOST_H) && (value > LOW_LIM_BOOST_H);
    MAX_BOOST = 0;
	if (!ok)
		return_value |= 16; ;  // 0001 xxxx

	return return_value;
} // Checks_Power_Supplies


//-----------------------------------------------------------------------------
// DAC0_Update
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : int value to write in DAC register
//
void DAC0_Update(unsigned int value)
{
    char SFRPAGE_SAVE = SFRPAGE;            // Save Current SFR page

	SFRPAGE = DAC0_PAGE;                    // Switch to DAC0 Page
	DAC0L = (unsigned char) (value & 0x00FF);
	DAC0H = (unsigned char) ((value & 0xFF00) >> 8);
	
	SFRPAGE = SFRPAGE_SAVE;                 // Restore SFRPAGE
} // DAC0_Update


//-----------------------------------------------------------------------------
// DAC1_Update
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : int value to write in DAC register
//
void DAC1_Update(unsigned int value)
{
    char SFRPAGE_SAVE = SFRPAGE;            // Save Current SFR page

	SFRPAGE = DAC1_PAGE;                    // Switch to DAC1 Page
	DAC1L = (unsigned char) (value & 0x00FF);
	DAC1H = (unsigned char) ((value & 0xFF00) >> 8);

	SFRPAGE = SFRPAGE_SAVE;                 // Restore SFRPAGE
}


//-----------------------------------------------------------------------------
// Set_DDS_Amplitude
//-----------------------------------------------------------------------------
//
// _____________                                     _________________
//             |                                     |
//    DDS      |                                     |       MCU
//             |                                     |
//             |                                     |
//             |                                     |
//             |    --------            --------     |
//    FSADJUST |----|   R1  |-----------|  R2   |----| DAC1OUT = MCU_VREF * DAC1_Data / 4096
//             |    --------       |     --------    |
//             |                   |                 |
//             |                 ----                |
//             |                |    |               |
//             |                | R3 |               |
//             |                |    |               |
//             |                 ----                |
// ____________|                   |                 |________________
//                                _|_
//                                GND
//
//
// R1 = R2 = 4700R
// R3 = 3900R
//
// G = Amplitude (DAC1_Data) / Amplitude (DAC1_Data = 0) 
// G always <=1
//
// DAC1_Data = (1 - G) * (DDS1_Vref / MCU_VREF) * (1 + R1 / R3) * 4096
//		set DAC_coeff = (DDS1_Vref / MCU_VREF) * (1 + R1 / R3) * 4096
// 	so DAC1_Data = (1 - G) * DAC_coeff
//
// Return Value : None
// Parameters   : Reduction_level >= 1 and <= 13
//
void Set_DDS_Amplitude(float Reduction_level)
{
	uint DAC1_Data;

	if (Reduction_level < 1.001)
		DAC1_Data = 0;
	else
		DAC1_Data = (uint)(DAC_coeff * (1 - (1/Reduction_level)));
	if (DAC1_Data > 4095)
		DAC1_Data = 4095;
	DAC1_Update(DAC1_Data);
	wait_ms(1);
} // Set_DDS_Amplitude



//-----------------------------------------------------------------------------
// Menu_Set_Source_Level
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
void Menu_Set_Source_Level(void)
{
    char akey = NO_KEY_PRESSED;

    Write_OK_Exit_Icons();
    old_cpt_encod = cpt_encod;
    Menu_Kind = KIND_LEVEL;
    Menu_Index = sourceLevel;
    Display_Menus();

    do
    {
        akey = GetUserAction();
        if (akey == MOVE_MARK_DOWN || akey == MOVE_MARK_UP)
            Menus_Move(akey);
    }
    while (!( (akey == KEY_5) || (akey == KEY_4)));     // Exit or OK

    if (akey == KEY_4)          // OK
    { 
        Set_Source_Level(Menu_Index);
    }
    GLCD_clear();
} // Menu_Set_Source_Level



//-----------------------------------------------------------------------------
// Set_Source_Level
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : LEVEL_1V_RMS, LEVEL_500mV_RMS, LEVEL_200mV_RMS, LEVEL_100mV_RMS
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
void Set_Source_Level(unsigned char value)
{
	switch (value)
	{
		default:
		case LEVEL_1V_RMS:
			reductionLevel = 1;
			break;
		case LEVEL_500mV_RMS:
			reductionLevel = 2;
			break;
		case LEVEL_200mV_RMS:
			reductionLevel = 5;
			break;
		case LEVEL_100mV_RMS:
			reductionLevel = 10;
			break;
	}

    sourceLevel = value;
    Set_Preamp_Gain(1);                         // set minimum preamp gain
    Set_DDS_Amplitude((float)reductionLevel);
    Set_Preamp_Gain(reductionLevel);            // compensation of DDS reduction level
} // Set_Source_Level



//-----------------------------------------------------------------------------
// Display_Bias_Control
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : step value
//
void Display_Bias_Control(uint step)
{
    char chaine1[20];

    if (DC_Bias_is_voltage)
    {
        ReadTextinFlash(38);                                    // "DC Bias level: 0 to 5V"
        if (step == 100)
            strcpy(chaine1, "step = 0.1 V ");
        else
            strcpy(chaine1, "step = 1 V   ");
    }
    else
    {
        ReadTextinFlash(39);                                    // "DC Bias level: 0 to 50mA"
        if (step == 100)
            strcpy(chaine1, "step = 1 mA  ");
        else
            strcpy(chaine1, "step = 10 mA ");
    }
    GLCD_draw_text(WITH_ICON28, 38, textLine, GLCD_PIXEL_ON);
    GLCD_draw_text(WITH_ICON28, 100, chaine1, GLCD_PIXEL_ON);
} // Display_Bias_Control



//-----------------------------------------------------------------------------
// Menu_Set_DC_BIAS
//-----------------------------------------------------------------------------
//
// Return Value : None
//
// DC bias voltage is DC_BIAS_VOLTAGE (0 to max 5.0V)
// DC bias current in low DC_R inductor is DC_BIAS_VOLTAGE / 100 (0 to max 50 mA)
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
void Menu_Set_DC_BIAS(void)
{
    uchar akey = NO_KEY_PRESSED;
    uint step = 1000;
    bit change = true;
    //uint oldDCmV = DC_mVolt;

    GLCD_clear();
    Write_OK_Exit_Icons();

    if (primaryKind != C_KIND && primaryKind != L_KIND)
    {
        Affiche_Text(WITH_ICON28, 38, 11, GLCD_PIXEL_ON);  // "No DC bias for resistor"
        DC_mVolt = 0;
        Set_DC_BIAS(DC_mVolt);
        wait_ms(2000);
        GLCD_clear();
        return;
    }

    Set_DC_BIAS(0);

    Display_Bias_Control(step);

    do
    {
        akey = GetUserAction();
        if (akey != NO_KEY_PRESSED)
            change = true;

        switch (akey)
        {
			case KEY_5: // Exit
                DC_mVolt = 0;
				break;

            case KEY_SW:
                if (step == 100)
                    step = 1000;
                else
                    step = 100;
                Display_Bias_Control(step);
                break;

            case MOVE_MARK_UP:
                if (DC_mVolt <= 5000 - step)
                    DC_mVolt += step;
                else
                    DC_mVolt = 5000;
                break;

            case MOVE_MARK_DOWN:
                if (DC_mVolt >= step)
                    DC_mVolt -= step;
                else
                    DC_mVolt = 0;
                break;

        }

        if (change)
        {
            change = false;

            if (DC_Bias_is_voltage)
                sprintf(chaine, "DC %1.1f V ", (float)DC_mVolt/1000);
            else    
                sprintf(chaine, "DC %1.0f mA ", (float)DC_mVolt/100);
            
            GLCD_draw_text(120, 80, chaine, GLCD_PIXEL_OFF);
        }
    }
    while (!( (akey == KEY_4) || (akey == KEY_5) ));    // Ok or Exit

    if (akey == KEY_5)  // Exit
    {
        DC_mVolt = 0;
        DC_Bias_is_voltage = true;
    }

    biasCurrent_Offset = Checks_Bias_Current();
    Set_DC_BIAS(DC_mVolt);
    GLCD_clear();
} // Menu_Set_DC_BIAS



//-----------------------------------------------------------------------------
// Set_DC_BIAS
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : the value
//
//
// DC_BIAS_VOLTAGE is 2 x DAC0_OUT.( 0 to max 5.0V)
// rangeHold is set to true for current bias
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
// 
void Set_DC_BIAS(uint DCmV)
{
    float coeff = 4096 / (2.0 * MCU_VREF);

    DAC0_Data = (uint)((float)DCmV/1000 * coeff);

    if (DCmV > 4000)
        MAX_BOOST = 1;              // V_BOOST = 7.5V
    else
        MAX_BOOST = 0;              // V_BOOST = 6.5V

    if (DAC0_Data == 0)
    {
        rangeHold = Saved_rangeHold;
        DC_BIAS_U_I = 0;
        DAC0_Update(0);
        return;
    }

    if (DC_Bias_is_voltage)
    {
        DC_BIAS_U_I = 1;
    }
    else
    {   
        Saved_rangeHold = rangeHold;
        rangeHold = true;
        DC_BIAS_U_I = 0;
    }

	if (DAC0_Data > 4095)
		DAC0_Data = 4095;

    DAC0_Update(DAC0_Data);
	wait_ms(10);
} // Set_DC_BIAS


//-----------------------------------------------------------------------------
// Set_Preamp_Gain
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : 1, 2, 5, 10
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
void Set_Preamp_Gain(unsigned char value)
{
	switch (value)
	{
		default:
		case 1:
			PGA1_A = 0;
			PGA1_B = 1;
			break;
		case 2:
			PGA1_A = 1;
			PGA1_B = 0;
			break;
		case 5:
			PGA1_A = 0;
			PGA1_B = 0;
			break;
		case 10:
			PGA1_A = 1;
			PGA1_B = 1;
			break;
	}
	wait_ms(1);
} // Set_Preamp_Gain


//-----------------------------------------------------------------------------
// Set_PSD_RC
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
void Set_PSD_RC(void)
{
	uchar i;
    
    if (freq >= 1490000.0)
    // R = 10R ->  freq: 1.5MHz   1.8MHz  2MHz		
	{
		i = 1;
        PSD_RC_C = 0;
        PSD_RC_B = 0;
		PSD_RC_A = 0;
		wait_steady_PSD = 2;    //1
	}

    else if (freq >= 495000.0)
    // R = 51R ->  freq: 500kHz  600kHz  700kHz  800kHz  900kHz  
    //                   1MHz  1.2MHz
	{
		i = 2;
        PSD_RC_C = 0;
		PSD_RC_B = 0;
		PSD_RC_A = 1;
		wait_steady_PSD = 3;    //2
	}
        
	else if (freq >= 49500.0)
    // R = 240R  ->  freq: 50kHz  60kHz  70kHz  80kHz  90kHz  
    //                     100kHz  120kHz  150kHz  200kHz  250kHz  300kHz  400kHz   
	{
		i = 3;
        PSD_RC_C = 0;
		PSD_RC_B = 1;
		PSD_RC_A = 0;
		wait_steady_PSD = 4;    //3
	}
        
	else if (freq >= 4950.0)
    // R = 1k  ->  freq: 5kHz  6kHz  7kHz  8kHz  9kHz  
    //                   10kHz  12kHz  15kHz  20kHz  25kHz  30kHz  40kHz
	{
		i = 4;
        PSD_RC_C = 0;
		PSD_RC_B = 1;
		PSD_RC_A = 1;
		wait_steady_PSD = 6;    //5
	}
          
    else if (freq >= 495.0)
    // R = 5.1k  -> freq: 500Hz  600Hz  700Hz  800Hz  900Hz  
    //                    1kHz  1.2kHz  1.5kHz  2kHz  3kHz  4kHz		        
	{
		i = 5;
        PSD_RC_C = 1;
		PSD_RC_B = 0;
		PSD_RC_A = 0;
		wait_steady_PSD = 22;
	}
          
    else if (freq >= 145.0)
    // R = 20k  ->  freq: 150Hz  200Hz  300Hz  400Hz
	{
		i = 6;
        PSD_RC_C = 1;
		PSD_RC_B = 0;
		PSD_RC_A = 1;
		wait_steady_PSD = 100;
	}
    
    else if (freq >= 99.0)
    // R = 51k  ->  freq: 100Hz  120Hz		        
	{
		i = 7;
        PSD_RC_C = 1;
		PSD_RC_B = 1;
		PSD_RC_A = 0;
		wait_steady_PSD = 150;
	}
       
    else
    // R = 75k  ->  freq: 50Hz  60Hz  70Hz  80Hz  90Hz 		        
	{
		i = 8;
        PSD_RC_C = 1;
		PSD_RC_B = 1;
		PSD_RC_A = 1;
		wait_steady_PSD = 250;
	}

	PGA_RC_level = i;
} // Set_PSD_RC


//-----------------------------------------------------------------------------
// Set_SPS_WithFreq
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
void Set_SPS_WithFreq(void)
{
    //uchar sps;

	if (freq >= 49900.0)
	{
		ADS_sps = ADS_SPS_80;
	}
	else if (freq >= 4990.0)
	{
		ADS_sps = ADS_SPS_80;
	}
	else if (freq >= 799.0)
	{
		ADS_sps = ADS_SPS_40;
	}
	else
	{
		ADS_sps = ADS_SPS_20;
	}

	ADS_SetSPS(ADS_sps);
} // Set_SPS_WithFreq


//-----------------------------------------------------------------------------
// Set_Resistor_Sense_Range
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : R_Range   1 to 4
//
// set RSELECT_SWx
// set Rsense value
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
void Set_Resistor_Sense_Range(unsigned char theRange)
{
    char SFRPAGE_SAVE = SFRPAGE;            // Save Current SFR page
	uchar port_P4;

    if (theRange == R_Range)
      return;

    SFRPAGE = CONFIG_PAGE;                  // P4 page

    port_P4 = P4 | 0x0F;			        // 0000 1111 -> open SW1 to SW4

    if (theRange == R_RANGE_1)
	{
		port_P4 &= 0xFE;					// 1111 1110 -> close SW1
		Rsense = R_VALUE_1;
        R_Standard = R_VALUE_1;
	}
	else if (theRange == R_RANGE_2)
	{ 
		port_P4 &= 0xFD;					// 1111 1101 -> close SW2
		Rsense = R_VALUE_2;
        R_Standard = R_VALUE_2;
	}
	else if (theRange == R_RANGE_3)
	{ 
		port_P4 &= 0xFB;					// 1111 1011 -> close SW3
		Rsense = R_VALUE_3;
        R_Standard = R_VALUE_3;
	}
	else if (theRange == R_RANGE_4)
	{
		port_P4 &= 0xF7;					// 1111 0111 -> close SW4
		Rsense = R_VALUE_4;
        R_Standard = R_VALUE_4;
	}

	R_Range = theRange;
	P4 = port_P4;

    SFRPAGE = SFRPAGE_SAVE;
    wait_us(50); 
} // Set_Resistor_Sense_Range


//-----------------------------------------------------------------------------
// Div_Complex
//-----------------------------------------------------------------------------
//
// Return Value : true if no error in a floating-point number operation
// Parameters   : A, B and pointer on C (real and imaginary parts)
//
//  C = A / B
//  If an error is detected the operation is not performed.
//
bit Div_Complex(float A_Real, float A_Imag, float B_Real, float B_Imag, float *C_Real, float *C_Imag)
{
    uchar a, b;
    float CR, CI;
	float Y = B_Real * B_Real + B_Imag * B_Imag;

    if (fabs(Y) < MINFLOAT)
        Y = MINFLOAT;

    CR = (A_Real * B_Real + A_Imag * B_Imag) / Y;
    CI = (A_Imag * B_Real - A_Real * B_Imag) / Y;

    a = _chkfloat_(CR); // >= 2 if there is an error
    b = _chkfloat_(CI);

    if (a >= 2 || b >= 2)
        return false;

    *C_Real = CR;
    *C_Imag = CI;
    return true;
} // Div_Complex


//-----------------------------------------------------------------------------
// Mul_Complex
//-----------------------------------------------------------------------------
//
// Return Value : true if no error in a floating-point number operation
// Parameters   : A, B and pointer on C (real and imaginary parts)
//
//  C = A * B
//  If an error is detected the operation is not performed.
//
bit Mul_Complex(float A_Real, float A_Imag, float B_Real, float B_Imag, float *C_Real, float *C_Imag)
{
    uchar a, b;
    float CR, CI;

	CR = (A_Real * B_Real - A_Imag * B_Imag);
	CI = (A_Imag * B_Real + A_Real * B_Imag);

    a = _chkfloat_(CR); // >= 2 if there is an error
    b = _chkfloat_(CI);

    if (a >= 2 || b >= 2)
        return false;

    *C_Real = CR;
    *C_Imag = CI;
    return true;
} // Mul_Complex


//-----------------------------------------------------------------------------
// Display_Non_Initialized_Data_Message
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Display a message when some variables are not initialized
//
void Display_Non_Initialized_Data_Message(void)
{
	uchar i = 1;
    uchar j = 0;
    uchar c_value;

    c_value = FLASH_ByteRead(CF_R1_OK_ADD, 0);
    if (c_value == 0 )
        j = 1;

    c_value = FLASH_ByteRead(CF_R2_OK_ADD, 0);
    if (c_value == 0 )
        j += 2;

    c_value = FLASH_ByteRead(CF_R3_OK_ADD, 0);
    if (c_value == 0 )
        j += 4;

    c_value = FLASH_ByteRead(CF_R4_OK_ADD, 0);
    if (c_value == 0 )
        j += 8;

    c_value = FLASH_ByteRead(PGA_G3_OK_ADD, 0);
    if (c_value == 0 )
        j += 16;

    c_value = FLASH_ByteRead(PGA_G10_OK_ADD, 0);
    if (c_value == 0 )
        j += 32;

	if (standalone)
    {
	    if (j != 0)
            GLCD_clear();

        if ( j & 0x01)
        {
            Affiche_Text(6, 12 * i, 19, GLCD_PIXEL_ON); // "Do the range 1 calibration"
            i++;
        }
        if ( j & 0x02)
        {
            Affiche_Text(6, 12 * i, 20, GLCD_PIXEL_ON); // "Do the range 2 calibration"
            i++;
        }
        if ( j & 0x04)
        {
            Affiche_Text(6, 12 * i, 21, GLCD_PIXEL_ON); // "Do the range 3 calibration"
            i++;
        }
        if ( j & 0x08)
        {
            Affiche_Text(6, 12 * i, 22, GLCD_PIXEL_ON); // "Do the range 4 calibration"
            i++;
        }
        if ( j & 0x10)
        {
            Affiche_Text(6, 12 * i, 24, GLCD_PIXEL_ON); // "Do PGA2 gain 3 calibration"
            i++;
        }
        if ( j & 0x20)
        {
            Affiche_Text(6, 12 * i, 25, GLCD_PIXEL_ON); // "Do PGA2 gain 10 calibration"
            i++;
        }
        if (j != 0)
            wait_ms (2000);
	}
    else
    {
		sprintf(chaine, "I_STATUS %u",(uint)j); 
		Send_Message(chaine);
	}      
} // Display_Non_Initialized_Data_Message


//-----------------------------------------------------------------------------
// Check_Calibration_Datas
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
void Check_Calibration_Datas (void)
{
    uchar c_value, c1_value;

    // PGA_G3_OK
    c1_value = 0;      // false	
    c_value = FLASH_ByteRead(PGA_G3_OK_ADD, 0);
	if (c_value == 0xFF )	
	{
        FLASH_Write (PGA_G3_OK_ADD, (char *) &c1_value, CHAR_SIZE, 0);
        PGA_G3_ok = false;
	}
    else
        PGA_G3_ok = (c_value == 1);

    // PGA_G10_OK
    c_value = FLASH_ByteRead(PGA_G10_OK_ADD, 0);
	if (c_value == 0xFF )	
	{
        FLASH_Write (PGA_G10_OK_ADD, (char *) &c1_value, CHAR_SIZE, 0);
        PGA_G10_ok = false;
	}
    else
        PGA_G10_ok = (c_value == 1);

    // CF_R1_OK
    c_value = FLASH_ByteRead(CF_R1_OK_ADD, 0);
	if (c_value == 0xFF )	
	{
        FLASH_Write (CF_R1_OK_ADD, (char *) &c1_value, CHAR_SIZE, 0);
        Calibration_Factor_R1_ok = false;
	}
    else
        Calibration_Factor_R1_ok = (c_value == 1);

    // CF_R2_OK
    c_value = FLASH_ByteRead(CF_R2_OK_ADD, 0);
	if (c_value == 0xFF )	
	{
        FLASH_Write (CF_R2_OK_ADD, (char *) &c1_value, CHAR_SIZE, 0);
        Calibration_Factor_R2_ok = false;
	}
    else
        Calibration_Factor_R2_ok = (c_value == 1);

    // CF_R3_OK
    c_value = FLASH_ByteRead(CF_R3_OK_ADD, 0);
	if (c_value == 0xFF )	
	{
        FLASH_Write (CF_R3_OK_ADD, (char *) &c1_value, CHAR_SIZE, 0);
        Calibration_Factor_R3_ok = false;
	}
    else
        Calibration_Factor_R3_ok = (c_value == 1);

    // CF_R4_OK
    c_value = FLASH_ByteRead(CF_R4_OK_ADD, 0);
	if (c_value == 0xFF )	
	{
        FLASH_Write (CF_R4_OK_ADD, (char *) &c1_value, CHAR_SIZE, 0);
        Calibration_Factor_R4_ok = false;
	}
    else
        Calibration_Factor_R4_ok = (c_value == 1);

} // Check_Calibration_Datas


//-----------------------------------------------------------------------------
// Check_Saved_Datas
//-----------------------------------------------------------------------------
//
// Return Value : false if no language loaded in high memory
// Parameters   : None
//
// check if code variables are initialized (first byte not equal to 0xFF, or value not allowed).
//                                                          
// If not, write the default value in the EEPROM
//
// update the XX_ok values
//
bit Check_Saved_Datas(void)
{
	uchar c_value, c1_value;
	uint i_value;
    ulong l_value;
	float f_value;
    char long_message[6];

    // saved_index_freq
    FLASH_Read((char *) &c_value, SAVED_I_FREQ_ADD, CHAR_SIZE, 0);
	if (c_value == 0xFF)	
	{
        c_value = 26;  // -> 10 kHz
        FLASH_Write (SAVED_I_FREQ_ADD, (char *) &c_value, CHAR_SIZE, 0);       
	}
    saved_index_freq = c_value;
    
    // Q limit
    FLASH_Read((char *) &i_value, Q_LIMIT_ADD, INT_SIZE, 0);
	if (i_value == 0xFFFF )				// no initialization
	{
		i_value = MAX_Q;				// Q = 50000
		FLASH_Write(Q_LIMIT_ADD, (char *) &i_value, INT_SIZE, 0);
	}
    else if (i_value < 100 || i_value > MAX_Q)      // bad initialization
	{
		i_value = MAX_Q;			    // Q = 50000
		FLASH_Update(Q_LIMIT_ADD, (char *) &i_value, INT_SIZE, 0);
	}
    Q_No_Display_Secondary = i_value;

    if (!standalone)
    {
        strcpy(textMenu, message_SAVED_PARAMETERS);             // "PAR "
        sprintf(long_message, "%u ", (uint)Q_No_Display_Secondary);
        strcat(textMenu, long_message);                         // "PAR 1000 "
    }

    // series
    c_value = FLASH_ByteRead(SERIES_ADD, 0);
	if (c_value > E96 )				                // no or bad initialization
	{
        c_value = 2;   // E24
        FLASH_Update(SERIES_ADD, (char *) &c_value, CHAR_SIZE, 0);
	}
    saved_Series = c_value;

    if (!standalone)
    {     
        strcpy(Buffer, Series_Array[saved_Series]);
        c1_value = 0;
        while ( Buffer[c1_value] != ' ')
        {
          long_message[c1_value] = Buffer[c1_value];
          c1_value++;  
        }
        long_message[c1_value] = '\0';
        strcat(textMenu, long_message);             // "PAR 1000 E24"
    }

    // baudrate
    FLASH_Read((char *) &l_value, UART1_BAUDRATE_ADD, LONG_SIZE, 0);
    if (l_value == 0xFFFFFFFF)
    {
        l_value = UART1_baudrate;
        FLASH_Write(UART1_BAUDRATE_ADD, (char *) &l_value, LONG_SIZE, 0);
    }
    if (l_value == UART1_baudrate)        
        strcat(textMenu, " 2");                     // "PAR 1000 E24 2"
    else
        strcat(textMenu, " 1");

    // DDS_VREF
    FLASH_Read((char *) &f_value, DDS_VREF_VALUE_ADD, FLOAT_SIZE, 0);
	if (f_value == 0xFFFFFFFF )	
	{
        f_value = DDS_VREF;
        FLASH_Write (DDS_VREF_VALUE_ADD, (char *) &f_value, FLOAT_SIZE, 0);
	}
    else if (f_value < 1.12 || f_value > 1.24)
	{
		f_value = DDS_VREF;					
		FLASH_Update(DDS_VREF_VALUE_ADD, (char *)  &f_value, FLOAT_SIZE, 0);
	}

    sprintf (long_message, " %1.0f", f_value * 1000);    // copy DDS_VREF mV in Buffer as xxxx
    if (!standalone)
    {     
        strcat(textMenu, long_message);             // "PAR 1000 E24 2 1180"
    }

    // BOOT_VERSION
    FLASH_Read((char *) &f_value, BOOTLOADER_VERSION_ADD, FLOAT_SIZE, 0);
    if (f_value == 0xFFFFFFFF )	
	{
        f_value = 1.0;
        FLASH_Write (BOOTLOADER_VERSION_ADD, (char *) &f_value, FLOAT_SIZE, 0);
	}
    Bootloader_Ver = f_value;

    // Calibrations
    Check_Calibration_Datas();

     // Test if valid languages are in BANK 2
    FLASH_Read((char *) &c_value, NUMBER_LANGUAGE_ADD, CHAR_SIZE, 0);
    if ( c_value > MAX_LANGUAGE || c_value == 0)				// no initialization (0xFF) or no valid language
        return false;
    numberLanguage = c_value;

    FLASH_Read((char *) &c_value, NUMBER_TEXT_LINES_ADD, CHAR_SIZE, 0);
    if ( c_value > MAX_TEXT_LINES || c_value == 0xFF)			// no initialization  or no valid language
        return false;
    numberLineText = c_value;

    FLASH_Read((char *) &c_value, NUMBER_CONFIG_LINES_ADD, CHAR_SIZE, 0);
    if ( c_value > MAX_CONFIG_LINES || c_value == 0xFF)			// no initialization  or no valid language
        return false;
    numberLineConfig = c_value;

    FLASH_Read((char *) &c_value, NUMBER_MENU_LINES_ADD, CHAR_SIZE, 0);
    if ( c_value > MAX_MENU_LINES || c_value == 0xFF)			// no initialization  or no valid language
        return false;
    numberLineMenu = c_value;

    // selected language
    c_value = FLASH_ByteRead(LANGUAGE_ADD, 0);
	if ( c_value > MAX_LANGUAGE - 1 )				// no or bad initialization
	{   
        c_value = 0;   // English       
        FLASH_Update(LANGUAGE_ADD, (char *) &c_value, CHAR_SIZE, 0);
	}
    current_language = c_value;

    return true;  
} // Check_Saved_Datas


//-----------------------------------------------------------------------------
// Justify_Right_Buffer
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//						
// move the string to the right
//
void Justify_Right_Buffer(void)
{
	char i, j;

	i = strlen(Buffer);
	if (i < BUFFER_SIZE)
	{
		for (j = BUFFER_SIZE; i >= 0; i--, j--)
		{
			Buffer[j] = Buffer[i];
            Buffer[i] = ' ';
		}

        if (j > 0)
        {
            for (j; j>= 0; j--)
            {
                Buffer[j] = ' ';
            }
        }
	}
} // Justify_Right_Buffer


//-----------------------------------------------------------------------------
// Convert_Value_to_String
//-----------------------------------------------------------------------------
//
// Return Value :	Number of character in Buffer
// Parameters   :	accuracy : 0 for 3 digits, 3 for 4 digits, 6 for 5 digits
//							suffix : add suffix or not
//							Comp_Kind : kind of componant to display value (R, L, C)
//							adjust_format : if true, modify accuracy if needed
//
// Convert float 'Value_to_Print' to formated string in 'Buffer'
//		according accuracy and kind of componant
// Put suffix (f, p, n, u, m, k, M, G, T) in 'Expo' if boolean 'suffix' is true
//
//
char Convert_Value_to_String(uchar accuracy, bit suffix, uchar Comp_Kind, bit adjust_format)
{
    char  expo, i;
    int format = 0;
    char len;
    float f1;
    float int_part;
    bit  lower_1 = true;
    bit  negatif;

    negatif = (Value_to_Print < 0.0);

    if ((negatif) && (accuracy > 3) && (adjust_format))
        accuracy -=3;

    f1 = fabs(Value_to_Print);

    // Deal with specific cases
    if ((Comp_Kind == R_KIND) && (f1 > 1.00e9))		// 1 Gohm
    {
        if (negatif)
            strcpy(Buffer, "< - 1");
        else
            strcpy(Buffer, " > 1");
        return 9;   // giga
    }
    else if ((Comp_Kind == C_KIND) && (f1 > 0.1))		// 100mF
    {
        strcpy(Buffer, ">100");
        return -3;  // milli
    }
    else if ((Comp_Kind == L_KIND) && (f1 > 100))		// 100H
    {
        strcpy(Buffer, ">100");
        return 0;
    }

/*
    // avoid displaying 1000.0 mV instead of 1.0000 V
    if ((f1 < 1.00) && (f1 >= 0.99998))
    {
        f1 = 1.0;
    }
    else if ((f1 < 1000.0) && (f1 >= 999.98))
    {
        f1 = 1000.0;
    }
    else if ((f1 < 1000000.0) && (f1 >= 999980.0))
    {
        f1 = 1000000.0;
    }
*/
    if (f1 != 0.0)						// 0.0 is special case!
    {
        lower_1 = (f1 < 1.0);			// true if value < 1.0
        f1 = log10(f1);
        f1 = modf (f1, &int_part);		// f1 is fractionnal part of log10
                                        // int_part is integer part
        f1 = pow(10,f1);				// f1 is formated value x.xxx to xxx.x
    }
    else
        int_part = 1.0;

    if ((!lower_1) && (f1 > 9.0) && (accuracy == 6) && (adjust_format))
        accuracy = 3;

   expo = (char)fmod(int_part, 3.0);

   if (lower_1)								// value < 1.0
   {
       if ( (Comp_Kind == C_KIND) && (int_part <= -9) )				// display in picoFarad
       {
           format = 2;                  // 2 digits after the decimal point
           if (int_part == -9)
           {
               f1 *= 1000.0;
               format = 1;              // 1 digits after the decimal point
           }
           else if (int_part == -10)
               f1 *= 100.0;
           else if (int_part == -11)
               f1 *= 10.0;
           else if (int_part == -12)
               ;
           else if (int_part == -13)
               f1 *= 0.1;
           else if (int_part == -14)
               f1 *= 0.01;
           else if (int_part == -15)
               f1 *= 0.001;
           else
               f1 = 0.0;
           int_part = -12;
       }
       else if ( (Comp_Kind == L_KIND) && (int_part <= -6) )		// display in nanoHenri
       {
           format = 1;                  // 1 digits after the decimal point
           if (int_part == -6)
               f1 *= 1000.0;
            else if (int_part == -7)
               f1 *= 100.0;
           else if (int_part == -8)
               f1 *= 10.0;
           else if (int_part == -9)
               ;
           else if (int_part == -10)
               f1 *= 0.1;
           else if (int_part == -11)
               f1 *= 0.01;
           else if (int_part == -12)
               f1 *= 0.001;
           else
               f1 = 0.0;
           int_part = -9;
       }
       else if ( (Comp_Kind == R_KIND) && (int_part <= 0) )			// display in milliOhm
       {
           if (int_part == 0)           // 0.xxxx
           {
               f1 *=1000.0;
               format = 1;              // 1 digits after the decimal point
           }
           else if (int_part == -1)    // 0.0xxxx
           {
               f1 *=100.0;
               format = 2;              // 2 digits after the decimal point
           }
           else if (int_part == -2)    // 0.00xxxx
           {
               f1 *=10.0;
               format = 2;              // 2 digits after the decimal point
           }
           else if (int_part == -3)    // 0.000xxxx
               format = 1;              // 1 digits after the decimal point
           else
           {
               f1 = 0.0;
               format = 2;          // 0.00
           }
           int_part = -3;
       }
        else
        {
            switch (expo)
            {
                case 0:
                    f1 *= 1000;
                    int_part -= 3.0;
                    format = 0 + accuracy;
                    break;
                case -1:
                    f1 *= 100;
                    int_part -= 2.0;
                    format = 1 + accuracy;
                    break;
                case -2:
                    f1 *= 10;
                    int_part -= 1.0;
                    format = 2 + accuracy;
                    break;
            } // switch
        }
   } // if (lower_1)
   else if (!lower_1)                 				// value >= 1.0
   {
        switch (expo)
        {
            case 0:
                format = 2 + accuracy;
                break;
            case 1:
                f1 *= 10.0;
                int_part -= 1.0;
                format = 1 + accuracy;
                break;
            case 2:
                f1 *= 100.0;
                int_part -= 2.0;
                format = 0 + accuracy;
                break;
        }

        if (Comp_Kind == C_KIND)
            format = 0;
   }

    sprintf (Buffer, Table_format[format], f1);
    len = strlen(Buffer);

    if (negatif)    // put '-' in front of Buffer
    {
        if (len == BUFFER_SIZE)
        {
            Buffer[BUFFER_SIZE - 1] = '\0';
            len--;
        }

        for (i = len; i >= 0; i--)
        {
            Buffer[i+1] = Buffer[i];
        }
        Buffer[0] = '-';
        len++;
    }

	if (suffix == WITHOUT_SUFFIX)
		return 0;

    return int_part;
} // Convert_Value_to_String



//-----------------------------------------------------------------------------
// Load_Expo
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : the exponent value, genre, add or not space before suffix
//
// Put suffix (p, n, �, m, k, M, G) in Expo[]					
//
void Load_Expo(char int_part, uchar theGenre, bit space)
{
    if (space)
        strcpy(Expo," ");
    else
        strcpy(Expo,"");

    if (activeFont == FONT_IS_8x16  && standalone)
    {
	    switch ((char)int_part)          // put suffix
        {
            case -12:
                strcat(Expo, CHAR_PICO);
                break;
            case -9:
                strcat(Expo, CHAR_NANO);
                break;
            case -6:
                strcat(Expo, CHAR_MU);
                break;
            case -3:
                strcat(Expo, CHAR_MILLI);
                break;
		    case 0:
                break;
            case 3:
                strcat(Expo, CHAR_KILO);
                break;
            case 6:
                strcat(Expo, CHAR_MEGA);
                break;
            case 9:
                strcat(Expo, CHAR_GIGA);
                break;
        }
        
        switch (theGenre)
	    {
		    case R_KIND:
			    strcat(Expo,CHAR_OMEGA);
			    break;
	    	case L_KIND:
			    strcat(Expo,CHAR_H);
			    break;
		    case C_KIND:
			    strcat(Expo,CHAR_F);
			    break;
		    default:;
	    }
	    if (strlen(Expo) == 1)
			    strcat(Expo," ");
    }
    else if (activeFont == FONT_IS_6x11 || !standalone)
    {
	    switch ((char)int_part)          // put suffix
        {
	        case -15:
                strcat(Expo, "f");
                break;
            case -12:
                strcat(Expo, "p");
                break;
            case -9:
                strcat(Expo, "n");
                break;
            case -6:
                if (standalone)
                    strcat(Expo, "�");
                else
                    strcat(Expo, "u");
                break;
            case -3:
                strcat(Expo, "m");
                break;
		    case 0:
                break;
            case 3:
                strcat(Expo, "k");
                break;
            case 6:
                strcat(Expo, "M");
                break;
            case 9:
                strcat(Expo, "G");
                break;
            case 12:
                strcat(Expo, "T");
                break;
        }

        switch (theGenre)
	    {
		    case R_KIND:
                if (standalone)
			        strcat(Expo,CHAR_OMEGA_6x11);
                else
                    strcat(Expo,"O");   // for omega
			    break;
	    	case L_KIND:
			    strcat(Expo,"H");
			    break;
		    case C_KIND:
			    strcat(Expo,"F");
			    break;
            case PHI_KIND:
                if (standalone)
                    strcat(Expo, "�");
                else
                    strcat(Expo,"D");  // for degre
                break;
            case A_KIND:
			    strcat(Expo,"A");
			    break;
		    case V_KIND:
			    strcat(Expo,"V");
			    break;
		    default:;
	    }
	    if (strlen(Expo) == 1)
			    strcat(Expo," ");
    }
} // Load_Expo


//-----------------------------------------------------------------------------
// FLASH Routines (From Silicon Labs Application Notes AN201) 
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
// FLASH_Clear
//-----------------------------------------------------------------------------
//
// This routine erases <numbytes> starting from the FLASH addressed by
// <dest> by performing a read-modify-write operation using <FLASH_TEMP> as
// a temporary holding area.  This function accepts <numbytes> up to
// <FLASH_PAGESIZE>.
//
void FLASH_Clear (FLADDR dest, unsigned numbytes, bit SFLE)
{
   FLADDR dest_1_page_start;           // first address in 1st page
                                       // containing <dest>
   FLADDR dest_1_page_end;             // last address in 1st page
                                       // containing <dest>
   FLADDR dest_2_page_start;           // first address in 2nd page
                                       // containing <dest>
   FLADDR dest_2_page_end;             // last address in 2nd page
                                       // containing <dest>
   unsigned numbytes_remainder;        // when crossing page boundary,
                                       // number of <src> bytes on 2nd page
   unsigned FLASH_pagesize;            // size of FLASH page to update

   FLADDR  wptr;                       // write address
   FLADDR  rptr;                       // read address

   unsigned length;

   if (SFLE) {                         // update Scratchpad
      FLASH_pagesize = FLASH_SCRATCHSIZE;
   } else {
      FLASH_pagesize = FLASH_PAGESIZE;
   }

   dest_1_page_start = dest & ~(FLASH_pagesize - 1);
   dest_1_page_end = dest_1_page_start + FLASH_pagesize - 1;
   dest_2_page_start = (dest + numbytes)  & ~(FLASH_pagesize - 1);
   dest_2_page_end = dest_2_page_start + FLASH_pagesize - 1;

   if (dest_1_page_end == dest_2_page_end) {

      // 1. Erase Scratch page
      FLASH_PageErase (FLASH_TEMP, 0);

      // 2. Copy bytes from first byte of dest page to dest-1 to Scratch page
      wptr = FLASH_TEMP;
      rptr = dest_1_page_start;
      length = dest - dest_1_page_start;
      FLASH_Copy (wptr, 0, rptr, SFLE, length);

      // 3. Copy from (dest+numbytes) to dest_page_end to Scratch page
      wptr = FLASH_TEMP + dest - dest_1_page_start + numbytes;
      rptr = dest + numbytes;
      length = dest_1_page_end - dest - numbytes + 1;
      FLASH_Copy (wptr, 0, rptr, SFLE, length);

      // 4. Erase destination page
      FLASH_PageErase (dest_1_page_start, SFLE);

      // 5. Copy Scratch page to destination page
      wptr = dest_1_page_start;
      rptr = FLASH_TEMP;
      length = FLASH_pagesize;
      FLASH_Copy (wptr, SFLE, rptr, 0, length);

   } else {                            // value crosses page boundary
      // 1. Erase Scratch page
      FLASH_PageErase (FLASH_TEMP, 0);

      // 2. Copy bytes from first byte of dest page to dest-1 to Scratch page
      wptr = FLASH_TEMP;
      rptr = dest_1_page_start;
      length = dest - dest_1_page_start;
      FLASH_Copy (wptr, 0, rptr, SFLE, length);

      // 3. Erase destination page 1
      FLASH_PageErase (dest_1_page_start, SFLE);

      // 4. Copy Scratch page to destination page 1
      wptr = dest_1_page_start;
      rptr = FLASH_TEMP;
      length = FLASH_pagesize;
      FLASH_Copy (wptr, SFLE, rptr, 0, length);

      // now handle 2nd page

      // 5. Erase Scratch page
      FLASH_PageErase (FLASH_TEMP, 0);

      // 6. Copy bytes from numbytes remaining to dest-2_page_end to Scratch page
      numbytes_remainder = numbytes - (dest_1_page_end - dest + 1);
      wptr = FLASH_TEMP + numbytes_remainder;
      rptr = dest_2_page_start + numbytes_remainder;
      length = FLASH_pagesize - numbytes_remainder;
      FLASH_Copy (wptr, 0, rptr, SFLE, length);

      // 7. Erase destination page 2
      FLASH_PageErase (dest_2_page_start, SFLE);

      // 8. Copy Scratch page to destination page 2
      wptr = dest_2_page_start;
      rptr = FLASH_TEMP;
      length = FLASH_pagesize;
      FLASH_Copy (wptr, SFLE, rptr, 0, length);
   }
}


//-----------------------------------------------------------------------------
// FLASH_Update
//-----------------------------------------------------------------------------
//
// This routine replaces <numbytes> from <src> to the FLASH addressed by
// <dest>.  This function calls FLASH_Clear() to handle the dirty work of
// initializing all <dest> bytes to 0xff's prior to copying the bytes from
// <src> to <dest>. This function accepts <numbytes> up to <FLASH_PAGESIZE>.
//
void FLASH_Update (FLADDR dest, char *src, unsigned numbytes, bit SFLE)
{
   // 1. Erase <numbytes> starting from <dest>
   FLASH_Clear (dest, numbytes, SFLE);

   // 2. Write <numbytes> from <src> to <dest>
   FLASH_Write (dest, src, numbytes, SFLE);
}


//-----------------------------------------------------------------------------
// FLASH_Write
//-----------------------------------------------------------------------------
//
// This routine copies <numbytes> from <src> to the linear FLASH address
// <dest>.
//
void FLASH_Write (FLADDR dest, char *src, unsigned numbytes, bit SFLE)
{
   FLADDR i;

   for (i = dest; i < dest+numbytes; i++) {
      FLASH_ByteWrite (i, *src++, SFLE);
   }
}


//-----------------------------------------------------------------------------
// FLASH_Read
//-----------------------------------------------------------------------------
//
// This routine copies <numbytes> from the linear FLASH address <src> to
// <dest>.
//
char * FLASH_Read (char *dest, FLADDR src, unsigned numbytes, bit SFLE)
{
   FLADDR i;

   for (i = 0; i < numbytes; i++) {
      *dest++ = FLASH_ByteRead (src+i, SFLE);
   }
   return dest;
}


//-----------------------------------------------------------------------------
// FLASH_Copy
//-----------------------------------------------------------------------------
//
// This routine copies <numbytes> from <src> to the linear FLASH address
// <dest>.
//
void FLASH_Copy (FLADDR dest, bit destSFLE, FLADDR src, bit srcSFLE,
                 unsigned numbytes)
{
   FLADDR i;

   for (i = 0; i < numbytes; i++) {

      FLASH_ByteWrite ((FLADDR) dest+i,
                       FLASH_ByteRead((FLADDR) src+i, srcSFLE),
                       destSFLE);
   }
}


//-----------------------------------------------------------------------------
// FLASH_ByteWrite
//-----------------------------------------------------------------------------
//
// This routine writes <byte> to the linear FLASH address <addr>.
// Linear map is decoded as follows:
// Linear Address       Bank     Bank Address
// ------------------------------------------------
// 0x00000 - 0x07FFF    0        0x0000 - 0x7FFF
// 0x08000 - 0x0FFFF    1        0x8000 - 0xFFFF
// 0x10000 - 0x17FFF    2        0x8000 - 0xFFFF
// 0x18000 - 0x1FFFF    3        0x8000 - 0xFFFF
//
void FLASH_ByteWrite (FLADDR addr, char byte, bit SFLE)
{
   char SFRPAGE_SAVE = SFRPAGE;        // preserve SFRPAGE
   bit EA_SAVE = EA;                   // preserve EA
   char PSBANK_SAVE = PSBANK;          // preserve PSBANK
   char xdata * data pwrite;           // FLASH write pointer

   EA = 0;                             // disable interrupts

   SFRPAGE = LEGACY_PAGE;

   if (addr < 0x10000) {               // 64K linear address
      pwrite = (char xdata *) addr;
   } else if (addr < 0x18000) {        // BANK 2
      addr |= 0x8000;
      pwrite = (char xdata *) addr;
      PSBANK &= ~0x30;                 // COBANK = 0x2
      PSBANK |=  0x20;
   } else {                            // BANK 3
      pwrite = (char xdata *) addr;
      PSBANK &= ~0x30;                 // COBANK = 0x3
      PSBANK |=  0x30;
   }

   FLSCL |= 0x01;                      // enable FLASH writes/erases
   PSCTL |= 0x01;                      // PSWE = 1

   if (SFLE) {
      PSCTL |= 0x04;                   // set SFLE
   }

   RSTSRC = 0x02;                      // enable VDDMON as reset source
   *pwrite = byte;                     // write the byte

   if (SFLE) {
      PSCTL &= ~0x04;                  // clear SFLE
   }
   PSCTL &= ~0x01;                     // PSWE = 0
   FLSCL &= ~0x01;                     // disable FLASH writes/erases

   PSBANK = PSBANK_SAVE;               // restore PSBANK
   SFRPAGE = SFRPAGE_SAVE;             // restore SFRPAGE
   EA = EA_SAVE;                       // restore interrupts
}


//-----------------------------------------------------------------------------
// FLASH_ByteRead
//-----------------------------------------------------------------------------
//
// This routine reads a <byte> from the linear FLASH address <addr>.
//
unsigned char FLASH_ByteRead (FLADDR addr, bit SFLE)
{
   char SFRPAGE_SAVE = SFRPAGE;        // preserve SFRPAGE
   bit EA_SAVE = EA;                   // preserve EA
   char PSBANK_SAVE = PSBANK;          // preserve PSBANK
   char code * data pread;             // FLASH read pointer
   unsigned char byte;

   EA = 0;                             // disable interrupts

   SFRPAGE = LEGACY_PAGE;

   if (addr < 0x10000) {               // 64K linear address
      pread = (char code *) addr;
   } else if (addr < 0x18000) {        // BANK 2
      addr |= 0x8000;
      pread = (char code *) addr;
      PSBANK &= ~0x30;                 // COBANK = 0x2
      PSBANK |=  0x20;
   } else {                            // BANK 3
      pread = (char code *) addr;
      PSBANK &= ~0x30;                 // COBANK = 0x3
      PSBANK |=  0x30;
   }

   if (SFLE) {
      PSCTL |= 0x04;                   // set SFLE
   }

   byte = *pread;                      // read the byte

   if (SFLE) {
      PSCTL &= ~0x04;                  // clear SFLE
   }

   PSBANK = PSBANK_SAVE;               // restore PSBANK
   SFRPAGE = SFRPAGE_SAVE;             // restore SFRPAGE
   EA = EA_SAVE;                       // restore interrupts

   return byte;
}


//-----------------------------------------------------------------------------
// FLASH_PageErase
//-----------------------------------------------------------------------------
//
// This routine erases the FLASH page containing the linear FLASH address
// <addr>.
//
void FLASH_PageErase (FLADDR addr, bit SFLE)
{
   char SFRPAGE_SAVE = SFRPAGE;        // preserve SFRPAGE
   bit EA_SAVE = EA;                   // preserve EA
   char PSBANK_SAVE = PSBANK;          // preserve PSBANK
   char xdata * data pwrite;           // FLASH write pointer

   EA = 0;                             // disable interrupts

   SFRPAGE = LEGACY_PAGE;

   if (addr < 0x10000) {               // 64K linear address
      pwrite = (char xdata *) addr;
   } else if (addr < 0x18000) {        // BANK 2
      addr |= 0x8000;
      pwrite = (char xdata *) addr;
      PSBANK &= ~0x30;                 // COBANK = 0x2
      PSBANK |=  0x20;
   } else {                            // BANK 3
      pwrite = (char xdata *) addr;
      PSBANK &= ~0x30;                 // COBANK = 0x3
      PSBANK |=  0x30;
   }

   FLSCL |= 0x01;                      // enable FLASH writes/erases
   PSCTL |= 0x03;                      // PSWE = 1; PSEE = 1

   if (SFLE) {
      PSCTL |= 0x04;                   // set SFLE
   }

   RSTSRC = 0x02;                      // enable VDDMON as reset source
   *pwrite = 0;                        // initiate page erase

   if (SFLE) {
      PSCTL &= ~0x04;                  // clear SFLE
   }

   PSCTL &= ~0x03;                     // PSWE = 0; PSEE = 0
   FLSCL &= ~0x01;                     // disable FLASH writes/erases

   PSBANK = PSBANK_SAVE;               // restore PSBANK
   SFRPAGE = SFRPAGE_SAVE;             // restore SFRPAGE
   EA = EA_SAVE;                       // restore interrupts
}


//-----------------------------------------------------------------------------
// erase_flash
//-----------------------------------------------------------------------------
//
// This routine erases pages of FLASH beetwen debut & fin
//
void erase_flash(FLADDR debut, FLADDR fin)
{
  	bit EA_state = EA;                  // preserve EA
     
  	FLADDR i;                 			// temporary long
    EA = 0;                          	// disable interrupts

	for (i = debut; i < fin; i += 0x400)    // C8051F12x size page is 1024 byte
		FLASH_PageErase (i, 0);
  
  	EA =  EA_state;                  	// restore interrupt state
}


//-----------------------------------------------------------------------------
// End Of File
//-----------------------------------------------------------------------------
