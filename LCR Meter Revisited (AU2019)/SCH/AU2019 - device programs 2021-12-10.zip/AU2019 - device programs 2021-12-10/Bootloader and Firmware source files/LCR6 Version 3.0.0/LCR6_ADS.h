//-----------------------------------------------------------------------------
// LCR6_ADS.h
//-----------------------------------------------------------------------------
// 
// Author: Jean-Jacques Aubry 2013-2020
//
// Target: C8051F120 
// Compiler: KEIL C51 V9.60.0.0  
//
// Version (see 'FirmwareVersion' in LCR5.h)
//
// ADS1246 functions
//

#ifndef _LCR6_ADS_H
#define _LCR6_ADS_H

#include "LCR6_Defines.h"

#include <intrins.h>			// NOP


void    ADS_Init (void);
void    ADS_Reset (void);
void    ADS_SelfOffset_Calibration (void);
uchar   ADS_Read_Register(uchar address);
void    ADS_Write_Register(uchar address, uchar value);
bit     ADS_Read_measure(long* result);
void    ADS_SetPGA_Range(uchar range);
void    ADS_SetSPS(uchar SPS);
bit     Get_Best_ADS_Measure (long* theresult);

#endif