//-----------------------------------------------------------------------------
// LCR6_DDS.c
//-----------------------------------------------------------------------------
// 
// Author: Jean-Jacques Aubry 2013-2020
//
// Target: C8051F120 
// Compiler: KEIL C51 V9.60.0.0  
//
// Version (see 'FirmwareVersion' in LCR6.h)
// 
// AD9834 functions
//


#include "LCR6_DDS.h"

extern  void    wait_us(unsigned int us);
extern  void	Set_PSD_RC(void);
extern  void    Buffer_Init (void);
extern  void    Set_DDS2_Phase_Correction(void);
extern  uint    code Tab_Phase_Init[FREQ_MEM_SIZE];
extern  void    ADS_SetSPS(uchar SPS);
extern  ulong   xdata overflow_time;
extern  uchar   xdata Max_Range;
extern  float   xdata freq;
extern  uchar   xdata Freq_index;
extern  char    xdata Range_counter;
extern  bit     in_calibration;
extern  bit 	wait_ms (unsigned int x);

uint    control_register;


//-----------------------------------------------------------------------------
// DDS_Init
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
// 
void DDS_Init(void)
{
	DDS_Init_Control_Register();
   	DDS_Reset();
    DDS_Load_PhaseReg(PHI_DDS1_0, DDS1_ONLY);   // DDS1 phase_register0 = PHI_DDS1_0
	DDS_Load_PhaseReg(PHI_DDS2_0, DDS2_ONLY);   // DDS2 phase_register0 = PHI_DDS2_0
}


//-----------------------------------------------------------------------------
// DDS_Init_Control_Register
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Init DDS1 & DDS2 for pin select of freq_register/phase_register/reset, and full 28-bit word
//
void DDS_Init_Control_Register(void)
{
    control_register = 0;

	// PIN_SW = 1 -> freq register, phase register & reset selected by pins
	control_register = BitSet(control_register, PIN_SW);

	// B28 = 1 -> full 28-bit word
	control_register = BitSet(control_register, B28);

	// default = 0 for others (FSEL, PSEL ...)
	DDS_Send(control_register, DDS1_AND_DDS2);	// send to both DDS
}



//-----------------------------------------------------------------------------
// DDS_Send
//-----------------------------------------------------------------------------
//
// Return Value :   None
// Parameters   :   int (16 bits) value to write in DDS register
//			    	uchar   DDS1_AND_DDS2 for update of both (DDS1 & DDS2), 
//					        or only DDS1 (DDS1_ONLY), or only DDS2 (DDS2_ONLY)
//
// FSYNC_DDS1_	= P6^3;
// FSYNC_DDS2_	= P6^6;
//
// MSB first
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
void DDS_Send(unsigned int value, uchar DDSx)
{
    uint mask = 0x8000;
	uchar P6_mask;

	if (DDSx == DDS1_AND_DDS2)
		P6_mask = 0xB7;		// 1011 0111	-> FSYNC_DDS1_ & FSYNC_DDS2_
	else if (DDSx == DDS1_ONLY)
		P6_mask = 0xF7;		// 1111 0111	-> FSYNC_DDS1_
	else if (DDSx == DDS2_ONLY)
		P6_mask = 0xBF;		// 1011 1111	-> FSYNC_DDS2_
	else
		return;

	// --> SCLK_DDS (P6^5) must be high before falling FSYNC ( set in PORT_Init() the first time )
	P6 &= P6_mask;				// set FSYNCx low

	do
	{
		SDATA_DDS = (value & mask);
		_nop_();
		SCLK_DDS = 0;			// shift register data advanced one bit
		_nop_();
		SCLK_DDS = 1;
		_nop_();
		mask >>= 1;
	}
	while (mask > 0);

	P6 |= 0x48; 				// 0100 1000  set FSYNCx high    
                                // --> on return SCLK_DDS is high	
}



//-----------------------------------------------------------------------------
// DDS_Reset
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//	
// Reset DDS1 & DDS2
//
// RESET_DDS_	= P6^7
//
// It is assumed that SFRPAGE = CONFIG_PAGE.
//
void DDS_Reset(void)
{
	RESET_DDS_ = 0;
	wait_us(10);
	RESET_DDS_ = 1;
}



//-----------------------------------------------------------------------------
// DDS1_OFF
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//	
// Stop DDS1 generator. 
//
// As the RESET pin is common to both DDS, it must be done by a software command
//
void DDS1_OFF(void)
{
	control_register = BitClr(control_register, PIN_SW);	// select soft command
	control_register = BitSet(control_register, RESET);		// set RESET bit
	DDS_Send(control_register, DDS1_ONLY);					// send to DDS1
}



//-----------------------------------------------------------------------------
// DDS1_ON
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//	
// Start DDS1 generator
//
// Soft command already selected, so return to pin command.
// The RESET pin is common to both DDS; its action allows the two DDS to be restarted in synchrony.
// 
//
void DDS1_ON(void)
{
	control_register = BitSet(control_register, PIN_SW);	// select pin command
	DDS_Send(control_register, DDS1_ONLY);
	DDS_Reset();
}


//-----------------------------------------------------------------------------
// DDS_Load_PhaseReg
//-----------------------------------------------------------------------------
//
// Return Value :   None
// Parameters   :   value to write in phase register 0
//					DDSx = DDS1_AND_DDS2 (0) for DDS1 and DDS2, DDS1_ONLY (1) for only DDS1, DDS2_ONLY (2) for only DDS2
//
void DDS_Load_PhaseReg(uint PHI_REG0_value, char DDSx)
{
	uint LSWord; 

	LSWord = (uint) (PHI_REG0_value & 0x0FFF); 	// only 12 bits of phase word

    // always DB15 and DB14 = 1
    LSWord |= 0XC000;					        // 1100 0000 0000 0000 -> DB13 = 0 -> PHI_REG0

	DDS_Send(LSWord, DDSx);
}


//-----------------------------------------------------------------------------
// DDS_Load_FreqReg
//-----------------------------------------------------------------------------
//
// Return Value : None
// Parameters   : value to write in freq register 0
//
// loads registers for freq in DDS1 and 2xfreq in DDS2.
//
// loads the frequency registers in a single step -> control register bit B28 (DB13) = 1,
// DDS1 and DDS2 together.
//
void DDS_Load_FreqReg(ulong FREQ_REG)
{
	uint LSWord1;
	uint LSWord2; 
	uint MSWord1;
	uint MSWord2;
	ulong Freq_reg_DDS1;
	ulong Freq_reg_DDS2;
	
	Freq_reg_DDS1 = FREQ_REG;
    Freq_reg_DDS2 = FREQ_REG << 1;

	LSWord1 = (uint) (Freq_reg_DDS1 & 0x3FFF); 	    // only 14 bits of freq word
	LSWord2 = (uint) (Freq_reg_DDS2 & 0x3FFF);
	LSWord1 |= 0X4000;								// DB15,DB14 = 01 -> FREQ_REG0
	LSWord2 |= 0X4000;

	Freq_reg_DDS1 &= 0XFFFC000;
	Freq_reg_DDS2 &= 0XFFFC000;
	MSWord1 = Freq_reg_DDS1 >>  14;
	MSWord1 |= 0X4000;								// DB15,DB14 = 01 -> FREQ_REG0
	MSWord2 = Freq_reg_DDS2 >>  14;
	MSWord2 |= 0X4000;								// DB15,DB14 = 01 -> FREQ_REG0

	DDS_Send(LSWord1, DDS1_ONLY);
	DDS_Send(MSWord1, DDS1_ONLY);
	DDS_Send(LSWord2, DDS2_ONLY);
	DDS_Send(MSWord2, DDS2_ONLY);
}


//-----------------------------------------------------------------------------
// DDS_SetFrequency
//-----------------------------------------------------------------------------
//
// Return Value : none
// Parameters   : frequency value
//
void DDS_SetFrequency(float frequency)
{
	unsigned long FREQ_REG1;
	unsigned long mask = 0x0FFFFFFF;			// phase accumulator is 28 bits long (7 x 4 bits)


	FREQ_REG1 = (ulong)(frequency * NCO_COEFF);
	FREQ_REG1 &= mask;

	DDS_Load_FreqReg(FREQ_REG1);

	Set_PSD_RC();

	Buffer_Init();

	overflow_time = (ulong)((ceil)(2000000 / frequency)); 	// us -> wait 2 cycles
	if (overflow_time < 1)
		overflow_time = 1;

	DDS_Reset();
    DDS_Load_PhaseReg(PHI_DDS1_0, DDS1_ONLY);
    wait_ms(10);
}


