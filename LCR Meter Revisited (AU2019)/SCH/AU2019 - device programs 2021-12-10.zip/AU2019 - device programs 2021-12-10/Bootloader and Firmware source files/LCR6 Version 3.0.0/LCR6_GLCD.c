//-----------------------------------------------------------------------------
// LCR6_GLCD.c
//-----------------------------------------------------------------------------
// 
// Author: Jean-Jacques Aubry 2013-2020
//
// Target: C8051F120 
// Compiler: KEIL C51 V9.60.0.0  
//
// Version (see 'FirmwareVersion' in LCR6.h)
// 
// This is the software interface for the MCCOG240128A6W GLCD from "MIDAS Display"
// using a UC1608 LCD driver
//		Mode 6800 - 8 bits
//		Display is 240 x 128 pixels.
//
//


#include "LCR6_GLCD.h"

uchar code *font;
uchar xdata font_width; 
uchar xdata font_height;
uchar xdata font_offset;
uchar xdata font_charsize;

uchar xdata activeFont = FONT_IS_6x11;

extern char  xdata chaine[40];
extern const unsigned char code font_6x11[];


// In Column_Array[], char value is 0 or 1 (like a bit) 
uchar xdata Column_Array[(LCD_ROWS + 1) * 8]; 	// + 1 for 2nd byte of charater in last line

uchar xdata GLCD_Array[LCD_COLS][LCD_ROWS] ;	    // GLCD RAM mirror

bit display_GLCD = false;   // At start-up and during the first measurement loop, don't display data

extern void wait_100us(void);
extern void wait_ms(unsigned int x);



// *******************************************************************
// As the entire interface of the GLCD extension card is with the P1,
// P2 and P3 ports, there is no need to specify a particular SFRPAGE.
// *******************************************************************



/* Not used!
// --------------------------------------------------------------
// GLCD_ReadData()
//---------------------------------------------------------------
//
// Return Value : the data
// Parameters   : none
//
// read data in Display at current position
// 
uchar GLCD_ReadData(void)
{
	uchar value;

	P2MDOUT	= 0x00;			// P2 port as input LCD-DBx
	P2 = 0xFF;

	LCD_CS = 1;
	LCD_CD = 1;			// it's a data
	LCD_RW_ = 1;		// (WR0) it's a read
    _nop_();

	LCD_E = 	1;			// (WR1)  pulse
	_nop_();
    _nop_();
	LCD_E = 	0;
	_nop_();
    _nop_();
	value = P2;

	LCD_CS = 0;
	P2MDOUT	= 0xFF;			// P2 port as output LCD-DBx
	return value;
}
*/


// --------------------------------------------------------------
// GLCD_WriteData()
//---------------------------------------------------------------
//
// Return Value : None
// Parameters   : data to write
//
// write data to Display at current position
// 
// LCD_CS = 1 -> device already selected
//
void GLCD_WriteData(uchar value)
{
	P2 = value;
	LCD_CD = 1;			// it's a data
	LCD_RW_ = 0;		// (WR0) it's a write
    _nop_();

	LCD_E = 1;			// (WR1)  pulse
	_nop_();
    _nop_();
	LCD_E = 0;
	_nop_();
    _nop_();
}



// --------------------------------------------------------------
// GLCD_WriteCommand()
//---------------------------------------------------------------
//
// Return Value : None
// Parameters   : cmd & modifier
//
// send command cmd + modifier
//
// LCD_CS = 1 -> device already selected
//
void GLCD_WriteCommand(uchar cmd, uchar modifier)
{
	cmd |= modifier;

	P2 = cmd;
	LCD_CD = 0;			// it's a command
	LCD_RW_ = 0;		// (WR0) it's a write
    _nop_();

	LCD_E = 1;			// (WR1)  pulse
	_nop_();
    _nop_();
	LCD_E = 0;
	_nop_();
    _nop_();
}


// --------------------------------------------------------------
// GLCD_Init()
//---------------------------------------------------------------
//
// Return Value : None
// Parameters   : contrast value
//
//	!!! When calling this fcn after power up, must wait a bit, until the LCD can be written to.
//  A 10ms wait works.
//
void GLCD_Init(void)
{
    LCD_CS = 1;                                 // enable the GLCD and leave it on
	GLCD_WriteCommand(GLCD_RESET,0);
	wait_ms(30);						        // wait at least 10 ms for external reset chip to complete

	GLCD_WriteCommand(GLCD_MAPPING, GLCD_MIRROR_ROW);
	GLCD_WriteCommand(GLCD_BIAS_11_3, 0);
	GLCD_clear();
	GLCD_WriteCommand(GLCD_DISPLAY_ON, 0);	  	//display on

	GLCD_select_font(( void * ) font_6x11, 6, 11);
}


// --------------------------------------------------------------
// GLCD_clear_Row()
//---------------------------------------------------------------
//
// Return Value : None
// Parameters   : row to clear
//
// clear row writing 0 to all positions
// 
void GLCD_clear_Row(int x, uchar row)
{
    uchar i, lenght;


    switch (activeFont)
    {
        case FONT_IS_6x11:
            lenght = 40;
            break;
        case FONT_IS_8x16:
            lenght = 30;
            break;
        case FONT_IS_12x24:
            lenght = 20;
            break;
    };

   
    chaine[0] = 0;          // instead of strcpy(chaine, "");    -> 12 bytes in code space saved!

    for (i = 0; i < lenght; i++)
    {
        strcat (chaine, " ");
    }
        
    if (x < WITHOUT_ICON)
    {
       lenght = (strlen(chaine) * font_width + x) / font_width;
       chaine[lenght] = 0;
    }
    GLCD_draw_text(0, row, chaine, GLCD_PIXEL_ON);
}


// --------------------------------------------------------------
// GLCD_clear()
//---------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// clear display writing 0 to all positions
// 
void GLCD_clear(void)
{
   uchar row, col;

   for (row = 0; row < LCD_ROWS; row++)
   {
   	    GLCD_set_pos(row, 0);
   	    for (col = 0; col < LCD_COLS; col++)
		{
	 		GLCD_WriteData(0);			// automatic column address increment
			GLCD_Array[col][row] = 0;
		}
   }
}



// --------------------------------------------------------------
// GLCD_Update_Display()
//---------------------------------------------------------------
//
// Return Value : None
// Parameters   : None
//
// Update the Display with the content of GLCD_Array (the RAM mirror)
// 
void GLCD_Update_Display(void)
{
   uchar row, col, theData;

   for (row = 0; row < LCD_ROWS; row++)
   {
   	    GLCD_set_pos(row, 0);
   	    for (col = 0; col < LCD_COLS; col++)
		{
            theData = GLCD_Array[col][row];
	 		GLCD_WriteData(theData);			// automatic column address increment	
		}
   }
}



// --------------------------------------------------------------
// GLCD_set_pos()
//---------------------------------------------------------------
//
// Return Value : None
// Parameters   : row & column
//
// set current position
//
void GLCD_set_pos(uchar row, uchar col)
{
	GLCD_WriteCommand(GLCD_PAGE_ADDRESS, row);
	GLCD_WriteCommand(GLCD_COLUMN_ADDRESS_HI, (col >> 4) & 0x0F);
	GLCD_WriteCommand(GLCD_COLUMN_ADDRESS_LO, col & 0x0F);
}



// --------------------------------------------------------------
// GLCD_read_column(uchar col)
//---------------------------------------------------------------
//
// Return Value : None
// Parameters   : column of RAM mirror to read.
//
// the data is saved in "Column_Array"
//
void GLCD_read_column(uchar col)
{
   uchar  rows, pix, i, j;

	i = 0;
	// read column col, byte after byte
	for (rows = 0; rows < LCD_ROWS; rows++)
	{
		pix = GLCD_Array[col][rows];
		// write pix, bit after bit
		for (j = 0; j < 8; j++)
		{
			Column_Array[i] = pix & 0x01;	// low bit first
			pix >>= 1;
			i++;
		}
	}
}



// --------------------------------------------------------------
// GLCD_write_column(uchar col)
//---------------------------------------------------------------
//
// Return Value : None
// Parameters   : column of GLCD RAM to update.
//
// the data is read from "Column_Array"
//
void GLCD_write_column(uchar col)
{
   uchar  rows, pix, i, j;

	i = 0;
	// write column col, byte after byte
	for (rows = 0; rows < LCD_ROWS; rows++)
	{
		pix = 0;
		// read pix, bit after bit
		for (j = 0; j < 8; j++)
		{
			pix += Column_Array[i] << j;
			i++;
		}

		if (GLCD_Array[col][rows] != pix)	// only if GLCD RAM byte modified
		{
            if (display_GLCD)
            {
			    GLCD_set_pos(rows, col);
			    GLCD_WriteData(pix);		// draw in GLCD RAM
            }
			GLCD_Array[col][rows] = pix; 	// update RAM mirror
		}
	}
}


// --------------------------------------------------------------
// GLCD_show_icon()
//---------------------------------------------------------------
//
// Return Value : None
// Parameters   : pointer to bitmap, width, height, x, y, mode
//
// write in GLCD RAM data from source
//
void GLCD_show_icon(uchar code *bitmap, uchar width, uchar height, uchar x, uchar y, uchar mode)
{
    uchar  X, Y, pix, b_height, i, j, k;

	b_height = (height - 1)/8 + 1; // character height in bytes

	for (X = 0; X < width; X++) // loop for width columns
	{
		GLCD_read_column(X + x);

		i = y;
		k = 0;

		for (Y = 0; Y < b_height; Y++) // read h_byte bytes of character font
   	    {
			pix = *(bitmap + Y * width + X); //  read one byte

      	    if (mode == GLCD_PIXEL_OFF)
      		    pix = ~pix;

			for (j = 0; j < 8; j++)	// write 8 bits of pix to Column_Array
			{
				if (mode != GLCD_PIXEL_INV)
					Column_Array[i] = pix & 0x01;
				else
					Column_Array[i] ^= pix & 0x01;
				pix >>= 1;
				if (k == height)
					break;
				i++;					
				k++;
			}
    	}
		GLCD_write_column(X + x);
  	}
}



// --------------------------------------------------------------
// GLCD_draw_text()
//---------------------------------------------------------------
//
// Return Value : x_pos of the last character
// Parameters   : x, y, pointer to text, mode
//
// write in GLCD RAM data from source
// If x >= 0, write the text from x.
// If x < 0 write the text centered on the screen
//      -> if x = WITHOUT_ICON (-1), on full screen (LCD_COLS pixels)
//      -> if x < WITHOUT_ICON, with icon (width |x| pixels) on the right
//
uchar GLCD_draw_text( int x, uchar y, uchar *text , uchar mode )
{
	int i, posx, posy, longueur, largeur;
	uchar *pt;
    int X = x;

    if (X < 0)
    {
        longueur = strlen(text);
        if (X == WITHOUT_ICON)  // -1
            largeur = LCD_COLS;
        else
            largeur = LCD_COLS + x;
        X = (largeur - (longueur * font_width)) / 2;
        if (X < 0)
            X = 0;
    }

	posy = y - font_height + 1;
	for( pt = text, i = 0; *pt; i++, pt++ )	// exit the loop when *pt == 0 (the C string terminator)
	{
		posx = X + i * font_width;
		if( posx + font_width > LCD_COLS ) 
		{
			i = 0;
			posx = X;
			posy += font_height;
		}
	
		GLCD_show_icon( font + (*pt - font_offset) * font_charsize, font_width, font_height, posx, posy, mode );		 
	}

    return posx;
}



// --------------------------------------------------------------
// GLCD_select_font()
//---------------------------------------------------------------
//
// Return Value : None
// Parameters   : pointer to font, w, h, 
//
// set font parameters according width & height (only for 6x11, 8x16 and 12x24 fonts) 
//
void GLCD_select_font( uchar code *f, uchar width, uchar height)
{
    font = f;
    font_width = width;
    font_height = height;
    font_charsize = (height + 7) / 8 * width;
    font_offset = FONT_OFFSET; 
    if (width == 6 && height == 11)
        activeFont = FONT_IS_6x11;
    else if (width == 8 && height == 16)
        activeFont = FONT_IS_8x16;
    else if (width == 12 && height == 24)
        activeFont = FONT_IS_12x24;
}


// --------------------------------------------------------------
// GLCD_draw_point()
//---------------------------------------------------------------
//
// Return Value : status
// Parameters   : x, y, mode
//
// 	mode: GLCD_PIXEL_OFF/GLCD_PIXEL_ON/GLCD_PIXEL_INV
//
// write in GLCD RAM data from source
//
uchar GLCD_draw_point(uchar x, uchar y, uchar mode)
{
  	uchar  a_byte, value, byte_y;

  	if ( (y >=  LCD_ROWS * 8) || (x >= LCD_COLS) )
    	return 1;

    byte_y = (y / 8);

  	a_byte = y - (byte_y * 8);

	GLCD_set_pos(byte_y, x);			// set DRAM pos

	value = GLCD_Array[x][byte_y];

	if (mode == GLCD_PIXEL_INV)		    // inverted
    	mode = (((~value) >> a_byte) & 1);

  	if (mode == GLCD_PIXEL_ON)
    	value |= (1 << a_byte);
  	else
    	value &= ~(1 << a_byte);

  	GLCD_WriteData(value);				// draw in GLCD RAM
	GLCD_Array[x][byte_y] = value;	    // update RAM mirror

  	return 0;
}


// --------------------------------------------------------------
// GLCD_draw_VLine()
//---------------------------------------------------------------
//
// Return Value : None
// Parameters   : 
// 	x    col
// 	y1   start row
// 	y2   end row
// 	mode GLCD_PIXEL_OFF/GLCD_PIXEL_ON/GLCD_PIXEL_INV
//
// draw a vertical line
// 
void GLCD_draw_VLine( uchar x, uchar y1, uchar y2, uchar mode )
{
  int	delta_y, posy, i;
  int 	sens_dy = 0, delta_y_abs = 0;

  delta_y = y2 - y1 + 1;

  if(delta_y > 0)
  {
    delta_y_abs = delta_y;
    sens_dy = 1;
  }
  else if (delta_y < 0)
  {
    delta_y_abs = -delta_y;
    sens_dy = -1;
  }
 
  for (i = 0; i != delta_y; i += sens_dy)
  {
    posy = i + y1;
    GLCD_draw_point(x, posy, mode);
  }
}


// --------------------------------------------------------------
// GLCD_draw_rect()
//---------------------------------------------------------------
//
// Return Value : None
// Parameters   : left, top, right, bottom
//
// drawl rectangle
//
void GLCD_draw_rect( uchar left, uchar top, uchar right, uchar bottom, uchar mode)  
{  
  GLCD_draw_HLine( left, right, top, mode );    // at top, from left to right 
  GLCD_draw_VLine( left, top,  bottom, mode );  // at left, from top to bottom 
  GLCD_draw_VLine( right, top, bottom, mode );  // at right, from top to bottom
  GLCD_draw_HLine( left, right, bottom, mode ); // at bottom, from left to right  
}  


// --------------------------------------------------------------
// GLCD_draw_HLine()
//---------------------------------------------------------------
//
// Return Value : None
// Parameters   : 
// 	x1   start col
// 	x2   end col
// 	y    row
// 	mode GLCD_PIXEL_OFF/GLCD_PIXEL_ON/GLCD_PIXEL_INV
//
// draw a horizontal line
// 
void GLCD_draw_HLine( uchar x1, uchar x2, uchar y, uchar mode )
{
  int	delta_x, posx, i;
  int 	sens_dx = 0, delta_x_abs = 0;

  delta_x = x2 - x1 + 1;

  if(delta_x > 0)
  {
    delta_x_abs = delta_x;
    sens_dx = 1;
  }
  else if (delta_x < 0)
  {
    delta_x_abs = -delta_x;
    sens_dx = -1;
  }

  for (i = 0; i != delta_x; i += sens_dx)
  {
    posx = i + x1;
    GLCD_draw_point(posx, y, mode);
  }
}

/*
// --------------------------------------------------------------
// GLCD_fill_rect()
//---------------------------------------------------------------
//
// Return Value : None
// Parameters   : left, top, right, bottom, fillstate
//
// fill rectangle
//
// left & top changed to uchar in V301
//
void GLCD_fill_rect(uchar left, uchar top, uchar right, uchar bottom, uchar fillstate)
{
  uchar	x, y;

  for (x = left; x < right; x++)
  {
	 for (y = top; y < bottom; y++)
      GLCD_draw_point( x, y, fillstate);
  }
}

*/


