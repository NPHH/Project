//-----------------------------------------------------------------------------
// LCR6.h
//-----------------------------------------------------------------------------
//
// Author: Jean-Jacques Aubry 2013-2021
//
// Target: C8051F120 
// Compiler: KEIL C51 V9.60.0.0  
//
// Version (see 'FirmwareVersion')
//


#ifndef _LCR6_H
#define _LCR6_H


#include "LCR6_Defines.h"

char    code FirmwareVersion[] 	= "3.0.0";  // 3.0.0 -> rangeHold set to false in the Menu_Set_CalibrationFactor (to avoid range conflicts).
                                            //          Function Set_Z_Sense_Value() removed.
                                            //          Changes made for versions 2.3.3 and 2.3.4, reworked.
                        
                                            // 2.3.6 -> Suppression of transient display of a wrong value when changing frequency by the rotary encoder.

                                            // 2.3.5 -> correction bug in Menu_PGA2_Calibration() for the <PC Mode>.   

                                            // 2.3.4 -> Fixed the same bug for the <PC Mode>.  

                                            // 2.3.3 -> Fixed a bug in SelectFrequency() function, where the user frequency was not applied.  

                                            // 2.3.2 -> Optimisation of encoder-related interruptions 

                                            // 2.3.1 -> Some optimizations of the code following Titune's remarks!   

                                            // 2.3.0 -> "Inverse/Normal Display" Menu added. 

                                            // 2.2.0 -> Improved Range 4 calibration. 

                                            // 2.1.0 -> The correction (ADS_VREF / 0x800000)of the true value measured by the ADC
                                            //              is only done for Vpp and Ipp, not in the Set_Measure() function.
                                            //          Bug corrected in UART0_Init() and UART1_Init().  
                                            //          Improved DisplayProgressionBar() function. 
                                            //          In range 4, takes into account a small parasitic capacity in parallel with Rsense. 
    
                                            // 2.0.5 -> possibility in stand-alone mode to save the current frequency by pressing the rotary knob.
                                            //          This will be the frequency of the next start.      
    
                                            // 2.0.4 -> Short-Trim and Open-Trim menu inversion correction.
                                            //          In <ExternalDisplay/case USER_FREQ> DDS_SetFrequency() replaced with Set_Frequency()
                                            //          to get the right <Freq_Index> when calling Do_CF()
         
                                            // 2.0.3 -> modification of Do_CF() with bit parameter.     
    
                                            // 2.0.2 -> according 'display_Range' display <Range, Voltage PGA2 gain, Current PGA2 gain>
                                            //          A longKeypressed on KEY_4 switch this display ON/OFF
                                            //          At startup display is OFF
                                            //          Send message with "Rx Uy Iz" if 'display_Range' is true for use by AU2019 PC program.
    
                                            // 2.0.1 -> always display Z, PHI and Q 
                                            //          Q_Limit of 'no limit' instead of 50000 -> secondary value always displayed   
    
                                            // 2.0.0 -> first major release before publication.  
                                            //          Average SLOW or FAST added (switch with KEY_3
                                            //          New values for Q_Limit (100 to 50000)
        
                                            // 1.5.6 -> bug corrected in INT_A_ISR and INT_B_ISR (bad value for disabling interrupt)  
        
                                            // 1.5.5 -> Rotary encoder way reversed if DEBUG_3 is defined

                                            // 1.5.4 -> whis external GUI (PC or BLE link) the message send for DC bias 
                                            //          is the value with 3 digits after the comma instead of 1.

                                            // 1.5.3 -> refresh display (GUI) from time to time         

                                            // 1.5.2 -> New values for Q_Limit (100 to 5000)
                                            //          Corrected bug in Z_test_for_Trim()
                                            //          New TextI_0[] = "LCR-Meter AU2019"
                                                   
                                            // 1.5.1 -> test version with possibility to switch PGA ON or OFF

                                            // 1.5.0 -> Better use of calculations with long-integer before conversion to float.
                                            //          New trim management and improved Calibration for Gain3 & Gain10          
                                            //          The order of the different choices of the "Calibrations" menu modified.

                                            // 1.4.1 -> new management for text messages (only a string, not an array).
                                            //          Better management of the rotary encoder.       
                                                    
                                            // 1.4.0 -> New message in response to "END_TEXT_FILE" if error in the Text file.          
          
                                            // 1.3.0 -> Possibility to load strings in BANK 2 with the use of
                                            //          an external program (AU2019) and a .txt file (Textes LCR6.txt).        

                                            // 1.2.2 -> Language selection modified for use of strings in BANK 2.          
                                                    
                                            // 1.2.1 -> Modified 6x11 font with code up to 0xFF
                                            //          to have some accented characters.          

                                            // 1.2.0 -> Communication with external GUI on PC via UART0.
                                            //          Code start at 0x2000 for use with Bootloader at 0x0000.
          
                                            // 1.0.5 -> Code data (strings) from 0x10000L (BANK 2).         
                                            //          ADC start synchro added.
                                            //          Inproved over voltage circuit.
                                            //          User defined frequency.
                                            //          ENCOD_A & ENCOD_B moved to P0.2 & P0.3
                                            //          --> Possibility to have RX1 & TX1 or INT0 & INT1.


// fonts & icons in glcd-bitmaps
extern  const uchar code blank[];
extern  const uchar code self[];
extern  const uchar code capa[];
extern  const uchar code resistor[];
extern  const uchar code rlc[];
extern  const uchar code font_6x11[];
extern  const uchar code font_8x16[];
extern  const uchar code font_12x24[];
extern  const uchar code Left_icon[];
extern  const uchar code Right_icon[];
extern  const uchar code NO_icon[];
extern  const uchar code OK_icon[];
extern  const uchar code BLANK_icon[];
extern  const uchar code EXit_icon[];
extern  const uchar code FAIL_Icon_48x24[];
extern  const uchar code PASS_Icon_48x24[];
extern  const uchar code Auto_Icon_48x24[];
extern  const uchar code Series_Icon_48x24[];
extern  const uchar code Parall_Icon_48x24[];
extern  const uchar code Blank_Icon_48x24[];
extern  const uchar code Trim_Icon_48x24[];
extern  const uchar code Bias0_Icon_48x24[];
extern  const uchar code Menu_Icon_48x24[];
extern  const uchar code R_Hold_Icon_48x24[];
extern  const uchar code SLOW_Icon_48x24[];
extern  const uchar code FAST_Icon_48x24[];


// Data used by GLCD 
extern  uchar code *font;
extern  uchar xdata font_width; 
extern  uchar xdata font_height;
extern  uchar xdata font_offset;
extern  uchar xdata font_charsize;
extern  uchar xdata activeFont;
extern  bit display_GLCD;


// ---------------------------------------------------------------------
// 			non-volatile data
// ---------------------------------------------------------------------

// Characters changed in Font 8x16
uchar code CHAR_POINTER[] 	= "\x2C";       // '^' instead of ','
uchar code CHAR_OMEGA[] 	= "\x3F";
uchar code CHAR_MU[] 	    = "\x40";
uchar code CHAR_PICO[] 	    = "\x41";
uchar code CHAR_NANO[] 	    = "\x42";
uchar code CHAR_MILLI[] 	= "\x43";
uchar code CHAR_KILO[] 	    = "\x44";
uchar code CHAR_MEGA[] 	    = "\x45";
uchar code CHAR_GIGA[] 	    = "\x46";
uchar code CHAR_F[] 	    = "\x47";
uchar code CHAR_H[] 	    = "\x48";
uchar code CHAR_z[] 	    = "\x49";
uchar code CHAR_V[] 	    = "\x4A";

// Characters changed in Font 6x11
uchar code CHAR_PHI_6x11[] 	= "\x80";
uchar code CHAR_OMEGA_6x11[]= "\x81";


float code DDS1_Vref                          _at_ DDS_VREF_VALUE_ADD;

float code Tab_freq[FREQ_MEM_SIZE] =    
    {   50.0, 60.0,                                                                                                             //  0 to 1  (2 frequencies)
        100.0, 120.0, 150.0, 200.0, 250.0, 300.0, 400.0, 500.0, 600.0, 700.0, 800.0, 900.0,                                     //  2 to 13 (12 frequencies)
		1000.0, 1200.0, 1500.0, 2000.0, 2500.0, 3000.0, 4000.0, 5000.0, 6000.0, 7000.0, 8000.0, 9000.0,                         // 14 to 25 (12 frequencies)
		10000.0, 12000.0, 15000.0, 20000.0, 25000.0, 30000.0, 40000.0, 50000.0, 60000.0, 70000.0, 80000.0, 90000.0,             // 26 to 37 (12 frequencies)
		100000.0, 120000.0, 150000.0, 200000.0, 250000.0, 300000.0, 400000.0, 500000.0, 600000.0, 700000.0, 800000.0, 900000.0, // 38 to 49 (12 frequencies) 
        1000000.0, 1200000.0, 1500000.0, 2000000.0                                                                              // 50 to 53 (4 frequencies)
	};


uint code Tab_E96[97] =     {100,102,105,107,110,113,115,118,121,124,127,
                             130,133,137,140,143,147,150,154,158,162,165,
                             169,174,178,182,187,191,196,200,205,210,215,
                             221,226,232,237,243,249,255,261,267,274,280,
                             287,294,301,309,316,324,332,340,348,357,365,
                             374,383,392,402,412,422,432,442,453,464,475,
                             487,499,511,523,536,549,562,576,590,604,619,
                             634,649,665,681,698,715,732,750,768,787,806,
                             825,845,866,887,909,931,953,976,1000 };

uint code Tab_E24[25] =     {100,110,120,130,150,160,180,200,220,240,270,
                             300,330,360,390,430,470,510,560,620,680,750,
                             820,910,1000 };


char code Table_format[12][6] 	=   {	"%1.0f","%1.1f","%1.2f",
									    "%1.1f","%1.2f","%1.3f",		// one more digit
									    "%1.2f","%1.3f","%1.4f"};       // one more digit again

char code Table_format_QD[5][6] =   {	"%0.5f","%1.3f","%1.2f","%1.1f","%1.0f"};



// ---------------------------------------------------------------------
// *** WARNING don't modify these strings (value and order),
//         there are received from the GUI
// ---------------------------------------------------------------------
char code token[TOKEN_SIZE][10] =   { 	// Menu configuration
                                        "SIN_OFS\n",    // 0 - set sinus generator offset
                                        "VREF\n",		// 1 - Measured value of VREF (DDS)
                                        "CMRR\n",		// 2 - start CMRR of Voltage diff. opamp
                                        "G3_CAL\n",	    // 3 - PGA2: gain 3 calibration
                                        "G10_CAL\n",	// 4 - PGA2: gain 10 calibration.
                                        "CAL_R1\n",	    // 5 - Calibration of the range 1
                                        "CAL_R2\n",	    // 6 - Calibration of the range 2
                                        "CAL_R3\n",	    // 7 - Calibration of the range 3
                                        "CAL_R4\n",	    // 8 - Calibration of the range 4                                        
                                        "TRIM_S\n",	    // 9 - <Short-circuit> TRim, all freq.
                                        "TRIM_O\n",	    // 10 - <Open-circuit> TRim, all freq.
                                        
                                        // Menu
                                        "Q_LIMIT\n",    // 11 - Q limit for secondary display
                                        "SORT_P\n",     // 12 - Sorting parameters
                                        "SORT\n",       // 13 - Sort
                                        "AC_LEVEL\n",   // 14 - AC level
                                        "DC_BIAS\n",    // 15 - DC bias

                                         // Various
                                        "RUN\n",        // 16 - start measurement
                                        "HALT\n",		// 17 - stop measurement
                                        "MODE_D\n",     // 18 - change the display mode: SERIES or PARALLEL or AUTO
                                        "TRIMS\n",      // 19 - TRim short pressed, current frequency
                                        "TRIML\n",      // 20 - TRim long pressed, save trim for all frequencies
                                        "R_HOLD\n",     // 21 - change rangeHold
                                        "USER_F\n",     // 22 - user frequency switch
                                        "F_VERS\n",     // 23 - Firmware Version
                                        "K5\n",         // 24 - key 5  
                                        "K4\n",         // 25 - key 4
                                        "MOVUP\n",      // 26 - move up
                                        "MOVDW\n",      // 27 - move down
                                        "DDSV\n",       // 28 - New DDS Vref
										"FWUPDA\n",	    // 29 - start Firmware Update
										"START\n",		// 30 - bootloader Start 
                                        "BAUDS\n",	    // 31 - test com with BLE module
                                        "TXTUPDA\n",    // 32 - start Texts Update
                                        "W\n",          // 33 - string to update at TEXT_ARRAY_ADD
                                        "X\n",          // 34 - string to update at CONFIG_ARRAY_ADD
                                        "Y\n",          // 35 - string to update at MENU_ARRAY_ADD
                                        "Z\n",          // 36 - string to update at LANG_ARRAY_ADD
                                        "NB_LANG\n",    // 37 - number of languages in memory
                                        "E_TXT\n",      // 38 - End of Texts file
                                        "AVGS\n",       // 39 - change AVERAGE to SLOW
                                        "AVGF\n",       // 40 - change AVERAGE to FAST
                                        "AFFG\n",       // 41 - change display_Range
                                    };


// ---------------------------------------------------------------------
// *** WARNING *** don't modify these strings, there are send to the GUI
// ---------------------------------------------------------------------
char code message_PRIMARY[] 	                = "PRIMAR ";
char code message_SECONDARY[] 	                = "SECOND ";
char code message_Z[] 	                        = "Z ";
char code message_Q[] 	                        = "QQ ";
char code message_D[] 	                        = "DD ";
char code message_PHI[]                         = "PHI ";
char code message_VX[]                          = "Vx ";
char code message_IX[]                          = "Ix ";
char code message_FREQ[]                        = "FREQ ";
char code message_DC[]                          = "DC ";
char code message_AC[]                          = "AC ";
char code message_R_HOLD[]                      = "R-Hold ";
char code message_NO_DISPLAY_SECONDARY[]        = "NDIS_S ";


char code message_FIRMVERSION[]                 = "FVER ";
char code message_BOOTVERSION[]                 = "BVER ";
char code message_TEXT[]                        = "J ";
char code message_SAVED_PARAMETERS[]            = "PAR ";
char code message_MEASURE[]                     = "MEAS ";
char code message_INDEX[]                       = "IND ";
char code message_END[]                         = "END ";
char code message_MAX[]                         = "MAX ";
char code message_MIN[]                         = "MIN ";
char code message_GO_APP[]					    = "GO_APP ";
char code message_BLE_ONJ14[]    	            = "BLE ";
char code message_READY_RECEIVE_TXT[]           = "RDY_TXT ";
char code message_ERROR_TXT[]                   = "ERROR_TXT ";
char code message_NULL_DC_BIAS[]                = "DC 0.0 V";
char code message_AVGS[]                        = "AVG_S ";
char code message_AVGF[]                        = "AVG_F ";
char code message_RUI[]                         = "RUI ";




// ---------------------------------------------------------------------
// 			data variables
// ---------------------------------------------------------------------

char    xdata textLine[LONG_TEXT];

bit     in_calibration = false;
bit     inSorting = false;
bit	    isCapacitive = false;
bit	    overVoltage = false;				// set to true by Comparator0 ISR
bit	    Menu_Mode = false;
char    Measure_Mode = CURRENT_MODE;
bit     rangeHold = false;
bit     Saved_rangeHold = false;
bit     highAccuracy = false;
bit     longKeypressed = false;
bit     trimShortModified = false;
bit     trimOpenModified = false;
bit     DisplayInverse = false;
bit     userDefinedFrequency = false;
bit     DC_Bias_is_voltage = true;
bit     BT_onJ14 = false;
bit     GLCD_onJ14 = true;                  // default
bit     use_USB = false;
bit     standalone = true;
bit     use_Bluetooth = false;
bit     Calibration_Factor_R1_ok = false;
bit     Calibration_Factor_R2_ok = false;
bit     Calibration_Factor_R3_ok = false;
bit     Calibration_Factor_R4_ok = false;
bit     PGA_G3_ok = false;
bit     PGA_G10_ok = false;
bit     no_display_secondary = false;
bit     permitCP1_ISR;
bit     ok_Texts = false;
bit     fast_mode = false;
bit     display_Range = false;

uchar   DisplayNormal;

// *** data for test
//bit     isVoltage = true;

#ifdef DEBUG_2
    bit     noPGA_Gain = false;
#endif

ulong   xdata UART1_baudrate = 115200L;
uchar   xdata numberLanguage;
uchar   xdata numberLineText;
uchar   xdata numberLineMenu;
uchar   xdata numberLineConfig;

float   xdata Bootloader_Ver;
uchar   xdata Menu_Kind;
char    xdata Buffer[BUFFER_SIZE + 3];        // 7+3
uchar   xdata Expo[5];

char    xdata primaryIntPart;
char    xdata PrimaryString[5];
char    xdata PrimaryExpo[5];
float   xdata primaryValue;
char    xdata primaryKind;

char xdata saved_chaine[14];


uchar   xdata old_primary = 0;
uchar   xdata old_secondary = 0;
uchar   xdata Auto_Model = 0;			// 0 for Auto mode, 1 for serial mode, 2 for parallel mode
uchar   xdata S_P_Mode = 0;   			// 0 for Auto mode, 1 for serial mode, 2 for parallel mode

uchar   xdata Auto_parameter;			// 0 for L or C, and Q > 1000 or D < 1/1000
										// 1 for Lx or Cx, and Rx (x is "s" or "p")
                                		// 2 for Rx, and Lx or Cx
										// 3 for R, and D > 1000

uchar	xdata count_key_pressed = 0;	// number of Timer4 overflow
char    xdata theKey = NO_KEY_PRESSED;
uchar   xdata errorMeasure = 0;
uchar   xdata First_Displayed_Menu = 1;
uchar   xdata Menu_Index = 1;

char    xdata textMenu[UART_IN_BUFFERSIZE];
char    xdata chaine[44];
uchar   xdata remainder_str[UART_IN_BUFFERSIZE];		// second part of received string (36 + 4 for 4 accented characters)

uchar   xdata gain = 1;
float   xdata DAC_coeff;				// DAC data = DAC_coeff * ratio Iout / Iout0
uint    xdata DAC0_Data;
uchar   xdata ADS_sps;

float   xdata Rsense;
float   xdata R_Standard;
uchar   xdata R_Range;					// 1 to NB_RANGE
					
float   xdata freq;
float   xdata last_freq;
uchar   xdata Freq_index;
uchar   xdata last_Freq_index;
uchar   xdata saved_index_freq;

float   xdata Vp;
float   xdata Vq;
float   xdata Ip;
float   xdata Iq;
float   xdata Rs;
float   xdata Rp;
float   xdata Xs;
float   xdata Rstdm,Xstdm; 
float   xdata Phi;
float   xdata Cp;
float   xdata Lp;
float   xdata Cs;
float   xdata Ls;
float   xdata Vpp;
float   xdata Ipp;
float   xdata Z;
float   xdata Q;
float   xdata Pulsation;
float   xdata SP_coeff;
float   Value_to_Print;	                // global used by Convert_Value_to_String()

float   xdata Gain_Up, Gain_Uq;
float   xdata Gain_Ip, Gain_Iq;
float   xdata PGA2_Gain_I;
float   xdata PGA2_Gain_U;
uchar   xdata PGA2_Range_I;
uchar   xdata PGA2_Range_U;

uchar   xdata numberSeries;
uchar   xdata numberLevel;

float   xdata phi_I;
float   xdata phi_U;

// rotary encodeur
int     xdata cpt_encod;
int     xdata old_cpt_encod;
char    xdata encodPOS = 0;
char    xdata encodOldPOS = 0;
uint    count0 = 5000;


ulong   xdata overflow_time;
uchar   xdata sourceLevel;
uint    xdata DC_mVolt = 0;
float   xdata biasCurrent_Offset;

uchar   xdata reductionLevel;
uchar   xdata PGA_RC_level;

uchar   xdata wait_steady_PSD = 20;             // 20 ms

// buffer for measurements
float   xdata buffer_Rs[BUFSIZE_DATA_MAX1];		// 0 to BUFSIZE_DATA_MAX1 - 1
float   xdata buffer_Xs[BUFSIZE_DATA_MAX1];
uchar   xdata in_Buffer;						// index for write
bit     buffer_full;
uchar   xdata Buf_counter = 0;

char    xdata current_language;
char    xdata saved_Series;
uint    xdata Q_No_Display_Secondary;

float   xdata Tab_Real[FREQ_MEM_SIZE];
float   xdata Tab_Imag[FREQ_MEM_SIZE];

uchar   xdata Tab_Trim_Open_OK[FREQ_MEM_SIZE];
float   xdata Tab_Xs_Trim_Open[FREQ_MEM_SIZE];
float   xdata Tab_Rs_Trim_Open[FREQ_MEM_SIZE];

uchar   xdata Tab_Trim_Short_OK[FREQ_MEM_SIZE];
float   xdata Tab_Xs_Trim_Short[FREQ_MEM_SIZE];
float   xdata Tab_Rs_Trim_Short[FREQ_MEM_SIZE];

uchar   xdata UART_InputBuffer[UART_IN_BUFFERSIZE];
uchar   xdata UART_OutputBuffer[UART_OUT_BUFFERSIZE];   // limited size for BLE
uchar   xdata UART_InputBuffer_Size;
uchar   xdata UART_OutputBuffer_Size;
uchar   xdata UART_Output_First;

uchar   TX_Ready;
uchar   RX_Ready;
static  char  Byte;

// The (LOAD calibration) data at the current frequency (predefined or defined by the user)
float   xdata CFX_R1;
float   xdata CFR_R1;

float   xdata CFX_R2;
float   xdata CFR_R2;

float   xdata CFX_R3;
float   xdata CFR_R3;

float   xdata CFX_R4;
float   xdata CFR_R4;


// The (PGA2 calibration) data at the current frequency (predefined or defined by the user)
float   xdata IMAG_G3;
float   xdata REAL_G3;

float   xdata IMAG_G10;
float   xdata REAL_G10;


// The (TRIM calibration) data at the current frequency (predefined or defined by the user)
bit    TrimShortOk;
float   xdata XsTrimShort;
float   xdata RsTrimShort;

bit    TrimOpenOk;
float   xdata XsTrimOpen;
float   xdata RsTrimOpen;



// ---------------------------------------------------------------------
// Function PROTOTYPES 
// ---------------------------------------------------------------------
extern  void    ADS_Init (void);
extern  uchar   ADS_Read_Register(uchar address);
extern  void    ADS_Write_Register(uchar address, uchar value);
extern  bit     ADS_Read_measure(long* result);
extern  float   ADS_Read_Temperature(void);
extern  void    ADS_SetPGA_Range(uchar range);
extern  void    Init_MCU_Peripherals (void);


// FLASH read/write/erase routines
void FLASH_ByteWrite (FLADDR addr, char byte, bit SFLE);
uchar FLASH_ByteRead (FLADDR addr, bit SFLE);
void FLASH_PageErase (FLADDR addr, bit SFLE);
void FLASH_Write (FLADDR dest, char *src, unsigned numbytes, bit SFLE);
char * FLASH_Read (char *dest, FLADDR src, unsigned numbytes, bit SFLE);
void FLASH_Clear (FLADDR addr, unsigned numbytes, bit SFLE);

// FLASH update/copy routines
void FLASH_Update (FLADDR dest, char *src, unsigned numbytes, bit SFLE);
void FLASH_Copy (FLADDR dest, bit destSFLE, FLADDR src, bit srcSFLE, unsigned numbytes);

// User FLASH functions
float   ReadFloatInFLASH(FLADDR source);
void    erase_flash(FLADDR debut, FLADDR fin);


void    Action_KEY_1(void);
void    Action_KEY_2(void);
void    Action_KEY_3(void);

#ifdef DEBUG_5
    void    Erase_Trim_Data(void);
#endif

void    OnBoardDisplay(void);
void    ExternalDisplay(void);

void    Stop_UART0(void);
void    Stop_UART1(void);

char    GetUserAction(void);

void    ReadTextinFlash(char index);
void    CopyStringInBANK2(char index);

char    Checks_Message(char index);
void    Send_Message(char * tex);
uchar   Affiche_Text(char XX, uchar YY, uchar index , uchar mode );

void 	Buffer_Init(void);
void 	Buffer_Add_Data(float rs, float xs);
void 	Buffer_Read(float* rs, float* xs);

bit     wait_overflow(void);
bit 	wait_ms(unsigned int x);
void    wait_us(unsigned int us);
void    Set_PSD_RC(void);
void    Set_SPS_WithFreq(void);

uint    Get_ADC0_Count(uchar channel);
float   Check_Minus_Voltage(uchar channel, uint R1, uint R2);
float   Checks_Plus_Voltage(uchar channel, uint R1, uint R2);
char    Checks_Power_Supplies(void);
float   Checks_Bias_Current(void);

uchar   SPI_Transfer(uchar SPI_byte);

void    DAC0_Update(unsigned int value);
void    DAC1_Update(unsigned int value);
void 	Set_DDS_Amplitude(float Reduction_level);
void 	Set_Preamp_Gain(unsigned char value);

void    Display_Bias_Control(uint step);
void    Set_DC_BIAS(uint DCmV);
void    Set_Source_Level(unsigned char level);
void    Display_Level(uchar x, uchar y);
void    Display_Range_Hold(void);

void 	Set_Resistor_Sense_Range(unsigned char theRange);
void    Set_Best_Sense_Resistor(void);
void 	Set_Best_PGA2_Gain(void);

void    Set_Phase(int degre);

char 	Set_Measure(float* InPhase_result, float* InQuadrature_result);

void 	Process_Measurement(uchar theRange);
void    Process_Gain_Corrections(void);
void    Get_Standard_Values(void);

void    Do_CF(bit with_Trim);
void    Process_Datas(void);

void    Z_test_for_Trim(void);
uchar   Set_Trim(bit kind);

void    Set_Encoder_action(void);
void    Set_COMP0_Interrup(void);
void 	Clear_COMP0_Interrup(void);
void 	Set_Measure_Mode(char mode);
void    Set_PGA2_Gain(unsigned char index, bit GainUpdate);

void    Display_Non_Initialized_Data_Message(void);
bit 	Check_Saved_Datas(void);    // ******************************************
void    Check_Calibration_Datas(void);

void    Restore_Display(void);
void    Write_Blank_Icons(char number);
void    Write_Measure_Icons(void);
void    Write_Exit_Icons(void);
void    Write_Ok_Icons(void);
void    Write_OK_Exit_Icons(void);
bit	    Get_Averaged_Values(bit mode);
bit     Gain_Calibration(uchar PGA_Gain);

uchar   Get_FreqIndex(float frequency);
float   FreqChange(void);
void 	Set_Frequency(uchar index);
void    SelectFrequency(bit userselected);
void    Write_Frequency(uchar x, uchar y, uchar GLCD_mode, bit extended);

void    Load_CF_fromTable(char freqindex);
void    Load_CF(void);

void    Load_Text_Menu(uchar MenuIndex); 
char    SearchValueInSeries(uint value, char series, char step);
float   DisplayValueInSeries(char index, char series, char reste);

void    Update_DDS_VRef(void);

void    Measure_value_for_Trim(void);
void    Display_Menus(void);
void    Run_Menu(char choise);
void    Menu_Choise(void);
void    Menus_Move(uchar move);
bit     Menu_Set_Trim(bit kind);
void 	Menu_PGA2_Calibration(uchar PGA_Gain);
void 	Menu_Set_Sinus_Offset(void);
void    Menu_Set_CalibrationFactor(uchar range);
void    Menu_Set_Voltage_Diff_Amp_CMRR(void);
void    Menu_Set_Language(void);
void    Menu_Set_Q_Limit(void);
void    Menu_Set_Sorting_Parameters(void);
void    Menu_Sort(void);
void    Menu_Set_Source_Level(void);
void    Menu_Set_DC_BIAS(void);
void    Menu_Set_DDS_Vref(void);

void    Copy_TrimValues_from_CodeData(void);
void    Copy_TrimValues_to_CodeData(void);
void    Copy_CalibrationFactor_to_CodeData(uchar range, bit onlyErase);

bit 	Process_Circuit_Xs(void);
bit 	Process_Circuit_Rs(void);

void    FormatsChaine();

bit 	Display_Primary_Value(uchar genre);
bit 	Display_Secondary_Value(uchar genre);
bit 	Display_Frequency(uchar x, uchar y);
bit     Display_Mode(void);
bit     Display_Z(void);
bit     Display_Q_D(bit inverse);
bit     Display_PHI(void);
bit     Display_Vx_Ix(void);
bit     Display_Circuit(uchar primary, uchar secondary, uchar mode);
void    Display_DC_Bias(uchar x, uchar y, bit blink);
void    Display_Error(void);

void    DisplayProgressionBar(uchar index);

void 	Justify_Right_Buffer(void);
char    Convert_Value_to_String(uchar accuracy, bit suffix, uchar Comp_Kind, bit adjust_format);
void    Load_Expo(char int_part, uchar genre, bit space);

bit     Div_Complex(float A_Real, float A_Imag, float B_Real, float B_Imag, float *C_Real, float *C_Imag);
bit     Mul_Complex(float A_Real, float A_Imag, float B_Real, float B_Imag, float *C_Real, float *C_Imag);

#endif