//-----------------------------------------------------------------------------
// LCR6_common.h
//-----------------------------------------------------------------------------
//
// Author: Jean-Jacques Aubry 2013-2020
//
// Target: C8051F120 
// Compiler: KEIL C51 V9.60.0.0  
//
// Version 1.2	    	New address	for	TEXT_ARRAY_ADD, CONFIG_ARRAY_ADD, etc... for possibility of 8 languages
// Version 1.3          SAVED_I_FREQ_ADD (Index of saved freq) added	    	
//					
//			

#ifndef _LCR6_COMMON_H
#define _LCR6_COMMON_H

//--------------------------------------------------------------
// Parameters & settings addresses common to LCR6 and boot_LCR6
//--------------------------------------------------------------

#define PROG_BEGIN_FLASH_ADD		0x01C00	    // starting addr for LCR6 program with bootloader in memory
#define PROG_END_FLASH_ADD			0x0FBFF	    // ending addr for program (allowing 1 page for program size etc...)

															
#define PROGRAM_SIZE_ADD			(PROG_END_FLASH_ADD + 1)			    // 0xFC00 uint
#define PROGRAM_CHECKSUM_ADD		(PROGRAM_SIZE_ADD + INT_SIZE)		    // 0xFC02 ulong
#define BOOTLOADER_VERSION_ADD	    (PROGRAM_CHECKSUM_ADD + LONG_SIZE) 	    // 0xFC06 float
#define Q_LIMIT_ADD				    (BOOTLOADER_VERSION_ADD + FLOAT_SIZE)	// 0xFC0A address of Q_No_Display_Secondary uint variable
#define SERIES_ADD			    	(Q_LIMIT_ADD + INT_SIZE)		        // 0xFC0C address of saved_Series char variable
#define LANGUAGE_ADD                (SERIES_ADD + CHAR_SIZE)                // 0xFC0D address of language_number char variable
#define SORTING_VAL_ADD             (LANGUAGE_ADD + CHAR_SIZE)              // 0xFC0E address of sortingValue float variable   
#define SORTING_KIND_ADD            (SORTING_VAL_ADD + FLOAT_SIZE)          // 0xFC12 address of sortingKind char variable
#define USER_FREQUENCY_ADD          (SORTING_KIND_ADD + CHAR_SIZE)          // 0xFC13 address of user frequency float variable
#define DDS_VREF_VALUE_ADD          (USER_FREQUENCY_ADD + FLOAT_SIZE)       // 0xFC17 address of DDS Vref value float variable
#define DISPLAY_MODE_ADD            (DDS_VREF_VALUE_ADD + FLOAT_SIZE)       // 0xFC1B address of standalone char variable
#define UART1_BAUDRATE_ADD          (DISPLAY_MODE_ADD + CHAR_SIZE)          // 0xFC1C address of UART1 baudrate ulong value
#define SAVED_I_FREQ_ADD            (UART1_BAUDRATE_ADD + LONG_SIZE)        // 0xFC20 address of saved index_frequency uchar value                                                                            
#define DISPLAY_KIND_ADD            (SAVED_I_FREQ_ADD + CHAR_SIZE)          // 0xFC20 address of inverse/normal display uchar value

#define LONG_TEXT_LANG      13      // 12 characters + null terminator - for Lang_array
#define LONG_TEXT           36      // 35 characters + null terminator - for Text_array, Config_array and Menu_array
                                    // -> 35 characters 6x11 = 210 pixels wide + 28 pixels for icon = 238 pixels (max is 240)

// With this EEPROM mapping, there is room for 8 languages! Each page is 1024 (0x400) bytes wide
#define MAX_LANGUAGE        8       // english, french, etc...
#define MAX_TEXT_LINES      56
#define MAX_CONFIG_LINES    14
#define MAX_MENU_LINES      10     

// for compatibility whis old version only
#define TEXT_LINES          42      // number of line in Text_Array. Max of 56 lines with 8 languages (0x3F00 on 0x4000)
#define CONFIG_LINES        11      // number of line in Config_Array. Max of 14 lines with 8 languages (0x0FC0 on 0x1000) 
#define MENU_LINES          6       // number of line in Menu_Array. Max of 10 lines with 8 languages (0x0BC8 on 0x0C00)

#define EEPROM_USER_DATA_ADD		0x10000L                                // (b2:8000)
#define TEXT_ARRAY_ADD              (EEPROM_USER_DATA_ADD)                  // 0x10000L (b2:8000)
#define CONFIG_ARRAY_ADD            (TEXT_ARRAY_ADD + 0x04000L)             // 0x14000L (b2:C000) 
#define MENU_ARRAY_ADD              (CONFIG_ARRAY_ADD + 0x01000L)           // 0x15000L (b2:D000)
#define LANG_ARRAY_ADD              (MENU_ARRAY_ADD + 0x00C00L)             // 0x15C00L (b2:DC00)

#define NUMBER_LANGUAGE_ADD         (LANG_ARRAY_ADD + 0x00400L)             // 0x16000L (b2:E000) address of number_language - char value
#define NUMBER_TEXT_LINES_ADD       (NUMBER_LANGUAGE_ADD + CHAR_SIZE)       // 0x16001L (b2:E001) address of number_text_lines - char value
#define NUMBER_CONFIG_LINES_ADD     (NUMBER_TEXT_LINES_ADD + CHAR_SIZE)     // 0x16002L (b2:E002) address of number_config_lines - char value
#define NUMBER_MENU_LINES_ADD       (NUMBER_CONFIG_LINES_ADD + CHAR_SIZE)   // 0x16003L (b2:E003) address of number_menu_lines - char value                                                                                                                                                                                                                                    
#define END_STRING_ADD              (NUMBER_MENU_LINES_ADD + CHAR_SIZE)     // 0x16004L (b2:E004)   



// configuration data   
#define PAGE1_FLASH_ADDR			0x18000L		                        // user data in page_a of BANK3
#define PAGE2_FLASH_ADDR			(PAGE1_FLASH_ADDR + 0x400L)	            // 0x18400 calibration data in page_b
#define PAGE3_FLASH_ADDR			(PAGE2_FLASH_ADDR + 0x400L)	            // 0x18800 calibration data in page_c
#define PAGE4_FLASH_ADDR			(PAGE3_FLASH_ADDR + 0x400L)	            // 0x18C00 calibration data in page_d
#define PAGE5_FLASH_ADDR			(PAGE4_FLASH_ADDR + 0x400L)	            // 0x19000 calibration data in page_e
#define PAGE6_FLASH_ADDR			(PAGE5_FLASH_ADDR + 0x400L)	            // 0x19400 calibration data in page_f
#define PAGE7_FLASH_ADDR			(PAGE6_FLASH_ADDR + 0x400L)	            // 0x19800 calibration data in page_g
#define PAGE8_FLASH_ADDR			(PAGE7_FLASH_ADDR + 0x400L)	            // 0x19C00 calibration data in page_h



//-----------------------------------------------------------------------------
// LCR6 Ports
//-----------------------------------------------------------------------------

// ------- Port_0 lines
// SFRPAGE = All Pages
//									  P0^0;			TX0 			(output)		
//									  P0^1;			RX0 			(input)
sbit ENCOD_A						= P0^2;		//  INT0/   (input) or TX1 (output)
sbit ENCOD_B						= P0^3;		//  INT1/   (input) or RX1 (input)
//				                      P0^4;
//									  P0^5;
sbit BLE_STATUS						= P0^6;     //  (ouput) set to 1 by the bootloader if BLE_onJ14
sbit GLCD_STATUS					= P0^7;     //  (ouput) set to 1 by the bootloader if GLCD_onJ14

// ------- Port_1 lines
// SFRPAGE = All Pages
sbit L1     					    = P1^0;		// input keyboard L1
sbit L2        				        = P1^1;		// input keyboard L2
sbit L3							    = P1^2;		// input keyboard L3
sbit CONFIG2					    = P1^3;		// input at startup -> configuration pin (if a resistor to ground, P1^3 = 0)
sbit LCD_CD							= P1^4;		// LCD Control (if 0) / LCD Data (if 1) (output)
sbit LCD_CS							= P1^5;		// LCD Chip Select (output)
sbit LCD_WR0						= P1^6;		// R/W_ in 6800 mode, WR_ in 8080 mode (output)
sbit LCD_WR1						= P1^7;		// EN   in 6800 mode, RD_ in 8080 mode (output)


// ------- Port_2 lines (outputs) LCD data word
// SFRPAGE = All Pages
//sbit LCD_DB0						= P2^0;		// LCD data bit 0
//sbit LCD_DB1						= P2^1;		// LCD data bit 1
//sbit LCD_DB2						= P2^2;		// LCD data bit 2
//sbit LCD_DB3						= P2^3;		// LCD data bit 3
//sbit LCD_DB4						= P2^4;		// LCD data bit 4
//sbit LCD_DB5						= P2^5;		// LCD data bit 5
//sbit LCD_DB6						= P2^6;		// LCD data bit 6
//sbit LCD_DB7						= P2^7;		// LCD data bit 7


// ------- Port_3 lines
// SFRPAGE = All Pages
sbit SYNCH_OUT                      = P3^0;		// SYNCH_CDE synchronized (input)
sbit SYNCH_CDE				    	= P3^1;		// To be synchronized (output)
sbit CONFIG1                        = P3^2;	    // input at startup -> configuration pin (if a resistor to ground, P3^2 = 0)
sbit J16							= P3^3;		// unconditional firmware update (input at startup)
//          						  P3^4;    
//									  P3^5;
sbit ENCOD_SW						= P3^6;		// encoder push-button (input)
sbit BACKLIGHT						= P3^7;		// BKL (input at startup -> detection of GLCD extension card, then output )


// ------- Port_4 lines
// SFRPAGE = CONFIG_PAGE
sbit RSELECT_SW1    				= P4^0;     // SW1 active low command. (open-drain ouput)
sbit RSELECT_SW2					= P4^1;		// SW2 active low command. (open-drain ouput)
sbit RSELECT_SW3					= P4^2;		// SW3 active low command. (open-drain ouput)
sbit RSELECT_SW4					= P4^3;		// SW4 active low command. (open-drain ouput)
sbit UISELECT_U					    = P4^4;		// SW5 active low command. (open-drain ouput)
sbit UISELECT_I 					= P4^5;		// SW6 active low command. (open-drain ouput)
sbit INPUT_CP0           	        = P4^6;		// (open-drain ouput) -> connected to CP0 input  0 = inhibited 
sbit DC_BIAS_U_I					= P4^7;		// (output)

// ------- Port_5 lines
// SFRPAGE = CONFIG_PAGE
sbit PGA1_A    					    = P5^0;		// PGA1 gain select A (output)
sbit PGA1_B    					    = P5^1;		// PGA1 gain select B (output)
sbit PGA2_G_1   					= P5^2;		// PGA2 gain select 1 (output)
sbit PGA2_G_3   					= P5^3;		// PGA2 gain select 3 (output)
sbit PGA2_G_10    				    = P5^4;		// PGA2 gain select 10 (output)
sbit ADS_START    				    = P5^5;		// ADS START CDE (output)
sbit ADS_CS_BARRE					= P5^6;		// SPI0_NSS 	(output)
sbit ADS_DRDY_BARRE				    = P5^7;		// ADS DATA READY SIGNAL (input)

// ------- Port_6 lines
// SFRPAGE = CONFIG_PAGE
sbit ADS_DOUT						= P6^0;		// SPI0_MISO	(input)
sbit ADS_DIN						= P6^1;		// SPIO_MOSI	(output)
sbit ADS_SCLK						= P6^2;		// SPI0_SCK		(output)	
sbit FSYNC_DDS1_					= P6^3;		// DDS1 frame synchronization signal for the data (output)
sbit SDATA_DDS						= P6^4;		// Serial Data (output)
sbit SCLK_DDS     				    = P6^5;		// Serial Clock (ouput)
sbit FSYNC_DDS2_					= P6^6;		// DDS2 frame synchronization signal for the data (output)
sbit RESET_DDS_					    = P6^7;		// Reset DDS appropriate internal registers to zero, clear D flip-flop (ouput)

// ------- Port_7 lines
// SFRPAGE = CONFIG_PAGE
sbit PSD_RC_C     				    = P7^0;		// PSD RC select C (output)
sbit PSD_RC_B     				    = P7^1;		// PSD RC select B (output)
sbit PSD_RC_A					    = P7^2;		// PSD RC select A (output)
sbit J23				            = P7^3;		// used for test (output) -> with PCB rev 2, LED D12 attached (ON when J23 = 0)
sbit MAX_BOOST             		    = P7^4;		// for +7.5V instead of +6.5V(output)
sbit ENABLE_BOOST					= P7^5;		// boost ON-OFF (output)
sbit SYNCHRO_SCOPE          	    = P7^6;		// (J20) used for test (synchro scope) (output)
sbit PWRN							= P7^7;		// detection of USB link (input)


#define TEST_GLCD   BACKLIGHT
#define TEST_BT     CONFIG2


#define INT_CLK       				(24500000L)       	// MCU Internal oscillator frequency
#define MCU_CLK					    (INT_CLK)			// MCU internal clock
#define BAUDRATE_0     				(115200L)			// Default Baud rate of UART0 in bps
#define BAUDRATE_1     				(115200L)			// Default Baud rate of UART1 in bps

#define PLL_MUL      				(3)         		// Sets PLL multiplier N
#define PLL_DIV      				(1)         		// *** ALWAYS 1 ***

#if (PLL_DIV != 1)
	#undef	PLL_DIV
	#define PLL_DIV					(1)
#endif

#if (PLL_MUL > 1)
	#define	USE_PLL
#endif

#ifdef USE_PLL
	#define PLL_DIV_CLK  			(MCU_CLK/PLL_DIV)       // PLL divided clock input frequency
	#define PLL_OUT_CLK  			(PLL_DIV_CLK*PLL_MUL)	// PLL output frequency
	#define SYSCLK					(PLL_OUT_CLK)

	// Macros used to calculate Loop Filter Bits
	#if (PLL_DIV_CLK)<(5000000L)
   	    #error "error: PLL divided clock frequency Too Low!"
	#elif (PLL_DIV_CLK)<(8000000L)
   	    #define PLLFLT_LOOP 0x0F
	#elif (PLL_DIV_CLK)<(12500000L)
   	    #define PLLFLT_LOOP 0x07
	#elif (PLL_DIV_CLK)<(19500000L)
   	    #define PLLFLT_LOOP 0x03
	#elif (PLL_DIV_CLK)<(30000001L)
    	#define PLLFLT_LOOP 0x01
	#else
   	    #error "error: PLL divided clock frequency Too High!"
	#endif

	// Macros used to calculate ICO  Bits
	#if (PLL_OUT_CLK)<(25000000L)
   	    #error "error: PLL output frequency Too Low!"
	#elif (PLL_OUT_CLK)<(42500000L)
	   #define PLLFLT_ICO 0x30
	#elif (PLL_OUT_CLK)<(52500000L)
   	    #define PLLFLT_ICO 0x20
	#elif (PLL_OUT_CLK)<(72500000L)
   	    #define PLLFLT_ICO 0x10
	#elif (PLL_OUT_CLK)<(100000001L)
   	    #define PLLFLT_ICO 0x00
	#else
   	    #error "error: PLL output frequency Too High"
	#endif

	// Macros used to calculate  Flash Read Time  Bits
	#if (SYSCLK)<(25000001L)
   	    #define FLSCL_FLRT 0x00
	#elif (SYSCLK)<(50000001L)
	   #define FLSCL_FLRT 0x10
	#elif (SYSCLK)<(75000001L)
   	    #define FLSCL_FLRT 0x20
	#elif (SYSCLK)<(100000001L)
   	    #define FLSCL_FLRT 0x30
	#else
	   #error "error: SYSCLK Too High"
	#endif
#else
	#define SYSCLK			MCU_CLK
#endif	// USE_PLL

#if (PLL_MUL>2)
	#define TMR3_COEFF    	(SYSCLK/2000000)
#else
	#define TMR3_COEFF  	(SYSCLK/1000000)
#endif


#if (PLL_MUL>2)
	#define LONG_PRESSED    90
#elif (PLL_MULL>1)
    #define LONG_PRESSED    60
#else
	#define LONG_PRESSED    30
#endif


#endif  // _LCR6_COMMON_H